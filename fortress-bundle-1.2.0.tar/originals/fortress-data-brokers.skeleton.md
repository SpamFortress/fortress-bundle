# Fortress data: broker catalog

Public people-search / data-broker opt-out catalog with priorities, network members and per-row verification notes. Rows are "the publisher reached this page on <date>", not proof a free form works today. Unverified rows are manual-discovery hints. Owner statuses go only in private/optout-log.json.

Write each block to `$FORTRESS_HOME/<path>` during **fortress-tools** setup and verify its hash. Read-only reference data; never write owner results into it.

````asset path=data/broker-catalog.json sha256=a57a320f6156fdf973413aadbb7130a1ec863ae9ef5602717d380cbc5b09ac6c
````
