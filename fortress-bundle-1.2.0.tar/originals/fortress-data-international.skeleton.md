# Fortress data: international

Per-country registries, regulators, carrier tools, checkers and loss-recovery hotlines with verification dates.

Write each block to `$FORTRESS_HOME/<path>` during **fortress-tools** setup and verify its hash. Read-only reference data; never write owner results into it.

````asset path=data/international.json sha256=3d6734635a0be5f30c5e0c2890ac01397dfb96b8a5c8f5f2aee3b094fe2795d2
````
