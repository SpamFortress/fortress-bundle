# Fortress data: core tables

Brand domains, verified abuse contacts, fraud-watch source rules, privacy-page catalog, public settlement seed list, caregiver digest template, elder checklist, letter templates, forwarding how-to, US capability matrix, international geo packs.

Write each block to `$FORTRESS_HOME/<path>` during **fortress-tools** setup and verify its hash. Read-only reference data; never write owner results into it.

````asset path=data/brand-domains.json sha256=add58f3b4164bfb23efd28b688d4e70d6ce0a92570b7503d2d23f4dddd4185af
````

````asset path=data/brand-abuse-directory.json sha256=598b7c393d45a1dbdc9207a008804bcfd957d6f3d35faaa3b4ddd2600a25aad7
````

````asset path=data/fraud-watch-allowlist.json sha256=3a913cd03d85f627f9cffd81aaa2600967c41f72aa0dd15bded78caab41ea0ab
````

````asset path=data/privacy-catalog.json sha256=a2e0c4962b15650fb628373b612863bc841a6aebccadffe6a6d98ba5aa245595
````

````asset path=data/settlements-public.json sha256=07d8dc0ec892bf757d0294a9b7171e68077b3dd1e40512cf12c8b4166e89f50d
````

````asset path=data/caregiver-summary.template.md sha256=e81935721cb829b5fa7634772d5a52d25b02b73305eb6adf1fa0fb84acde5d02
````

````asset path=data/elder-defense.md sha256=3c867ca1ee82763c62458265c4a53f8aa13dda9e27f0841ae0e46d91fafa09b4
````

````asset path=data/letter-templates.md sha256=4cb605262a4cdeb64712108fe40c1fb2b13f3770bb7c90ea56bce2bed31b2272
````

````asset path=data/forward-howto.md sha256=7350d796441b9e56149f5f40749005d0bddb684ae6c409411e1e23bc17e17d71
````

````asset path=data/capability-matrix.md sha256=fad3300d9530064dd68c51bf985b2215486726c15cdeb5575440d2c1a661a419
````

````asset path=data/geo-packs.md sha256=b231b1bfc652765c6f1376f46b8673554673a6af9db21bfc4f2c7efdbb0d70cd
````
