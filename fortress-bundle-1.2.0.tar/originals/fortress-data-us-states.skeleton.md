# Fortress data: US states

50 states + DC/territories: AG complaint pages, state DNC/telemarketing notes, mini-TCPA status with last-checked dates.

Write each block to `$FORTRESS_HOME/<path>` during **fortress-tools** setup and verify its hash. Read-only reference data; never write owner results into it.

````asset path=data/us-states.json sha256=5937de04cf05b214f7373f3c1a629234808c190f10e16da8987d4a764dfabeb1
````
