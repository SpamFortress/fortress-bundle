# Fortress tools (bundled helpers)

Portable helper scripts every Fortress skill refers to as `$FORTRESS_HOME/tools/<name>.py`. Nothing here is the publisher's data; each new owner gets an empty private workspace.

## This bot's own workspace (why it matters)
All of an owner's bots share one computer (the box), so a fixed folder would be shared by every bot that imports Fortress. Each Fortress bot therefore gets its **own** folder, named by a random instance id created once and saved in **this bot's own memory**:
`~/fortress-data/instances/<instance id>/`. Every helper call passes it explicitly:
`FORTRESS_HOME=<that folder> FORTRESS_INSTANCE=<id> python3 $FORTRESS_HOME/tools/<helper>.py ...`
Helpers refuse a folder whose ownership file names another instance. Never reuse another bot's folder, even a paired sibling's; pairing shares counts only through the consented relay.

## One-time setup (ask before running; takes a minute)
1. `python3 fortress_bootstrap.py init --tz <owner IANA timezone> --lane <phone|email>` (write `tools/fortress_bootstrap.py` from the block below to a temporary folder first, then copy it in). It creates a new random instance folder with an exclusive ownership file, `private/` with empty files and **every opt-in off**, and prints a `remember` line. Save that line to this bot's memory now. Ask the owner's timezone if unknown; never assume the publisher's.
2. Write every asset block below, and those in **fortress-data-core**, **fortress-data-brokers**, **fortress-data-international** and **fortress-data-us-states** (only the ones this bot has), to `$FORTRESS_HOME/<path>` exactly as shown (Shell heredoc with a quoted delimiter so nothing expands). `manifest.json` lists every hash.
3. `python3 $FORTRESS_HOME/tools/fortress_bootstrap.py preflight --instance <id> --home $FORTRESS_HOME`: checks ownership, every hash against `manifest.json`, migrates older private files without dropping data, and makes private copies of fillable templates (e.g. `private/templates/elder-defense.md`; `data/` stays read-only). Any mismatch → rewrite that file; never run a helper that fails its hash.
4. Run preflight again before the first helper step of any later session (logging, clocks, verdict helpers, label scan, caregiver, update).
5. Optional: `pip install --user tldextract` enables Public Suffix List domain parsing (offline snapshot, no network at use). Without it the domain helper answers "unknown" and skills treat that as review.
6. Optional for attachment/QR checks: `poppler-utils` (pdftotext/pdftoppm), `opencv-python-headless` (QR), `tesseract` (OCR). Missing tools are reported, never faked.

## Private file schemas (one per file; helpers and skills use these)
| File (under private/) | Shape |
|---|---|
| settings.json | schema_version, timezone, country, us_state, lane, opt-ins (all "off" at start), label_scan_schedule, trusted_authserv_ids (legacy, ignored), installed_fortress_version, fortress_feed_url |
| safelist.json | version 2: categories{7 lists of {address} or {domain, subdomains}}, brands{name: domains}, vip[], auth_keywords, near_misses[] |
| phone/evidence/index.json, email/evidence/index.json | {version, items[]}; each lane writes its own index (email evidence never goes in the phone index) |
| email/receipts/index.json, optout-log.json (+pending_owner[]), call-queue.json, settlement-ledger.json, who-sold/signup-log.json, email/regulator-packets/queue.json | {version, items[]} |
| email/receipts/index.json items | each receipt keyed by `reference_id` (fallback receipt_id, then id) with its own `sent_at`; clocks are written back to that exact row |
| phone/evidence (STOP rows) | `stop_at` nested under `stop` or top level (top level is copied into `stop` with migrated_from on `--write`); each phone's STOP clock is separate |
| <lane>/recovery/incidents.json | {version, items[{incident_id, kind wire72/rege2bd/rege60/credit60, anchor_at (ISO with offset), anchor_what, done_at?}]}; `deadline-clocks.py list` re-reads every run |
| who-sold/map.json | {version, aliases[{alias, site, ...}]} |
| breach-watch.json | {version, brands[]} |
| household.json | {version, phones[{phone_id, label, type, number_e164}]} (the owner's protected numbers, written at setup and whenever the owner adds or drops a number; `extract-identifiers.py` reads `number_e164`/`number`; separate from evidence) |
| junk-mail/log.jsonl | one JSON object per line |
| caregiver/state.json, email/label-scan/state.json | owned by caregiver_state.py / label_scan.py |
| update/ (state.json, plans/, backups/, journal.json, fetch-receipts.json, approvals.json, trust.key, lock) | owned by fortress_update.py |

## Rules
- `private/` is this owner's only: evidence, receipts, safelist, logs, caregiver and label-scan state. Never export it, paste it into a skill, or include it in a template or bug report.
- `data/` is the bundled public tables (read-only; updates replace them through **fortress-update-check**).
- Helpers never send, submit, call, or visit suspicious links. Public lookups they make: FCC/FTC open data and localcallingguide (numbers), RDAP and DNS-over-HTTPS (domains), and the official policy pages in the privacy catalog.
- Pasted or forwarded headers are never provenance: `enrich-domain.py` reports authentication as `unknown` for any header text (an authserv-id that matches the owner's provider is still just text; `trusted_authserv_ids` is a legacy setting that is no longer read). Only a result returned directly by the owner's provider connector could count, and no such adapter ships yet. The IP hint comes only from the top Received line (unverified; never origin or location); lower hops are never used. Registered domains need the Public Suffix List; without it the domain is unknown.

## Helpers
| File | What it does |
|---|---|
| deadline-clocks.py | STOP/unsubscribe 10-business-day clocks, 48-hour clocks (elapsed UTC, shown in owner time), recovery clocks rege60 / rege2bd / credit60 / wire72; per-destination-phone STOP matching; facts only, not legal conclusions |
| enrich-number.py | Public reverse lookup for a phone number (FCC complaints data, FTC DNC reports, original carrier block); cache in private/ |
| enrich-domain.py | Domain age/registrar via RDAP, header parse with trust boundary, official brand-domain check |
| extract-identifiers.py | Pull numbers/domains/handles from evidence; campaign grouping; IC3 paste block |
| privacy-watch.py | Fetch-normalize-diff official privacy/OS pages; keeps material cookie/ad-sharing clauses; state in private/ |
| inspect-attachment.py | Offline link/QR extraction: 15 MB + signature/type gate before parsing, MIME structure pre-scan, encoded and decoded image pixel limits, bounded local PDF rasterization (first 5 pages) for QR only; image/MIME parsing and tools in limited child processes, empty network namespace when available (reported as enforced/unavailable); JSON status complete/incomplete/refused |
| takedown-drafts.py | Draft-only abuse reports from verified directory entries, wording limited to recorded facts |
| fortress_domain.py | URL/host parse + Public Suffix List: owner domain (private suffixes like github.io tenants) vs ICANN domain |
| label_scan.py | Gmail Likely Scam: persisted pagination, per-step durable protocol, lock, protective gate, conservative envelope verdict |
| caregiver_state.py | Caregiver consent versions, refusal-safe consent, cap, queue binding, dedupe, timing driver, final pre-send gate |
| fortress_update.py | No-reset Apply: trust only from its own sealed feed-fetch receipt or a sealed controller-recorded owner yes to an exact hash (native card check pending); strict validation; sealed cached plan re-checked at every step; no-follow fd-relative I/O; restore set pre-verified; lock + phased journal; coherent crash recovery incl. repairs and rollbacks; lineage-aware rollback; issued native skill writes with snapshot/readback; recover-first for consumers; Skip/Remind |
| fortress_bootstrap.py | Per-bot workspace: init (all opt-ins off), preflight (ownership, hashes, migrations), verify |

````asset path=tools/caregiver_state.py sha256=4475095507a45c9ec371db9e6915176082bac4e798a3fb1a72576c94361fe778
````

````asset path=tools/deadline-clocks.py sha256=1cd734da66a5515e4167f28f7bf95d13019571d7cd86f17e966d2a73051859a1
````

````asset path=tools/enrich-domain.py sha256=3d93b08bbd793c8bcf0f7313399f93475ce01f57147dcd65c9064867a47c24c3
````

````asset path=tools/enrich-number.py sha256=c0f8e9a052bcf61b0b4c8d559641ae76e8c1f894f82e64b1e54f409a1a9383c9
````

````asset path=tools/extract-identifiers.py sha256=435e8f34062d19e242a210033b5fb3dc969325e0585278ab4309f9700561e504
````

````asset path=tools/fortress_bootstrap.py sha256=82da953a6bb5ca2651690dab1dd1d998ef8438d8b4ec5a247857fdde59c16d50
````

````asset path=tools/fortress_controller.py sha256=378d2eff9299b524dc4f8e97c3c74a3c6414ad342cf4a2bfcae386ed860f0c0f
````

````asset path=tools/fortress_domain.py sha256=1eb3a92d9f50ebea4e73802f3c43ba776c57605d70ea6f8d906b9e89b3f77250
````

````asset path=tools/fortress_owner.py sha256=921c760d7bb08c5a9092d06a8be6a7f5c77a5e0445b529be1a54e1d30eaba221
````

````asset path=tools/fortress_update.py sha256=2bc8bb12d6070275c5eab261905f4aeeba1ae71ad3dafe01f22e319a1d040b10
````

````asset path=tools/inspect-attachment.py sha256=66db79ee56aa191a63c23597f3333759a58da8384db3190bf2b2ac4ae95af99b
````

````asset path=tools/label_scan.py sha256=e1487b4c4cf5a753ba0b702844d57022f7f13d5baea9d90c900dbbaa65606445
````

````asset path=tools/privacy-watch.py sha256=556f7a3bd69e5b125d440d4430784bae1d8e250fa1493eccb76e81dfa7386588
````

````asset path=tools/takedown-drafts.py sha256=3f712d89fc73746c2b167258fc7370ba9c13c1ec5b40480d0f01fa21f7d1e4d0
````

````asset path=manifest.json sha256=f9d78c400e2b2d2636029f0fc7a3ba93ee182e8a88ff048ce17cddd70623cfc2
````
