#!/usr/bin/env python3
"""Scam identifier extractor + "same operation" clustering for Phone + Email Fortress.

Reads SAVED evidence only (ev-*.json text fields). Never opens a link, never resolves a
short link, never messages or looks up a person. Pure text parsing on what is already logged.

Extracts
  telegram / whatsapp / signal / other-chat links + handles (off-platform push)
  phone numbers in the body (callback / TOAD), emails, URLs + hosts, short links
  crypto wallets (BTC legacy/P2SH with base58check, bech32 bc1, ETH 0x, TRON T... base58check)
  payment handles: Cash App $cashtag, Venmo, Zelle (email/phone near "zelle"), PayPal.me
Flags
  pivot_platform, off_platform_push, sextortion_pressure, payment_pressure
  sender_type: short_code | toll_free | long_code_10dlc_possible | email_to_sms | alphanumeric | international | unknown
  spoof_signals (calls/texts): signals only - a handset cannot PROVE a spoof
Clusters
  records sharing any identifier (or a near-identical script) -> one campaign.
  SHARED IDENTIFIER != ATTRIBUTION. It shows shared infrastructure, not who is behind it.

Usage
  extract-identifiers.py --scan                       # all phone + email evidence, print JSON
  extract-identifiers.py --scan --write               # also tag evidence (backup .bak-identifiers) + write evidence/_campaigns/campaigns.json
  extract-identifiers.py --evidence <ev.json>         # one file
  extract-identifiers.py --text "msg..." --from +15551234567   # ad hoc paste (nothing saved)
  extract-identifiers.py --scan --ic3                 # print IC3-ready identifier block per campaign
  extract-identifiers.py --scan --rmd-removed-list removed.txt # optional: flag block carriers removed from FCC RMD
"""
# --- Fortress portable header (v3) ---
import os as _os, json as _j
from zoneinfo import ZoneInfo as _ZI
FORTRESS_HOME = _os.environ.get("FORTRESS_HOME")
if not FORTRESS_HOME:
    raise SystemExit("FORTRESS_HOME not set: pass this bot's own workspace (from its memory), e.g. FORTRESS_HOME=... FORTRESS_INSTANCE=... python3 tool.py")
def _check_owner():
    """Fail closed: the root must carry this bot's ownership file AND FORTRESS_INSTANCE must name that same instance."""
    try: m = _j.load(open(_os.path.join(FORTRESS_HOME, ".fortress-owner.json")))
    except Exception: raise SystemExit("FORTRESS_HOME has no Fortress ownership file: run fortress_bootstrap.py init/preflight first; refusing")
    want = _os.environ.get("FORTRESS_INSTANCE")
    if not want: raise SystemExit("FORTRESS_INSTANCE not set: pass this bot's own instance id from its memory; refusing")
    if m.get("instance_id") != want:
        raise SystemExit(f"FORTRESS_HOME belongs to Fortress instance {m.get('instance_id')}, not {want}; refusing")
_check_owner()
def _owner_tz():
    tz = _os.environ.get("FORTRESS_TZ")
    if not tz:
        try: tz = _j.load(open(_os.path.join(FORTRESS_HOME, "private", "settings.json"))).get("timezone")
        except Exception: tz = None
    if not tz:
        raise SystemExit("Owner timezone not set: run fortress_bootstrap.py init --tz <IANA zone> (ask the owner)")
    return tz
OWNER_TZ_NAME = _owner_tz()
OWNER_TZ = _ZI(OWNER_TZ_NAME)
# --- end header ---

import argparse, glob, hashlib, json, os, re, shutil, sys, datetime as dt
from zoneinfo import ZoneInfo

PT = OWNER_TZ
PHONE_ROOT = os.path.join(FORTRESS_HOME, "private", "phone")
EMAIL_ROOT = os.path.join(FORTRESS_HOME, "private", "email")
CAVEAT = ("Shared identifier != attribution: it shows shared infrastructure (same link, handle, wallet or script), "
          "not who is behind it. A handset cannot prove a spoof; spoof_signals are signals only.")

TEXT_FIELDS = ("content_excerpt", "content_summary", "transcript", "transcript_excerpt", "body", "body_text", "subject", "ocr_text",
               "message", "text", "notes", "links", "urls", "reply_to", "from", "from_display", "display_name",
               "cnam_display", "claimed_identity", "payment_instructions", "threat_text")

CHAT = [
    ("telegram", r"(?:https?://)?(?:t\.me|telegram\.me|telegram\.dog)/(?:joinchat/|\+)?[A-Za-z0-9_+\-]{3,64}"),
    ("telegram", r"tg://resolve\?domain=[A-Za-z0-9_]{3,64}"),
    ("whatsapp", r"(?:https?://)?(?:wa\.me/|api\.whatsapp\.com/send\?phone=|chat\.whatsapp\.com/)[A-Za-z0-9+]{4,40}"),
    ("signal", r"(?:https?://)?(?:signal\.me/#[A-Za-z0-9/._\-]+|signal\.group/#[A-Za-z0-9._\-]+)"),
    ("line", r"(?:https?://)?line\.me/[A-Za-z0-9/_~\-]+"),
    ("snapchat", r"(?:https?://)?snapchat\.com/add/[A-Za-z0-9._\-]+"),
    ("kik", r"(?:https?://)?kik\.me/[A-Za-z0-9._\-]+"),
    ("discord", r"(?:https?://)?(?:discord\.gg|discord\.com/invite)/[A-Za-z0-9\-]+"),
    ("instagram_dm", r"(?:https?://)?ig\.me/[A-Za-z0-9._\-]+"),
    ("messenger", r"(?:https?://)?m\.me/[A-Za-z0-9._\-]+"),
]
PLATFORM_WORDS = r"(telegram|whatsapp|whats app|signal|snapchat|snap|kik|line app|wechat|viber|discord|session app|wickr|threema|instagram|insta)"
PUSH = re.compile(r"\b(text|message|msg|chat|talk|reach|add|find|contact|dm|hit)\s+me\s+(on|at|via)\s+" + PLATFORM_WORDS +
                  r"|\b(move|switch|continue|let'?s talk|lets chat|talk)\b[^.\n]{0,25}\b(on|to|over)\s+" + PLATFORM_WORDS +
                  r"|\bmy\s+" + PLATFORM_WORDS + r"\s+(is|handle|id|username)\b|\bscan\s+(the|this|my)\s+qr\b", re.I)
HANDLE_NEAR = re.compile(PLATFORM_WORDS + r"[^@\n]{0,25}(@[A-Za-z0-9_]{4,32})", re.I)
SEXTORT = re.compile(r"\b((send|forward|share|post)\w* (it |them |this |these |the (pics?|photos?|videos?) )?(to|with) (all )?(your |ur )?(family|friends|wife|husband|partner|boss|employer|followers|contacts|school|parents)|"
                     r"(leak|expose|post|share|publish)\w*\b[^.\n]{0,30}\b(pics?|photos?|videos?|images?|chat|screenshots?)|"
                     r"(your|ur) (family|friends|followers|contacts|employer|school) (will|gonna) (see|get)|"
                     r"recorded (you|ur)|webcam|ruin (your|ur) (life|reputation)|pay (or|now or)\b)", re.I)
PAYPRESS = re.compile(r"\b(gift ?cards?|bitcoin|btc|usdt|crypto|wallet address|cash ?app|zelle|venmo|paypal|western union|moneygram|wire)\b", re.I)
URL = re.compile(r"\b(?:https?://)?(?:[a-z0-9\-]+\.)+[a-z]{2,24}(?:/[^\s<>\"')\]]*)?", re.I)
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "rb.gy", "cutt.ly", "ow.ly", "shorturl.at", "tiny.cc", "s.id",
              "goo.su", "rebrand.ly", "bl.ink", "t.ly", "v.gd", "buff.ly", "lnkd.in", "qrco.de", "short.gy", "urlz.fr", "shor.by"}
EMAIL = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,24}\b")
PHONE = re.compile(r"(?<![\w$])(?:\+?1[\s.\-]?)?\(?([2-9]\d{2})\)?[\s.\-]?([2-9]\d{2})[\s.\-]?(\d{4})(?!\d)")
INTL = re.compile(r"(?<!\w)\+(?!1)(\d[\d\s\-]{7,16}\d)")
ETH = re.compile(r"\b0x[a-fA-F0-9]{40}\b")
BTC_LEG = re.compile(r"\b[13][1-9A-HJ-NP-Za-km-z]{25,34}\b")
BTC_B32 = re.compile(r"\bbc1[ac-hj-np-z02-9]{11,71}\b", re.I)
TRX = re.compile(r"\bT[1-9A-HJ-NP-Za-km-z]{33}\b")
CASHTAG = re.compile(r"(?<![\w$])\$[A-Za-z][A-Za-z0-9_\-]{0,19}\b")
VENMO = re.compile(r"(?:venmo\.com/(?:u/)?([A-Za-z0-9_\-]{3,30})|venmo[^@\n]{0,20}(@[A-Za-z0-9_\-]{3,30}))", re.I)
PAYPAL = re.compile(r"(?:https?://)?(?:www\.)?paypal\.me/[A-Za-z0-9_\-]{2,40}", re.I)
ZELLE = re.compile(r"zelle[^\n]{0,40}?(" + EMAIL.pattern + r"|\(?[2-9]\d{2}\)?[\s.\-]?\d{3}[\s.\-]?\d{4})", re.I)
TOLL_FREE = {"800", "833", "844", "855", "866", "877", "888"}
CLAIM = re.compile(r"\b(bank|chase|wells fargo|bank of america|citi|capital one|irs|social security|ssa|medicare|police|sheriff|fbi|"
                   r"amazon|apple|microsoft|paypal|usps|fedex|ups|dmv|toll|e-?zpass|fraud department|geek squad)\b", re.I)
VOIP_HINT = re.compile(r"(CLEC|BANDWIDTH|TWILIO|PEERLESS|ONVOY|INTELIQUENT|LEVEL 3|TELNYX|VONAGE|NUSO|COMMIO|SINCH|IP PHONE)", re.I)
B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def b58check(s):
    n = 0
    for ch in s:
        if ch not in B58:
            return False
        n = n * 58 + B58.index(ch)
    full = n.to_bytes(25, "big") if n.bit_length() <= 200 else None
    if not full:
        return False
    pad = len(s) - len(s.lstrip("1"))
    raw = b"\x00" * pad + full.lstrip(b"\x00")
    if len(raw) != 25:
        return False
    return hashlib.sha256(hashlib.sha256(raw[:-4]).digest()).digest()[:4] == raw[-4:]


def digits(s):
    return re.sub(r"\D", "", s or "")


def e164(s):
    d = digits(s)
    if len(d) == 10:
        return "+1" + d
    if len(d) == 11 and d.startswith("1"):
        return "+" + d
    return None


def sender_type(sender, channel):
    s = (sender or "").strip()
    if not s:
        return "unknown"
    if "@" in s:
        return "email_to_sms"  # text whose sender is an email address (carrier email-to-SMS gateway / iMessage email)
    if re.search(r"[A-Za-z]", s) and not re.search(r"\d{5,}", s):
        return "alphanumeric"  # alphanumeric sender IDs are rare/unsupported on US networks -> usually international
    d = digits(s)
    if 5 <= len(d) <= 6 and not s.startswith("+"):
        return "short_code"
    if len(d) == 10 or (len(d) == 11 and d.startswith("1")):
        npa = d[-10:][:3]
        if npa in TOLL_FREE:
            return "toll_free"
        return "long_code_10dlc_possible" if channel in ("sms", "text", "mms", "rcs") else "long_code"
    if s.startswith("+") or len(d) > 11:
        return "international"
    return "unknown"


def text_of(ev):
    parts = []
    for k in TEXT_FIELDS:
        v = ev.get(k)
        if isinstance(v, str):
            parts.append(v)
        elif isinstance(v, list):
            parts += [x for x in v if isinstance(x, str)]
    for k in ("ocr", "message_parts", "messages"):
        v = ev.get(k)
        if isinstance(v, list):
            parts += [x.get("text", "") if isinstance(x, dict) else str(x) for x in v]
    return "\n".join(parts)


def extract(text, own_numbers=()):
    ids = {k: set() for k in ("telegram", "whatsapp", "signal", "other_chat", "chat_handles", "body_phones",
                              "intl_phones", "emails", "urls", "hosts", "short_links", "btc", "eth", "trx",
                              "cashapp", "venmo", "zelle", "paypal")}
    for plat, rx in CHAT:
        for m in re.finditer(rx, text, re.I):
            v = m.group(0).lower().replace("https://", "").replace("http://", "")
            (ids[plat] if plat in ("telegram", "whatsapp", "signal") else ids["other_chat"]).add(v if plat in ("telegram", "whatsapp", "signal") else f"{plat}:{v}")
    for m in HANDLE_NEAR.finditer(text):
        ids["chat_handles"].add(f"{m.group(1).lower().replace(' ', '')}:{m.group(2).lower()}")
    for m in EMAIL.finditer(text):
        ids["emails"].add(m.group(0).lower())
    for m in URL.finditer(text):
        u = m.group(0).rstrip(".,;:!?")
        if "@" in text[max(0, m.start() - 1):m.start()]:
            continue  # host part of an email
        host = re.sub(r"^https?://", "", u, flags=re.I).split("/")[0].lower()
        if "." not in host or host.replace(".", "").isdigit():
            continue
        if not (u.lower().startswith("http") or "/" in u or host.split(".")[-1] in ("com", "net", "org", "io", "me", "ly", "co", "xyz", "top", "info", "link", "site", "online", "app", "gd", "at", "gy", "cc", "id", "su", "fr", "de", "us")):
            continue
        ids["urls"].add(u.lower())
        ids["hosts"].add(host)
        if host in SHORTENERS:
            ids["short_links"].add(u.lower())
    own = {e164(n) for n in own_numbers if e164(n)}
    for m in PHONE.finditer(text):
        n = "+1" + "".join(m.groups())
        if n not in own:
            ids["body_phones"].add(n)
    for m in INTL.finditer(text):
        ids["intl_phones"].add("+" + digits(m.group(1)))
    ids["eth"] |= {m.group(0) for m in ETH.finditer(text)}
    ids["btc"] |= {m.group(0) for m in BTC_LEG.finditer(text) if b58check(m.group(0))}
    ids["btc"] |= {m.group(0).lower() for m in BTC_B32.finditer(text)}
    ids["trx"] |= {m.group(0) for m in TRX.finditer(text) if b58check(m.group(0))}
    ids["cashapp"] |= {m.group(0) for m in CASHTAG.finditer(text) if not re.fullmatch(r"\$\d", m.group(0)) and "cash" in text.lower()}
    for m in VENMO.finditer(text):
        ids["venmo"].add((m.group(1) or m.group(2) or "").lower())
    ids["paypal"] |= {m.group(0).lower() for m in PAYPAL.finditer(text)}
    for m in ZELLE.finditer(text):
        ids["zelle"].add(m.group(1).lower())
    return {k: sorted(v) for k, v in ids.items() if v}


def flags_for(text, ids):
    pivots = sorted({k for k in ("telegram", "whatsapp", "signal") if ids.get(k)} |
                    {x.split(":")[0] for x in ids.get("other_chat", [])} |
                    {x.split(":")[0] for x in ids.get("chat_handles", [])} |
                    {m.group(0).split()[-1].lower() for m in re.finditer(PLATFORM_WORDS, text, re.I) if PUSH.search(text)})
    return {
        "pivot_platform": pivots,
        "off_platform_push": bool(PUSH.search(text) or ids.get("telegram") or ids.get("whatsapp") or ids.get("signal") or ids.get("other_chat")),
        "sextortion_pressure": bool(SEXTORT.search(text)),
        "payment_pressure": bool(PAYPRESS.search(text)),
        "claimed_brand": sorted({m.group(0).lower() for m in CLAIM.finditer(text)}),
    }


def spoof_signals(ev, flags, owner_numbers, rmd_removed):
    sig = []
    num = e164(ev.get("from_number") or ev.get("number_e164") or ev.get("number") or ev.get("from_number_display") or "")
    owners = [e164(o) for o in owner_numbers if e164(o)]
    if num and num in owners:
        sig.append({"signal": "own_number_shown", "weight": "strong", "note": "Caller ID shows YOUR number - almost certainly spoofed. FCC complaint sub-issue: my own number is being spoofed."})
    if num:
        for o in owners:
            if o and o != num and o[2:8] == num[2:8]:
                sig.append({"signal": "neighbor_spoof_pattern", "weight": "medium", "note": "Same area code + prefix as your number (neighbor spoofing pattern)."})
    st = (ev.get("stir_shaken") or ev.get("verified_badge") or "").lower() if isinstance(ev.get("stir_shaken") or ev.get("verified_badge") or "", str) else ""
    if st in ("verified", "yes", "a", "checkmark"):
        sig.append({"signal": "verified_badge_present", "weight": "info", "note": "Carrier 'Verified'/check = STIR/SHAKEN attestation the originating carrier vouched for this number. Identity, NOT intent - scammers can use real numbers they own."})
    elif st in ("none", "not_shown", "no"):
        sig.append({"signal": "no_verified_badge", "weight": "info", "note": "No badge proves nothing (non-IP/international/older networks and many phones never show one)."})
    cnam = (ev.get("cnam_display") or "").strip()
    claimed = flags.get("claimed_brand") or []
    if cnam and claimed and not any(c.split()[0] in cnam.lower() for c in claimed):
        sig.append({"signal": "cnam_mismatch", "weight": "medium", "note": f"Caller name shown '{cnam}' does not match who they claimed ({', '.join(claimed)})."})
    bc = ((ev.get("number_intel") or {}).get("block_carrier") or "")
    if claimed and bc:
        if VOIP_HINT.search(bc):
            sig.append({"signal": "claimed_brand_vs_voip_block", "weight": "medium", "note": f"Claims {', '.join(claimed)} but the number's original block is a VoIP/texting platform ({bc}). Real banks/agencies rarely cold-call from these; may have ported."})
        else:
            sig.append({"signal": "claimed_brand_vs_block_carrier", "weight": "low", "note": f"Claims {', '.join(claimed)}; original block carrier {bc}. Compare to the number on your card/statement - call that one instead."})
    if ev.get("callback_test") in ("real_owner_never_called", "number_not_in_service"):
        sig.append({"signal": "callback_test", "weight": "strong", "note": "The real owner of the displayed number says they never called you (or it is not in service) - spoofed."})
    if bc and rmd_removed and any(r.lower() in bc.lower() for r in rmd_removed):
        sig.append({"signal": "rmd_removed_provider", "weight": "medium", "note": f"Block carrier '{bc}' matches a provider on your FCC Robocall Mitigation Database removal list (other carriers must refuse its traffic). Name match only - verify in the FCC order."})
    strong = sum(1 for s in sig if s["weight"] == "strong")
    med = sum(1 for s in sig if s["weight"] == "medium")
    level = "likely_spoofed" if strong or med >= 2 else "possible" if med else "no_spoof_signals"
    return {"assessment": level, "signals": sig,
            "honesty": "Signals only - a phone cannot prove a spoof. Log geography as unknown when spoof is likely; FCC/FTC zero counts stay logged as zero (they do not clear the number)."}


def shingles(text):
    t = URL.sub(" URL ", text.lower())
    t = re.sub(r"@[a-z0-9_]+|\$[a-z][a-z0-9_\-]*", " HANDLE ", t)
    t = re.sub(r"\d+", "N", t)
    t = re.sub(PLATFORM_WORDS, " PLATFORM ", t, flags=re.I)
    t = re.sub(r"\b(i'?m|i am|this is|it'?s)\s+[a-z]+", r"\1 NAME", t)
    w = re.findall(r"[a-z']+|N|URL|HANDLE|PLATFORM|NAME", t)
    return {" ".join(w[i:i + 2]) for i in range(max(0, len(w) - 1))}


def load_owner_numbers():
    """Owner's protected numbers: canonical private/household.json phones[].number (+ legacy evidence-index phones if still present)."""
    nums = []
    for f, key in ((os.path.join(FORTRESS_HOME, "private", "household.json"), "phones"), (f"{PHONE_ROOT}/evidence/index.json", "phones")):
        try:
            for ph in json.load(open(f)).get(key, []) or []:
                n = ph.get("number") or ph.get("number_e164") if isinstance(ph, dict) else ph
                if n and n not in nums: nums.append(n)
        except Exception:
            pass
    return nums


def evidence_paths():
    out = []
    for root in (PHONE_ROOT, EMAIL_ROOT):
        for p in sorted(glob.glob(f"{root}/evidence/*/*.json")):
            b = os.path.basename(p)
            if ".bak" in p or b.endswith("-intel.json") or b == "index.json" or "/_campaigns/" in p:
                continue
            out.append(p)
    return out


def analyze(ev, owner, rmd_removed):
    text = text_of(ev)
    ids = extract(text, owner)
    fl = flags_for(text, ids)
    sender = ev.get("from_number") or ev.get("number_e164") or ev.get("number_displayed") or ev.get("from") or ev.get("from_number_display") or ev.get("original_from") or ""
    ch = (ev.get("channel") or "").lower()
    ch = "call" if ch.startswith("call") or "voicemail" in ch else ch
    res = {"identifiers": ids, **{k: v for k, v in fl.items()},
           "sender": sender, "sender_type": sender_type(sender, ch) if ch not in ("email",) else "email"}
    if ch in ("call", "voicemail", "voice", "sms", "text", "mms", "rcs") or ev.get("from_number") or ev.get("number_e164"):
        res["spoof"] = spoof_signals(ev, fl, owner, rmd_removed)
    if fl["off_platform_push"]:
        res.setdefault("tags", []).append("off_platform_bait")
    if fl["sextortion_pressure"]:
        res.setdefault("tags", []).append("sextortion")
    res["_shingles"] = shingles(text)
    return res


def cluster(records):
    parent = list(range(len(records)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def keys(r):
        k = set()
        for typ, vals in r["identifiers"].items():
            if typ == "hosts":
                continue  # hosts alone are too broad (e.g. shared clouds); full URLs/links still count
            for v in vals:
                k.add(f"{typ}:{v}")
        return k

    owners = {}
    for i, r in enumerate(records):
        for k in keys(r):
            if k in owners:
                parent[find(i)] = find(owners[k])
            else:
                owners[k] = i
    for i in range(len(records)):
        for j in range(i + 1, len(records)):
            a, b = records[i]["_shingles"], records[j]["_shingles"]
            if len(a) >= 6 and len(b) >= 6 and len(a & b) / len(a | b) >= 0.6:
                parent[find(j)] = find(i)
                records[i].setdefault("_script_links", []).append(j)
    groups = {}
    for i in range(len(records)):
        groups.setdefault(find(i), []).append(i)
    camps = []
    for members in groups.values():
        if len(members) < 2:
            continue
        cnt = {}
        for m in members:
            for k in keys(records[m]):
                cnt[k] = cnt.get(k, 0) + 1
        shared = {k for k, n in cnt.items() if n >= 2}
        allk = set().union(*[keys(records[m]) for m in members])
        cid = "camp-" + hashlib.sha1("|".join(sorted(records[m]["evidence_id"] for m in members)).encode()).hexdigest()[:8]
        camps.append({"campaign_id": cid,
                      "members": [records[m]["evidence_id"] for m in members],
                      "senders": sorted({records[m]["sender"] for m in members if records[m]["sender"]}),
                      "linking_identifiers": sorted(shared),
                      "all_identifiers": sorted(allk),
                      "script_match": any(records[m].get("_script_links") for m in members),
                      "pivot_platforms": sorted(set().union(*[set(records[m]["pivot_platform"]) for m in members])),
                      "caveat": CAVEAT})
        for m in members:
            records[m]["campaign_id"] = cid
    return camps


def ic3_block(camp_or_rec, records_by_id=None):
    ids = {}
    src = [camp_or_rec] if "identifiers" in camp_or_rec else [records_by_id[e] for e in camp_or_rec["members"]]
    for r in src:
        for k, v in r["identifiers"].items():
            ids.setdefault(k, set()).update(v)
    senders = sorted({r["sender"] for r in src if r.get("sender")})
    L = ["IC3 identifier block (paste into the 'Information about the subject' / description fields; verify each line):",
         f"- Contacting numbers/addresses: {', '.join(senders) or 'unknown'}"]
    lab = {"telegram": "Telegram links", "whatsapp": "WhatsApp links", "signal": "Signal links", "other_chat": "Other chat links",
           "chat_handles": "Usernames/handles", "body_phones": "Phone numbers in messages", "intl_phones": "International numbers",
           "emails": "Email addresses", "btc": "Bitcoin addresses", "eth": "Ethereum addresses", "trx": "TRON addresses",
           "cashapp": "Cash App $cashtags", "venmo": "Venmo usernames", "zelle": "Zelle recipient (email/phone)",
           "paypal": "PayPal.me links", "short_links": "Short links (not opened)", "urls": "Links (not opened)"}
    for k, label in lab.items():
        if ids.get(k):
            L.append(f"- {label}: {', '.join(sorted(ids[k]))}")
    L.append("- Transaction IDs / amounts / dates paid: <owner fills from bank or app receipts; 'none' if nothing paid>")
    L.append("Note: identifiers are as shown in saved messages; links were not opened. Shared identifiers suggest a common operation, not identity.")
    return "\n".join(L)


ALLEGATION_VERDICTS = {"scam", "phishing", "phish", "fraud", "fraudulent", "likely_scam", "extortion", "sextortion"}
def recorded_facts(ev):
    """v12 D01: typed facts record taken ONLY from saved evidence. Absent keys stay absent (rendered as unknown); explicit
    False / 0 / 'no' are kept as recorded values. Nothing is inferred from the message text."""
    src = dict(ev.get("facts") or {}) if isinstance(ev.get("facts"), dict) else {}
    alias = {"message_date": ("message_date", "occurred_at", "received_at"), "contact_channel": ("contact_channel", "channel"),
             "what_asked": ("what_asked",), "paid": ("paid",), "reported_in_app": ("reported_in_app",), "screenshots": ("screenshots",),
             "owner_allegation": ("owner_allegation",)}
    out = {}
    for k, keys in alias.items():
        for kk in [k] if k in src else []:
            out[k] = src[kk]
        if k in out: continue
        for kk in keys:
            if kk in ev and ev[kk] is not None and ev[kk] != "":
                out[k] = ev[kk]; break
    v = str(ev.get("verdict") or "").strip().lower()
    if "owner_allegation" not in out and v in ALLEGATION_VERDICTS: out["owner_allegation"] = v
    return out
def _fact(v):
    if v is True: return "yes"
    if v is False: return "no"
    return str(v)
def side_drafts(ids, facts=None):
    """Report drafts containing ONLY recorded identifiers and facts the caller passes from saved evidence.
    Anything not recorded is an explicit <unknown/fill in> field; no threat, demand, payment or prior report is assumed.
    False/0 are recorded answers (rendered 'no'/'0'), never replaced by 'unknown'. '#scam' only with a recorded allegation."""
    facts = facts or {}
    def f(k, blank):
        v = facts.get(k)
        return blank if v is None or v == "" else _fact(v)
    alleged = facts.get("owner_allegation")
    d = []
    tg = ids.get("telegram", []) + [h for h in ids.get("chat_handles", []) if h.startswith("telegram")]
    if tg:
        d.append({"to": "Telegram @notoscam (https://t.me/notoscam) - user sends from their own Telegram, or skip",
                  "text": (f"#scam Reporting account(s) the owner recorded as {_fact(alleged)}: " if alleged else
                           "Account(s) seen in saved message(s), for your review (no scam allegation recorded; allegation: unknown): ")
                          + f"{', '.join(sorted(tg))}. "
                          f"How they contacted me: {f('contact_channel', '<from saved evidence, or unknown>')}. "
                          f"What the messages asked for: {f('what_asked', '<from saved messages, or unknown>')}. "
                          f"Screenshots: {f('screenshots', '<available / not available>')}. "
                          f"Reported in the app already: {f('reported_in_app', '<yes with date / no / unknown>')}."})
    wal = ids.get("btc", []) + ids.get("eth", []) + ids.get("trx", [])
    if wal:
        d.append({"to": "Chainabuse (https://www.chainabuse.com/) - user submits; optional",
                  "text": f"Crypto address(es) seen in saved message(s): {', '.join(sorted(wal))}. "
                          f"Message date: {f('message_date', '<from saved evidence, or unknown>')}. "
                          f"What the message said about the address: {f('what_asked', '<quote from saved message, or unknown>')}. "
                          f"Paid: {f('paid', '<no / yes, amount and TXID / unknown>')}."})
    return d


def main():
    ap = argparse.ArgumentParser(description="Extract scam identifiers + cluster same-operation evidence (saved logs only).",
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__.split("Usage")[1])
    ap.add_argument("--scan", action="store_true")
    ap.add_argument("--evidence", action="append", default=[])
    ap.add_argument("--text")
    ap.add_argument("--from", dest="sender", default="")
    ap.add_argument("--channel", default="sms")
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--ic3", action="store_true")
    ap.add_argument("--rmd-removed-list", help="text file: one removed-provider name per line (from FCC RMD removal orders)")
    a = ap.parse_args()
    owner = load_owner_numbers()
    rmd = [l.strip() for l in open(a.rmd_removed_list) if l.strip()] if a.rmd_removed_list else []
    if a.text:
        ev = {"evidence_id": "adhoc", "content_excerpt": a.text, "from_number": a.sender, "channel": a.channel}
        r = analyze(ev, owner, rmd)
        r.pop("_shingles")
        r["drafts"] = side_drafts(r["identifiers"])
        r["caveat"] = CAVEAT
        print(json.dumps(r, indent=2))
        if a.ic3:
            print(ic3_block({**r, "sender": a.sender}))
        return
    paths = a.evidence or (evidence_paths() if a.scan else [])
    if not paths:
        ap.error("give --scan, --evidence, or --text")
    recs = []
    for p in paths:
        try:
            ev = json.load(open(p))
        except Exception:
            continue
        if not isinstance(ev, dict):
            continue
        r = analyze(ev, owner, rmd)
        r["recorded_facts"] = recorded_facts(ev)
        r["evidence_id"] = ev.get("evidence_id") or ev.get("id") or os.path.basename(p)
        r["path"] = p
        recs.append(r)
    camps = cluster(recs)
    by_id = {r["evidence_id"]: r for r in recs}
    now = dt.datetime.now(PT).isoformat(timespec="minutes")
    if a.write:
        for r in recs:
            p = r["path"]
            if not os.path.exists(p + ".bak-identifiers"):
                shutil.copy2(p, p + ".bak-identifiers")
            ev = json.load(open(p))
            ev["scam_identifiers"] = {"extracted_at": now, "identifiers": r["identifiers"],
                                      "pivot_platform": r["pivot_platform"], "off_platform_push": r["off_platform_push"],
                                      "sextortion_pressure": r["sextortion_pressure"], "payment_pressure": r["payment_pressure"],
                                      "sender_type": r["sender_type"], "campaign_id": r.get("campaign_id"),
                                      "spoof": r.get("spoof"), "caveat": CAVEAT}
            for t in r.get("tags", []):
                ev.setdefault("tags", [])
                if t not in ev["tags"]:
                    ev["tags"].append(t)
            json.dump(ev, open(p, "w"), indent=2)
        os.makedirs(f"{PHONE_ROOT}/evidence/_campaigns", exist_ok=True)
        json.dump({"updated_pt": now, "campaigns": camps, "caveat": CAVEAT},
                  open(f"{PHONE_ROOT}/evidence/_campaigns/campaigns.json", "w"), indent=2)
    for r in recs:
        r.pop("_shingles", None)
        r.pop("_script_links", None)
        r["drafts"] = side_drafts(r["identifiers"], r.get("recorded_facts") or {})
    print(json.dumps({"computed_at_pt": now, "records": recs, "campaigns": camps, "caveat": CAVEAT}, indent=2))
    if a.ic3:
        for c in camps:
            print(f"\n## {c['campaign_id']}\n" + ic3_block(c, by_id))
        for r in recs:
            if not r.get("campaign_id") and (r.get("tags")):
                print(f"\n## {r['evidence_id']}\n" + ic3_block(r))


if __name__ == "__main__":
    main()
