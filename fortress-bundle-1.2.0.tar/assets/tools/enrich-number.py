#!/usr/bin/env python3
"""Phone Spam Fortress - "Number intel" enrichment for a SAVED spam number.

Free public sources only (no paid CNAM / reputation APIs, no SSN, no callbacks):
  1. FCC Consumer Complaints - Unwanted Calls (opendata.fcc.gov, Socrata SODA, no key)
     dataset vakf-fz8e; matches caller_id_number OR advertiser_business_phone_number.
  2. FTC Do Not Call reported-calls API (api.ftc.gov, free api.data.gov key; DEMO_KEY
     fallback is ~10 req/hour). The API cannot filter by caller number, so we scan a
     recent window (by consumer area code and/or state) and count matches on
     company-phone-number. A zero is "not seen in the scanned window", nothing more.
  3. Original block carrier for the NPA-NXX(-X) via localcallingguide.com (free, from
     NANPA/LERG-derived public data). Porting means it may not be today's carrier.
  4. Static FTC/FCC guidance + report links (we never read anyone's private FTC data).

Never invents counts: any source that fails returns status "error"/"skipped" with an
open_url the owner can open in a browser.

Examples:
  enrich-number.py +12025550123
  enrich-number.py --evidence ../evidence/primary-cell/ev-EXAMPLE-+12025550123.json --write
  enrich-number.py 202-555-0123 --offline           # no network: links + cache only
  enrich-number.py +12025550123 --fcc-csv ~/Downloads/fcc_unwanted_calls.csv
"""
# --- Fortress portable header (v3) ---
import os as _os, json as _j
from zoneinfo import ZoneInfo as _ZI
FORTRESS_HOME = _os.environ.get("FORTRESS_HOME")
if not FORTRESS_HOME:
    raise SystemExit("FORTRESS_HOME not set: pass this bot's own workspace (from its memory), e.g. FORTRESS_HOME=... FORTRESS_INSTANCE=... python3 tool.py")
def _check_owner():
    """Fail closed: the root must carry this bot's ownership file AND FORTRESS_INSTANCE must name that same instance."""
    try: m = _j.load(open(_os.path.join(FORTRESS_HOME, ".fortress-owner.json")))
    except Exception: raise SystemExit("FORTRESS_HOME has no Fortress ownership file: run fortress_bootstrap.py init/preflight first; refusing")
    want = _os.environ.get("FORTRESS_INSTANCE")
    if not want: raise SystemExit("FORTRESS_INSTANCE not set: pass this bot's own instance id from its memory; refusing")
    if m.get("instance_id") != want:
        raise SystemExit(f"FORTRESS_HOME belongs to Fortress instance {m.get('instance_id')}, not {want}; refusing")
_check_owner()
def _owner_tz():
    tz = _os.environ.get("FORTRESS_TZ")
    if not tz:
        try: tz = _j.load(open(_os.path.join(FORTRESS_HOME, "private", "settings.json"))).get("timezone")
        except Exception: tz = None
    if not tz:
        raise SystemExit("Owner timezone not set: run fortress_bootstrap.py init --tz <IANA zone> (ask the owner)")
    return tz
OWNER_TZ_NAME = _owner_tz()
OWNER_TZ = _ZI(OWNER_TZ_NAME)
# --- end header ---

import argparse, csv, datetime as dt, json, os, re, shutil, sys, urllib.parse, urllib.request
import xml.etree.ElementTree as ET
from zoneinfo import ZoneInfo

PT = OWNER_TZ
HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(FORTRESS_HOME, "private", "cache", "enrich-number")
UA = "PhoneSpamFortress-enrich/1.0 (personal consumer evidence; contact via owner)"
FCC_DATASET = "https://opendata.fcc.gov/resource/vakf-fz8e.json"
FCC_PAGE = "https://opendata.fcc.gov/Consumer/Consumer-Complaints-Data-Unwanted-Calls/vakf-fz8e"
FCC_CSV = "https://opendata.fcc.gov/api/views/vakf-fz8e/rows.csv?accessType=DOWNLOAD"
FTC_API = "https://api.ftc.gov/v0/dnc-complaints"
STATES = {"AL":"Alabama","AK":"Alaska","AZ":"Arizona","AR":"Arkansas","CA":"California","CO":"Colorado","CT":"Connecticut","DE":"Delaware","DC":"District of Columbia","FL":"Florida","GA":"Georgia","HI":"Hawaii","ID":"Idaho","IL":"Illinois","IN":"Indiana","IA":"Iowa","KS":"Kansas","KY":"Kentucky","LA":"Louisiana","ME":"Maine","MD":"Maryland","MA":"Massachusetts","MI":"Michigan","MN":"Minnesota","MS":"Mississippi","MO":"Missouri","MT":"Montana","NE":"Nebraska","NV":"Nevada","NH":"New Hampshire","NJ":"New Jersey","NM":"New Mexico","NY":"New York","NC":"North Carolina","ND":"North Dakota","OH":"Ohio","OK":"Oklahoma","OR":"Oregon","PA":"Pennsylvania","RI":"Rhode Island","SC":"South Carolina","SD":"South Dakota","TN":"Tennessee","TX":"Texas","UT":"Utah","VT":"Vermont","VA":"Virginia","WA":"Washington","WV":"West Virginia","WI":"Wisconsin","WY":"Wyoming","PR":"Puerto Rico"}

CAVEATS = [
    "Public aggregates only; not proof of illegality or of who actually placed the call.",
    "FCC/FTC complaint data is consumer-reported and unverified; caller ID is often spoofed.",
    "Zero matches does not clear a number - many people never file, and spoofed numbers rotate.",
    "Spoof cases: if the number is likely spoofed (your own number, neighbor pattern, claimed bank/IRS on a consumer/VoIP block), the FCC/FTC counts describe the DISPLAYED number's real owner, not the caller - keep the zeros/counts logged exactly as returned and set geography to unknown.",
    "FTC DNC scan covers only the scanned window/filters shown; the API cannot search by number.",
    "Block carrier = original NPA-NXX(-X) assignee; numbers port, so it may not be the current carrier.",
    "Never call the number back; never reply HELP/anything to suspected scam numbers.",
]


def now_pt():
    return dt.datetime.now(PT).isoformat(timespec="seconds")


def http_get(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read().decode("utf-8", "replace"), dict(r.headers)


def normalize(raw):
    digits = re.sub(r"\D", "", raw or "")
    if 5 <= len(digits) <= 6:
        return {"kind": "short_code", "digits": digits, "e164": None, "dashed": None, "display": digits}
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) != 10:
        raise SystemExit(f"Not a US 10-digit number or 5-6 digit short code: {raw!r}")
    return {"kind": "nanp", "digits": digits, "e164": "+1" + digits,
            "dashed": f"{digits[:3]}-{digits[3:6]}-{digits[6:]}",
            "display": f"+1 ({digits[:3]}) {digits[3:6]}-{digits[6:]}",
            "npa": digits[:3], "nxx": digits[3:6], "x": digits[6]}


def cache_path(source, key):
    os.makedirs(os.path.join(CACHE, source), exist_ok=True)
    return os.path.join(CACHE, source, f"{key}.json")


def cache_put(source, key, obj):
    with open(cache_path(source, key), "w") as f:
        json.dump(obj, f, indent=2)


def cache_get(source, key):
    p = cache_path(source, key)
    if os.path.exists(p):
        with open(p) as f:
            o = json.load(f)
        o["status"] = "cached"
        return o
    return None


# ---------------- FCC ----------------
def fcc_where(n):
    # Dataset stores numbers as NNN-NNN-NNNN; also try bare digits defensively.
    vals = [n["dashed"], n["digits"]]
    parts = []
    for col in ("caller_id_number", "advertiser_business_phone_number"):
        for v in vals:
            parts.append(f"{col}='{v}'")
    return " OR ".join(parts)


def fcc_open_url(n):
    q = urllib.parse.urlencode({"$where": fcc_where(n), "$limit": 50})
    return f"{FCC_DATASET}?{q}"


def fcc_lookup(n, offline=False, csv_path=None):
    out = {"source": "FCC Consumer Complaints - Unwanted Calls (vakf-fz8e)", "dataset_page": FCC_PAGE,
           "bulk_csv": FCC_CSV, "open_url": fcc_open_url(n), "checked_at": now_pt()}
    if csv_path:
        return fcc_from_csv(n, csv_path, out)
    if offline:
        c = cache_get("fcc", n["digits"])
        if c:
            return c
        out.update(status="skipped_offline", hits=None)
        return out
    where = fcc_where(n)
    try:
        q = urllib.parse.urlencode({"$where": where, "$order": "issue_date DESC", "$limit": 500})
        _, body, _ = http_get(f"{FCC_DATASET}?{q}")
        rows = json.loads(body)
        if isinstance(rows, dict):
            raise RuntimeError(rows.get("message", "unexpected response"))
        out.update(status="ok", **summarize_fcc(rows, n))
        cache_put("fcc", n["digits"], out)
    except Exception as e:  # noqa
        c = cache_get("fcc", n["digits"])
        if c:
            c["live_error"] = str(e)[:300]
            return c
        out.update(status="error", error=str(e)[:300], hits=None,
                   note="Live FCC query failed; open open_url in a browser or pass --fcc-csv with the bulk CSV.")
    return out


def summarize_fcc(rows, n):
    def d(r):
        return (r.get("issue_date") or "")[:10]
    dates = sorted(x for x in (d(r) for r in rows) if x[:2] in ("19", "20"))
    by_type, by_state, by_method = {}, {}, {}
    matched_as = {"caller_id_number": 0, "advertiser_business_phone_number": 0}
    for r in rows:
        for k, bucket in (("type_of_call_or_messge", by_type), ("state", by_state), ("method", by_method)):
            v = r.get(k) or "unknown"
            bucket[v] = bucket.get(v, 0) + 1
        if re.sub(r"\D", "", r.get("caller_id_number") or "") == n["digits"]:
            matched_as["caller_id_number"] += 1
        if re.sub(r"\D", "", r.get("advertiser_business_phone_number") or "") == n["digits"]:
            matched_as["advertiser_business_phone_number"] += 1
    top = lambda b: dict(sorted(b.items(), key=lambda kv: -kv[1])[:5])
    count = len(rows)
    return {"hits": count, "capped_at_500": count >= 500,
            "first_issue_date": dates[0] if dates else None, "last_issue_date": dates[-1] if dates else None,
            "matched_as": matched_as, "by_call_type": top(by_type), "by_complainant_state": top(by_state),
            "by_method": top(by_method), "sample_complaint_ids": [r.get("id") for r in rows[:5]],
            "chip": (f"{count} FCC consumer complaint(s) list this number" if count else
                     "0 FCC complaints list this number (does not clear it)")}


def fcc_from_csv(n, path, out):
    rows = []
    with open(os.path.expanduser(path), newline="", encoding="utf-8", errors="replace") as f:
        rd = csv.DictReader(f)
        for r in rd:
            r = {k.strip().lower().replace(" ", "_").replace("/", "_"): v for k, v in r.items() if k}
            cid = re.sub(r"\D", "", r.get("caller_id_number", ""))
            adv = re.sub(r"\D", "", r.get("advertiser_business_phone_number", ""))
            if n["digits"] in (cid[-10:], adv[-10:]):
                rows.append(r)
    out.update(status="ok_offline_csv", csv_path=path, **summarize_fcc(rows, n))
    return out


# ---------------- FTC ----------------
def ftc_lookup(n, area_codes, state, days, pages, offline=False):
    key = os.environ.get("FTC_API_KEY") or os.environ.get("DATA_GOV_API_KEY") or "DEMO_KEY"
    out = {"source": "FTC Do Not Call reported calls API", "docs": "https://www.ftc.gov/developer/api/v0/endpoints/do-not-call-dnc-reported-calls-data-api",
           "data_page": "https://www.ftc.gov/policy-notices/open-government/data-sets/do-not-call-data",
           "api_key_type": "DEMO_KEY (rate-limited)" if key == "DEMO_KEY" else "personal api.data.gov key",
           "checked_at": now_pt()}
    if offline:
        out.update(status="skipped_offline", matches=None)
        return out
    since = (dt.datetime.now(PT) - dt.timedelta(days=days)).strftime("%Y-%m-%d 00:00:00")
    filters = [("area_code", a) for a in area_codes] or ([("state", state)] if state else [])
    if not filters:
        out.update(status="skipped", matches=None, note="Pass --ftc-area-code or --ftc-state (consumer side filter).")
        return out
    scanned, matches, bad, scopes, hdr = 0, [], 0, [], {}
    try:
        for fk, fv in filters:
            for p in range(pages):
                q = {"api_key": key, "items_per_page": 50, "offset": p * 50, fk: fv,
                     "created_date_from": f'"{since}"', "sort_by": "created_date", "sort_order": "DESC"}
                url = FTC_API + "?" + urllib.parse.urlencode(q)
                _, body, hdr = http_get(url)
                d = json.loads(body)
                data = d.get("data") or []
                for rec in data:
                    a = rec.get("attributes", {})
                    cpn = re.sub(r"\D", "", a.get("company-phone-number") or "")
                    created = a.get("created-date") or ""
                    if not re.match(r"^\d{4}-\d{2}-\d{2}", created):
                        bad += 1  # misaligned record (seen in DEMO_KEY tests) - skip, never count
                        continue
                    scanned += 1
                    if cpn[-10:] == n["digits"]:
                        matches.append({"created": created, "violation": a.get("violation-date"),
                                        "consumer_state": a.get("consumer-state"), "subject": a.get("subject"),
                                        "robocall": a.get("recorded-message-or-robocall")})
                if len(data) < 50:
                    break
            scopes.append(f"{fk}={fv}")
        out.update(status="ok", window_from=since, scope=scopes, records_scanned=scanned,
                   malformed_skipped=bad, matches=len(matches), match_samples=matches[:5],
                   rate_limit_remaining=hdr.get("X-Ratelimit-Remaining") or hdr.get("x-ratelimit-remaining"),
                   chip=(f"{len(matches)} FTC DNC report(s) of this number in scanned window" if matches else
                         f"0 FTC DNC reports in {scanned} scanned records (window only)"))
    except Exception as e:  # noqa
        out.update(status="error", error=str(e)[:300], matches=None, records_scanned=scanned,
                   note="Likely DEMO_KEY rate limit. Set FTC_API_KEY (free at https://api.data.gov/signup/) or retry later.")
    return out


# ---------------- Block carrier ----------------
def block_carrier(n, offline=False):
    url = f"https://www.localcallingguide.com/xmlprefix.php?npa={n['npa']}&nxx={n['nxx']}"
    out = {"source": "localcallingguide.com (public NANPA/LERG-derived prefix data)", "open_url": url,
           "nanpa_reference": "https://www.nanpa.com/reports/co-code-reports/cocodes_assign",
           "rmd_lookup": "https://fccprod.servicenowservices.com/rmd?id=rmd_listings",
           "label": "original block carrier (may have ported)", "checked_at": now_pt()}
    if offline:
        c = cache_get("block", n["npa"] + n["nxx"] + n["x"])
        if c:
            return c
        out.update(status="skipped_offline")
        return out
    try:
        _, body, _ = http_get(url)
        body = body[body.find("<root>"):]
        root = ET.fromstring(re.sub(r"&(?!amp;|lt;|gt;|quot;|apos;|#)\w+;", "", body))
        blocks = root.findall("prefixdata")
        pick = next((b for b in blocks if (b.findtext("x") or "") == n["x"]), None)
        if pick is None:
            pick = next((b for b in blocks if (b.findtext("x") or "") == "A"), None)
        if pick is None:
            out.update(status="not_found")
        else:
            out.update(status="ok", block=f"{n['npa']}-{n['nxx']}-{pick.findtext('x')}",
                       company=pick.findtext("company-name"), ocn=pick.findtext("ocn"),
                       company_type={"C": "CLEC", "I": "ILEC", "W": "Wireless", "R": "Reseller"}.get(pick.findtext("company-type"), pick.findtext("company-type")),
                       rate_center=pick.findtext("rc"), region=pick.findtext("region"))
            cache_put("block", n["npa"] + n["nxx"] + n["x"], out)
    except Exception as e:  # noqa
        out.update(status="error", error=str(e)[:300])
    return out


def guidance(n):
    g = {
        "ftc_report_url": "https://reportfraud.ftc.gov/",
        "ftc_dnc_complaint_url": "https://www.donotcall.gov/report.html",
        "ftc_dnc_verify_url": "https://www.donotcall.gov/verify.html",
        "fcc_complaint_url": "https://consumercomplaints.fcc.gov/hc/en-us",
        "fcc_robocall_guidance": "https://www.fcc.gov/consumers/guides/stop-unwanted-robocalls-and-texts",
        "carrier_spam_forward": "Forward texts to 7726 (SPAM) from the phone that received them.",
        "what_to_enter": f"Enter the number exactly as shown on your phone ({n['display']}) plus date/time and what was said.",
    }
    if n["kind"] == "short_code":
        g["short_code_registry"] = "https://www.usshortcodes.com/"
        g["short_code_note"] = ("Look up the code in the CTIA registry. Only text HELP to codes that look like a "
                                "legitimate brand program - never to suspected scams (it confirms a live number).")
    return g


def run(raw, args):
    n = normalize(raw)
    res = {"tool": "enrich-number", "version": "1.0", "checked_at": now_pt(), "timezone": OWNER_TZ_NAME,
           "number": n["e164"] or n["digits"], "number_display": n["display"], "number_kind": n["kind"]}
    res.update(guidance(n))
    if n["kind"] == "short_code":
        res.update(fcc_hits_summary=None, fcc_open_url=FCC_PAGE, ftc_dnc=None, block_carrier=None,
                   lookup_attempted={"fcc": "skipped_short_code", "ftc": "skipped_short_code", "block": "n/a"})
    else:
        fcc = None if args.no_fcc else fcc_lookup(n, args.offline, args.fcc_csv)
        ftc = None if args.no_ftc else ftc_lookup(n, args.ftc_area_code or [], STATES.get((args.ftc_state or "").upper(), args.ftc_state),
                                                  args.ftc_days, args.ftc_pages, args.offline)
        blk = None if args.no_block else block_carrier(n, args.offline)
        res["fcc_hits_summary"] = fcc if fcc and fcc.get("hits") is not None else None
        res["fcc_open_url"] = fcc_open_url(n)
        if fcc and fcc.get("hits") is None:
            res["fcc_lookup"] = fcc
        res["ftc_dnc"] = ftc
        res["block_carrier"] = blk
        res["lookup_attempted"] = {"fcc": fcc["status"] if fcc else "disabled",
                                   "ftc": ftc["status"] if ftc else "disabled",
                                   "block": blk["status"] if blk else "disabled"}
    res["caveats"] = CAVEATS
    res["status_chips"] = [c for c in [
        (res.get("fcc_hits_summary") or {}).get("chip"),
        (res.get("ftc_dnc") or {}).get("chip"),
        (f"Original block carrier: {res['block_carrier']['company']}" if (res.get("block_carrier") or {}).get("company") else None)] if c]
    return res


def from_evidence(path):
    with open(path) as f:
        ev = json.load(f)
    for k in ("from_number", "number_e164", "number_displayed", "from_number_display", "number"):
        if ev.get(k):
            return ev, ev[k]
    raise SystemExit(f"No sender number field in {path}")


def main():
    ap = argparse.ArgumentParser(description="Enrich a saved spam number with free public FCC/FTC/numbering data (never invents counts).",
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__.split("Examples:")[1])
    ap.add_argument("number", nargs="?", help="US number (any format) or 5-6 digit short code")
    ap.add_argument("--evidence", help="Path to a saved ev-*.json; number read from it")
    ap.add_argument("--write", action="store_true", help="With --evidence: merge result as `number_intel` (backup .bak-enrich) and write sidecar ev-*.number-intel.json")
    ap.add_argument("--offline", action="store_true", help="No network; return open URLs + any cached results")
    ap.add_argument("--fcc-csv", help="Scan a locally downloaded FCC bulk CSV instead of the live API")
    ap.add_argument("--ftc-area-code", action="append", help="Consumer area code(s) to scan in FTC DNC data (e.g. the owner's 503 and the caller's NPA)")
    ap.add_argument("--ftc-state", help="Consumer state (e.g. ID) to scan if no area code given")
    ap.add_argument("--ftc-days", type=int, default=14, help="FTC window in days (default 14)")
    ap.add_argument("--ftc-pages", type=int, default=2, help="FTC pages of 50 per filter (default 2; DEMO_KEY ~10 req/hr)")
    ap.add_argument("--no-fcc", action="store_true"); ap.add_argument("--no-ftc", action="store_true"); ap.add_argument("--no-block", action="store_true")
    args = ap.parse_args()
    ev = None
    raw = args.number
    if args.evidence:
        ev, raw = from_evidence(args.evidence)
        if not args.ftc_area_code and not args.ftc_state:
            n = normalize(raw)
            args.ftc_area_code = [n["npa"]] if n["kind"] == "nanp" else []
    if not raw:
        ap.error("give a number or --evidence")
    res = run(raw, args)
    if ev is not None:
        res["evidence_id"] = ev.get("evidence_id")
    if args.write and args.evidence:
        base = args.evidence[:-5] if args.evidence.endswith(".json") else args.evidence
        side = base + ".number-intel.json"
        with open(side, "w") as f:
            json.dump(res, f, indent=2)
        if not os.path.exists(args.evidence + ".bak-enrich"):
            shutil.copy2(args.evidence, args.evidence + ".bak-enrich")  # keep the pre-enrichment original
        ev["number_intel"] = {"checked_at": res["checked_at"], "sidecar": os.path.basename(side),
                              "fcc_complaint_count": (res.get("fcc_hits_summary") or {}).get("hits"),
                              "ftc_dnc_matches": (res.get("ftc_dnc") or {}).get("matches"),
                              "ftc_dnc_scope": (res.get("ftc_dnc") or {}).get("scope"),
                              "block_carrier": (res.get("block_carrier") or {}).get("company"),
                              "lookup_attempted": res.get("lookup_attempted"),
                              "status_chips": res["status_chips"],
                              "caveat": CAVEATS[0]}
        with open(args.evidence, "w") as f:
            json.dump(ev, f, indent=2)
        res["written"] = {"evidence": args.evidence, "sidecar": side, "backup": args.evidence + ".bak-enrich"}
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
