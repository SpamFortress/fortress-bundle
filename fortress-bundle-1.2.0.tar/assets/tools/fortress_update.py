#!/usr/bin/env python3
"""fortress_update.py (updater-hardening-v1) - no-reset Apply for Fortress updates.

Manifest (fortress-patch/1): {"format","lane","version":"X.Y.Z","from_min":"X.Y.Z","source_url",
  "patches":[{"id","kind":"skill"|"data"|"tool","target","sha256","body","required":true}]}

TRUST MODEL (explicit trusted controller). The controller is this bot's runtime acting for the owner. It calls
  `approve-local` only after it showed the owner the exact manifest hash and the owner said yes, and `fetch` only for
  the configured HTTPS feed. Records are bound to instance/lane/version/manifest hash/event id/issuer and sealed with
  an instance key (private/update/trust.key). Seals detect hand-written or edited records; they are NOT protection
  against hostile code running as the same user, and they are NOT proof of a native owner card. A native owner-card /
  host attestation adapter is a pending integration gate. Negative words never become a grant. A patch sha256 is body
  INTEGRITY; trust records say what was fetched/approved, not who wrote the feed (publisher authenticity unproven).
PLAN. The first Apply caches the validated plan and binds its digest (sealed) in state. Every apply/resume/rollback/
  recover/skill step re-validates the cached plan's schema, ids, targets, body hashes and binding.
FILESYSTEM. All internal and target I/O walks from FORTRESS_HOME with no-follow, fd-relative opens; any symlinked
  ancestor or leaf refuses. Backup payload names are derived from validated targets/ids, never from index pointers.
TRANSACTION. One lock. Before any mutation: version baseline backups (first-ever originals) are written and the whole
  restore set (every file, asset manifest, required skill snapshot) is pre-verified; then a journal with op/phase/
  plan digest/baseline installed version. A failed or interrupted Apply (including a repair of an already-installed
  version) restores the version baseline and, if that version was installed, steps the recorded version back, so
  bytes/manifest/version stay coherent; repair-time bytes are kept as evidence. Recovery holds (journal kept) on any
  missing/corrupt metadata instead of claiming success. Interrupted rollbacks are finished, including the version.
SKILLS. The managed skill store is never written by this helper or Shell. Per skill: snapshot-skill (old body) ->
  issue-skill-write (operation id) -> native skill-edit -> commit-skill --op-id ID --readback-file F (or --failed /
  --unknown). Without snapshot+issued id nothing completes. A readback file is controller-attested hash equality, not
  host proof; a Python NativeSkillAdapter may supply the readback directly. Failed/unknown writes keep restore work.
CONSUMERS. Run `recover-first` before preflight/check on every wake: it verifies this helper against the installed
  asset manifest, finishes/undoes interrupted transactions, then reports held work. `status` is read-only.
  check|apply --manifest F | fetch | approve-local --manifest F --sha256 H --owner-said TEXT | record-installed
  snapshot-skill|issue-skill-write|commit-skill|confirm-skill-restore | rollback --version V | recover | recover-first
  skip|remind --version V | status"""
import argparse, json, os, re, sys, hashlib, hmac, stat, errno, datetime as dt
FH = os.environ.get("FORTRESS_HOME")
if not FH: raise SystemExit("FORTRESS_HOME not set")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from fortress_owner import require as _require
    _require()
except PermissionError as _e:
    raise SystemExit(str(_e))
FH = os.path.abspath(FH); INSTANCE = os.environ.get("FORTRESS_INSTANCE", "")
UP = os.path.join(FH, "private", "update"); ST = os.path.join(UP, "state.json"); BK = os.path.join(UP, "backups")
PLANS = os.path.join(UP, "plans"); JR = os.path.join(UP, "journal.json"); LOCK = os.path.join(UP, "lock")
RECEIPTS = os.path.join(UP, "fetch-receipts.json"); APPROVALS = os.path.join(UP, "approvals.json"); FETCHED = os.path.join(UP, "fetched")
KEY = os.path.join(UP, "trust.key"); AMAN = os.path.join(FH, "manifest.json")
FMT = "fortress-patch/1"; SEMVER = re.compile(r"^(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})$")
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:._-]{0,79}$"); SKILL_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
HEX = re.compile(r"^[0-9a-f]{64}$"); MAX_PATCHES = 200; MAX_BODY = 2 * 1024 * 1024; MAX_FETCH = 8 * 1024 * 1024
STATE_SCHEMA = 2
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fortress_controller import Controller, ControllerHeld   # scope-A controller: epochs, serialized log, immutable baselines
def _ctl(): return Controller(FH, INSTANCE, "updater")
def now(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
def sha(b): return hashlib.sha256(b.encode() if isinstance(b, str) else b).hexdigest()
def canon(m): return json.dumps(m, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
def mhash(m): return sha(canon(m))
def vt(v): return tuple(int(x) for x in v.split("."))
class Held(ValueError): """Recovery or review needed; nothing (further) changed."""

# ---------------- no-follow fd-relative filesystem ----------------
def _parts(p):
    p = os.path.abspath(p); root = os.path.join(FH, "")
    if not p.startswith(root): raise ValueError(f"path outside this bot's root: {p}")
    parts = p[len(root):].split("/")
    if any(x in ("", ".", "..") for x in parts): raise ValueError(f"bad internal path {p}")
    return parts
def _root_fd():
    st = os.lstat(FH)
    if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode): raise ValueError("FORTRESS_HOME is not a real directory")
    return os.open(FH, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
def _dir_fd(dirparts, create):
    """Walk ancestors with O_NOFOLLOW; a symlinked or non-directory ancestor refuses. Returns fd or None (absent)."""
    fd = _root_fd()
    try:
        for part in dirparts:
            if create:
                try: os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError: pass
            try: nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except FileNotFoundError:
                os.close(fd); return None
            except OSError as e:
                raise ValueError(f"unsafe path component '{part}' (symlink or not a directory)") from e
            os.close(fd); fd = nxt
        return fd
    except BaseException:
        try: os.close(fd)
        except OSError: pass
        raise
def _leaf_ok(dfd, name):
    try: s = os.stat(name, dir_fd=dfd, follow_symlinks=False)
    except FileNotFoundError: return False
    if not stat.S_ISREG(s.st_mode): raise ValueError(f"'{name}' is a symlink or not a regular file; refusing")
    return True
def atomic(p, data):
    parts = _parts(p); dfd = _dir_fd(parts[:-1], create=True); leaf = parts[-1]
    try:
        _leaf_ok(dfd, leaf); tmp = ".up-" + os.urandom(8).hex()
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=dfd)
        try:
            with os.fdopen(fd, "wb") as f: f.write(data if isinstance(data, bytes) else data.encode()); f.flush(); os.fsync(f.fileno())
            os.rename(tmp, leaf, src_dir_fd=dfd, dst_dir_fd=dfd); os.fsync(dfd)
        finally:
            try: os.unlink(tmp, dir_fd=dfd)
            except FileNotFoundError: pass
    finally: os.close(dfd)
def _read(p):
    """Bytes, or None when absent. Symlinked ancestor/leaf or non-regular file raises."""
    parts = _parts(p); dfd = _dir_fd(parts[:-1], create=False)
    if dfd is None: return None
    try:
        if not _leaf_ok(dfd, parts[-1]): return None
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=dfd)
        with os.fdopen(fd, "rb") as f: return f.read()
    finally: os.close(dfd)
def _exists(p): return _read(p) is not None
def _unlink(p):
    parts = _parts(p); dfd = _dir_fd(parts[:-1], create=False)
    if dfd is None: return
    try:
        if _leaf_ok(dfd, parts[-1]): os.unlink(parts[-1], dir_fd=dfd); os.fsync(dfd)
    finally: os.close(dfd)
def load(p, d):
    """Strict JSON: genuinely absent -> default; present but unreadable/invalid -> Held (never silently reset)."""
    b = _read(p)
    if b is None: return d
    try: return json.loads(b.decode("utf-8"))
    except (UnicodeError, ValueError) as e: raise Held(f"{os.path.basename(p)} is unreadable; recovery/review needed, nothing changed") from e
_jread = load        # internal locked read-modify-write paths use this name
def jdump(p, v): atomic(p, json.dumps(v, indent=1, sort_keys=True))
def settings():
    s = load(os.path.join(FH, "private", "settings.json"), {})
    return s if isinstance(s, dict) else {}

# ---------------- state ----------------
def state():
    s = load(ST, None)
    if s is None: return {"version": STATE_SCHEMA, "installed": None, "patches": {}, "history": [], "plans": {}}
    if not isinstance(s, dict) or s.get("version", 1) not in (1, 2): raise Held("update state has an unknown schema; review needed")
    if not isinstance(s.get("patches", {}), dict) or not isinstance(s.get("history", []), list) or not isinstance(s.get("plans", {}), dict):
        raise Held("update state is malformed; review needed")
    inst = s.get("installed")
    if inst is not None and not (isinstance(inst, str) and SEMVER.match(inst)): raise Held(f"recorded installed version {inst!r} is invalid")
    s.setdefault("patches", {}); s.setdefault("history", []); s.setdefault("plans", {}); s["version"] = STATE_SCHEMA   # unknown keys preserved
    return s
def installed():
    """Recorded installed version, or None when unknown OR when state is unreadable (mutations still refuse via state())."""
    try: return state().get("installed")
    except Held: return None
def _no_pending():
    cur = load(ST, None)
    if _read(JR) is None and isinstance(cur, dict) and cur.get("pending_transaction"):
        raise Held("a pending transaction is recorded but its journal is missing; recovery needed, all update steps held")
    if _read(JR) is not None: raise Held("an interrupted update transaction is pending; run recover-first before any other update step")

# ---------------- paths ----------------
def safe_target(rel):
    if not isinstance(rel, str) or not rel or len(rel) > 240: raise ValueError(f"bad path {rel!r}")
    if os.path.isabs(rel) or "\\" in rel or any(ord(c) < 32 or ord(c) == 127 for c in rel): raise ValueError(f"bad path {rel!r}")
    parts = rel.split("/")
    if any(p in ("", ".", "..") or p.startswith(".") for p in parts): raise ValueError(f"bad path component in {rel!r}")
    if parts[0] not in ("data", "tools") or len(parts) < 2: raise ValueError(f"path outside data/ or tools/: {rel}")
    cur = FH
    if os.path.islink(FH): raise ValueError("FORTRESS_HOME is a symlink")
    for part in parts:
        cur = os.path.join(cur, part)
        if os.path.islink(cur): raise ValueError(f"symlink in path: {rel}")
    p = os.path.join(FH, *parts)
    if os.path.exists(p) and not os.path.isfile(p): raise ValueError(f"target is not a regular file: {rel}")
    return p                 # writes re-walk no-follow at use time (atomic/_read), closing check/use races

# ---------------- seals / trust ----------------
def _key():
    b = _read(KEY)
    if b is None:
        try: atomic(KEY + ".new", os.urandom(32).hex())
        except ValueError: raise
        parts = _parts(KEY); dfd = _dir_fd(parts[:-1], create=True)
        try:
            try: os.link(parts[-1] + ".new", parts[-1], src_dir_fd=dfd, dst_dir_fd=dfd, follow_symlinks=False)
            except FileExistsError: pass
            os.unlink(parts[-1] + ".new", dir_fd=dfd); os.fsync(dfd)
        finally: os.close(dfd)
        b = _read(KEY)
    k = b.decode().strip()
    if not HEX.match(k): raise Held("trust key unreadable; review needed")
    return bytes.fromhex(k)
def _seal(obj): return hmac.new(_key(), canon({k: v for k, v in obj.items() if k != "seal"}).encode(), "sha256").hexdigest()
def _sealed(obj):
    try: return isinstance(obj, dict) and isinstance(obj.get("seal"), str) and hmac.compare_digest(obj["seal"], _seal(obj))
    except Held: return False
class FetchReceipt:
    """Made only by fetch_manifest() in this module (capability-gated); not constructible from text or flags."""
    __slots__ = ("url", "manifest_sha256", "bytes_sha256", "at")
    def __init__(self, url, manifest_sha256, bytes_sha256, at, _cap=None):
        if _cap is not _CAP: raise PermissionError("fetch receipts come only from this helper's own fetch")
        self.url, self.manifest_sha256, self.bytes_sha256, self.at = url, manifest_sha256, bytes_sha256, at
_CAP = object()
def _feed_ok(feed):
    from urllib.parse import urlsplit
    if not isinstance(feed, str) or not feed.startswith("https://"): return False
    u = urlsplit(feed)
    return u.scheme == "https" and bool(u.hostname) and "@" not in u.netloc and not any(c.isspace() for c in feed)
def _http_get(url):
    """Exact configured HTTPS source only; redirects are refused before any request to another destination."""
    import urllib.request as ur, urllib.error as ue, copy
    feed = settings().get("fortress_feed_url")
    if url != feed or not _feed_ok(url): raise ValueError("refusing request: not the exact configured HTTPS feed")
    base = ur._opener or ur.build_opener(); od = ur.OpenerDirector()
    for h in base.handlers:
        if isinstance(h, ur.HTTPRedirectHandler): continue
        od.add_handler(copy.copy(h))
    req = ur.Request(url, headers={"User-Agent": "Fortress-update/1.2"})
    try:
        with od.open(req, timeout=20) as r:
            if r.geturl() != url: raise ValueError("feed answered from another URL; not the configured source")
            code = getattr(r, "status", None) or r.getcode()
            if code is not None and not 200 <= int(code) < 300: raise ValueError(f"feed answered HTTP {code}; redirects are not followed")
            b = r.read(MAX_FETCH + 1)
    except ue.HTTPError as e: raise ValueError(f"feed answered HTTP {e.code}; redirects are not followed") from None
    if len(b) > MAX_FETCH: raise ValueError("feed manifest too large")
    return b
class Lock:
    def __init__(self, wait=False): self.wait = wait
    def __enter__(self):
        import fcntl, time
        parts = _parts(LOCK); dfd = _dir_fd(parts[:-1], create=True)
        try:
            _leaf_ok(dfd, parts[-1]); fd = os.open(parts[-1], os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=dfd)
        finally: os.close(dfd)
        self.fd = fd; limit = time.monotonic() + 15
        while True:
            try: fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB); return self
            except OSError:
                if not self.wait or time.monotonic() > limit: os.close(fd); raise RuntimeError("another update step is running; try again shortly")
                time.sleep(0.02)
    def __exit__(self, *a):
        import fcntl
        fcntl.flock(self.fd, fcntl.LOCK_UN); os.close(self.fd)
def fetch_manifest():
    feed = settings().get("fortress_feed_url")
    if not feed: raise ValueError("no update source configured (fortress_feed_url unset): updates blocked, nothing guessed")
    if not _feed_ok(feed): raise ValueError("configured feed is not a plain HTTPS URL")
    b = _http_get(feed); m = json.loads(b.decode("utf-8"))
    rc = FetchReceipt(feed, mhash(m), sha(b), now(), _cap=_CAP)
    with Lock(wait=True):
        rs = _jread(RECEIPTS, {"version": 2, "items": []})
        row = {"url": rc.url, "manifest_sha256": rc.manifest_sha256, "bytes_sha256": rc.bytes_sha256, "at": rc.at, "instance": INSTANCE,
               "lane": settings().get("lane"), "version": m.get("version") if isinstance(m, dict) else None, "event": os.urandom(8).hex(), "issuer": "fortress_update.fetch"}
        row["seal"] = _seal(row); rs.setdefault("items", []).append(row); rs["version"] = 2
        path = os.path.join(FETCHED, rc.manifest_sha256 + ".json"); atomic(path, b); jdump(RECEIPTS, rs)
    return m, rc, path
NEG_WORDS = re.compile(r"(?i)\b(no|not|don'?t|do not|never|stop|cancel|wait|hold|later|skip|refuse|decline|reject|nope|nah|without)\b|n't\b")
AFF_WORDS = re.compile(r"(?i)\b(yes|yeah|yep|approve[sd]?|apply|go ahead|ok(ay)?|sure|confirm(ed|s)?|do it|proceed)\b")
def owner_words_affirmative(text):
    return isinstance(text, str) and len(text.strip()) >= 3 and bool(AFF_WORDS.search(text)) and not NEG_WORDS.search(text)
def approve_local(m, given_sha, owner_said):
    h = mhash(m)
    if not isinstance(given_sha, str) or given_sha.lower() != h: raise ValueError(f"approval must name this manifest's exact hash {h}")
    if not isinstance(owner_said, str) or len(owner_said.strip()) < 3: raise ValueError("record the owner's own words of approval")
    if not owner_words_affirmative(owner_said): raise ValueError("the owner's words are not a clear yes (negative or unclear wording is never an approval)")
    if not isinstance(m, dict) or not (isinstance(m.get("version"), str) and SEMVER.match(m["version"])): raise ValueError("approval needs a manifest with a valid version")
    with Lock(wait=True):
        a = _jread(APPROVALS, {"version": 2, "items": []})
        if not isinstance(a, dict) or not isinstance(a.get("items", []), list): raise Held("approvals record malformed; review needed")
        row = {"manifest_sha256": h, "version": m.get("version"), "lane": m.get("lane"), "instance": INSTANCE, "owner_said": owner_said.strip()[:500],
               "at": now(), "event": os.urandom(8).hex(), "issuer": "controller:approve-local", "native_card": "not attested (pending native gate)",
               "note": "controller-recorded owner yes to this exact local manifest hash; integrity + owner decision, not publisher authenticity"}
        row["seal"] = _seal(row); a.setdefault("items", []).append(row); a["version"] = 2; jdump(APPROVALS, a)
    return {"approved": h, "event": row["event"]}
def trust_of(m, evidence=None):
    """Return a trust summary or raise. evidence may only be a FetchReceipt object; strings/bools are claims."""
    h = mhash(m); s = settings(); feed = s.get("fortress_feed_url")
    if isinstance(evidence, FetchReceipt):
        if evidence.manifest_sha256 == h and feed and evidence.url == feed: return {"kind": "fetch_receipt", "url": evidence.url, "manifest_sha256": h}
        raise ValueError("fetch receipt does not match this manifest or the configured source")
    rs = load(RECEIPTS, {}); ap = load(APPROVALS, {})
    for r in (rs.get("items", []) if isinstance(rs, dict) else []):
        if isinstance(r, dict) and r.get("manifest_sha256") == h and feed and r.get("url") == feed and r.get("instance") == INSTANCE and _sealed(r):
            return {"kind": "fetch_receipt", "url": feed, "manifest_sha256": h, "at": r.get("at"), "event": r.get("event")}
    for a in (ap.get("items", []) if isinstance(ap, dict) else []):
        if isinstance(a, dict) and a.get("manifest_sha256") == h and a.get("instance") == INSTANCE and a.get("lane") == s.get("lane") \
           and a.get("version") == m.get("version") and owner_words_affirmative(a.get("owner_said")) and _sealed(a):
            return {"kind": "owner_approved_local_hash", "manifest_sha256": h, "at": a.get("at"), "event": a.get("event")}
    raise ValueError("fetch origin not proven: no receipt from this helper's own fetch of the configured feed and no owner approval of this exact hash "
                     "(a URL string, --fetched-from or a flag is a claim, not evidence)")

# ---------------- validation ----------------
def _struct_errors(m, lane=None):
    errs = []
    if not isinstance(m, dict): return ["manifest is not an object"]
    if m.get("format") != FMT: errs.append("unknown manifest format")
    if lane is not None and m.get("lane") != lane: errs.append(f"lane mismatch: manifest {m.get('lane')} vs this bot {lane}")
    v, fm = m.get("version"), m.get("from_min")
    if not (isinstance(v, str) and SEMVER.match(v)): errs.append(f"bad version {v!r} (X.Y.Z only)")
    if not (isinstance(fm, str) and SEMVER.match(fm)): errs.append(f"bad or missing from_min {fm!r}")
    elif isinstance(v, str) and SEMVER.match(v) and vt(fm) > vt(v): errs.append("from_min is newer than version")
    pats = m.get("patches")
    if not isinstance(pats, list): errs.append("patches is not a list"); pats = []
    if len(pats) > MAX_PATCHES: errs.append("too many patches")
    ids, tg = set(), set()
    for p in pats:
        if not isinstance(p, dict): errs.append("patch is not an object"); continue
        pid = p.get("id")
        if not (isinstance(pid, str) and ID_RE.match(pid)): errs.append(f"bad patch id {pid!r}")
        elif pid in ids: errs.append(f"duplicate patch id {pid}")
        ids.add(pid)
        k = p.get("kind"); t = p.get("target")
        if k not in ("skill", "data", "tool"): errs.append(f"{pid}: bad kind"); continue
        key = (k == "skill", str(t).casefold())
        if key in tg: errs.append(f"{pid}: duplicate target {t}")
        tg.add(key)
        if not isinstance(p.get("required", True), bool): errs.append(f"{pid}: required must be true/false")
        if not isinstance(p.get("body"), str): errs.append(f"{pid}: no body")
        elif len(p["body"].encode()) > MAX_BODY: errs.append(f"{pid}: body too large")
        elif not (isinstance(p.get("sha256"), str) and HEX.match(p["sha256"])) or sha(p["body"]) != p["sha256"]: errs.append(f"{pid}: body does not match sha256")
        if k == "skill":
            if not (isinstance(t, str) and SKILL_RE.match(t)): errs.append(f"{pid}: bad skill name {t!r}")
        else:
            try: safe_target(t)
            except ValueError as e: errs.append(f"{pid}: {e}")
            if k == "tool" and not str(t).startswith("tools/"): errs.append(f"{pid}: tool outside tools/")
            if k == "data" and not str(t).startswith("data/"): errs.append(f"{pid}: data outside data/")
    return errs
def validate(m, fetched_from=None, trust=True, resume_ok=True):
    s = settings(); feed = s.get("fortress_feed_url")
    errs = _struct_errors(m, s.get("lane"))
    if not isinstance(m, dict): return errs
    if not feed: errs.append("no update source configured (fortress_feed_url unset): updates blocked, nothing guessed")
    elif not _feed_ok(feed): errs.append("configured update source is not a plain HTTPS URL; updates blocked")
    elif m.get("source_url") != feed: errs.append("manifest source_url is not the configured source")
    v, fm = m.get("version"), m.get("from_min")
    if isinstance(v, str) and SEMVER.match(v) and isinstance(fm, str) and SEMVER.match(fm):
        try: st = state(); cur = st.get("installed")
        except Held as e: return errs + [str(e)]
        if cur is None: errs.append("installed version unknown: record the imported version first (record-installed)")
        else:
            bound = st["plans"].get(v, {}).get("manifest_sha256")
            same_plan = resume_ok and bound == mhash(m)
            if vt(cur) < vt(fm): errs.append(f"installed {cur} is older than from_min {fm}: needs an intermediate update")
            if vt(v) < vt(cur) or (vt(v) == vt(cur) and not same_plan): errs.append(f"version {v} is not newer than installed {cur}")
        bound_v = st["plans"].get(v, {}).get("manifest_sha256")
        if bound_v is not None and bound_v != mhash(m): errs.append(f"a different manifest was already used for version {v}; refusing to mix plans")
    if trust and not errs:
        try: trust_of(m, fetched_from if isinstance(fetched_from, FetchReceipt) else None)
        except ValueError as e: errs.append(str(e))
    return errs

# ---------------- cached plan ----------------
def _plan(version, required=False):
    if not (isinstance(version, str) and SEMVER.match(version)): raise ValueError(f"bad version {version!r}")
    p = load(os.path.join(PLANS, version + ".json"), None); st = state(); b = st["plans"].get(version)
    if p is None and b is None:
        if required: raise ValueError(f"no cached plan for {version}")
        return None
    if p is None or b is None: raise Held(f"cached plan for {version} and its sealed binding disagree; review needed")
    m = p.get("manifest") if isinstance(p, dict) else None
    if not isinstance(m, dict) or m.get("version") != version: raise Held("cached plan is damaged; refusing")
    h = mhash(m)
    if h != p.get("manifest_sha256") or h != b.get("manifest_sha256") or b.get("version") != version or b.get("instance") != INSTANCE or not _sealed(b):
        raise Held("cached plan does not match its original sealed transaction binding; refusing")
    errs = _struct_errors(m, b.get("lane"))
    if errs: raise Held("cached plan fails validation: " + "; ".join(errs))
    return {**p, "binding": b}
def _bind_plan(st, m, tr):
    v = m["version"]; h = mhash(m)
    jdump(os.path.join(PLANS, v + ".json"), {"manifest_sha256": h, "manifest": m, "trust": tr, "cached_at": now()})
    b = {"version": v, "manifest_sha256": h, "instance": INSTANCE, "lane": m["lane"], "trust_kind": tr.get("kind"), "trust_event": tr.get("event"), "at": now()}
    b["seal"] = _seal(b); st["plans"][v] = b; jdump(ST, st)

# ---------------- backups ----------------
def bname(target): return sha("target:" + target) + ".bin"
def sname(pid): return sha("skill:" + pid) + ".old"
def _file_patches(m): return [p for p in m["patches"] if p["kind"] != "skill"]
def _manifest_obj():
    b = _read(AMAN)
    if b is None: raise ValueError("installed asset manifest (manifest.json) missing: preflight would fail; nothing applied")
    try: am = json.loads(b.decode())
    except ValueError: raise Held("installed asset manifest unreadable")
    if not isinstance(am, dict): raise Held("installed asset manifest unreadable")
    return am, b
def _assets(am): return am["assets"] if isinstance(am.get("assets"), dict) else am
def _backup_all(version, m):
    bdir = os.path.join(BK, version); ip = os.path.join(bdir, "index.json")
    rec = state()["patches"].get(version, {})
    cb = _ctl().baseline(version)
    established = [p["target"] for p in _file_patches(m) if rec.get(p["id"]) is not None or (cb and p["target"] in cb.get("targets", []))]
    idx = load(ip, None)
    if idx is None:
        if established: raise Held(f"established baseline index for {version} is missing; not recapturing current bytes over the original (held for review)")
        idx = {"version": 2, "files": {}, "asset_manifest": None}
    missing = [t for t in established if t not in idx.get("files", {})]
    if missing: raise Held(f"established baseline entries missing for {missing}; not recapturing (held for review)")
    for p in _file_patches(m):
        if p["target"] in idx["files"]: continue      # first backup = the true version baseline; never overwritten
        b = _read(safe_target(p["target"]))
        if b is not None:
            atomic(os.path.join(bdir, bname(p["target"])), b); idx["files"][p["target"]] = {"existed": True, "sha256": sha(b), "file": bname(p["target"])}
        else: idx["files"][p["target"]] = {"existed": False}
    if idx.get("asset_manifest") is None:
        am, b = _manifest_obj(); atomic(os.path.join(bdir, "asset-manifest.bin"), b); idx["asset_manifest"] = {"sha256": sha(b)}
    jdump(ip, idx); return idx
def _restore_set(version, m, need_skills=()):
    """Pre-verify EVERY entry before any restore mutation. Raises Held on anything missing/corrupt."""
    bdir = os.path.join(BK, version); idx = load(os.path.join(bdir, "index.json"), None)
    if idx is None and not _file_patches(m): idx = {"files": {}, "asset_manifest": {}, "skills_only": True}
    if not isinstance(idx, dict) or not isinstance(idx.get("files"), dict) or not isinstance(idx.get("asset_manifest"), dict):
        raise Held(f"backup index for {version} missing or malformed; nothing restored (journal kept for review)")
    out = {"files": {}, "manifest": None}
    for p in _file_patches(m):
        e = idx["files"].get(p["target"])
        if not isinstance(e, dict) or not isinstance(e.get("existed"), bool): raise Held(f"required backup entry for {p['target']} missing; nothing restored")
        if e["existed"]:
            b = _read(os.path.join(bdir, bname(p["target"])))          # derived name; index 'file' pointers are ignored
            if b is None or not isinstance(e.get("sha256"), str) or sha(b) != e["sha256"]: raise Held(f"backup for {p['target']} missing or failed its hash check; nothing restored")
            out["files"][p["target"]] = b
        else: out["files"][p["target"]] = None
    mb = None if idx.get("skills_only") else _read(os.path.join(bdir, "asset-manifest.bin"))
    if idx.get("skills_only"): out["manifest"] = {}
    elif mb is None or sha(mb) != idx["asset_manifest"].get("sha256"): raise Held("asset-manifest backup missing or failed its hash check; nothing restored")
    if mb is not None:
        try: out["manifest"] = _assets(json.loads(mb.decode()))
        except ValueError: raise Held("asset-manifest backup unreadable")
    sk = load(os.path.join(bdir, "skills", "index.json"), {"skills": {}}); out["skills"] = {}
    for pid in need_skills:
        e = (sk.get("skills") or {}).get(pid)
        if not isinstance(e, dict): out["skills"][pid] = None; continue
        b = _read(os.path.join(bdir, "skills", sname(pid)))
        if b is None or sha(b) != e.get("sha256"): raise Held(f"saved old body for skill {pid} missing or corrupt; not offered as a restore plan")
        out["skills"][pid] = {"sha256": e["sha256"], "file": os.path.join(bdir, "skills", sname(pid))}
    return out
def _apply_restore(m, rs):
    """Mutations only after _restore_set succeeded."""
    files = []; upd = {}
    for p in _file_patches(m):
        tgt = safe_target(p["target"]); b = rs["files"][p["target"]]
        if b is not None: atomic(tgt, b); upd[p["target"]] = sha(b); files.append((p["target"], "restored"))
        else:
            cur = _read(tgt)
            if cur is not None and sha(cur) == p["sha256"]: _unlink(tgt); files.append((p["target"], "removed (did not exist before)"))
            elif cur is not None: files.append((p["target"], "absent before; current file not ours, left"))
            else: files.append((p["target"], "absent"))
            upd[p["target"]] = None
    if upd: _set_manifest_entries({t: rs["manifest"].get(t) for t in upd})
    return files
def _baseline_coherent(m, rs):
    am, _ = _manifest_obj(); a = _assets(am)
    for p in _file_patches(m):
        b = rs["files"][p["target"]]; cur = _read(safe_target(p["target"]))
        if b is not None and (cur is None or sha(cur) != sha(b)): return False
        if a.get(p["target"]) != rs["manifest"].get(p["target"]): return False
    return True
def _set_manifest_entries(updates):
    am, _ = _manifest_obj(); assets = _assets(am)
    for t, h in updates.items():
        if h is None: assets.pop(t, None)
        else: assets[t] = h
    atomic(AMAN, json.dumps(am, indent=1))
def _file_ok(p):
    try: b = _read(safe_target(p["target"])); return b is not None and sha(b) == p["sha256"]
    except (OSError, ValueError): return False
def _manifest_ok(m):
    am, _ = _manifest_obj(); a = _assets(am)
    return all(a.get(p["target"]) == p["sha256"] for p in _file_patches(m))
def _required_done(st, m):
    rec = st["patches"].get(m["version"], {})
    for p in m["patches"]:
        if not p.get("required", True): continue
        if p["kind"] == "skill":
            if rec.get(p["id"]) != "ok": return False
        elif rec.get(p["id"]) != "ok" or not _file_ok(p): return False
    return _manifest_ok(m)
def _maybe_advance(st, m):
    if st.get("installed") != m["version"] and _required_done(st, m):
        st["history"].append({"from": st.get("installed"), "to": m["version"], "at": now()}); st["installed"] = m["version"]

# ---------------- journal / recovery ----------------
def _journal(op, v, h, steps, st, **extra):
    j = {"schema": 2, "txid": os.urandom(8).hex(), "op": op, "version": v, "manifest_sha256": h, "phase": "mutating", "started": now(),
         "baseline_installed": st.get("installed"), "steps": steps, **extra}
    jdump(JR, j); st["pending_transaction"] = {"txid": j["txid"], "op": op, "version": v, "baseline": j["baseline_installed"], "manifest_sha256": h}; jdump(ST, st); return j
def _tx_done(st, txid): st.setdefault("completed_txids", []).append(txid)
_PHASES = ("mutating", "committed")
class _Retire(Exception): """journal belongs to the LAST completed transaction: retire it as evidence; no byte/state change"""
def _bind_journal(j, st):
    """UH1-R01: a journal is only actionable when bound to the CURRENT transaction lineage. Raises Held otherwise."""
    if j.get("schema") != 2 or not (isinstance(j.get("txid"), str) and re.fullmatch(r"[0-9a-f]{16}", j["txid"])) or j.get("phase") not in _PHASES \
       or not isinstance(j.get("steps"), dict) or any(x not in ("pending", "written") for x in j["steps"].values()) \
       or not (j.get("baseline_installed") is None or (isinstance(j.get("baseline_installed"), str) and SEMVER.match(j["baseline_installed"]))):
        raise Held("journal fields malformed; pending transaction held for review (nothing changed)")
    done = set(st.get("completed_txids", [])) | {r.get("txid") for r in st.get("recoveries", []) if isinstance(r, dict)}
    if j["txid"] in done:
        last = (st.get("completed_txids") or [None])[-1]
        if j["txid"] == last and not st.get("pending_transaction"): raise _Retire()
        raise Held("journal replays an already completed transaction; held for review (nothing changed)")
    pend = st.get("pending_transaction")
    if pend:
        for k, jk in (("txid", "txid"), ("op", "op"), ("version", "version"), ("baseline", "baseline_installed"), ("manifest_sha256", "manifest_sha256")):
            if k in pend and pend[k] != j.get(jk): raise Held(f"journal {jk} does not match the current pending transaction; held for review (nothing changed)")
        return
    # Legitimate journal-first crash (journal durable, state binding not yet written): only a MUTATING journal whose baseline is
    # exactly the current installed version may proceed. Committed or other-lineage journals without a binding are stale replays.
    if j["phase"] != "mutating" or j.get("baseline_installed") != st.get("installed"):
        raise Held("journal is not bound to the current transaction lineage (stale replay?); held for review (nothing changed)")
def _journal_phase(j, phase): j["phase"] = phase; jdump(JR, j)
def _prev_of(st, v): return next((h.get("from") for h in reversed(st["history"]) if h.get("to") == v and not h.get("rollback")), None)
def _skill_restore_needed(rec, pid):
    return rec.get(pid) not in (None, "pending_native_skill_apply", "not_applied_nothing_to_restore", "restored") or \
           bool((rec.get("_native") or {}).get(pid))
def _finish_version_rollback(st, v, m, rs, files, reason):
    _ctl().close_epoch(v, reason)          # rollback closes the current forward epoch (controller fact)
    rec = st["patches"].setdefault(v, {}); splan = []
    for p in m["patches"]:
        if p["kind"] != "skill": rec[p["id"]] = "rolled_back"; continue
        if not _skill_restore_needed(rec, p["id"]): rec[p["id"]] = "not_applied_nothing_to_restore"; continue
        s = rs["skills"].get(p["id"])
        if s: splan.append({"id": p["id"], "skill": p["target"], "restore_body_file": s["file"], "sha256": s["sha256"],
                            "steps": [f"Write this saved old body back with the native skill-edit tool (owner asked for rollback), read it back to a file, then: confirm-skill-restore --version {v} --id {p['id']} --readback-file FILE"]})
        else: splan.append({"id": p["id"], "skill": p["target"], "status": "old_body_not_captured", "action": "Cannot restore automatically: the old body was never snapshotted. Tell the owner; a fresh copy of this one skill from the pack is the fallback."})
        rec[p["id"]] = "rollback_pending_native_restore"
    prev = rec.get("_rollback", {}).get("restore_to") if rec.get("_rollback", {}).get("active") else _prev_of(st, v)
    rec["_rollback"] = {"active": bool(splan), "id": os.urandom(6).hex(), "files": files, "skills_pending": [x["id"] for x in splan], "at": now(), "restore_to": prev, "reason": reason}
    if st.get("installed") == v and not splan:
        st["installed"] = prev; st["history"].append({"from": v, "to": prev, "at": now(), "rollback": True, "reason": reason})
    return splan
def recover():
    """Finish or undo an interrupted transaction (call under Lock). Holds (raises, journal kept) on any doubt."""
    raw = _read(JR)
    if raw is None:
        if state().get("pending_transaction"): raise Held("a pending transaction is recorded but its journal is missing; recovery needed, all update steps held")
        return None
    try: j = json.loads(raw.decode())
    except ValueError: raise Held("journal unreadable; pending transaction held for review (nothing changed)")
    if not isinstance(j, dict) or j.get("op") not in ("apply", "rollback") or not (isinstance(j.get("version"), str) and SEMVER.match(j["version"])):
        raise Held("journal malformed; pending transaction held for review (nothing changed)")
    st = state()
    try: _bind_journal(j, st)
    except _Retire:
        atomic(os.path.join(UP, "retired-journals", j["txid"] + ".json"), raw); _unlink(JR)
        _ctl().fact("journal_retired", version=j.get("version"), txid=j["txid"], reason="leftover of last completed transaction")
        return {"recovered": j["txid"], "op": j.get("op"), "files": [], "result": "leftover journal of a completed transaction retired (nothing changed)"}
    v = j["version"]; plan = _plan(v)
    if set(j["steps"]) - {p["target"] for p in _file_patches(plan["manifest"]) if plan}: raise Held("journal steps name targets outside its plan; held for review")
    if plan is None or plan["manifest_sha256"] != j.get("manifest_sha256"): raise Held("journal does not match a valid cached plan; manual review needed (nothing changed)")
    m = plan["manifest"]; rec = st["patches"].setdefault(v, {})
    skills = [p["id"] for p in m["patches"] if p["kind"] == "skill" and _skill_restore_needed(rec, p["id"])]
    if j["op"] == "apply" and j.get("phase") == "committed" and all(_file_ok(p) for p in _file_patches(m)) and _manifest_ok(m):
        for p in _file_patches(m): rec[p["id"]] = "ok"
        _maybe_advance(st, m); outcome = {"recovered": j["txid"], "op": "apply", "files": [], "result": "completed (commit was durable)"}
    else:
        rs = _restore_set(v, m, skills)
        if j["op"] == "apply":
            ev = j.get("repair_evidence")
            files = _apply_restore(m, rs)
            for p in _file_patches(m): rec[p["id"]] = "rolled_back_after_interruption"
            rec["_last_error"] = f"interrupted apply {j['txid']} recovered: files restored from the version baseline"
            if st.get("installed") == v: _finish_version_rollback(st, v, m, rs, files, "interrupted repair of installed version")
        else:
            files = _apply_restore(m, rs); _finish_version_rollback(st, v, m, rs, files, "rollback")
        if not _baseline_coherent(m, rs): raise Held("post-recovery bytes/manifest are not coherent; journal kept for review")
        outcome = {"recovered": j["txid"], "op": j["op"], "files": files}
    st.pop("pending_transaction", None); _tx_done(st, j["txid"]); st.setdefault("recoveries", []).append({"txid": j["txid"], "op": j["op"], "version": v, "at": now(), "files": outcome["files"]})
    jdump(ST, st); _unlink(JR); return outcome

# ---------------- operations ----------------
def apply(m, fetched_from=None, fail_after=None):
    with Lock():
        try: rcv = recover()
        except (Held, ValueError) as e: return {"ok": False, "errors": [str(e)], "applied": [], "held": True}
        errs = validate(m, fetched_from)
        if errs: return {"ok": False, "errors": errs, "applied": [], **({"recovered": rcv} if rcv else {})}
        tr = trust_of(m, fetched_from if isinstance(fetched_from, FetchReceipt) else None)
        v = m["version"]; h = mhash(m); st = state()
        try:
            pf = os.path.join(PLANS, v + ".json"); orphan = _read(pf)
            if orphan is not None and v not in st["plans"] and _read(JR) is None:
                # plan file written but its sealed binding never committed (crash): keep as evidence, re-bind from this approved manifest
                atomic(os.path.join(PLANS, "orphan-" + os.urandom(4).hex() + "-" + v + ".json.bak"), orphan); _unlink(pf)
            if _plan(v) is None: _bind_plan(st, m, tr)
            plan = _plan(v, required=True)
            _manifest_obj()
        except (Held, ValueError) as e: return {"ok": False, "errors": [str(e)], "applied": []}
        m = plan["manifest"]; st = state(); rec = st["patches"].setdefault(v, {})
        files = _file_patches(m)
        todo = [p for p in files if not (rec.get(p["id"]) == "ok" and _file_ok(p))]   # resume re-hashes; stale "ok" is redone
        done = []
        if todo or not _manifest_ok(m):
            try:
                idx = _backup_all(v, m); skills = [p["id"] for p in m["patches"] if p["kind"] == "skill" and _skill_restore_needed(rec, p["id"])]
                rs = _restore_set(v, m, skills)
            except (Held, ValueError) as e: return {"ok": False, "errors": [str(e)], "applied": []}
            st = state(); ev = None
            if st.get("installed") == v:          # repair of an installed version: keep repair-time bytes as evidence only
                ev = os.urandom(6).hex()
                for p in todo:
                    b = _read(safe_target(p["target"]))
                    if b is not None: atomic(os.path.join(BK, v, "repair-" + ev, bname(p["target"])), b)
            j = _journal("apply", v, h, {p["target"]: "pending" for p in todo}, st, repair_evidence=ev)
            try:
                for n, p in enumerate(todo):
                    if fail_after is not None and n >= fail_after: raise IOError("simulated failure")
                    tgt = safe_target(p["target"]); atomic(tgt, p["body"])
                    rb = _read(tgt)
                    if rb is None or sha(rb) != p["sha256"]: raise IOError(f"verify failed {p['target']}")
                    done.append(p); j["steps"][p["target"]] = "written"; jdump(JR, j)
                _set_manifest_entries({p["target"]: p["sha256"] for p in files})
                if not (all(_file_ok(p) for p in files) and _manifest_ok(m)): raise IOError("post-write verification failed")
                st = state(); rec = st["patches"].setdefault(v, {})
                for p in files: rec[p["id"]] = "ok"
                rec.pop("_last_error", None); jdump(ST, st)
                _journal_phase(j, "committed")
                st = state(); st.pop("pending_transaction", None); _tx_done(st, j["txid"]); _maybe_advance(st, m); jdump(ST, st); _unlink(JR)
            except Exception as e:
                try: r = recover()
                except (Held, ValueError) as he: return {"ok": False, "errors": [str(e), "recovery held: " + str(he)], "held": True}
                st = state(); rec = st["patches"].setdefault(v, {}); rec["_last_error"] = str(e); jdump(ST, st)
                return {"ok": False, "errors": [str(e)], "rolled_back": [p["id"] for p in todo], "restored": (r or {}).get("files"), "installed": st.get("installed")}
        st = state(); rec = st["patches"].setdefault(v, {})
        for p in m["patches"]:
            if p["kind"] == "skill" and rec.get(p["id"]) != "ok": rec.setdefault(p["id"], "pending_native_skill_apply")
        _maybe_advance(st, m); jdump(ST, st)
        c = _ctl(); ip = os.path.join(BK, v, "index.json"); ib = _read(ip)
        if files and ib is not None and all(rec.get(p["id"]) == "ok" for p in files): c.establish_baseline(v, sha(ib), [p["target"] for p in files], h)
        epoch = c.open_epoch(v, h, approval_scope={"kind": "local_approval", "manifest_sha256": h}, source_rev=st.get("installed"))
        return {"ok": True, "epoch": epoch, **({"recovered": rcv} if rcv else {}), "trust": tr, "files_applied": [p["id"] for p in done], "files_verified": [p["id"] for p in files],
                "skill_plan": skill_plan(m, rec), "installed": st["installed"],
                "pending": [p["id"] for p in m["patches"] if p.get("required", True) and rec.get(p["id"]) != "ok"]}
def skill_plan(m, rec):
    v = m["version"]
    return [{"id": p["id"], "skill": p["target"], "sha256": p["sha256"], "status": rec.get(p["id"]),
             "steps": [f"1. Read the CURRENT body of skill '{p['target']}' with the bot's native skill read tool, save it to a file, then: snapshot-skill --version {v} --id {p['id']} --body-file FILE",
                       f"2. issue-skill-write --version {v} --id {p['id']}  (returns an op id; only after the owner tapped Apply)",
                       f"3. Write the new body (patch body, sha256 {p['sha256'][:12]}...) with the native skill-edit tool.",
                       f"4. Read it back natively to a file, then: commit-skill --version {v} --id {p['id']} --op-id OP --readback-file FILE  (or --failed / --unknown)",
                       "No native skill-edit tool this turn -> leave pending and say so. Never write the managed skill store through Shell."]}
            for p in m["patches"] if p["kind"] == "skill" and rec.get(p["id"]) != "ok"]
def _skill_patch(version, pid):
    plan = _plan(version, required=True)
    for p in plan["manifest"]["patches"]:
        if p["id"] == pid and p["kind"] == "skill": return plan["manifest"], p
    raise ValueError(f"{pid} is not a skill patch of {version}")
def _refuse(e): return {"ok": False, "errors": [str(e)]}
def snapshot_skill(version, pid, body):
    if not (isinstance(version, str) and SEMVER.match(version)): raise ValueError(f"bad version {version!r}")
    try:
        with Lock(wait=True):
            _no_pending(); m, p = _skill_patch(version, pid); d = os.path.join(BK, version, "skills"); ip = os.path.join(d, "index.json")
            idx = load(ip, {"version": 2, "skills": {}})
            if pid in idx["skills"]: return {"snapshot": "kept first snapshot", "sha256": idx["skills"][pid]["sha256"]}
            rec = state()["patches"].get(version, {})
            if (rec.get("_native") or {}).get(pid): return {"ok": False, "snapshot": "refused: a native write was already issued; the pre-write body can no longer be captured"}
            if not isinstance(body, str): return {"ok": False, "snapshot": "refused: no body"}
            if sha(body) == p["sha256"]: return {"snapshot": "refused: this is already the NEW body; the old body was not captured"}
            atomic(os.path.join(d, sname(pid)), body)
            idx["skills"][pid] = {"skill": p["target"], "sha256": sha(body), "file": sname(pid), "at": now()}; jdump(ip, idx)
            return {"snapshot": "saved", "sha256": sha(body)}
    except (Held, ValueError, RuntimeError) as e: return _refuse(e)
def issue_skill_write(version, pid):
    with Lock(wait=True):
        _no_pending(); m, p = _skill_patch(version, pid); st = state(); rec = st["patches"].setdefault(version, {})
        if rec.get(pid) == "ok": return {"ok": False, "errors": ["already applied and read back"]}
        why = _forward_epoch_closed(st, version, rec)
        if why: return {"ok": False, "errors": [why]}
        prior = (rec.get("_native") or {}).get(pid); ep = _ctl().current_epoch(version)
        if prior and prior.get("phase") != "read_back" and prior.get("epoch", ep) == ep:
            return {"ok": False, "errors": ["an earlier native write for this skill is unresolved (issued/unknown/failed-may-have-effects); reconcile it first, never reissue over its history"]}
        rs = _restore_set(version, m, [pid])
        if not rs["skills"].get(pid): return {"ok": False, "errors": ["snapshot-skill must capture the current (old) body before a native write is issued"]}
        if prior: rec.setdefault("_native_history", {}).setdefault(pid, []).append(prior)   # append-only: never discard earlier attempts
        op = os.urandom(8).hex(); rec.setdefault("_native", {})[pid] = {"op": op, "epoch": ep, "issued_at": now(), "phase": "issued", "outcomes": []}
        _ctl().fact("native_issue", version=version, epoch=ep, op_id=op, skill=pid)
        rec[pid] = "native_write_issued"; jdump(ST, st)
        return {"ok": True, "op_id": op, "skill": p["target"], "sha256": p["sha256"]}
def _forward_epoch_closed(st, version, rec):
    """UH1-R04: forward native work is only allowed in the current forward epoch of the current lineage."""
    rb = rec.get("_rollback") or {}
    if rb.get("active"): return f"{version} is being rolled back; forward native writes are forbidden"
    cur = st.get("installed")
    if cur is not None and vt(cur) > vt(version): return f"installed {cur} is newer than {version}; historical forward writes are forbidden"
    if not _ctl().current_epoch(version): return f"no open controller forward epoch for {version} (closed by rollback or never applied under the controller; legacy work is held); a new Apply opens one"
    return None
class NativeSkillAdapter:
    """Interface for a host adapter that reads the managed skill store itself. Subclass and implement read_skill.
    A local model of this class is a test double, not host attestation."""
    attestation = "adapter_readback"
    def read_skill(self, name): raise NotImplementedError
def commit_skill(m, pid, ok, readback=None, op_id=None, native=None, outcome=None):
    v = m["version"] if isinstance(m, dict) else m
    with Lock(wait=True):
        _no_pending(); mm, p = _skill_patch(v, pid); st = state(); rec = st["patches"].setdefault(v, {})
        nat = (rec.get("_native") or {}).get(pid)
        if not nat or not op_id or op_id != nat.get("op"):
            if rec.get(pid) != "ok":     # a write was claimed outside the protocol: it may have had effects; keep restore work
                rec[pid] = "write_claimed_without_issuance"; st["patches"][v] = rec; jdump(ST, st)
            return {"ok": False, "installed": st["installed"], "patch": rec.get(pid), "errors": ["no matching issued native write (snapshot-skill then issue-skill-write first)"]}
        why = _forward_epoch_closed(st, v, rec)
        if not why and nat.get("epoch") != _ctl().current_epoch(v): why = f"callback belongs to closed epoch {nat.get('epoch')}"
        if why:
            _ctl().fact("stale_callback", version=v, epoch=nat.get("epoch"), op_id=op_id, skill=pid, reported_ok=bool(ok), why=why)      # late forward callback: record possible effects append-only, keep restore work, never OK/advance
            nat.setdefault("outcomes", []).append({"result": "late_forward_callback_ignored", "reported_ok": bool(ok), "at": now(), "why": why})
            jdump(ST, st); return {"ok": False, "installed": st["installed"], "patch": rec.get(pid), "errors": [why + " (late callback recorded; restore work preserved)"]}
        if not ok:
            rec[pid] = "native_write_unknown" if outcome == "unknown" else "native_write_failed_may_have_effects"
            _ctl().fact("receipt_unknown" if outcome == "unknown" else "receipt_failed", version=v, epoch=nat.get("epoch"), op_id=op_id, skill=pid, hold=True)
            nat["outcomes"].append({"result": rec[pid], "at": now()})
        else:
            if isinstance(native, NativeSkillAdapter): rb = native.read_skill(p["target"]); att = native.attestation
            else: rb = readback; att = "controller_readback_file (hash equality; host attestation pending)"
            if rb is None: rec[pid] = "reported_ok_unverified"
            elif sha(rb) == p["sha256"]: rec[pid] = "ok"; nat["phase"] = "read_back"; nat["attestation"] = att
            else: rec[pid] = "readback_mismatch"
            nat["outcomes"].append({"result": rec[pid], "at": now()})
        _maybe_advance(st, mm); jdump(ST, st); return {"installed": st["installed"], "patch": rec[pid]}
def rollback(version, m=None):
    with Lock():
        try: rcv = recover()
        except (Held, ValueError) as e: return {"ok": False, "errors": [str(e)], "held": True}
        if not (isinstance(version, str) and SEMVER.match(version)): return {"ok": False, "errors": [f"bad version {version!r}"]}
        try: plan = _plan(version); st = state()
        except (Held, ValueError) as e: return {"ok": False, "errors": [str(e)]}
        if not plan: return {"ok": False, "errors": [f"no applied plan cached for {version}: nothing to roll back (caller manifests are never trusted for targets)"]}
        if m is not None and isinstance(m, dict) and m.get("patches") is not None and mhash(m) != plan["manifest_sha256"]:
            return {"ok": False, "errors": ["the given manifest is not the plan that was applied; refusing"]}
        cur = st.get("installed")
        if cur is not None and vt(cur) > vt(version):
            return {"ok": False, "errors": [f"installed {cur} is newer than {version}: roll back the later version first (no partial ancestor rollback)"]}
        cm = plan["manifest"]; rec = st["patches"].setdefault(version, {})
        if rec.get("_rollback", {}).get("active") is False and cur != version and all(rec.get(p["id"]) in ("rolled_back", "not_applied_nothing_to_restore", "restored") for p in cm["patches"]):
            return {"ok": True, "files": [], "skill_rollback_plan": [], "installed": cur, "status": "rollback_complete", "note": "already rolled back"}
        skills = [p["id"] for p in cm["patches"] if p["kind"] == "skill" and _skill_restore_needed(rec, p["id"])]
        try: rs = _restore_set(version, cm, skills); _manifest_obj()
        except (Held, ValueError) as e: return {"ok": False, "errors": [str(e)]}
        j = _journal("rollback", version, plan["manifest_sha256"], {}, st, restore_to=_prev_of(st, version))
        files = _apply_restore(cm, rs)
        if not _baseline_coherent(cm, rs): return {"ok": False, "errors": ["restored bytes not coherent; journal kept"], "held": True}
        st = state(); splan = _finish_version_rollback(st, version, cm, rs, files, "rollback")
        st.pop("pending_transaction", None); _tx_done(st, j["txid"]); jdump(ST, st); _unlink(JR)
        return {"ok": True, "files": files, "skill_rollback_plan": splan, "installed": st["installed"],
                "status": "rollback_complete" if not splan else "rollback_pending_native_skill_restore", **({"recovered": rcv} if rcv else {})}
def confirm_skill_restore(version, pid, readback, rollback_id=None):
    if not (isinstance(version, str) and SEMVER.match(version)): raise ValueError("bad version")
    with Lock(wait=True):
        _no_pending(); st = state(); rec = st["patches"].setdefault(version, {}); rb = rec.get("_rollback") or {}
        if not rb.get("active") or pid not in rb.get("skills_pending", []) or (rollback_id and rollback_id != rb.get("id")):
            raise ValueError("no active rollback with this skill outstanding; nothing confirmed")
        m = _plan(version, required=True)["manifest"]; rs = _restore_set(version, m, [pid]); s = rs["skills"].get(pid)
        if not s: raise ValueError("no saved old body for this skill")
        if sha(readback) != s["sha256"]: return {"restored": False, "why": "readback does not match the saved old body"}
        rec[pid] = "restored"; rb["skills_pending"] = [x for x in rb["skills_pending"] if x != pid]
        if not rb["skills_pending"]:
            rb["active"] = False
            if st.get("installed") == version:
                st["installed"] = rb.get("restore_to"); st["history"].append({"from": version, "to": st["installed"], "at": now(), "rollback": True})
        jdump(ST, st); return {"restored": True, "installed": st["installed"], "skills_pending": rb["skills_pending"]}
def record_installed(v):
    if not (isinstance(v, str) and SEMVER.match(v)): raise ValueError("bad version")
    with Lock(wait=True):
        _no_pending(); st = state()
        if st.get("installed") is not None: return {"installed": st["installed"], "changed": False}
        st["installed"] = v; st["history"].append({"from": None, "to": v, "at": now(), "recorded_import": True}); jdump(ST, st)
        return {"installed": v, "changed": True}
def skip_or_remind(version, action, today=None):
    if not (isinstance(version, str) and SEMVER.match(version)): raise ValueError("bad version")
    with Lock(wait=True):
        st = state(); d = dt.date.fromisoformat(today) if today else dt.date.today()
        if action == "skip": st.setdefault("skipped", {})[version] = now()
        else: st.setdefault("remind", {})[version] = {"after": (d + dt.timedelta(days=7)).isoformat(), "once": True}
        jdump(ST, st); return {"version": version, action: True, "installed": st.get("installed")}
def should_offer(version, today=None):
    st = state(); d = dt.date.fromisoformat(today) if today else dt.date.today()
    if version in st.get("skipped", {}): return False
    r = st.get("remind", {}).get(version)
    return not (r and d < dt.date.fromisoformat(r["after"]))
def status():
    out = {}
    try: out["state"] = state()
    except Held as e: out["state"] = None; out["state_error"] = str(e)
    raw = _read(JR)
    try: out["journal"] = json.loads(raw.decode()) if raw is not None else None
    except ValueError: out["journal"] = "unreadable"
    out["recovery_needed"] = raw is not None or bool((out.get("state") or {}).get("pending_transaction"))
    return out
def helper_trusted():
    """This helper's bytes must match the installed asset manifest entry (known-good recovery component)."""
    me = open(os.path.abspath(__file__), "rb").read(); am, _ = _manifest_obj()
    return _assets(am).get("tools/fortress_update.py") == sha(me)
def recover_first():
    if not helper_trusted(): return {"ok": False, "errors": ["updater helper does not match the installed asset manifest; not running recovery with an untrusted helper"]}
    with Lock(wait=True):
        try: r = recover()
        except (Held, ValueError, ControllerHeld) as e: return {"ok": False, "held": True, "errors": [str(e)]}
    return {"ok": True, "recovered": r, "status": status()}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Fortress no-reset updater")
    ap.add_argument("cmd", choices=["check", "apply", "fetch", "approve-local", "record-installed", "snapshot-skill", "issue-skill-write", "commit-skill",
                                    "confirm-skill-restore", "rollback", "recover", "recover-first", "skip", "remind", "status"])
    ap.add_argument("--manifest"); ap.add_argument("--fetched-from", help="ignored as evidence (a claim); kept for old callers")
    ap.add_argument("--version"); ap.add_argument("--id"); ap.add_argument("--ok", action="store_true"); ap.add_argument("--failed", action="store_true")
    ap.add_argument("--unknown", action="store_true"); ap.add_argument("--op-id"); ap.add_argument("--rollback-id")
    ap.add_argument("--body-file"); ap.add_argument("--readback-file"); ap.add_argument("--sha256"); ap.add_argument("--owner-said")
    a = ap.parse_args()
    def man():
        if not a.manifest: raise SystemExit("--manifest required")
        return json.load(open(a.manifest))
    try:
        if a.cmd == "check":
            m = man(); print(json.dumps({"errors": validate(m), "manifest_sha256": mhash(m), "patches": [(p.get("id"), p.get("kind"), p.get("target")) for p in m.get("patches", []) if isinstance(p, dict)]}))
        elif a.cmd == "apply": print(json.dumps(apply(man())))
        elif a.cmd == "fetch":
            m, rc, path = fetch_manifest(); print(json.dumps({"saved": path, "manifest_sha256": rc.manifest_sha256, "errors": validate(m)}))
        elif a.cmd == "approve-local": print(json.dumps(approve_local(man(), a.sha256, a.owner_said)))
        elif a.cmd == "record-installed": print(json.dumps(record_installed(a.version)))
        elif a.cmd == "snapshot-skill": print(json.dumps(snapshot_skill(a.version, a.id, open(a.body_file).read())))
        elif a.cmd == "issue-skill-write": print(json.dumps(issue_skill_write(a.version, a.id)))
        elif a.cmd == "commit-skill":
            rb = open(a.readback_file).read() if a.readback_file else None
            print(json.dumps(commit_skill(a.version or man()["version"], a.id, not (a.failed or a.unknown) and (a.ok or rb is not None), rb, op_id=a.op_id, outcome="unknown" if a.unknown else None)))
        elif a.cmd == "confirm-skill-restore": print(json.dumps(confirm_skill_restore(a.version, a.id, open(a.readback_file).read(), a.rollback_id)))
        elif a.cmd == "rollback": print(json.dumps(rollback(a.version or man()["version"], man() if a.manifest else None)))
        elif a.cmd == "recover":
            with Lock(wait=True): print(json.dumps(recover() or {"recovered": None}))
        elif a.cmd == "recover-first": print(json.dumps(recover_first()))
        elif a.cmd in ("skip", "remind"): print(json.dumps(skip_or_remind(a.version, a.cmd)))
        else: print(json.dumps(status()))
    except (ValueError, RuntimeError, PermissionError) as e:
        print(json.dumps({"ok": False, "errors": [str(e)]})); sys.exit(2)
