#!/usr/bin/env python3
"""Shared Phone + Email Fortress deadline clocks (pure date math on SAVED logs).

Clocks
  stop    SMS/call STOP / revocation: 10 US business days after the revocation
          (47 CFR 64.1200(a)(10), eff. 2025-04-11). Contact AFTER the deadline =
          "post-revocation contact past the FCC window" (strongest evidence). Contact
          after STOP but inside the window is still logged as post_stop (TCPA damages
          analysis may still use it; courts vary).
  unsub   Commercial email Unsubscribe: 10 US business days after the request
          (15 U.S.C. 7704(a)(4)(A), CAN-SPAM).
  gmail48 Gmail one-click (RFC 8058) / Manage subscriptions: bulk senders are expected
          to honor within ~48 hours. Provider guideline, NOT law -> route repeats to
          Report spam first.
  takeitdown48  TAKE IT DOWN Act: a covered platform must remove a reported
          non-consensual intimate image (and known identical copies) within 48 hours
          of a valid removal request. Start = when the removal request was sent;
          --contact = times the image was STILL visible. Still visible after 48h ->
          draft a TakeItDown.ftc.gov platform report (owner/victim files).
          Evidence never stores the image - only platform, post URL/ID, request time.

Business days = Mon-Fri excluding US federal holidays (observed: Sat->Fri, Sun->Mon).
Day 1 is the first business day AFTER the request date (owner local). Deadline is end of that
day, owner timezone.

Commands
  deadline-clocks.py compute --kind stop --start 2026-10-27T12:59:00-07:00
  deadline-clocks.py compute --kind unsub --start 2026-10-27 [--contact 2026-11-12T09:00-08:00]
  deadline-clocks.py compute --kind takeitdown48 --start 2026-10-27T21:00 [--contact 2026-10-30T09:00]
  deadline-clocks.py list                       # scan phone evidence + email receipts/evidence
  deadline-clocks.py list --write               # also store `clocks` into each evidence/receipt
  deadline-clocks.py list --due                 # only clocks that need action now
  deadline-clocks.py holidays --year 2026
Not legal advice; deadlines are informational for drafts the owner approves.
"""
# --- Fortress portable header (v3) ---
import os as _os, json as _j
from zoneinfo import ZoneInfo as _ZI
FORTRESS_HOME = _os.environ.get("FORTRESS_HOME")
if not FORTRESS_HOME:
    raise SystemExit("FORTRESS_HOME not set: pass this bot's own workspace (from its memory), e.g. FORTRESS_HOME=... FORTRESS_INSTANCE=... python3 tool.py")
def _check_owner():
    """Fail closed: the root must carry this bot's ownership file AND FORTRESS_INSTANCE must name that same instance."""
    try: m = _j.load(open(_os.path.join(FORTRESS_HOME, ".fortress-owner.json")))
    except Exception: raise SystemExit("FORTRESS_HOME has no Fortress ownership file: run fortress_bootstrap.py init/preflight first; refusing")
    want = _os.environ.get("FORTRESS_INSTANCE")
    if not want: raise SystemExit("FORTRESS_INSTANCE not set: pass this bot's own instance id from its memory; refusing")
    if m.get("instance_id") != want:
        raise SystemExit(f"FORTRESS_HOME belongs to Fortress instance {m.get('instance_id')}, not {want}; refusing")
_check_owner()
def _owner_tz():
    tz = _os.environ.get("FORTRESS_TZ")
    if not tz:
        try: tz = _j.load(open(_os.path.join(FORTRESS_HOME, "private", "settings.json"))).get("timezone")
        except Exception: tz = None
    if not tz:
        raise SystemExit("Owner timezone not set: run fortress_bootstrap.py init --tz <IANA zone> (ask the owner)")
    return tz
OWNER_TZ_NAME = _owner_tz()
OWNER_TZ = _ZI(OWNER_TZ_NAME)
# --- end header ---

import argparse, datetime as dt, glob, json, os, shutil, sys, hashlib, fcntl, tempfile
from zoneinfo import ZoneInfo

PT = OWNER_TZ  # owner timezone, not publisher
PHONE_ROOT = os.path.join(FORTRESS_HOME, "private", "phone")
EMAIL_ROOT = os.path.join(FORTRESS_HOME, "private", "email")
CITES = {
    "stop": "47 CFR 64.1200(a)(10)-(11): honor a valid revocation within a reasonable time, max 10 business days. Before 2026-11-25 any reasonable method; from 2026-11-25 a caller may designate one clearly disclosed exclusive method (FCC 26-67, 91 FR 67214). Method, category (informational vs marketing) and date must be checked before any legal conclusion.",
    "rege60": "Regulation E 12 CFR 1005.6(b)(3): report unauthorized EFTs within 60 days after the statement showing them was sent, or later unauthorized transfers may not be covered. Applies to UNAUTHORIZED transfers; payments you made yourself after being tricked may not be covered.",
    "rege2bd": "Regulation E 12 CFR 1005.6(b)(1): report a lost/stolen access device within 2 business days of learning of it to limit liability to $50 (if the conditions apply).",
    "credit60": "Fair Credit Billing Act (Regulation Z 12 CFR 1026.13): send a written billing-error notice so the card issuer receives it within 60 days after it sent the first statement showing the error.",
    "wire72": "Not a legal deadline: banks and the FBI advise asking for a wire recall/SWIFT recall as fast as possible; recovery odds drop sharply after about 72 hours. Also report at ic3.gov.",
    "unsub": "15 U.S.C. 7704(a)(4)(A) (CAN-SPAM) - no further commercial email more than 10 business days after opt-out",
    "gmail48": "Gmail bulk-sender guidelines - honor one-click unsubscribe within 48 hours (provider rule, not law)",
    "takeitdown48": "TAKE IT DOWN Act (FTC-enforced, platform duties eff. May 2026) - covered platforms remove reported NCII + known identical copies within 48 hours of a valid request; report misses at https://takeitdown.ftc.gov/",
}
H48 = ("gmail48", "takeitdown48", "wire72")
CAL60 = ("rege60", "credit60")
BD2 = ("rege2bd",)
RECOVERY = ("rege60", "rege2bd", "credit60", "wire72")
KINDS = ["stop", "unsub", "gmail48", "takeitdown48", "rege60", "rege2bd", "credit60", "wire72"]


def nth_weekday(y, m, wd, n):
    d = dt.date(y, m, 1)
    d += dt.timedelta(days=(wd - d.weekday()) % 7)
    return d + dt.timedelta(weeks=n - 1)


def last_weekday(y, m, wd):
    d = dt.date(y, m + 1, 1) - dt.timedelta(days=1) if m < 12 else dt.date(y, 12, 31)
    return d - dt.timedelta(days=(d.weekday() - wd) % 7)


def observed(d):
    return d - dt.timedelta(days=1) if d.weekday() == 5 else d + dt.timedelta(days=1) if d.weekday() == 6 else d


def federal_holidays(y):
    h = {
        observed(dt.date(y, 1, 1)): "New Year's Day",
        nth_weekday(y, 1, 0, 3): "Martin Luther King Jr. Day",
        nth_weekday(y, 2, 0, 3): "Washington's Birthday",
        last_weekday(y, 5, 0): "Memorial Day",
        observed(dt.date(y, 6, 19)): "Juneteenth",
        observed(dt.date(y, 7, 4)): "Independence Day",
        nth_weekday(y, 9, 0, 1): "Labor Day",
        nth_weekday(y, 10, 0, 2): "Columbus Day",
        observed(dt.date(y, 11, 11)): "Veterans Day",
        nth_weekday(y, 11, 3, 4): "Thanksgiving Day",
        observed(dt.date(y, 12, 25)): "Christmas Day",
    }
    nxt = dt.date(y + 1, 1, 1)
    if nxt.weekday() == 5:  # Jan 1 on Saturday -> observed Fri Dec 31 of this year
        h[dt.date(y, 12, 31)] = "New Year's Day (observed)"
    return h


def is_business_day(d):
    return d.weekday() < 5 and d not in federal_holidays(d.year)


def add_business_days(d, n):
    skipped = []
    while n > 0:
        d += dt.timedelta(days=1)
        if is_business_day(d):
            n -= 1
        elif d.weekday() < 5:
            skipped.append(f"{d.isoformat()} {federal_holidays(d.year)[d]}")
    return d, skipped


def business_days_between(a, b):
    """Business days strictly after a, up to and including b."""
    n, d = 0, a
    while d < b:
        d += dt.timedelta(days=1)
        if is_business_day(d):
            n += 1
    return n


def parse_ts(s):
    if not s:
        return None
    s = s.strip().replace("Z", "+00:00")
    try:
        t = dt.datetime.fromisoformat(s)
    except ValueError:
        t = dt.datetime.fromisoformat(s[:10])
    if t.tzinfo is None:
        t = t.replace(tzinfo=PT)
    return t.astimezone(PT)


def _u(x): return x.astimezone(dt.timezone.utc)      # all comparisons/elapsed math on real instants (UTC)
def compute(kind, start, contacts=(), now=None):
    now = now or dt.datetime.now(PT)
    st = parse_ts(start)
    if st is None: raise ValueError("no start time recorded")
    if kind in H48:
        hrs = 72 if kind == "wire72" else 48
        # elapsed-time math in UTC, then render in the owner zone (DST-safe)
        deadline = (st.astimezone(dt.timezone.utc) + dt.timedelta(hours=hrs)).astimezone(PT)
        skipped = []
        deadline_date = deadline.date()
    elif kind in CAL60:
        deadline_date = st.date() + dt.timedelta(days=60); skipped = []
        deadline = dt.datetime.combine(deadline_date, dt.time(23, 59, 59), PT)
    elif kind in BD2:
        deadline_date, skipped = add_business_days(st.date(), 2)
        deadline = dt.datetime.combine(deadline_date, dt.time(23, 59, 59), PT)
    else:
        deadline_date, skipped = add_business_days(st.date(), 10)
        deadline = dt.datetime.combine(deadline_date, dt.time(23, 59, 59), PT)
    out = {"kind": kind, "cite": CITES[kind], "start_pt": st.isoformat(timespec="minutes"),
           "deadline_pt": deadline.isoformat(timespec="minutes"),
           "deadline_rule": (f"start + {72 if kind == 'wire72' else 48} elapsed hours" if kind in H48 else "60 calendar days after the anchor date (statement sent)" if kind in CAL60
                             else "2 US business days" if kind in BD2 else "10 US business days after start date (federal holidays excluded), end of day owner local time"),
           "timezone": OWNER_TZ_NAME, "start_local": st.isoformat(timespec="minutes"), "deadline_local": deadline.isoformat(timespec="minutes"),
           "holidays_skipped": skipped,
           "business_days_elapsed": business_days_between(st.date(), now.date()),
           "computed_at_pt": now.isoformat(timespec="minutes"),
           "start_original": start if isinstance(start, str) else None,      # the recorded instant exactly as saved
           "start_utc": _u(st).isoformat(timespec="seconds"), "deadline_utc": _u(deadline).isoformat(timespec="seconds"),
           "observed_scope": "only contacts saved in Fortress evidence (forwards, pastes, opted-in connector items, owner reports)"}
    contacts_ignored = bool(kind in RECOVERY and [c for c in contacts if c])
    if kind in RECOVERY: contacts = ()     # v12 C04: recovery anchors have no 'repeat contact' semantics (never Gmail advice)
    later = sorted((parse_ts(c) for c in contacts if c and parse_ts(c) and _u(parse_ts(c)) > _u(st)), key=_u)
    after = [c for c in later if _u(c) > _u(deadline)]
    within = [c for c in later if _u(c) <= _u(deadline)]
    out["repeats_within_window"] = [c.isoformat(timespec="minutes") for c in within]
    out["repeats_after_deadline"] = [c.isoformat(timespec="minutes") for c in after]
    if after:
        out["status"] = "repeat_after_deadline"
        out["action"] = ("REVIEW: contact logged after the 10-business-day window. Before any draft, check the revocation date, the method used vs any method the caller disclosed, and whether the messages were informational or marketing (FCC 26-67). Facts only; not a legal conclusion."
                         if kind == "stop" else
                         "DRAFT READY: repeat after unsub window -> enforced-unsub-recheck widget (Junk/block, FTC draft)"
                         if kind == "unsub" else
                         "DRAFT READY: image still up >48h after removal request -> draft TakeItDown.ftc.gov platform report (victim files; never attach the image)"
                         if kind == "takeitdown48" else "Repeat after 48h one-click -> Report spam in Gmail first (provider recourse)"
                         if kind == "gmail48" else "REVIEW: later contact recorded; check the dates with the owner (no provider action implied).")
    elif within:
        out["status"] = "repeat_within_window"
        out["action"] = ("Log as post_stop:true (still evidence); re-check after deadline." if kind == "stop"
                         else "Still up inside the 48h window - re-check after the deadline." if kind == "takeitdown48"
                         else "Inside honor window - log only; re-check after deadline.")
    elif _u(now) > _u(deadline):
        out["status"] = "deadline_passed_no_repeat"
        out["honored"] = "unknown"                       # no observed repeat is never proof it was honored
        out["action"] = ("Watching: any new contact now is past the window." if kind == "stop"
                         else "Recheck due: ask the victim (do not look yourself) whether the post is gone; if still up -> TakeItDown.ftc.gov draft." if kind == "takeitdown48"
                         else "Anchor date passed: confirm with the owner what was filed and when." if kind in CAL60 + BD2 + ("wire72",)
                         else "Recheck due: no repeat observed in the evidence Fortress can see (forwards, pastes, opted-in connector items). This is not proof the sender stopped; ask the owner before marking it resolved.")
    else:
        out["status"] = "running"
        days_left = business_days_between(now.date(), deadline_date) if kind not in H48 else None
        out["business_days_left"] = days_left
        out["hours_left"] = round((_u(deadline) - _u(now)).total_seconds() / 3600, 1)
        out["action"] = "Clock running - nothing to do yet."
    if contacts_ignored:
        out["contacts_ignored"] = "later-contact times do not apply to recovery clocks (wire/RegE/credit anchors); they were not evaluated"
    out["needs_action"] = out["status"] in ("repeat_after_deadline",) or (out["status"] == "deadline_passed_no_repeat" and kind != "stop")
    out["caveat"] = "Informational date math, not legal advice. Political/charity/transactional mail or calls may fall outside these rules."
    return out


# ---------------- scanners ----------------
UNSENT_STATES = {"planned", "draft", "pending", "not_sent", "unsent", "failed", "cancelled", "canceled"}
def _explicit_unsent(d):
    """True when a record explicitly says the opt-out was NOT (yet) sent. Explicit unsent/conflicting state is authoritative."""
    if not isinstance(d, dict): return False
    if d.get("sent") is False: return True
    st = str(d.get("status") or d.get("state") or "").strip().lower()
    return st in UNSENT_STATES and not d.get("sent_at") and d.get("sent") is not True
def _stop_of(ev):
    """CONFIRMED STOP only: nested {stop:{sent:true, stop_at}} or the documented flat stop_at/stop_text/stop_channel.
    v12 C01: an explicit nested sent:false (or a planned/pending status, or flat stop_sent:false) wins over any residual flat
    stop_at; planned text/time live in stop_planned_* and never start a clock."""
    s = ev.get("stop") if isinstance(ev.get("stop"), dict) else None
    if s is not None and _explicit_unsent(s): return None
    if ev.get("stop_sent") is False or str(ev.get("stop_status") or "").lower() in UNSENT_STATES: return None
    if s and s.get("stop_at") and s.get("sent", True): return s
    if ev.get("stop_at"): return {"sent": True, "stop_at": ev["stop_at"], "stop_text": ev.get("stop_text"), "stop_channel": ev.get("stop_channel")}
    return None
_NANP = {"US", "CA", "PR", "GU", "VI", "AS", "MP", "AG", "AI", "BB", "BM", "BS", "DM", "DO", "GD", "JM", "KN", "KY", "LC", "MS", "SX", "TC", "TT", "VC", "VG"}
def _home_country():
    """Declared home region: settings.country, else the country of the configured IANA timezone (zone.tab). None = unknown."""
    try:
        st = json.load(open(os.path.join(os.environ.get("FORTRESS_HOME", ""), "private", "settings.json")))
    except Exception: st = {}
    c = str(st.get("country") or "").strip().upper()
    if len(c) == 2: return c
    tz = st.get("timezone") or os.environ.get("FORTRESS_TZ")
    if tz:
        for zt in ("/usr/share/zoneinfo/zone.tab", "/usr/share/zoneinfo/zone1970.tab"):
            try:
                for line in open(zt):
                    f = line.split("\t")
                    if len(f) >= 3 and not line.startswith("#") and f[2].strip() == tz and len(f[0]) == 2: return f[0]
            except OSError: continue
    return None
def _number_identity(raw, region=None):
    """v12 R01: full country-aware identity, no last-10 shortcut.
    +<digits>            -> ('e164', digits)
    00<digits>           -> ('e164', digits)  (international prefix)
    1 + 10 NANP digits   -> ('e164', '1'+..) only when the declared region is NANP
    10 NANP-shaped digits-> ('e164', '1'+..) only when the declared region is NANP (the only justified alias)
    <= 6 digits          -> ('short', digits) short code, per protected phone as before
    anything else        -> ('national', region or '?', digits): exact same written national number only; never merges
                            with an E.164 identity, and an unknown region never auto-matches another format."""
    t = str(raw).strip(); d = "".join(ch for ch in t if ch.isdigit())
    if len(d) < 3: return None
    if t.startswith("+"): return ("e164", d)
    if d.startswith("00") and len(d) > 8: return ("e164", d[2:])
    if len(d) <= 6: return ("short", d)
    nanp = region in _NANP
    def shape(x): return len(x) == 10 and x[0] in "23456789" and x[3] in "23456789"
    if nanp and len(d) == 11 and d[0] == "1" and shape(d[1:]): return ("e164", d)
    if nanp and shape(d): return ("e164", "1" + d)
    return ("national", region or "?", d)
def _caller_id(o):
    """Normalized caller identity (number / short code / campaign). None = unknown; unknown never matches anything (v12 C02/R01)."""
    region = (str(o.get("country") or o.get("region") or "").strip().upper() or None) if isinstance(o, dict) else None
    for k in ("from_number", "number_e164", "short_code"):
        v = o.get(k)
        if isinstance(v, (str, int)) and str(v).strip():
            ident = _number_identity(v, region if region and len(region) == 2 else _home_country())
            if ident: return ("num",) + ident
    v = o.get("campaign_id")
    if isinstance(v, str) and v.strip(): return ("campaign", v.strip().lower())
    return None
def phone_items():
    for p in sorted(glob.glob(f"{PHONE_ROOT}/evidence/*/ev-*.json")):
        if p.endswith(("-intel.json",)) or ".bak" in p:
            continue
        ev = json.load(open(p))
        stop = _stop_of(ev)
        if not stop: continue
        num = ev.get("from_number") or ev.get("number_e164")
        ident = _caller_id(ev)
        contacts = []
        # same-number later evidence = subsequent contact
        dest = ev.get("phone_id") or os.path.basename(os.path.dirname(p))
        for q in glob.glob(f"{PHONE_ROOT}/evidence/*/ev-*.json"):
            if q == p or ".bak" in q or q.endswith("-intel.json"):
                continue
            o = json.load(open(q))
            # only later contact to the SAME protected destination phone counts (household numbers stay separate)
            if (o.get("phone_id") or os.path.basename(os.path.dirname(q))) != dest:
                continue
            if ident is not None and _caller_id(o) == ident:     # unknown == unknown is NOT a match
                contacts.append(o.get("occurred_at") or o.get("received_at"))
        contacts += [c.get("at") for c in ev.get("post_stop_contacts", []) if isinstance(c, dict)]
        yield p, ev, "stop", stop["stop_at"], contacts, {"lane": "phone", "id": ev.get("evidence_id"), "who": num,
                                                           "caller_identity": "known" if ident else "unknown: later evidence is not auto-matched; add post_stop_contacts only when the owner confirms",
                                                           "entity": (ev.get("reverse_id") or {}).get("entity_name")}


def takeitdown_items():
    """Phone + email evidence may carry takeitdown_requests: [{platform, post_ref, requested_at,
    still_visible_at:[...], removed_at}] - no image data ever."""
    for root in (PHONE_ROOT, EMAIL_ROOT):
        for p in sorted(glob.glob(f"{root}/evidence/*/*.json")):
            if ".bak" in p or p.endswith("-intel.json") or p.endswith("index.json"):
                continue
            try:
                ev = json.load(open(p))
            except Exception:
                continue
            for i, r in enumerate(ev.get("takeitdown_requests") or []):
                if not r.get("requested_at") or r.get("removed_at"):
                    continue
                yield p, ev, "takeitdown48", r["requested_at"], r.get("still_visible_at", []), {
                    "lane": "phone" if root == PHONE_ROOT else "email", "id": ev.get("evidence_id"),
                    "who": r.get("platform"), "request_index": i, "request_key": _tid_key(r)}


def _tid_key(r):
    """Stable per-request clock key from the request's own identity + anchor (not from how many keys already exist)."""
    ident = json.dumps([r.get("platform"), r.get("post_ref"), r.get("requested_at")], sort_keys=True)
    return "takeitdown48_" + hashlib.sha256(ident.encode()).hexdigest()[:12]
def _rid(r): return r.get("reference_id") or r.get("receipt_id") or r.get("id")    # canonical: reference_id
def recovery_items():
    """After-click recovery anchors saved by after-click-loss-recovery at private/<lane>/recovery/incidents.json:
    {version, items:[{incident_id, kind: rege60|rege2bd|credit60|wire72, anchor_at, anchor_what, done_at}]}.
    Re-read on every recurring list scan, so a saved anchor keeps its clock across wakes."""
    for lane, root in (("phone", PHONE_ROOT), ("email", EMAIL_ROOT)):
        rp = f"{root}/recovery/incidents.json"
        if not os.path.exists(rp): continue
        try: data = json.load(open(rp))
        except Exception: continue
        for idx, r in enumerate(data.get("items", []) if isinstance(data, dict) else []):
            if not isinstance(r, dict) or r.get("done_at") or r.get("kind") not in ("rege60", "rege2bd", "credit60", "wire72") or not r.get("anchor_at"): continue
            yield rp, r, r["kind"], r["anchor_at"], [], {"lane": lane, "id": r.get("incident_id"), "who": r.get("anchor_what"), "index": idx}
def email_items():
    rp = f"{EMAIL_ROOT}/receipts/index.json"
    if os.path.exists(rp):
        recs = json.load(open(rp))
        recs = recs.get("items", []) if isinstance(recs, dict) else recs   # bootstrap schema {version, items}
        for idx, r in enumerate(recs):
            if not isinstance(r, dict): continue
            if "unsub" not in (r.get("action") or ""):
                continue
            if _explicit_unsent(r): continue                  # v12 C01: failed/unsent filing is not a received opt-out
            st = str(r.get("status") or "").lower()
            start = r.get("sent_at") or r.get("when_pt") or (r.get("filed_at") if st not in ("failed",) else None)
            contacts = [c.get("at") if isinstance(c, dict) else c for c in r.get("repeat_contacts", [])]
            if not start: continue
            meta = {"lane": "email", "id": _rid(r), "who": r.get("campaign") or r.get("what"), "index": idx}
            yield rp, r, "unsub", start, contacts, meta
            dest = json.dumps(r.get("destination", "")) + json.dumps(r.get("where", ""))
            if r.get("one_click") or "gmail" in dest.lower():
                yield rp, r, "gmail48", start, contacts, meta
    for p in sorted(glob.glob(f"{EMAIL_ROOT}/evidence/*/*.json")):
        if ".bak" in p or p.endswith("-intel.json") or p.endswith("index.json"):
            continue
        ev = json.load(open(p))
        if not isinstance(ev, dict): continue
        u = ev.get("unsub") or {}
        if not isinstance(u, dict) or _explicit_unsent(u): continue
        start = u.get("sent_at") or u.get("clicked_at") or ev.get("unsub_at")
        if not start:
            continue
        contacts = [c.get("at") if isinstance(c, dict) else c for c in ev.get("repeat_contacts", [])]
        meta = {"lane": "email", "id": ev.get("evidence_id") or ev.get("id"), "who": ev.get("original_from_domain")}
        yield p, ev, "unsub", start, contacts, meta
        if u.get("one_click") or u.get("method") == "gmail_manage_subscriptions":
            yield p, ev, "gmail48", start, contacts, meta


def cmd_list(a):
    rows, writes = [], {}
    for path, obj, kind, start, contacts, meta in list(phone_items()) + list(email_items()) + list(takeitdown_items()) + list(recovery_items()):
        c = compute(kind, start, contacts)
        rows.append({**meta, "source_file": path, **c})
        writes.setdefault(path, []).append((obj, kind, c, meta))
    if a.due:
        rows = [r for r in rows if r["needs_action"] or r["status"] == "repeat_within_window"]
    if a.write:
        for path, items in writes.items():
            if not os.path.exists(path + ".bak-clocks"):
                shutil.copy2(path, path + ".bak-clocks")
            _controller().commit_fresh(path, lambda data, path=path, items=items: _apply_fresh(path, data, items),
                                       lambda pth, mut: locked_update(pth, mut), producer="deadline-clocks", kinds=sorted({k for _, k, _c, _m in items}))
    print(json.dumps({"computed_at_pt": dt.datetime.now(PT).isoformat(timespec="minutes"),
                      "open_clocks": len(rows), "clocks": rows}, indent=2))


class ConcurrentChange(RuntimeError): pass
def locked_update(path, mutate, retries=4):
    """Shared producer protocol (v12 C03): exclusive flock on <path>.lock, read, mutate a FRESH copy, write a temp file in the
    same directory, re-verify the on-disk bytes are still the ones we read, then atomic os.replace. If another writer changed
    the file meanwhile we re-read and re-apply (its change is kept); after `retries` we abort without writing. A writer that
    ignores the lock can still race the final re-check->replace instant (documented residual)."""
    d = os.path.dirname(path) or "."
    with open(path + ".lock", "a") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        for _ in range(retries):
            with open(path, "rb") as f: before = f.read()
            data = json.loads(before)
            new = mutate(data)
            if new is None: return False
            fd, tmp = tempfile.mkstemp(prefix=".clk-", dir=d)
            try:
                with os.fdopen(fd, "w") as f: json.dump(new, f, indent=2); f.flush(); os.fsync(f.fileno())
                with open(path, "rb") as f: now_b = f.read()
                if now_b != before: continue
                os.replace(tmp, path); tmp = None; return True
            finally:
                if tmp and os.path.exists(tmp): os.unlink(tmp)
        raise ConcurrentChange(f"{path} kept changing during the clock write; nothing was overwritten")


def _controller():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from fortress_controller import Controller
    return Controller(os.environ.get("FORTRESS_HOME", ""), os.environ.get("FORTRESS_INSTANCE", ""), "deadline-clocks")
def _fresh_anchor(path, data, kind, meta):
    """Recompute the clock anchor from the FRESH locked source. None = the source no longer authorizes this clock."""
    if path.endswith("receipts/index.json") or path.endswith("recovery/incidents.json"): return "row-checked"   # exact-row compare in _apply
    if not isinstance(data, dict): return None
    if kind == "stop":
        s = _stop_of(data); return s and s.get("stop_at")
    if kind in ("unsub", "gmail48"):
        u = data.get("unsub") or {}
        if not isinstance(u, dict) or _explicit_unsent(u): return None
        return u.get("sent_at") or u.get("clicked_at") or data.get("unsub_at")
    if kind == "takeitdown48":
        for r in data.get("takeitdown_requests") or []:
            if isinstance(r, dict) and _tid_key(r) == meta.get("request_key") and r.get("requested_at") and not r.get("removed_at"): return r["requested_at"]
        return None
    return None
def _apply_fresh(path, data, items):
    """Controller plan validation: keep only clocks whose anchor recomputed from the fresh locked read equals the planned one,
    recompute the clock from that fresh anchor; stale clocks are rejected (never committed)."""
    keep, rej = [], []
    for obj, kind, c, meta in items:
        a = _fresh_anchor(path, data, kind, meta)
        planned = c.get("start_original") or c.get("start_pt")
        if a is None or (a != "row-checked" and a != planned):
            rej.append({"kind": kind, "why": "anchor/confirmation changed or no longer authorizes this clock under the fresh locked read"}); continue
        keep.append((obj, kind, c, meta))
    if not keep: return None, rej
    return _apply(path, data, keep), rej
def _apply(path, data, items):
    if True:
        if True:
            if path.endswith("receipts/index.json") or path.endswith("recovery/incidents.json"):
                lst = data.get("items", []) if isinstance(data, dict) else data
                for obj, kind, c, meta in items:
                    i = meta.get("index")
                    # exact row it came from (ids may be missing or legacy); refuse if the file changed under us
                    if i is None or i >= len(lst) or {k: v for k, v in lst[i].items() if k not in ("clocks", "recheck_after_pt")} != \
                       {k: v for k, v in obj.items() if k not in ("clocks", "recheck_after_pt")}: continue
                    lst[i].setdefault("clocks", {})[kind] = slim(c)
                    if kind == "unsub": lst[i]["recheck_after_pt"] = c["deadline_pt"][:10]
                return data
            else:
                obj = data
                if obj.get("stop_at") and not isinstance(obj.get("stop"), dict):   # explicit migration: flat STOP also saved nested
                    obj["stop"] = {"sent": True, "stop_at": obj["stop_at"], "stop_text": obj.get("stop_text"), "stop_channel": obj.get("stop_channel"), "migrated_from": "flat"}
                clocks = obj.setdefault("clocks", {})
                if any(kind == "takeitdown48" for _, kind, _c, _m in items):
                    # migrate pre-v12 count-based keys (takeitdown48_<n>) into history once; never delete them
                    legacy = {k: v for k, v in clocks.items() if k.startswith("takeitdown48_") and k[13:].isdigit()}
                    if legacy:
                        obj.setdefault("clocks_legacy_count_keys", {}).update(legacy)
                        for k in legacy: clocks.pop(k)
                for _, kind, c, m in items:
                    key = kind + ("_10bd" if kind in ("stop", "unsub") else "")
                    if kind == "takeitdown48":
                        key = m.get("request_key")
                    clocks[key] = slim(c)
                return obj


def slim(c):
    return {k: c.get(k) for k in ("kind", "start_pt", "start_original", "start_utc", "deadline_pt", "deadline_utc", "status", "honored",
                                  "repeats_after_deadline", "needs_action", "cite", "computed_at_pt", "observed_scope") if k in c}


def main():
    ap = argparse.ArgumentParser(description="STOP 10-business-day + unsubscribe + TAKE IT DOWN 48h clocks for Phone/Email Fortress.",
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__.split("Commands")[1])
    sp = ap.add_subparsers(dest="cmd", required=True)
    c = sp.add_parser("compute", help="one clock from a start date")
    c.add_argument("--kind", choices=KINDS, required=True)
    c.add_argument("--start", required=True, help="ISO date/time of STOP or Unsubscribe (owner local if no offset)")
    c.add_argument("--contact", action="append", default=[], help="Later contact time(s) to classify")
    c.add_argument("--now", help="Override 'now' (testing)")
    l = sp.add_parser("list", help="scan saved logs for open clocks")
    l.add_argument("--write", action="store_true", help="store clocks into evidence/receipts (backup .bak-clocks)")
    l.add_argument("--due", action="store_true", help="only clocks needing action / repeats")
    h = sp.add_parser("holidays", help="print US federal holidays (observed)")
    h.add_argument("--year", type=int, default=dt.date.today().year)
    a = ap.parse_args()
    if a.cmd == "compute" and a.kind in RECOVERY and a.contact:
        ap.error("--contact does not apply to recovery clocks (wire72/rege60/rege2bd/credit60)")
    if a.cmd == "compute":
        print(json.dumps(compute(a.kind, a.start, a.contact, parse_ts(a.now) if a.now else None), indent=2))
    elif a.cmd == "list":
        cmd_list(a)
    else:
        print(json.dumps({d.isoformat(): n for d, n in sorted(federal_holidays(a.year).items())}, indent=2))


if __name__ == "__main__":
    main()
