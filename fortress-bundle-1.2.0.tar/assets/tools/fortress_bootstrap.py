#!/usr/bin/env python3
"""fortress_bootstrap.py (v3) - create / verify / migrate ONE bot's private Fortress workspace.

All agents of an owner share one Linux box, so a fixed default folder would be shared by every bot. Instead each
bot instance gets its own root under ~/fortress-data/instances/<instance_id>/ where instance_id is a RANDOM
namespace created once at first setup and then remembered in THIS bot's own memory (the bot saves the printed
`remember` line). Every helper call passes FORTRESS_HOME (and FORTRESS_INSTANCE) explicitly; helpers refuse to run
on a root whose ownership marker names a different instance. Paired bots keep separate roots.

  init      --tz ZONE --lane phone|email [--instance ID] [--home DIR]   create (or re-open own) workspace; all opt-ins OFF
  preflight --instance ID [--home DIR] [--manifest F]                    ownership + hashes + schema migration + private copies
  verify    --manifest F [--home DIR]
Exit codes: 0 ok, 2 ownership mismatch/collision, 3 hash mismatch, 4 bad args."""
import argparse, json, os, hashlib, sys, secrets, tempfile, datetime as dt, shutil
from zoneinfo import ZoneInfo
SCHEMA_VERSION = 3
MARKER = ".fortress-owner.json"
def V(**k): return {"version": 1, **k}
PRIVATE_FILES = {
 "settings.json": {"schema_version": SCHEMA_VERSION, "timezone": None, "country": None, "us_state": None, "lane": None,
                   "inbox_label_scan": "off", "label_scan_schedule": None, "x_dm_lane": "off", "forward_to_bot": "off",
                   "caregiver_sharing": "off", "outbound_calls": "off", "elder_speak": "off", "quiet_mode": "quiet",
                   "trusted_authserv_ids": [], "installed_fortress_version": None, "fortress_feed_url": None},
 "identity.md": "# Identity (private)\nFill only what the owner provides. Never export.\n",
 "safelist.json": {"version": 2, "categories": {c: [] for c in ["banks_and_cards", "auth_and_security", "delivery_and_orders",
                   "health_and_pharmacy", "government", "family_and_contacts", "caregiver"]}, "brands": {}, "vip": [],
                   "auth_keywords": "on", "near_misses": []},
 "phone/evidence/index.json": V(items=[]), "email/evidence/index.json": V(items=[]),
 "email/receipts/index.json": V(items=[]), "optout-log.json": V(items=[], pending_owner=[]),
 "call-queue.json": V(items=[]), "who-sold/map.json": V(aliases=[]), "who-sold/signup-log.json": V(items=[]),
 "breach-watch.json": V(brands=[]), "settlement-ledger.json": V(items=[]),
 "junk-mail/log.jsonl": "", "email/regulator-packets/queue.json": V(items=[]),
 "household.json": V(phones=[]), "pairing.json": {"version": 1, "sibling": None, "status": "unpaired", "pending_relays": []},
 "privacy-watch/state.json": {}, "update/state.json": {"version": 1, "installed": None, "patches": {}, "history": []},
}
PRIVATE_DIRS = ["phone/evidence", "phone/letters", "email/evidence", "caregiver", "email/label-scan", "privacy-watch/snapshots",
                "cache/enrich-number", "update/backups", "templates"]
PRIVATE_TEMPLATE_COPIES = {"data/elder-defense.md": "templates/elder-defense.md"}   # fillable copies; data/ stays read-only
def atomic_write(p, val):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".fb-", dir=os.path.dirname(p))
    with os.fdopen(fd, "w") as f:
        f.write(val if isinstance(val, str) else json.dumps(val, indent=1)); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, p)
def base_dir(): return os.path.join(os.path.expanduser("~"), "fortress-data", "instances")
def root_for(a, instance):
    return os.path.abspath(a.home) if getattr(a, "home", None) else os.path.join(base_dir(), instance)
def read_marker(h):
    p = os.path.join(h, MARKER)
    return json.load(open(p)) if os.path.exists(p) else None
def fail(code, msg): print(json.dumps({"ok": False, "error": msg})); sys.exit(code)
def init(a):
    try: ZoneInfo(a.tz)
    except Exception: fail(4, f"not an IANA timezone: {a.tz!r}; ask the owner")
    a.instance = getattr(a, "instance", None); a.lane = getattr(a, "lane", None)
    inst = a.instance or ("fx-" + secrets.token_hex(8))
    h = root_for(a, inst)
    m = read_marker(h)
    if m and m.get("instance_id") != inst:
        fail(2, f"{h} belongs to another Fortress bot (instance {m.get('instance_id')}); refusing to reuse it")
    if not m:
        if os.path.exists(os.path.join(h, "private")):
            fail(2, f"{h} has an unowned private/ folder; refusing to adopt it - pick a new folder")
        os.makedirs(h, exist_ok=True)
        try:   # exclusive create = collision safeguard if two bots race for the same name
            fd = os.open(os.path.join(h, MARKER), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            fail(2, "another bot claimed this folder at the same moment; run init again without --instance")
        with os.fdopen(fd, "w") as f:
            json.dump({"instance_id": inst, "lane": a.lane, "created": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                       "schema_version": SCHEMA_VERSION}, f)
    for d in ("tools", "data", "private"): os.makedirs(os.path.join(h, d), exist_ok=True)
    for d in PRIVATE_DIRS: os.makedirs(os.path.join(h, "private", d), exist_ok=True)
    created = []
    for rel, val in PRIVATE_FILES.items():
        p = os.path.join(h, "private", rel)
        if os.path.exists(p): continue          # never overwrite this bot's own existing state
        if rel == "settings.json": val = {**val, "timezone": a.tz, "lane": a.lane}
        atomic_write(p, val); created.append(rel)
    os.chmod(os.path.join(h, "private"), 0o700)
    mig = migrate(h)
    print(json.dumps({"ok": True, "instance_id": inst, "home": h, "timezone": a.tz, "created_private": sorted(created), "migrated": mig,
                      "remember": f"Fortress instance {inst}, FORTRESS_HOME={h} (pass both on every helper call)"}))
def migrate(h):
    """Narrow, non-destructive schema migrations of THIS bot's private files. Populated data is never dropped."""
    done = []; P = lambda r: os.path.join(h, "private", r)
    def load(r):
        try: return json.load(open(P(r)))
        except Exception: return None
    def put(r, v, why): atomic_write(P(r), v); done.append(f"{r}: {why}")
    for r, key in [("email/receipts/index.json", "items"), ("optout-log.json", "items"), ("call-queue.json", "items"),
                   ("settlement-ledger.json", "items"), ("email/regulator-packets/queue.json", "items"), ("who-sold/signup-log.json", "items"),
                   ("phone/evidence/index.json", "items"), ("email/evidence/index.json", "items")]:
        v = load(r)
        if isinstance(v, list): put(r, V(**{key: v}), "list -> {version, items}")
        elif isinstance(v, dict) and "entries" in v:
            ent = v.pop("entries") or []; cur = v.get(key) or []
            nv = {**v, key: cur + [e for e in ent if e not in cur]}; nv.setdefault("version", 1)
            put(r, nv, "entries merged into items (nothing dropped)")
    v = load("optout-log.json")
    if isinstance(v, dict) and "pending_owner" not in v: v["pending_owner"] = []; put("optout-log.json", v, "add pending_owner")
    v = load("who-sold/map.json")
    if isinstance(v, dict) and "aliases" not in v:
        put("who-sold/map.json", V(aliases=[{"alias": k, **(x if isinstance(x, dict) else {"site": x})} for k, x in v.items() if k != "version"]), "{alias: site} -> aliases[]")
    v = load("breach-watch.json")
    if isinstance(v, dict) and "brands" not in v:
        nv = {k: x for k, x in v.items() if k != "items"}; nv["brands"] = v.get("items", []); nv.setdefault("version", 1)
        put("breach-watch.json", nv, "items -> brands (all other fields kept)")
    v = load("phone/evidence/index.json")
    if isinstance(v, dict) and "phones" in v:   # household numbers belong in household.json, not the evidence index
        hh = load("household.json") or V(phones=[])
        hh["phones"] += [p for p in v.pop("phones") if p not in hh["phones"]]; put("household.json", hh, "phones moved from evidence index")
        put("phone/evidence/index.json", v, "phones removed (moved to household.json)")
    v = load("safelist.json")
    if isinstance(v, dict) and v.get("version", 1) < 2:
        put("safelist.json", migrate_safelist(v), "legacy -> v2 categories (every entry and unknown field kept)")
    s = load("settings.json")
    if isinstance(s, dict):
        ch = False
        if "last_seen_fortress_version" in s and "installed_fortress_version" not in s:
            s["installed_fortress_version"] = s.pop("last_seen_fortress_version"); ch = True
        for k, dv in PRIVATE_FILES["settings.json"].items():
            if k not in s: s[k] = dv; ch = True
        if s.get("schema_version") != SCHEMA_VERSION: s["schema_version"] = SCHEMA_VERSION; ch = True
        if ch: put("settings.json", s, "settings fields added (existing values kept)")
    for src, dst in PRIVATE_TEMPLATE_COPIES.items():
        if os.path.exists(os.path.join(h, src)) and not os.path.exists(P(dst)):
            shutil.copy2(os.path.join(h, src), P(dst)); done.append(f"private copy {dst}")
    return done
CATS = ["banks_and_cards", "auth_and_security", "delivery_and_orders", "health_and_pharmacy", "government", "family_and_contacts", "caregiver"]
def _entries(val):
    """Legacy category value -> list of {address}|{domain,...}; returns (entries, leftover_fields)."""
    out, rest = [], {}
    if isinstance(val, list): items = val
    elif isinstance(val, dict):
        items = []
        for k, x in val.items():
            if k in ("domains", "domain"): items += [d if isinstance(d, dict) else {"domain": d} for d in (x if isinstance(x, list) else [x])]
            elif k in ("addresses", "address", "senders"): items += [d if isinstance(d, dict) else {"address": d} for d in (x if isinstance(x, list) else [x])]
            else: rest[k] = x
    else: items = [val]
    for i in items:
        if isinstance(i, str): out.append({"address": i.lower()} if "@" in i else {"domain": i.lower()})
        elif isinstance(i, dict): out.append(i)
    return out, rest
def migrate_safelist(v):
    """Lossless legacy -> v2. Known category keys become entry lists; non-entry fields (e.g. keywords) go to
    category_meta; always_allow becomes family_and_contacts entries AND is kept verbatim; unknown keys are kept."""
    cats = {c: [] for c in CATS}; meta = json.loads(json.dumps(v.get("category_meta") or {}))
    def _merge_meta(c, rest):
        m = meta.setdefault(c, {})
        for k, x in rest.items():
            if isinstance(x, list) and isinstance(m.get(k), list): m[k] = m[k] + [y for y in x if y not in m[k]]
            elif k not in m: m[k] = x
            elif m[k] != x: m.setdefault("_conflicts", []).append({k: x})
    canon = v.get("categories") or {}
    for c in list(dict.fromkeys(CATS + list(canon))):
        for src in (canon.get(c), v.get(c) if c in CATS else None):      # canonical AND legacy top-level: both kept
            if src is None: continue
            e, rest = _entries(src); cats.setdefault(c, []).extend(x for x in e if x not in cats[c])
            if rest: _merge_meta(c, rest)
    for a in v.get("always_allow", []) or []:
        e, _ = _entries([a]); cats["family_and_contacts"].extend(x for x in e if x not in cats["family_and_contacts"])
    unc = [{"address": x.lower()} for x in v.get("addresses", []) if isinstance(x, str)] + [x if isinstance(x, dict) else {"domain": x} for x in v.get("domains", [])]
    if unc: cats.setdefault("uncategorized", []).extend(unc)
    keep = {k: x for k, x in v.items() if k not in CATS and k not in ("categories", "addresses", "domains", "version")}
    out = {**keep, "version": 2, "categories": cats, "brands": v.get("brands", {}), "vip": v.get("vip", []),
           "auth_keywords": v.get("auth_keywords", "on"), "near_misses": v.get("near_misses", [])}
    if meta: out["category_meta"] = meta
    return out
def check_hashes(h, manifest):
    m = json.load(open(manifest)); m = m.get("assets", m); bad = []
    for rel, sha in m.items():
        p = os.path.join(h, rel)
        if not os.path.exists(p): bad.append(("missing", rel)); continue
        if hashlib.sha256(open(p, "rb").read()).hexdigest() != sha: bad.append(("hash", rel))
    return bad
def preflight(a):
    h = root_for(a, a.instance); m = read_marker(h)
    if not m: fail(2, f"no Fortress workspace at {h}; run init (after the owner agrees)")
    if m.get("instance_id") != a.instance: fail(2, f"{h} belongs to instance {m.get('instance_id')}, not {a.instance}")
    man = a.manifest or os.path.join(h, "manifest.json")
    bad = check_hashes(h, man) if os.path.exists(man) else [("missing", "manifest.json")]
    if bad: print(json.dumps({"ok": False, "problems": bad, "fix": "rewrite these files from the fortress-tools/data asset blocks"})); sys.exit(3)
    for d in PRIVATE_DIRS: os.makedirs(os.path.join(h, "private", d), exist_ok=True)
    for rel, val in PRIVATE_FILES.items():
        p = os.path.join(h, "private", rel)
        if not os.path.exists(p):
            if rel == "settings.json": fail(2, "settings.json missing; run init again with --instance")
            atomic_write(p, val)
    print(json.dumps({"ok": True, "home": h, "instance_id": a.instance, "migrated": migrate(h)}))
def verify(a):
    h = os.path.abspath(a.home) if a.home else os.environ.get("FORTRESS_HOME")
    if not h: fail(4, "pass --home")
    bad = check_hashes(h, a.manifest); print(json.dumps({"ok": not bad, "problems": bad})); sys.exit(3 if bad else 0)
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd", required=True)
    i = sp.add_parser("init"); i.add_argument("--tz", required=True); i.add_argument("--home"); i.add_argument("--instance"); i.add_argument("--lane", default=None)
    p = sp.add_parser("preflight"); p.add_argument("--instance", required=True); p.add_argument("--home"); p.add_argument("--manifest")
    v = sp.add_parser("verify"); v.add_argument("--manifest", required=True); v.add_argument("--home")
    a = ap.parse_args(); {"init": init, "preflight": preflight, "verify": verify}[a.cmd](a)
