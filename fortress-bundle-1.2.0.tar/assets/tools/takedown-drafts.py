#!/usr/bin/env python3
"""takedown-drafts.py - build a DRAFT takedown bundle from a saved Email Fortress evidence file.

Never sends anything. Never visits the phishing link. Network use (optional, --hosting):
DNS-over-HTTPS A lookup (dns.google) + RDAP IP lookup (rdap.org) to find the hosting network abuse contact.

Usage:
  python3 takedown-drafts.py --evidence evidence/primary-mail/ev-....json [--hosting] [--brand apple] [--out letters/takedown/<id>]
  python3 takedown-drafts.py --list-brands

Output folder: one Markdown draft per destination + bundle.json (status=draft, sent=false).
The owner reviews, edits, and sends. After each send, log a receipt (email-report-receipts).
"""
# --- Fortress portable header (v3) ---
import os as _os, json as _j
from zoneinfo import ZoneInfo as _ZI
FORTRESS_HOME = _os.environ.get("FORTRESS_HOME")
if not FORTRESS_HOME:
    raise SystemExit("FORTRESS_HOME not set: pass this bot's own workspace (from its memory), e.g. FORTRESS_HOME=... FORTRESS_INSTANCE=... python3 tool.py")
def _check_owner():
    """Fail closed: the root must carry this bot's ownership file AND FORTRESS_INSTANCE must name that same instance."""
    try: m = _j.load(open(_os.path.join(FORTRESS_HOME, ".fortress-owner.json")))
    except Exception: raise SystemExit("FORTRESS_HOME has no Fortress ownership file: run fortress_bootstrap.py init/preflight first; refusing")
    want = _os.environ.get("FORTRESS_INSTANCE")
    if not want: raise SystemExit("FORTRESS_INSTANCE not set: pass this bot's own instance id from its memory; refusing")
    if m.get("instance_id") != want:
        raise SystemExit(f"FORTRESS_HOME belongs to Fortress instance {m.get('instance_id')}, not {want}; refusing")
_check_owner()
def _owner_tz():
    tz = _os.environ.get("FORTRESS_TZ")
    if not tz:
        try: tz = _j.load(open(_os.path.join(FORTRESS_HOME, "private", "settings.json"))).get("timezone")
        except Exception: tz = None
    if not tz:
        raise SystemExit("Owner timezone not set: run fortress_bootstrap.py init --tz <IANA zone> (ask the owner)")
    return tz
OWNER_TZ_NAME = _owner_tz()
OWNER_TZ = _ZI(OWNER_TZ_NAME)
def _owner_local(s):
    """Convert a saved instant to the owner zone BEFORE labeling it with that zone; the original is kept alongside.
    No offset saved -> it is shown as recorded, labeled 'as recorded' (never relabeled as owner time)."""
    import datetime as _dt
    if not s: return "unknown"
    try: x = _dt.datetime.fromisoformat(str(s).strip().replace("Z", "+00:00"))
    except ValueError: return f"{s} (as recorded)"
    if x.tzinfo is None: return f"{s} (as recorded; no time zone saved)"
    loc = x.astimezone(OWNER_TZ).isoformat(timespec="seconds")
    return f"{loc} ({OWNER_TZ_NAME})" + ("" if loc == str(s) else f"; recorded as {s}")
# --- end header ---

import argparse, json, os, re, sys, urllib.request, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = FORTRESS_HOME
DIRECTORY = os.path.join(ROOT, "data", "brand-abuse-directory.json")
IDENTITY = os.path.join(ROOT, "private", "identity.md")
TZ = OWNER_TZ

BRAND_HINTS = {  # keyword in subject/from/summary -> directory id (verified entries only)
    "usps": "usps_uspis", "postal": "usps_uspis", "package delivery": "usps_uspis",
    "apple": "apple_phish", "icloud": "apple_phish", "itunes": "apple_phish",
    "paypal": "paypal", "irs": "irs", "treasury": "irs",
    "amazon": "amazon_verify", "t.me/": "telegram_abuse", "telegram": "telegram_abuse",
    "bitcoin": "chainabuse", "btc": "chainabuse", "crypto": "chainabuse", "usdt": "chainabuse",
}

def now():
    return datetime.datetime.now(TZ).isoformat(timespec="seconds")

def defang(s):
    return (s or "").replace("http", "hxxp").replace(".", "[.]")

def owner_addresses():
    addrs = set()
    try:
        for m in re.finditer(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", open(IDENTITY).read()):
            addrs.add(m.group(0).lower())
    except FileNotFoundError:
        pass
    return addrs

def scrub(text, addrs):
    out = text or ""
    for a in addrs:
        out = re.sub(re.escape(a), "[recipient removed]", out, flags=re.I)
        local = a.split("@")[0]
        out = re.sub(re.escape(local) + r"(\+[^@\s]*)?@[A-Za-z0-9.-]+", "[recipient removed]", out, flags=re.I)
    out = re.sub(r"([?&](ct|uid|email|e|u|token|t|id)=)[^&\s]+", r"\1[token removed]", out, flags=re.I)
    return out

def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "EmailFortress-takedown-drafts/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)

def hosting_lookup(host):
    """DoH A record + RDAP IP abuse contact. Does NOT connect to the host itself."""
    res = {"host": host, "ip": None, "network": None, "abuse_email": None, "checked_at": now(), "source": None}
    try:
        d = get_json(f"https://dns.google/resolve?name={host}&type=A")
        ips = [a["data"] for a in d.get("Answer", []) if a.get("type") == 1]
        if not ips:
            res["error"] = "no A record"; return res
        res["ip"] = ips[0]
        r = get_json(f"https://rdap.org/ip/{ips[0]}")
        res["network"] = f"{r.get('name')} ({r.get('handle')})"
        res["source"] = f"https://rdap.org/ip/{ips[0]}"
        def walk(ents):
            for e in ents or []:
                v = (e.get("vcardArray") or [None, []])[1]
                emails = [x[3] for x in v if x[0] == "email"]
                if "abuse" in (e.get("roles") or []) and emails and not res["abuse_email"]:
                    res["abuse_email"] = emails[0]
                walk(e.get("entities"))
        walk(r.get("entities"))
    except Exception as ex:
        res["error"] = str(ex)[:200]
    return res

def load_intel(ev, ev_path):
    di = ev.get("domain_intel") or {}
    side = di.get("sidecar")
    if side:
        p = os.path.join(os.path.dirname(ev_path), side)
        if os.path.exists(p):
            return json.load(open(p)).get("domains", [])
    return di.get("domains", [])

def md(path, text):
    with open(path, "w") as f:
        f.write(text.rstrip() + "\n")

HEADER = "> **DRAFT - not sent.** Review, edit, and send it yourself. Then tell the bot so it can log a receipt.\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--evidence")
    ap.add_argument("--hosting", action="store_true", help="Look up the hosting network abuse contact for each link host (DoH + RDAP; no visit)")
    ap.add_argument("--brand", action="append", default=[], help="Force a verified directory id (see --list-brands)")
    ap.add_argument("--out")
    ap.add_argument("--list-brands", action="store_true")
    a = ap.parse_args()
    directory = json.load(open(DIRECTORY))
    ver = {e["id"]: e for e in directory["verified"]}
    if a.list_brands:
        for k, e in ver.items():
            print(f"{k:22} {e.get('address') or e.get('handle') or e.get('web_form')}  <- {e['source_url']}")
        return
    if not a.evidence:
        ap.error("--evidence required")
    ev = json.load(open(a.evidence))
    ev_id = ev.get("evidence_id") or os.path.basename(a.evidence).replace(".json", "")
    out = a.out or os.path.join(ROOT, "private", "email", "letters", "takedown", ev_id)
    os.makedirs(out, exist_ok=True)
    addrs = owner_addresses() | {str(ev.get(k, "")).lower() for k in ("destination", "forwarded_from") if ev.get(k)}
    addrs.discard("")
    # identity.md may quote spammer addresses in logs: never scrub the sender's own domain
    fd = (ev.get("original_from_domain") or "").lower()
    addrs = {x for x in addrs if fd and not x.endswith("@" + fd) and not x.endswith("." + fd) or not fd}
    intel = load_intel(ev, a.evidence)
    links = ev.get("links") or {}
    link_hosts = sorted({h for h in (links.get("cta_host"), links.get("unsub_host")) if h})
    from_dom = ev.get("original_from_domain")
    subj = scrub(ev.get("subject", ""), addrs)
    frm = scrub(ev.get("original_from", ""), addrs)
    summary = scrub(ev.get("content_summary", ""), addrs)
    occurred = _owner_local(ev.get("occurred_at"))
    # v12 D02: only a RECORDED owner allegation becomes "reports as fraudulent"; hosting only when actually looked up
    _v = str(ev.get("verdict") or "").strip().lower()
    alleged = ev.get("owner_allegation") or (_v if _v in {"scam", "phishing", "phish", "fraud", "fraudulent", "likely_scam"} else None)
    allegation_line = ("the recipient reports as fraudulent" if alleged else
                       "the recipient saved for review (no fraud allegation is recorded; please assess it yourself)")
    when_line = f"Received {occurred}."
    drafts = []

    evidence_block = f"""- Received: {occurred}
- From (as displayed): {frm}
- Subject: {subj}
- What it does: {summary}
- Link host(s) (defanged; the bot did not visit them): {', '.join(defang(h) for h in link_hosts) or 'n/a'}"""

    # 1. Registrar abuse for each registered domain with an abuse email
    for d in intel:
        dom, ab = d.get("domain"), d.get("abuse_email")
        if ab:
            role = "sending domain" if from_dom and from_dom.endswith(dom) else "link domain"
            fn = f"registrar-{dom}.md"
            md(os.path.join(out, fn), f"""{HEADER}
**To:** {ab}
**Subject:** Abuse report: {dom} used in a suspected scam email ({role})

Hello {d.get('registrar') or 'registrar'} abuse team,

I am reporting abuse involving **{defang(dom)}** (registered with you; IANA ID {d.get('registrar_iana_id') or 'n/a'}, per RDAP checked {d.get('checked_at','')}).
This domain appears as the {role} in an email {allegation_line}. What the recipient recorded: {summary or 'see evidence below'}

{evidence_block}

The domain is {d.get('domain_age_days','?')} days old. Please investigate under your abuse policy and the ICANN Registrar Accreditation Agreement (section 3.18), and suspend or notify the registrant as appropriate.

I can provide the full message headers on request. I have removed my own address and tracking tokens from this report.

Thank you.
""")
            drafts.append({"file": fn, "to": ab, "type": "registrar_abuse", "domain": dom, "source": d.get("rdap_url") or "rdap"})

    # 2. ccTLD / CERT.br and hosting network
    hosting = []
    if a.hosting:
        for h in link_hosts:
            hosting.append(hosting_lookup(h))
    for d in intel:
        if (d.get("domain") or "").endswith(".br"):
            dom = d["domain"]
            hosts_for = [x for x in hosting if x["host"].endswith(dom)]
            to = ", ".join(sorted({x["abuse_email"] for x in hosts_for if x.get("abuse_email")})) or "[hosting network abuse contact - run with --hosting]"
            fn = f"hosting-{dom}-cc-certbr.md"
            serving_line = (f"A host on your network (per the lookup below) appears in link(s) from an email {allegation_line}." if hosts_for else
                            f"The link host below appeared in an email {allegation_line}. Hosting was NOT looked up, so whether it is on your network is unverified.")
            net_lines = "\n".join(f"- {x['host']} resolves to {x.get('ip')} - network {x.get('network')} (RDAP {x.get('source')}, checked {x['checked_at']})" for x in hosts_for) or "- (hosting not looked up)"
            md(os.path.join(out, fn), f"""{HEADER}
**To:** {to}
**Cc:** cert@cert.br  (CERT.br asks reporters to write to the network where the activity is hosted and Cc them: https://www.cert.br/contato/)
**Subject:** Phishing / scam landing host on your network: {defang(link_hosts[0] if link_hosts else dom)}

Hello abuse team,

{serving_line} Recorded summary: {summary or "n/a"}

{evidence_block}

Hosting details:
{net_lines}

Registered domain: **{defang(dom)}** (registro.br; created {d.get('created') or 'not recorded'}). Who owns it, and whether this host was compromised or set up by the sender: not recorded (unknown). Please investigate and, if you find abusive content, take it down.

I can provide full headers on request. My own address and tracking tokens are removed.

Thank you.
""")
            drafts.append({"file": fn, "to": to, "cc": "cert@cert.br", "type": "hosting_abuse_cc_certbr", "domain": dom})
    for x in hosting:
        if x.get("abuse_email") and not any(x["host"].endswith(dd.get("domain", "~")) and dd.get("domain", "").endswith(".br") for dd in intel):
            fn = f"hosting-{x['host']}.md"
            md(os.path.join(out, fn), f"""{HEADER}
**To:** {x['abuse_email']}
**Subject:** Phishing landing host on your network: {defang(x['host'])} ({x.get('ip')})

Hello abuse team,

{evidence_block}

{x['host']} resolves to {x.get('ip')} on your network {x.get('network')} (RDAP {x.get('source')}, checked {x['checked_at']}). Please investigate and remove the abusive content.

My own address and tracking tokens are removed.
""")
            drafts.append({"file": fn, "to": x["abuse_email"], "type": "hosting_abuse"})

    # 3. Forward-as-is inboxes + web forms
    apwg, net, gsb = ver["apwg"], ver["netcraft_mail"], ver["google_safe_browsing"]
    md(os.path.join(out, "forward-apwg-netcraft.md"), f"""{HEADER}
**How:** In Apple Mail / iCloud Mail, forward the ORIGINAL message (not the bot's copy) **as an attachment** if you can (Apple Mail on Mac: Message > Forward as Attachment), otherwise a normal Forward.
**To:** {apwg['address']}, {net['address']}
**Subject:** Fwd: {subj}
**Body (optional one line):** Suspected phishing reported by the recipient. {when_line} Link host: {', '.join(defang(h) for h in link_hosts)}.

Heads-up: a forward as-is includes your own address and full headers. That is normal for these inboxes (APWG: {apwg['source_url']}; Netcraft: {net['source_url']}).
""")
    drafts.append({"file": "forward-apwg-netcraft.md", "to": f"{apwg['address']}, {net['address']}", "type": "forward_as_is"})
    md(os.path.join(out, "web-safe-browsing.md"), f"""{HEADER}
**Where:** {gsb['web_form']}  (you open this; the bot does not submit forms)
**URL to report:** paste the link host from the evidence, re-fanged (remove the [.] brackets and change hxxp back to http), for example: {', '.join(defang('https://' + h + '/') for h in link_hosts)}
**Additional details box (copy):**
Suspected phishing/scam email reported by the recipient. {when_line} Sender displayed: {frm}. What the recipient recorded: {summary or 'n/a'}

Optional second form: Netcraft URL report at {net['web_form']} (needs JavaScript in your browser).
""")
    drafts.append({"file": "web-safe-browsing.md", "to": gsb["web_form"], "type": "web_form"})

    # 4. Brand inboxes (verified only). Brands with no verified inbox are listed, never guessed.
    unverified = [u for u in directory.get("unverified_do_not_use", []) if any(k in (subj + " " + summary).lower() for k in u.get("match", []))]
    blob = " ".join([subj, frm, summary, " ".join(link_hosts)]).lower()
    brand_ids = list(dict.fromkeys(a.brand + [v for k, v in BRAND_HINTS.items() if k in blob]))
    for bid in brand_ids:
        e = ver.get(bid)
        if not e:
            print(f"skip {bid}: not in verified directory", file=sys.stderr); continue
        fn = f"brand-{bid}.md"
        how = {"forward_as_attachment": "Forward the original **as an attachment**",
               "forward_as_is": "Forward the original message as-is",
               "web_form": "Open the web form and paste the details",
               "in_app_message": "Send a message from your own app account",
               "user_email": "Send this email yourself",
               "cc_on_network_abuse_mail": "Cc on the network abuse email"}.get(e["method"], e["method"])
        md(os.path.join(out, fn), f"""{HEADER}
**Destination:** {e['name']} - {e.get('address') or e.get('handle') or e.get('web_form')}
**How:** {how}. {('Subject: ' + e['subject']) if e.get('subject') else ''}
**Source (official page, checked {e['verified_at']}):** {e['source_url']}
**Note:** {e.get('notes','')}
**One-line body (optional):** Suspected impersonation. {when_line} Subject: "{subj}".
""")
        drafts.append({"file": fn, "to": e.get("address") or e.get("handle") or e.get("web_form"), "type": "brand", "brand_id": bid})

    bundle = {"tool": "takedown-drafts", "version": "1.0", "evidence_id": ev_id, "created_at": now(),
              "timezone": OWNER_TZ_NAME, "status": "draft", "sent": False,
              "rule": "Draft only. Owner sends. One receipt per destination after send (email-report-receipts).",
              "drafts": drafts, "hosting_lookups": hosting,
              "privacy": "Registrar/hosting drafts have the owner's address and URL tracking tokens removed. Forward-as-is destinations will see the owner's address."}
    json.dump(bundle, open(os.path.join(out, "bundle.json"), "w"), indent=2)
    lines = [f"# Takedown draft bundle - {ev_id}", "", HEADER, f"Created {bundle['created_at']} ({OWNER_TZ_NAME}). Nothing has been sent.", "",
             "| # | File | Goes to | Type |", "|---|---|---|---|"]
    for i, d in enumerate(drafts, 1):
        lines.append(f"| {i} | `{d['file']}` | {d['to']}{(' (Cc ' + d['cc'] + ')') if d.get('cc') else ''} | {d['type']} |")
    for u in unverified:
        lines.append(f"\n**No verified inbox for {u.get('name')}** - {u.get('why','').rstrip('.')}. Do not guess an address; the registrar/hosting/APWG reports above cover it.")
    lines += ["", "After you send any of these, say which ones so the bot can log one receipt each."]
    md(os.path.join(out, "README.md"), "\n".join(lines))
    print(json.dumps({"out": out, "drafts": [d["file"] for d in drafts]}, indent=2))

if __name__ == "__main__":
    main()
