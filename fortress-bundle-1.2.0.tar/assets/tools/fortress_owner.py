#!/usr/bin/env python3
"""fortress_owner.py - fail-closed ownership check shared by stateful helpers (label_scan, caregiver_state, fortress_update).
require(path=None) -> FORTRESS_HOME after verifying: FORTRESS_HOME set, ownership file present, FORTRESS_INSTANCE set and equal,
and (if a path is given) the path resolves inside FORTRESS_HOME. Raises PermissionError otherwise."""
import os, json
MARKER = ".fortress-owner.json"
def require(path=None):
    h = os.environ.get("FORTRESS_HOME")
    if not h: raise PermissionError("FORTRESS_HOME not set; refusing")
    try: m = json.load(open(os.path.join(h, MARKER)))
    except Exception: raise PermissionError("no Fortress ownership file in FORTRESS_HOME; run init/preflight; refusing")
    want = os.environ.get("FORTRESS_INSTANCE")
    if not want: raise PermissionError("FORTRESS_INSTANCE not set; refusing")
    if m.get("instance_id") != want: raise PermissionError(f"root belongs to instance {m.get('instance_id')}, not {want}; refusing")
    if path is not None:
        rp, rh = os.path.realpath(path), os.path.realpath(h)
        if not (rp == rh or rp.startswith(rh + os.sep)): raise PermissionError(f"{path} is outside this bot's FORTRESS_HOME; refusing")
    return h
