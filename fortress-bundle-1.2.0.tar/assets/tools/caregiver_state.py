#!/usr/bin/env python3
"""caregiver_state.py (schema 8/contract 2, unpublished local adapter contract) - Caregiver View-only sharing: consent, exact content, timing and a crash-safe dispatcher.

Recipient: proposed -> sample_shown -> consented -> active -> stopped (1-5 people; stopped people count again if re-added).
CONSENT uses a bounded positive grammar tied to ONE structured sample/person. by="owner" is bookkeeping, NOT origin proof,
tied to the exact sample shown, its scope and the RESOLVED DESTINATION ADDRESS shown on that sample. Refusals,
negations (any apostrophe form, "cannot"), conditions, questions, third-party relays and mixed answers are rejected.
CONTENT is never free text: messages are built only by render() from structured, allowlisted fields (counts, sender
domains, fixed reason/pattern/next-step codes, a local date). The gate requires the exact rendered text, re-scans it
against the default AND custom Never list, and refuses anything that differs from render().
DISPATCH: presend_gate() checks everything immediately before a send and, when it passes, RESERVES the message in a
durable journal ($FORTRESS_HOME/private/caregiver/dispatch-journal/<id>.json, created with O_EXCL, fsynced). Only one
process can ever hold a reservation. A reservation without a recorded result (crash, timeout) blocks every retry until
reconcile() records what the send tool's own sent record shows. Generic toggles (drafts off, standby) are never
permission: a send needs this person's consent, the send tool present this turn and the app's send permission.
TIMING: owner-zone (IANA) daily/weekly slots with DST-correct local time, missed-wake catch-up as ONE batch, ~15-minute
Immediate batches, same-day high-risk alerts only for people whose scope includes them, 90-day review pause.
STOP: footer in every message; the reply arrives in this bot's OWN inbox (the only receive route) and the inbox routine
calls `inbound` first, before anything else; it stops only the person whose consented address sent it.
CLI (state file is locked for every command):
  due --state S [--now T] | batch --state S --rid R [--now T] | render --state S --id I
  claim --state S --id I --from ADDR --to ADDR --tools T1,T2 --permission P --text-file F [--now T]
  result --state S --id I --outcome sent|failed|unknown | reconcile --state S --id I --outcome sent|not_sent --evidence E
  inbound --state S --from ADDR --to ADDR --subject SUBJ --text-file F | stop --state S --rid R | stop-all --state S"""
import email.utils
import json, hashlib, time, re, os, sys, argparse, tempfile, unicodedata, contextlib, threading, datetime as dt
from zoneinfo import ZoneInfo
NEVER_DEFAULT = ["passwords", "codes", "pins", "vault_contents", "full_card_or_account_numbers", "ssn_or_id_numbers",
                 "message_bodies", "attachments", "reset_or_login_links", "location", "bank_pharmacy_medical_details",
                 "protected_sender_content", "unrelated_personal_mail"]
SCOPES = {"digest", "high_risk_alert"}
TIMINGS = ("immediate", "daily", "weekly")
IMMEDIATE_BATCH_S = 15 * 60
REVIEW_S = 90 * 86400
COUNT_KEYS = ("reported_blocked", "unsubscribed", "held")
HELD_REASONS = {"unknown_sender": "unknown sender", "protected_needs_review": "looked like a protected sender, not verified",
                "payment_request": "asked for a payment", "sign_in_wording": "sign-in or code wording", "lookalike_domain": "look-alike address"}
PATTERNS = {"gift_card_request": "gift-card payment request", "crypto_request": "crypto payment request", "wire_request": "wire-transfer request",
            "remote_access_request": "remote-access request", "family_emergency": "family-emergency money request",
            "government_demand": "government payment demand", "romance_money": "online-relationship money request"}
NEXT_STEPS = {"call_known_number": "call a number {owner} already has; don't use a number from the message.",
              "check_in": "check in with {owner} the way you usually do.", "no_action": "nothing to do; it was handled."}
SEND_PERMISSIONS = {"approval_card_approved", "app_send_permission_present"}
# Documented host tools that can deliver an email under the app's own approval policy. A name match is NOT authority:
# the host's card/permission still decides; this list only refuses invented tool names.
NATIVE_SEND_TOOLS = {"DraftExternalMessage", "SendEmail"}
RECEIPT_STATES = {"prepared": "prepared (not yet sent)", "filed": "filed", "confirmed": "confirmed by the company", "pending": "waiting for an answer",
                  "honored": "honored", "not_honored": "not honored yet"}
STEPS = {"report_prepared": "a report was prepared", "report_filed": "a report was filed", "sender_blocked": "the sender was blocked",
         "unsubscribed": "an unsubscribe was done", "held_for_review": "a message was held for review", "owner_told": "the owner was told"}
SENDER_KINDS = {"email": None, "phone": "Unknown caller", "sms": "Unknown SMS", "short_code": "Unknown SMS", "unknown": "Unknown sender"}
SENDER_DISPLAYS = {"Unknown caller", "Unknown SMS", "Short code", "Unknown sender", "Unknown email sender"}
NOT_PERMISSION = {"drafts_disabled", "standby", "generic_toggle", "sharing_on"}
def _valid_name(n):
    """Bounded first names in any script: letters/marks/digits, single spaces, hyphen, apostrophe; no controls/bidi."""
    if not isinstance(n, str): return False
    n2 = unicodedata.normalize("NFC", n)
    if n2 != n or not (1 <= len(n) <= 30) or n != n.strip() or "  " in n: return False
    if unicodedata.category(n[0])[0] not in "LN": return False
    return all(unicodedata.category(ch)[0] in "LMN" or ch in " -'" for ch in n)
DOMAIN_RE = re.compile(r"^(?=.{1,80}$)[a-z0-9-]+(\.[a-z0-9-]+)+$")
ADDR_RE = re.compile(r"^[^@\s<>\"]+@[a-z0-9-]+(\.[a-z0-9-]+)+$")

def new(owner_never=None):
    defaults = [x for x in (owner_never or []) if x in NEVER_DEFAULT]
    return {"version": 8, "contract_revision": 2, "revision": 0, "quarantine": [], "delivered_sources": {}, "source_bindings": {}, "delivered_events": {}, "state_id": os.urandom(6).hex(), "sharing": "off", "recipients": {}, "queue": [], "sent_log": {},
            "never": sorted(set(NEVER_DEFAULT) | set(defaults)), "never_custom": [x for x in (owner_never or []) if x not in NEVER_DEFAULT],
            "max_recipients": 5, "own_inbox": None, "send_tool": None, "owner_name": None, "daily_hour": 18, "weekly_day": 6,
            "timezone": None, "inbox_checked_at": None, "log": []}
def migrate(st):
    legacy = st.get("version", 0) < 8 or st.get("contract_revision", 0) < 2
    for k, v in new().items(): st.setdefault(k, v)      # (a migrated state gets its own state_id once)
    # legacy custom Never entries (anything outside the defaults) become enforced custom terms AND tags; nothing is deleted
    custom = list(st.get("never_custom") or [])
    for x in st.get("never", []):
        if x not in NEVER_DEFAULT and x not in custom: custom.append(x)
    st["never_custom"] = custom; st["never"] = sorted(set(st.get("never", [])) | set(NEVER_DEFAULT))
    for r in st["recipients"].values():
        r.setdefault("destination", None); r.setdefault("last_slot", 0); r.setdefault("first_notice_sent", False)
        if r.get("state") in ("active", "consented") and (legacy or not _valid_sample(st, r)): r["sample_refresh_required"] = True
    st["version"] = 8; st["contract_revision"] = 2; return st
def _h(s): return hashlib.sha256(s.encode()).hexdigest()[:16]
def _now(now): return int(now if now is not None else time.time())
def _addr(a): return (a or "").strip().lower()

# ---------------- ownership, journal, disk ----------------
def _home():
    from fortress_owner import require
    return require()
ID_RE = re.compile(r"^[0-9a-f]{16}$")
JNAME_RE = re.compile(r"^[0-9a-f]{16}\.json(?:\.(?:attempt|issued|abandoned)-[0-9]+)?$")
@contextlib.contextmanager
def _jfd():
    """Walk from the owned root with no-follow openat; all journal IO uses this pinned fd.
    Symlinks (including intermediate directories) are never followed, even during replacement races."""
    fd = os.open(_home(), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in ("private", "caregiver", "dispatch-journal"):
            try: os.mkdir(part, mode=0o700, dir_fd=fd); os.fsync(fd)
            except FileExistsError: pass
            try: nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except OSError as e: raise PermissionError("journal directory must be a real directory inside this bot's root") from e
            os.close(fd); fd = nxt
        yield fd
    finally: os.close(fd)
def _jdir():
    with _jfd(): pass
    return os.path.join(_home(), "private", "caregiver", "dispatch-journal")
def _jpath(iid):
    if not isinstance(iid, str) or not ID_RE.fullmatch(iid): raise ValueError("not a Fortress message id")
    with _jfd() as fd:
        try:
            import stat
            if not stat.S_ISREG(os.stat(iid + ".json", dir_fd=fd, follow_symlinks=False).st_mode):
                raise PermissionError("journal entry must be a regular file, not a symlink")
        except FileNotFoundError: pass
    return os.path.join(_home(), "private", "caregiver", "dispatch-journal", iid + ".json")
def _fsync_write(path, obj, excl=False):
    name = os.path.basename(path)
    if not JNAME_RE.fullmatch(name): raise ValueError("invalid journal filename")
    with _jfd() as fd:
        tmp = ".tmp-" + os.urandom(16).hex()
        out = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
        try:
            with os.fdopen(out, "w") as f: json.dump(obj, f); f.flush(); os.fsync(f.fileno())
            if excl: os.link(tmp, name, src_dir_fd=fd, dst_dir_fd=fd, follow_symlinks=False)
            else: os.replace(tmp, name, src_dir_fd=fd, dst_dir_fd=fd)
            os.fsync(fd)
        finally:
            try: os.unlink(tmp, dir_fd=fd)
            except FileNotFoundError: pass
def _jread(name):
    if not JNAME_RE.fullmatch(name): raise ValueError("invalid journal filename")
    with _jfd() as fd:
        try: f = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
        except FileNotFoundError: return None
        with os.fdopen(f) as inp: return json.load(inp)
def journal(iid):
    _jpath(iid)
    try: return _jread(iid + ".json")
    except (json.JSONDecodeError, UnicodeError): return {"id": iid, "state": "reserved", "note": "unreadable journal entry treated as reserved"}
@contextlib.contextmanager
def _jlock(iid):
    import fcntl
    _jpath(iid)
    with _jfd() as fd:
        f = os.open(".lock-" + iid, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=fd)
        try: fcntl.flock(f, fcntl.LOCK_EX); yield
        finally: os.close(f)
ISSUED_KEYS = ("journal_schema","id","rid","state_id","epoch","sample_hash","contact_ref","to","text_sha","kind","members","slot","source_events","attempt","token","at")
def _identity(j): return {k:j[k] for k in ISSUED_KEYS}
def _valid_journal(j):
    try:
        if j["journal_schema"] != 2 or j["state"] not in {"reserved","unknown","failed","sent"}: return False
        if any(not isinstance(j[k],str) or not ID_RE.fullmatch(j[k]) for k in ("id","sample_hash","token")): return False
        if not isinstance(j["text_sha"],str) or not re.fullmatch(r"[0-9a-f]{64}",j["text_sha"]): return False
        if not isinstance(j["state_id"],str) or not re.fullmatch(r"[0-9a-f]{12}",j["state_id"]): return False
        if any(type(j[k]) is not int or j[k]<0 for k in ("epoch","slot","attempt","at")) or j["attempt"]<1 or j["epoch"]<1: return False
        if any(not isinstance(j[k],str) or not j[k] for k in ("rid","contact_ref","to")) or not ADDR_RE.fullmatch(j["to"]) or j["kind"] not in SCOPES: return False
        if any(not isinstance(j[k],list) or len(j[k])!=len(set(j[k])) or any(not isinstance(x,str) or not ID_RE.fullmatch(x) for x in j[k]) for k in ("members","source_events")): return False
        if j["id"] in j["members"] or (j["kind"]!="digest" and j["members"]): return False
        receipts=j.get("receipts",[])
        if not isinstance(receipts,list) or any(not isinstance(x,dict) or set(x)!={"outcome","at","evidence"} or x["outcome"] not in {"sent","failed","unknown"} or type(x["at"]) is not int for x in receipts): return False
        if j["state"]!="reserved" and (not receipts or receipts[-1]["outcome"]!=j["state"] or receipts[-1]["at"]!=j.get("result_at")): return False
        return True
    except (KeyError,TypeError,ValueError): return False
def _issue(j):
    if not _valid_journal(j): raise ValueError("invalid issuance")
    _fsync_write(_jpath(j["id"])+".issued-"+str(j["attempt"]),_identity(j),excl=True)
def _issued_matches(j):
    if not _valid_journal(j): return False
    try: issued=_jread(j["id"]+".json.issued-"+str(j["attempt"]))
    except (OSError,ValueError): return False
    return issued == _identity(j)
def _history(j):
    if not _issued_matches(j): raise ValueError("journal does not match immutable issued tuple")
    p=_jpath(j["id"])+".attempt-"+str(j["attempt"]); old=_jread(os.path.basename(p))
    if old is not None:
        if not _issued_matches(old) or _identity(old)!=_identity(j): raise ValueError("issued history conflict; hold for review")
        previous=old.get("receipts",[])
        if j.get("receipts",[])[:len(previous)]!=previous: raise ValueError("receipt history cannot be removed or replaced")
    _fsync_write(p,j)
def _verified_record(j):
    if not _issued_matches(j): return False
    try:
        h=_jread(j["id"]+".json.attempt-"+str(j["attempt"]))
        if h is not None:
            if not _issued_matches(h) or _identity(h)!=_identity(j): return False
            a,b=h.get("receipts",[]),j.get("receipts",[])
            if a[:min(len(a),len(b))]!=b[:min(len(a),len(b))]: return False
        current=journal(j["id"])
        if current and current.get("token")==j["token"]:
            if not _issued_matches(current) or _identity(current)!=_identity(j): return False
            c=current.get("receipts",[])
            if h is not None and (len(c)<len(h.get("receipts",[])) or c[:len(h.get("receipts",[]))]!=h.get("receipts",[])): return False
        return True
    except (OSError,ValueError,TypeError,KeyError): return False
def _histories(iid):
    _jpath(iid)
    with _jfd() as fd: names = os.listdir(fd)
    return [j for n in sorted(names) if n.startswith(iid + ".json.attempt-") and JNAME_RE.fullmatch(n) and (j := _jread(n))]
def _remove_current(iid):
    with _jfd() as fd:
        try: os.unlink(iid + ".json", dir_fd=fd); os.fsync(fd)
        except FileNotFoundError: pass
def _owned(path):
    from fortress_owner import require
    return require(path)          # path must be inside THIS bot's FORTRESS_HOME, owned by FORTRESS_INSTANCE
class StaleStateError(PermissionError): pass
def _state_path(): return os.path.join(_home(), "private", "caregiver", "state.json")
def _state_owned(path):
    _owned(path)
    if os.path.abspath(path)!=os.path.abspath(_state_path()):
        raise PermissionError("caregiver state must use this bot's canonical private/caregiver/state.json; shadow state files are not authorities")
def save(path, st):
    """Compare-and-swap commit. Every writer, including callbacks and lifecycle callers, must
    carry the revision it actually loaded. Old policy cannot be serialized over newer authority."""
    _state_owned(path)
    with locked(path):
        try:
            with open(path) as f: cur = json.load(f)
        except FileNotFoundError: cur = None
        revision = st.get("revision", 0)
        if type(revision) is not int or revision < 0: raise StaleStateError("invalid state revision")
        if cur is not None and (type(cur.get("revision",0)) is not int or cur.get("revision",0)<0 or cur.get("state_id") != st.get("state_id") or cur.get("revision", 0) != revision):
            raise StaleStateError("stale caregiver state: reload and reapply the intended operation, never overwrite current policy")
        if cur is None and revision != 0: raise StaleStateError("missing canonical state; restoration requires explicit reviewed migration")
        obj = json.loads(json.dumps(st)); obj["revision"] = revision + 1
        fd, tmp = tempfile.mkstemp(prefix=".cg-", dir=os.path.dirname(os.path.abspath(path)))
        try:
            with os.fdopen(fd, "w") as f: json.dump(obj, f, indent=1); f.flush(); os.fsync(f.fileno())
            os.replace(tmp, path)
            fd = os.open(os.path.dirname(os.path.abspath(path)), os.O_RDONLY); os.fsync(fd); os.close(fd)
        finally:
            try: os.unlink(tmp)
            except FileNotFoundError: pass
        st["revision"] = obj["revision"]
def load(path):
    _state_owned(path)
    with locked(path):
        st = migrate(json.load(open(path)))
        if type(st.get("revision")) is not int or st["revision"]<0: raise StaleStateError("malformed caregiver revision; hold for reviewed migration")
        if recover_sent(st): save(path, st)
        return st
_LOCKS = threading.local()
_ACTIVE = threading.local()
def _active():
    if not hasattr(_ACTIVE,"states"): _ACTIVE.states={}
    return _ACTIVE.states
@contextlib.contextmanager
def locked(path):
    import fcntl
    _state_owned(path); path = os.path.abspath(path)
    held = getattr(_LOCKS, "held", None)
    if held is None: held = _LOCKS.held = set()
    if path in held:
        yield; return
    f = open(path + ".lock", "a+"); fcntl.flock(f, fcntl.LOCK_EX); held.add(path)
    try: yield
    finally: held.remove(path); fcntl.flock(f, fcntl.LOCK_UN); f.close()
@contextlib.contextmanager
def transaction(path=None):
    """Atomic owner lifecycle transaction. Nested lifecycle APIs mutate only this current
    object; commit once on success. An exception commits nothing. Receipt settlement is separate."""
    path = path or _state_path()
    with locked(path):
        if path in _active(): raise StaleStateError("nested owner transaction is not supported")
        st=load(path); _active()[path]=st
        try:
            yield st
            save(path,st)
        finally: _active().pop(path,None)
def _settings():
    try: return json.load(open(os.path.join(_home(), "private", "settings.json")))
    except Exception: return {}
def _pairing():
    try: return json.load(open(os.path.join(_home(), "private", "pairing.json")))
    except Exception: return {}
def _zone(st):
    z = st.get("timezone") or _settings().get("timezone")
    if not z: raise ValueError("owner timezone not configured; ask the owner")
    return ZoneInfo(z)

# ---------------- recipients and consent ----------------
def propose(st, rid, first_name, contact_ref, timing):
    migrate(st)
    if timing not in TIMINGS: raise ValueError("timing")
    if not _valid_name(first_name): raise ValueError("first name only (letters in any script, digits, space, hyphen, apostrophe; max 30)")
    others = [k for k, r in st["recipients"].items() if r["state"] != "stopped" and k != rid]
    if len(others) >= 5: raise ValueError("max 5 caregivers (stopped people count again if re-added)")
    epoch = (st["recipients"].get(rid) or {}).get("epoch", 0) + 1
    st["queue"] = [q for q in st["queue"] if q["rid"] != rid]
    st["recipients"][rid] = {"name": first_name, "contact_ref": contact_ref, "timing": timing, "state": "proposed", "consent": None,
                             "sample_hash": None, "destination": None, "stopped_at": None, "epoch": epoch, "first_notice_sent": False, "last_slot": 0}
def sample_preview(st, rid, samples, destination):
    """Build what the host must actually show. Structured {kind: fields}; no Subject-header inference.
    This local envelope is NOT proof of a displayed host card or owner-origin message."""
    r = st["recipients"][rid]; d = _addr(destination)
    if not ADDR_RE.fullmatch(d) or not isinstance(samples, dict) or not samples or not set(samples) <= SCOPES:
        raise ValueError("structured samples and one destination required")
    docs = {k: {"fields": _validate(k, f), "text": render(st, {"rid": rid, "kind": k, "fields": _validate(k, f)})} for k, f in sorted(samples.items())}
    if any(not v["text"] for v in docs.values()): raise ValueError("owner name required")
    return {"schema": "fortress-caregiver-sample/1", "rid": rid, "epoch": r["epoch"], "contact_ref": r["contact_ref"],
            "to": d, "name": r["name"], "question_scope": sorted(samples), "render_context": {"owner_name": st.get("owner_name"), "timing": r["timing"], "first_notice_sent": bool(r.get("first_notice_sent"))}, "samples": docs}
def _valid_sample(st, r):
    e = r.get("sample_envelope")
    try:
        if not isinstance(e, dict) or e.get("epoch") != r["epoch"] or e.get("contact_ref") != r["contact_ref"] or e.get("name") != r["name"] or e.get("to") != r.get("destination") or _fsha(e) != r.get("sample_hash"): return False
        tmp = json.loads(json.dumps(st)); rid = e["rid"]
        if tmp["recipients"].get(rid, {}).get("epoch") != r["epoch"]: return False
        ctx = e["render_context"]
        if set(ctx) != {"owner_name", "timing", "first_notice_sent"} or type(ctx["first_notice_sent"]) is not bool: return False
        tmp["owner_name"] = ctx["owner_name"]; tmp["recipients"][rid].update(timing=ctx["timing"], first_notice_sent=ctx["first_notice_sent"])
        expected = sample_preview(tmp, rid, {k:v["fields"] for k,v in e["samples"].items()}, e["to"])
        return e == expected
    except (KeyError, TypeError, ValueError): return False
def show_sample(st, rid, sample_text, destination=None):
    r = st["recipients"][rid]
    if not isinstance(sample_text, dict): raise PermissionError("use sample_preview's structured actual renders, not arbitrary text")
    try: expected = sample_preview(st, rid, {k: v["fields"] for k,v in sample_text["samples"].items()}, destination or sample_text["to"])
    except (KeyError, TypeError, ValueError) as e: raise PermissionError("invalid structured sample") from e
    if sample_text != expected: raise PermissionError("sample must exactly match current recipient and rendered content")
    r["destination"] = expected["to"]; r["shown_kinds"] = sorted(expected["samples"])
    r["sample_envelope"] = expected; r.pop("sample_refresh_required", None)
    r["sample_hash"] = _fsha(expected); r["state"] = "sample_shown"
    return r["sample_hash"]
APOS = dict.fromkeys(map(ord, "\u2019\u2018\u02bc\u02b9`\u00b4\u2032"), "'")
def _norm(w):
    w = unicodedata.normalize("NFKC", w or "").translate(APOS)
    return w.strip()
def is_affirmative(words, name=None):
    """Small positive grammar, NOT a semantic yes-prefix/withdrawal blacklist.
    Unsupported language requests a plain confirmation; no trailing clauses accepted."""
    if not isinstance(words, str): return False
    w = _norm(words).casefold()
    plain = {"yes", "yep", "yeah", "ok", "okay", "sure", "i agree", "agreed", "go ahead", "yes — go ahead"}
    if w.rstrip(".! ") in plain: return True
    if name is None: return False
    n = re.escape(_norm(name).casefold())
    return bool(re.fullmatch(r"(?:yes,? |please )?(?:send|share with|keep sending) " + n +
                            r" (?:these updates|updates|the weekly digest|this weekly digest|the daily digest|the immediate digest|the alerts)[.!]?", w))
def _confirmation_scope(words, r, question_scope):
    if not is_affirmative(words, r["name"]): raise PermissionError("plain owner confirmation for this person required")
    w = _norm(words).casefold().rstrip(".! ")
    m = re.fullmatch(r"(?:yes,? |please )?(?:send|share with|keep sending) " + re.escape(_norm(r["name"]).casefold()) +
                     r" (?P<phrase>these updates|updates|the weekly digest|this weekly digest|the daily digest|the immediate digest|the alerts)", w)
    if m:
        phrase=m["phrase"]
        if phrase.endswith("digest"):
            timing=phrase.split()[-2]
            if r["timing"]!=timing: raise PermissionError("confirmation timing contradicts this person's preview")
            return {"digest"}
        if phrase=="the alerts": return {"high_risk_alert"}
    return set(question_scope)
def record_consent(st, rid, owner_words, sample_hash, scope, by="owner", now=None):
    r = st["recipients"][rid]
    if by != "owner": raise PermissionError("only the owner can consent; a caregiver or anyone else cannot")
    if r["state"] != "sample_shown" or sample_hash != r["sample_hash"] or not _valid_sample(st,r): raise PermissionError("show this recipient's genuine current sample first")
    if not is_affirmative(owner_words, r["name"]): raise PermissionError("not an unambiguous yes from the owner; ask again plainly")
    scope = set(scope)
    if not scope or not scope <= SCOPES: raise ValueError("scope")
    if scope != _confirmation_scope(owner_words, r, r["sample_envelope"]["question_scope"]): raise PermissionError("confirmation does not authorize this exact requested scope; clarify or show a narrower question")
    if not scope <= set(r.get("shown_kinds") or []): raise PermissionError("scope includes a kind of message the owner was not shown; show that sample first")
    t = _now(now)
    r["consent"] = {"at": t, "words": owner_words, "source_role": "owner", "scope": sorted(scope), "sample_hash": sample_hash, "epoch": r["epoch"],
                    "contact_ref": r["contact_ref"], "destination": r["destination"], "confirmed_scope": sorted(scope), "review_due": t + REVIEW_S}
    r["state"] = "consented"
def _valid_consent(st,r):
    try:
        if not _valid_sample(st,r): return False
        c=r["consent"]; e=r["sample_envelope"]; frozen=dict(r); frozen["timing"]=e["render_context"]["timing"]
        permitted=_confirmation_scope(c["words"],frozen,e["question_scope"])
        return bool(c["scope"]) and set(c["scope"])<=permitted and set(c["confirmed_scope"])==permitted and c["epoch"]==r["epoch"] and c["contact_ref"]==r["contact_ref"] and c["destination"]==r["destination"] and c["sample_hash"]==r["sample_hash"]
    except (KeyError,TypeError,ValueError,PermissionError): return False
def reconfirm(st, rid, owner_words, by="owner", now=None):
    r = st["recipients"][rid]
    if by != "owner" or not is_affirmative(owner_words, r["name"]) or r["state"] != "active" or _confirmation_scope(owner_words, r, r["consent"]["scope"]) != set(r["consent"]["scope"]): raise PermissionError("owner's plain yes for an active person needed")
    r["consent"]["review_due"] = _now(now) + REVIEW_S; r["consent"]["reconfirmed"] = {"at": _now(now), "words": owner_words}
def configure_sender(st, own_inbox, send_tool, owner_name=None):
    if owner_name is not None and not _valid_name(owner_name): raise ValueError("owner first name only")
    st["own_inbox"], st["send_tool"] = _addr(own_inbox), send_tool
    if owner_name: st["owner_name"] = owner_name
def activate(st, rid):
    r = st["recipients"][rid]
    if r["state"] != "consented": raise PermissionError("consent first")
    r["state"] = "active"; st["sharing"] = "on"
def change_timing(st, rid, timing):
    if timing not in TIMINGS: raise ValueError("timing")
    st["recipients"][rid]["timing"] = timing

# ---------------- structured content ----------------
def _held_ok(x):
    if not isinstance(x, dict) or x.get("reason") not in HELD_REASONS: return False
    if set(x) == {"sender_domain", "reason"}: return isinstance(x["sender_domain"], str) and bool(DOMAIN_RE.match(x["sender_domain"]))
    if set(x) <= {"sender_kind", "sender_display", "reason"} and x.get("sender_kind") in SENDER_KINDS and x["sender_kind"] != "email":
        return x.get("sender_display", SENDER_KINDS[x["sender_kind"]]) in SENDER_DISPLAYS
    return False
def _validate(kind, f, aggregate=False):
    f = f or {}
    if kind == "digest":
        c = f.get("counts", {})
        if not isinstance(c, dict) or set(c) - set(COUNT_KEYS) or not all(type(v) is int and 0 <= v and (aggregate or v <= 100000) for v in c.values()): raise ValueError("counts")
        held = f.get("held", [])
        if not isinstance(held, list) or (not aggregate and len(held) > 10) or not all(_held_ok(x) for x in held): raise ValueError("held")
        if set(f.get("high_risk_types", [])) - set(PATTERNS): raise ValueError("high_risk_types")
        rs = f.get("receipt_states", {})
        if not isinstance(rs, dict) or set(rs) - set(RECEIPT_STATES) or not all(type(v) is int and 0 <= v and (aggregate or v <= 100000) for v in rs.values()): raise ValueError("receipt_states")
        if not isinstance(f.get("steps_taken", []), list) or set(f.get("steps_taken", [])) - set(STEPS): raise ValueError("steps_taken")
        if set(f) - {"counts", "held", "high_risk_types", "receipt_states", "steps_taken"}: raise ValueError("unknown digest field")
    elif kind == "high_risk_alert":
        keys = set(f)
        if not ({"pattern", "day_local", "next_step"} <= keys <= {"pattern", "day_local", "next_step", "sender_domain", "sender_kind", "sender_display"}): raise ValueError("alert fields")
        if f["pattern"] not in PATTERNS or f["next_step"] not in NEXT_STEPS or not re.match(r"^\d{4}-\d{2}-\d{2}$", f["day_local"]): raise ValueError("alert values")
        if "sender_domain" in f:
            if keys & {"sender_kind", "sender_display"} or not DOMAIN_RE.match(f["sender_domain"]): raise ValueError("alert sender")
        elif not (f.get("sender_kind") in SENDER_KINDS and f["sender_kind"] != "email" and f.get("sender_display", SENDER_KINDS[f["sender_kind"]]) in SENDER_DISPLAYS):
            raise ValueError("alert sender: a domain for email, or a phone/SMS/unknown kind (never a made-up domain)")
    else: raise ValueError("kind")
    return json.loads(json.dumps(f))
def _fsha(f): return hashlib.sha256(json.dumps(f, sort_keys=True).encode()).hexdigest()[:16]
def enqueue(st, rid, kind, categories, body_ref, now=None, event_key=None, fields=None):
    r = st["recipients"][rid]
    iid = _h(f"{st.get('state_id', '')}|{rid}|{r['epoch']}|{kind}|{event_key or body_ref}")   # unique per state: journals never collide
    dup = iid in st["sent_log"] or iid in st.get("delivered_events", {}) or any(q["id"] == iid or iid in q.get("members", []) for q in st["queue"])
    f = _validate(kind, fields) if fields is not None else None
    item = {"id": iid, "rid": rid, "epoch": r["epoch"], "contact_ref": r["contact_ref"], "sample_hash": r["sample_hash"], "kind": kind,
            "categories": sorted(set(categories)), "body_ref": body_ref, "created": _now(now), "sent": False, "duplicate": dup,
            "fields": f, "fields_sha": _fsha(f) if f is not None else None}
    st["queue"].append(item); return iid
def _member_ok(st, q):
    try:
        r = st["recipients"].get(q["rid"]); c = (r or {}).get("consent") or {}
        base = bool(r) and _valid_consent(st,r) and not r.get("sample_refresh_required") and r["state"] == "active" and q.get("epoch") == r["epoch"] == c.get("epoch") and q.get("contact_ref") == r["contact_ref"] == c.get("contact_ref") \
            and q.get("sample_hash") == c.get("sample_hash") and q["kind"] in c.get("scope", []) and not q.get("duplicate") and not q.get("sent") \
            and q.get("fields") is not None and q.get("fields_sha") == _fsha(q["fields"]) and q["id"] not in st.get("delivered_events", {})
        if not base or _validate(q["kind"], q["fields"], aggregate=bool(q.get("members"))) != q["fields"]: return False
        if set(q["categories"]) & (set(st["never"]) | set(st.get("never_custom", []))): return False
        if _never_hits(st, render(st, q)): return False
        if q.get("members"):
            ms = q.get("member_items", [])
            return len(ms) == len(q["members"]) == len(set(q["members"])) and sorted(m["id"] for m in ms) == sorted(q["members"]) and q["kind"] == "digest" and all(not m.get("members") and m["kind"] == "digest" and m["rid"] == q["rid"] and _member_ok(st,m) for m in ms) and _aggregate(ms) == q["fields"] and q["categories"] == sorted({c for m in ms for c in m["categories"]}) and q["created"] == min(m["created"] for m in ms) and q["id"] == _batch_id(st,q["rid"],q["members"])
        return not _domain_hits(st, q["fields"], q)
    except (KeyError, ValueError, TypeError): return False

def _aggregate(src):
    if not src or any(q.get("kind") != "digest" or q.get("members") for q in src): raise ValueError("digest leaves only")
    counts = {k: sum(q["fields"].get("counts", {}).get(k, 0) for q in src) for k in COUNT_KEYS}
    rs = {}
    for q in src:
        for k, v in q["fields"].get("receipt_states", {}).items(): rs[k] = rs.get(k, 0) + v
    f = {"counts": counts, "held": [h for q in src for h in q["fields"].get("held", [])],
         "high_risk_types": sorted({x for q in src for x in q["fields"].get("high_risk_types", [])})}
    if rs: f["receipt_states"] = rs
    steps = sorted({x for q in src for x in q["fields"].get("steps_taken", [])})
    if steps: f["steps_taken"] = steps
    return _validate("digest", f, aggregate=True)
def _quarantine(st, item, reason):
    entry = {"payload": json.loads(json.dumps(item)), "reason": reason}
    if entry not in st.setdefault("quarantine", []): st["quarantine"].append(entry)
def _outstanding(item):
    j = journal(item["id"])
    return bool(j and not (j.get("state") == "failed" and _verified_record(j)))
def _batch_id(st,rid,members):
    r=st["recipients"][rid]
    return _h(f"batch|{st.get('state_id', '')}|{rid}|{r['epoch']}|{r['sample_hash']}|{'|'.join(sorted(members))}")
def make_batch(st, rid, ids, now=None):
    """Flatten ALL eligible released digest containers. Unknown/reserved work stays intact.
    Malformed parents are quarantined; individually valid digest leaves can still progress."""
    selected = set(ids); src = []; seen = set(); consumed = set()
    for q in list(st["queue"]):
        if q.get("rid") != rid or q.get("id") not in selected or q.get("kind") != "digest" or _outstanding(q): continue
        if q.get("members"):
            if not _member_ok(st, q):
                _quarantine(st, q, "invalid digest batch retained intact; no child is consumed from this malformed container")
                consumed.add(q["id"])
                continue
            children = q.get("member_items", [])
            if not isinstance(children, list): continue
            consumed.add(q["id"])
        else: children = [q]
        for m in children:
            if not isinstance(m, dict) or m.get("kind") != "digest" or m.get("members") or m.get("rid") != rid: continue
            if m.get("id") in seen or not _member_ok(st, m) or _outstanding(m): continue
            src.append(m); seen.add(m["id"]); consumed.add(m["id"])
    if not src:
        st["queue"] = [q for q in st["queue"] if q.get("id") not in consumed]
        return None
    # Deterministic ordering makes both membership and full aggregate content stable.
    src.sort(key=lambda q:(q["created"],q["id"]))
    r = st["recipients"][rid]; members = sorted(q["id"] for q in src); fields = _aggregate(src)
    b = {"id": _batch_id(st,rid,members), "rid": rid, "epoch": r["epoch"], "contact_ref": r["contact_ref"],
         "sample_hash": r["sample_hash"], "kind": "digest", "categories": sorted({c for q in src for c in q["categories"]}), "body_ref": "batch",
         "created": min(q["created"] for q in src), "sent": False, "duplicate": False, "members": members, "member_items": src,
         "fields": fields, "fields_sha": _fsha(fields), "slot": max(q.get("slot", 0) for q in src)}
    # Released parents carry the due slot, which their original leaves may not have.
    b["slot"] = max([b["slot"]] + [q.get("slot",0) for q in st["queue"] if q.get("id") in consumed])
    st["queue"] = [q for q in st["queue"] if q.get("id") not in consumed] + [b]
    return b["id"]
def _sender(f):
    return f["sender_domain"] if "sender_domain" in f else f.get("sender_display", SENDER_KINDS.get(f.get("sender_kind"), "Unknown sender"))
def render(st, item):
    """The ONLY message text a caregiver can receive. Returns 'Subject: ...\\n\\n<body>'."""
    r = st["recipients"][item["rid"]]; owner = st.get("owner_name"); f = item.get("fields")
    if not owner or f is None: return None
    tim = {"immediate": "last ~15 minutes", "daily": "today", "weekly": "this week"}[r["timing"]]
    intro = (f"{owner} added you ({r['name']}) to receive View-only Fortress updates about scam activity aimed at {owner}. "
             f"{owner} chose this and can change or stop it anytime.\n\n") if not r.get("first_notice_sent") else ""
    if item["kind"] == "digest":
        c = f.get("counts", {}); held = f.get("held", [])
        lines = "\n".join(f"  - {_sender(h)}: {HELD_REASONS[h['reason']]}" for h in held) or "  - none"
        hr = ", ".join(PATTERNS[t] for t in f.get("high_risk_types", [])) or "none"
        extra = ""
        if f.get("receipt_states"): extra += "- Report/opt-out receipts: " + ", ".join(f"{v} {RECEIPT_STATES[k]}" for k, v in sorted(f["receipt_states"].items())) + "\n"
        if f.get("steps_taken"): extra += "- Steps taken: " + "; ".join(STEPS[s] for s in f["steps_taken"]) + "\n"
        subj = f"Fortress update for {owner}"
        body = (f"Hi {r['name']},\n\n{intro}Fortress update for {owner} (View-only), {tim}:\n- Reported / blocked: {c.get('reported_blocked', 0)}\n"
                f"- Unsubscribed: {c.get('unsubscribed', 0)}\n- Held for review: {c.get('held', 0)}\n{lines}\n- High-risk flags: {hr}\n{extra}\n"
                f"No full messages, codes, or account details are included.")
    else:
        subj = f"Fortress heads-up for {owner}"
        body = (f"Hi {r['name']},\n\n{intro}Fortress saw a {PATTERNS[f['pattern']]} pattern aimed at {owner} on {f['day_local']} "
                f"(sender: {_sender(f)}). Next step: {NEXT_STEPS[f['next_step']].format(owner=owner)}\n\nNo full message text is included.")
    return f"Subject: {subj}\n\n{body}\n\nTo stop these emails, reply STOP to this message.\n- Fortress"
SECRET_TEXT = re.compile(r"(?i)(\b(code|otp|pin|passcode)\b\D{0,15}\d{4,8}\b|\b\d{3}-\d{2}-\d{4}\b|\b(?:\d[ -]?){13,19}\b|https?://|www\.|"
                         r"\bpassword|\bpass ?phrase|\bbalance\b|\$\s?\d|\bmedication|\bpharmacy\b|\bprescription|\bdiagnos|\baccount (no|number)|\brouting\b|"
                         r"\baddress is\b|\blocated at\b)")
def _source_store():
    """Typed producer boundary. Reads ONLY this bot's dedicated evidence projection, never inbox/Vault.
    Future supported producers must authenticate originals and provision vetted sender contexts.
    An owned JSON file is local authority for offline modeling, NOT a native provenance attestation."""
    p = os.path.join(_home(), "private", "caregiver", "source-projection.json")
    _owned(p)
    try:
        with open(p) as f: store = json.load(f)
    except FileNotFoundError: return {"records": {}, "sender_contexts": {}}
    if store.get("schema") != "fortress-caregiver-sources/1": raise ValueError("source projection schema")
    return store
def _source_event(st, rid, source_id):
    return _h(f"source-event|{st['state_id']}|{rid}|{source_id}")
def _project_record(st, rid, source_id):
    if not isinstance(source_id, str) or not source_id: raise ValueError("source identity")
    store = _source_store(); rec = store.get("records", {})[source_id]
    if set(rec) != {"kind", "fields", "categories", "created"}: raise ValueError("source record shape")
    fields = json.loads(json.dumps(rec["fields"]))
    for obj in fields.get("held", []) + ([fields] if rec["kind"] == "high_risk_alert" else []):
        if "sender_context_ref" in obj:
            ref = obj.pop("sender_context_ref"); ctx = store.get("sender_contexts", {}).get(ref)
            if not isinstance(ctx, dict) or set(ctx) != {"domain", "source_role"} or ctx["source_role"] != "vetted_sender_domain" or not isinstance(ctx.get("domain"), str) or not DOMAIN_RE.fullmatch(ctx["domain"]):
                obj["sender_kind"] = "unknown"; obj["sender_display"] = "Unknown email sender"
            else: obj["sender_domain"] = ctx["domain"]
        elif "sender_domain" in obj:
            # Unvetted/attacker-controlled labels are never copied to output. Keep reason, counts,
            # receipts and steps; use fixed unknown-email context instead of suppressing the digest.
            obj.pop("sender_domain"); obj["sender_kind"] = "unknown"; obj["sender_display"] = "Unknown email sender"
    fields = _validate(rec["kind"], fields)
    if not isinstance(rec["categories"], list) or not all(isinstance(x,str) for x in rec["categories"]) or type(rec["created"]) is not int or rec["created"] < 0: raise ValueError("source metadata")
    r = st["recipients"][rid]
    return {"id": _h(f"{st['state_id']}|{rid}|{r['epoch']}|{rec['kind']}|source:{source_id}"), "rid":rid,"epoch":r["epoch"],"contact_ref":r["contact_ref"],"sample_hash":r["sample_hash"],
            "kind":rec["kind"],"categories":sorted(set(rec["categories"])),"body_ref":"source:"+source_id,"created":rec["created"],"fields":fields,"fields_sha":_fsha(fields),
            "source_id":source_id,"source_sha":_fsha(rec),"source_event":_source_event(st,rid,source_id)}
def _leaves(q): return q.get("member_items", []) if q.get("members") else [q]
def reproject_source(st, rid, source_id):
    """Explicit lossless binding migration: quarantine only superseded UNSENT/non-outstanding
    payloads. Delivered or reserved/unknown event identities never become fresh work."""
    expected = _project_record(st,rid,source_id); sid = expected["source_event"]
    blocked = sid in st.get("delivered_sources", {}) or expected["id"] in st.get("delivered_events", {})
    remove = set(); retained = []
    for q in st["queue"]:
        leaves = _leaves(q)
        matches = [m for m in leaves if m.get("rid")==rid and (m.get("source_id")==source_id or m.get("id")==expected["id"])]
        if not matches: continue
        if _outstanding(q) or q.get("sent") or any(m.get("id") in st.get("delivered_events", {}) for m in matches): blocked = True; continue
        # A current binding is ordinary duplicate work, not a reason to rewrite it.
        if any(all(m.get(k)==v for k,v in expected.items()) and not m.get("duplicate") for m in matches): blocked = True; continue
        _quarantine(st,q,"superseded unsent source binding; explicit reprojection")
        remove.add(q["id"])
        # Do not lose unrelated safe events from an old mixed batch.
        retained.extend(m for m in leaves if m not in matches)
    st["queue"] = [q for q in st["queue"] if q["id"] not in remove]
    for m in retained:
        if not any(q["id"]==m["id"] for q in st["queue"]): st["queue"].append(m)
    item = {**expected,"sent":False,"duplicate":blocked}
    st["queue"].append(item)
    st.setdefault("source_bindings", {})[item["id"]] = expected
    return item["id"]
def project_source(st, rid, source_id, now=None):
    return reproject_source(st,rid,source_id)
def _domain_hits(st, f, item=None):
    doms = [h["sender_domain"] for h in (f or {}).get("held", []) if "sender_domain" in h] + ([f["sender_domain"]] if (f or {}).get("sender_domain") else [])
    if not (item or {}).get("source_id"):
        if (item or {}).get("id") in st.get("source_bindings", {}): return ["source identity metadata cannot be removed"]
        return ["sender context lacks typed source projection"] if doms else []
    try:
        q = _project_record(st,item["rid"],item["source_id"])
        if st.get("source_bindings", {}).get(item["id"]) != q or any(item.get(k)!=v for k,v in q.items()): return ["canonical source identity, privacy categories or content changed"]
        if q["source_event"] in st.get("delivered_sources", {}): return ["source event already delivered"]
    except (OSError,KeyError,ValueError,TypeError): return ["source projection unavailable or invalid"]
    return []
def _persisted_check(st, item):
    """The canonical persisted state is the current authority for revocation: a stale in-memory snapshot cannot send."""
    p = os.path.join(_home(), "private", "caregiver", "state.json")
    try: _owned(p); cur = json.load(open(p))
    except FileNotFoundError: return ["no saved caregiver state in this bot's folder; save state before dispatch"]
    except Exception: return ["saved caregiver state unreadable; treated as revoked"]
    pr = (cur.get("recipients") or {}).get(item["rid"]) or {}; mr = st["recipients"].get(item["rid"]) or {}
    pc = pr.get("consent") or {}; mc = mr.get("consent") or {}
    if type(cur.get("revision",0)) is not int or type(st.get("revision",0)) is not int: return ["invalid state revision"]
    if cur.get("revision",0) != st.get("revision",0): return ["saved caregiver revision changed; reload before dispatch"]
    if cur.get("state_id") != st.get("state_id"): return ["saved state belongs to a different caregiver setup"]
    if cur.get("sharing") != "on" or pr.get("state") != "active": return ["saved state says sharing is off or this person was stopped"]
    if pr.get("epoch") != mr.get("epoch") or pc.get("epoch") != mc.get("epoch") or pc.get("sample_hash") != mc.get("sample_hash") or pc.get("destination") != mc.get("destination"):
        return ["saved state has a different consent version for this person"]
    saved_item=next((q for q in cur.get("queue",[]) if q.get("id")==item.get("id") and not q.get("duplicate")),None)
    if saved_item is None or saved_item != item: return ["queued content must be committed at this revision before dispatch"]
    keys = ("never", "never_custom", "own_inbox", "send_tool", "owner_name", "timezone", "daily_hour", "weekly_day")
    if any(cur.get(k) != st.get(k) for k in keys) or pr != mr:
        return ["saved caregiver policy, scope, review or recipient changed; reload current state before dispatch"]
    return []
def _never_hits(st, text):
    hits = []
    if SECRET_TEXT.search(text): hits.append("default Never content (secret, number, link, money or medical detail)")
    for term in st.get("never_custom", []):
        if term and _norm(term).lower() in _norm(text).lower(): hits.append(f"owner's custom Never term '{term}'")
    return hits

# ---------------- final gate + durable reservation ----------------
def presend_gate(st, item, from_addr, now=None, tools_present=None, rendered_text=None, resolved_to=None, send_permission=None, reserve=True):
    """Call immediately before ONE send. All arguments are required. Passing returns (True, []) AND reserves the message
    in the durable journal: dispatch exactly the rendered text to resolved_to, then call mark_sent."""
    migrate(st); r = st["recipients"].get(item["rid"]); why = []; t = _now(now)
    if st["sharing"] != "on": why.append("sharing off")
    if not r or r["state"] != "active": why.append("recipient not active")
    elif r.get("sample_refresh_required") or not _valid_consent(st,r): why.append("sample/consent needs a genuine structured preview and exact-scope owner confirmation")
    else:
        c = r["consent"] or {}
        if item.get("epoch") != r["epoch"] or item.get("contact_ref") != r["contact_ref"] or c.get("epoch") != r["epoch"] \
           or c.get("contact_ref") != r["contact_ref"] or item.get("sample_hash") != c.get("sample_hash"):
            why.append("queued for a different recipient/consent version")
        if item["kind"] not in c.get("scope", []): why.append("kind outside consented scope")
        if t > c.get("review_due", 0): why.append("90-day review due; sends to this person paused until the owner reconfirms")
        if not c.get("destination"): why.append("consent was not bound to a shown destination address; show the sample with the address and ask again")
        elif not resolved_to: why.append("destination not re-resolved right before dispatch")
        elif _addr(resolved_to) != c["destination"]: why.append("destination changed since consent: new sample and owner yes required")
    bad = set(item["categories"]) & (set(st["never"]) | set(st.get("never_custom", [])))
    if bad: why.append("never-list content: " + ",".join(sorted(bad)))
    try: _validate(item["kind"], item.get("fields"), aggregate=bool(item.get("members")))
    except (ValueError, TypeError, KeyError): return False, why + ["invalid structured fields"]
    if rendered_text is None: why.append("exact rendered text not supplied")
    else:
        exp = render(st, item) if r else None
        if exp is None: why.append("message has no structured fields/owner name; only render() output can be sent")
        elif rendered_text != exp: why.append("text differs from the structured render; free text is never sent")
        why += _never_hits(st, rendered_text)
    if item.get("members") and not _member_ok(st, item): why.append("batch member content or consent invalid")
    if item.get("fields") is not None and item.get("fields_sha") != _fsha(item["fields"]): why.append("message content changed after it was queued; re-queue and re-approve")
    why += _domain_hits(st, item.get("fields"), item) if not item.get("members") else []
    dv = st.get("delivered_events", {})
    if item["id"] in dv or any(m in dv for m in item.get("members", [])): why.append("an event in this message was already delivered")
    if r and r["state"] == "active": why += _persisted_check(st, item)
    if not st["own_inbox"] or _addr(from_addr) != st["own_inbox"]: why.append("not sending from this bot's own inbox")
    if not st["send_tool"]: why.append("no send tool configured -> draft only, tell owner")
    elif st["send_tool"] not in NATIVE_SEND_TOOLS: why.append("configured send tool is not a documented host send tool; draft only")
    elif tools_present is None or st["send_tool"] not in tools_present: why.append("send tool not confirmed present this turn")
    if send_permission in NOT_PERMISSION: why.append(f"'{send_permission}' is not permission to send")
    elif send_permission not in SEND_PERMISSIONS: why.append("app send permission/approval card not confirmed")
    pr = _pairing()
    if pr.get("status") == "paired" and pr.get("caregiver_sender") != _owner_instance(): why.append("paired: the other bot (or nobody yet) is the caregiver sender")
    if st.get("inbox_checked_at") is None or t - st["inbox_checked_at"] > 30 * 60: why.append("own-inbox STOP replies not processed this wake")
    if item.get("sent") or item.get("duplicate"): why.append("duplicate or already sent")
    if any(q is not item and q["id"] == item["id"] and q.get("sent") for q in st["queue"]): why.append("same event already sent")
    prior = st["sent_log"].get(item["id"])
    if prior: why.append("already dispatched" if prior["result"] == "sent" else "previous send result unknown; reconcile first")
    if not why:
        if reserve: _reclaim_unissued(item["id"], t)
        j = journal(item["id"])
        if j: why.append("already dispatched" if j["state"] == "sent" else "a dispatch of this message was reserved without a known result; reconcile with the send tool's sent record first")
    if why or not reserve: return (not why), why
    with _jlock(item["id"]):
        return _reserve(st, item, rendered_text, c, t)
def _reserve(st, item, rendered_text, c, t):
    if journal(item["id"]): return False, ["another dispatcher reserved this message first"]
    n = _attempt_no(item["id"])
    try:
        _fsync_write(_jpath(item["id"]), {"journal_schema": 2, "id": item["id"], "rid": item["rid"], "state": "reserved", "at": t, "pid": os.getpid(),
                                          "attempt": n, "token": os.urandom(8).hex(), "slot": item.get("slot", 0), "kind": item["kind"], "members": item.get("members", []),
                                          "state_id": st["state_id"], "epoch": item["epoch"], "sample_hash": item["sample_hash"], "contact_ref": item["contact_ref"],
                                          "source_events": sorted({m["source_event"] for m in _leaves(item) if m.get("source_event")}),
                                          "to": c["destination"], "text_sha": hashlib.sha256(rendered_text.encode()).hexdigest()}, excl=True)
    except FileExistsError:
        return False, ["another dispatcher reserved this message first"]
    _issue(journal(item["id"]))
    _history(journal(item["id"]))
    return True, []
RECLAIM_GRACE_S = 300
def _reclaim_unissued(iid, t):
    """CG-V2-F3. A reservation whose issuer died between the reserved fsync and the immutable issued record was never
    handed to a sender: presend_gate returns True only after _issue and _history complete while holding _jlock(iid).
    Reclaim ONLY when, under that same lock (so no live v3 issuer is mid-issuance), the current entry is a well-formed
    reserved journal, no issued/attempt record exists for its attempt, and it is older than a grace window (covers
    pre-v3 lock-less issuers). Unreadable/partial/unknown/sent/issued entries are never reclaimed. The abandoned
    reservation's original JSON fields are preserved as .abandoned-N history together with added reclaim metadata
    (reclaimed_at, reclaim_reason); the file is a re-serialization, NOT byte-identical to the original journal. Its
    attempt number is never reused."""
    try:
        peek = journal(iid)
        if not peek or peek.get("state") != "reserved": return False   # nothing to reclaim; create no lock file
        with _jlock(iid):
            j = journal(iid)
            if not j or j.get("note") or j.get("state") != "reserved" or j.get("receipts"): return False
            if not _valid_journal(j): return False
            n = j["attempt"]
            with _jfd() as fd: names = set(os.listdir(fd))
            if f"{iid}.json.issued-{n}" in names or f"{iid}.json.attempt-{n}" in names: return False
            if type(j.get("at")) is not int or t - j["at"] < RECLAIM_GRACE_S: return False
            _fsync_write(_jpath(iid) + ".abandoned-" + str(n), {**j, "reclaimed_at": t, "reclaim_reason": "issuer died before immutable issuance; never dispatched"}, excl=True)
            _remove_current(iid)
            return True
    except (OSError, ValueError, FileExistsError):
        return False
def _owner_instance():
    try: return json.load(open(os.path.join(_home(), ".fortress-owner.json"))).get("instance_id")
    except Exception: return None
def _attempt_no(iid):
    js = _histories(iid) + ([journal(iid)] if journal(iid) else [])
    with _jfd() as fd: names=os.listdir(fd)
    issued=[int(n.rsplit("-",1)[1]) for n in names if (n.startswith(iid+".json.issued-") or n.startswith(iid+".json.abandoned-")) and JNAME_RE.fullmatch(n)]
    return 1 + max([j.get("attempt",0) for j in js]+issued+[0])
def _ack_ok(j, attempt):
    return bool(j and attempt and j.get("token") == attempt)
def _apply_sent(st, iid, j, t):
    if j.get("state_id") != st["state_id"]: return
    st["sent_log"][iid] = {"result": "sent", "at": t, "rid": j["rid"], "token": j["token"]}
    dv = st.setdefault("delivered_events", {})
    for m in [iid] + list(j.get("members", [])): dv.setdefault(m, t)
    for source in j.get("source_events", []): st.setdefault("delivered_sources",{}).setdefault(source,t)
    st["queue"] = [q for q in st["queue"] if q["id"] != iid]
    r = st["recipients"].get(j["rid"]); c = (r or {}).get("consent") or {}
    if r and r["state"] == "active" and j.get("epoch") == r["epoch"] == c.get("epoch") and j.get("sample_hash") == c.get("sample_hash") and j.get("contact_ref") == c.get("contact_ref") and j.get("to") == c.get("destination"):
        r["first_notice_sent"] = True
        if j.get("kind") == "digest": r["last_slot"] = max(r.get("last_slot", 0), j.get("slot", 0))
def recover_sent(st):
    before = json.dumps(st, sort_keys=True)
    with _jfd() as fd: names = os.listdir(fd)
    records = []
    for n in sorted(names):
        if not JNAME_RE.fullmatch(n): continue
        try: j = _jread(n)
        except (ValueError, OSError): continue
        if j and j.get("state_id") == st["state_id"] and _verified_record(j): records.append(j)
    for j in records:
        iid = j["id"]
        if j.get("state") == "sent": _history(j); _apply_sent(st, iid, j, j["result_at"])
    for j in records:
        iid = j["id"]
        if iid in st.get("delivered_events", {}): continue
        current = journal(iid)
        if j.get("state") == "failed" and (_ack_ok(current, j["token"]) or current is None):
            if current is not None and current.get("state") != "failed": continue
            _history(j)
            if current is not None: _remove_current(iid)
            old = st["sent_log"].get(iid, {})
            if old.get("token") == j["token"]: st["sent_log"].pop(iid, None)
            if not st["sent_log"].get(iid):
                for q in st["queue"]:
                    if q["id"] == iid: q.pop("blocked", None)
        elif j.get("state") == "unknown" and _ack_ok(current, j["token"]) and current.get("state") == "unknown":
            st["sent_log"][iid] = {"result": "unknown", "at": j["result_at"], "rid": j["rid"], "token": j["token"]}
            for q in st["queue"]:
                if q["id"] == iid: q["blocked"] = "unknown result; reconcile first"
    return before != json.dumps(st, sort_keys=True)
def _find_attempt(iid, token):
    if not token: return None
    j = journal(iid)
    if _ack_ok(j, token): return j if _verified_record(j) else None
    return next((a for a in _histories(iid) if _ack_ok(a, token) and _verified_record(a)), None)
def _settle(st, iid, result, attempt, t, evidence=None):
    p=_state_path()
    if p in _active(): raise StaleStateError("finish the owner lifecycle transaction before applying receipts")
    with locked(p):
        current=load(p)
        if current["state_id"]!=st.get("state_id"): return {"ok":False,"why":"different caregiver setup"}
        out=_settle_current(current,iid,result,attempt,t,evidence)
        if out["ok"]: save(p,current)
        # Never hand a stale callback an active-policy snapshot to serialize later.
        st.clear(); st.update(current)
        return out

def _settle_current(st, iid, result, attempt, t, evidence=None):
    with _jlock(iid):
        j = _find_attempt(iid, attempt); current = journal(iid)
        if not j: return {"ok": False, "why": "a matching issued attempt token is required"}
        if j.get("state_id") != st["state_id"]: return {"ok": False, "why": "attempt belongs to another setup"}
        if result == "sent" and j["state"] == "sent":
            _apply_sent(st, iid, j, j["result_at"]); return {"ok": True, "replayed": True}
        # Only a genuine issued historical sent completion may settle an older attempt.
        if result != "sent" and (iid in st.get("delivered_events", {}) or not _ack_ok(current, attempt) or j["state"] not in ("reserved", "unknown")):
            return {"ok": False, "why": "not the current outstanding attempt"}
        j = {**j, "state": result, "result_at": t, "receipts": list(j.get("receipts", [])) + [{"outcome": result, "at": t, "evidence": evidence}]}
        # Current sent outcome is the durable write-ahead record; crash recovery applies it without dispatch.
        if _ack_ok(current, attempt): _fsync_write(_jpath(iid), j)
        _history(j)
        if result == "sent": _apply_sent(st, iid, j, t)
        elif result == "failed":
            _remove_current(iid); st["sent_log"].pop(iid, None)
            for q in st["queue"]:
                if q["id"] == iid: q.pop("blocked", None)
        else:
            st["sent_log"][iid] = {"result": "unknown", "at": t, "rid": j["rid"], "token": attempt}
            for q in st["queue"]:
                if q["id"] == iid: q["blocked"] = "unknown result; reconcile first"
        return {"ok": True}
def mark_sent(st, item, result, now=None, attempt=None):
    if result not in ("sent", "failed", "unknown"): raise ValueError("result")
    iid = item["id"] if isinstance(item, dict) else item
    return _settle(st, iid, result, attempt, _now(now))
def reconcile(st, iid, outcome, evidence, now=None, attempt=None):
    """Evidence is local audit data, NOT native send authority. Adapter must verify actual tool record."""
    if not evidence: raise ValueError("evidence from the send tool's own record required")
    if outcome not in ("sent", "not_sent"): raise ValueError("outcome")
    out = _settle(st, iid, "sent" if outcome == "sent" else "failed", attempt, _now(now), evidence)
    if not out["ok"]: raise ValueError(out["why"])
    return out
# ---------------- timing ----------------
def _slots(st, r, z, start, end):
    """Owner-zone slot instants (epoch) in (start, end], DST-correct."""
    hour = r.get("daily_hour", st["daily_hour"]); wd = r.get("weekly_day", st["weekly_day"]); out = []
    d = dt.datetime.fromtimestamp(start, z).date() - dt.timedelta(days=1); last = dt.datetime.fromtimestamp(end, z).date()
    while d <= last:
        if r["timing"] == "daily" or d.weekday() == wd:
            s = int(dt.datetime(d.year, d.month, d.day, hour, tzinfo=z).timestamp())
            if start < s <= end: out.append(s)
        d += dt.timedelta(days=1)
    return out
def due_batches(st, now=None):
    """{rid: [item ids]} due now. Daily/weekly: an item is due at the first owner-zone slot after it was queued (missed
    wakes catch up as one batch; a slot already sent is never sent again). Immediate: after its ~15-minute window.
    High-risk alerts: right away, only for people whose consented scope includes them. Paused people are skipped."""
    migrate(st); t = _now(now); z = _zone(st); out = {}
    for q in st["queue"]:
        r = st["recipients"].get(q["rid"])
        if not r or not _member_ok(st, q) or q.get("blocked"): continue
        c = r.get("consent") or {}
        if q["kind"] not in c.get("scope", []) or t > c.get("review_due", 0): continue
        j = journal(q["id"])
        if _outstanding(q): continue
        if q.get("epoch") != r["epoch"] or q.get("contact_ref") != r["contact_ref"] or q.get("sample_hash") != c.get("sample_hash") or c.get("epoch") != r["epoch"]: continue
        if q["id"] in st.get("delivered_events", {}) or any(m in st.get("delivered_events", {}) for m in q.get("members", [])): continue
        if q["kind"] == "high_risk_alert": due = True
        elif r["timing"] == "immediate":
            # one window per person: it opens at the FIRST unsent event and closes 15 minutes later; everything that
            # arrived inside it goes in that one message
            first = min((x["created"] for x in st["queue"] if x["rid"] == q["rid"] and x["kind"] == "digest" and not x.get("blocked") and _member_ok(st,x) and not journal(x["id"])), default=q["created"])
            due = t >= first + IMMEDIATE_BATCH_S and q["created"] <= first + IMMEDIATE_BATCH_S
        else:
            s = _slots(st, r, z, max(q["created"], r.get("last_slot", 0)), t)
            due = bool(s)
            if due: q["slot"] = s[-1]
        if due: out.setdefault(q["rid"], []).append(q["id"])
    return out

# ---------------- stop / inbound ----------------
def stop(st, rid, now=None):
    r = st["recipients"][rid]; r["state"] = "stopped"; r["stopped_at"] = _now(now)
    st["queue"] = [q for q in st["queue"] if q["rid"] != rid]
    if not any(x["state"] == "active" for x in st["recipients"].values()): st["sharing"] = "off"
def inbound_stop(st, from_addr, resolve_contact):
    sender = _from_addr(from_addr)
    hits = [rid for rid, r in st["recipients"].items() if sender and r["state"] == "active" and _from_addr(resolve_contact(r["contact_ref"])) == sender]
    for rid in hits: stop(st, rid)
    return hits
# Semantic normalization is ONLY for request text. Never apply compatibility normalization
# before mailbox comparison: a visually similar sender is not the consented address.
_STOP_APOS = str.maketrans({"\u2018": "'", "\u2019": "'", "\u02bc": "'"})
_FEED = r"(?:(?:(?:these|those|this|the|your|my|any|all|more|further|such|fortress)\s+)*(?:e-?mails?|messages?|updates?|texts?|digests?|alerts?|notifications?|mailings?|mail|subscription|list)\b|(?:these|those|this|them|it|all|everything)\b)"
_POLITE = r"(?:(?:please|kindly|ok(?:ay)?|thanks|thank\s+you|no\s+thanks)\b[\s,!:]*|(?:can|could|would|will)\s+you\s+(?:please\s+)?|i\s+(?:want|wish)\s+(?:you\s+)?to\s+|i(?:'d|\s+would)\s+like\s+(?:you\s+)?to\s+)"
_TAIL = r"[\s,!]*?(?:(?:please|now|anymore|again|immediately|asap|thanks|thank\s+you|from\s+now\s+on)\s*[,!]*\s*)*$"
_SEND = r"(?:send(?:ing)?|e-?mail(?:ing)?|messag(?:e|ing)|text(?:ing)?|contact(?:ing)?)"
# Positive grammatical predicates, not a negative-lookbehind search for the word STOP.
# Negating STOP ('don't stop', 'do not want you to stop') never reaches an affirmative
# predicate. Negating SEND or WANT/RECEIVE is itself a revocation; scope stays clause-local.
_REVOCATIONS = [
    re.compile(r"^(?:stop|cancel|unsubscribe|opt[ -]?out)(?:\s+all)?" + _TAIL),
    re.compile(r"^(?:stop|quit|cease|discontinue)\s+(?:all\s+)?" + _SEND + r"\s+(?:me\s+|us\s+)?" + _FEED),
    re.compile(r"^(?:stop|quit|cease|discontinue)\s+" + _SEND + _TAIL),
    re.compile(r"^stop\s+" + _FEED + _TAIL),
    re.compile(r"^(?:stop|quit|cease|discontinue)\s+" + _SEND + r"\s+(?:me|us)" + _TAIL),
    re.compile(r"^unsubscribe\s+(?:me|us)\b"),
    re.compile(r"^unsubscribe\s+from\s+" + _FEED),
    re.compile(r"^opt[ -]?out\s+(?:of\s+)?" + _FEED),
    re.compile(r"^(?:take\s+(?:me|us)\s+off|remove\s+(?:me|us)(?:\s+from)?)\s*(?:" + _FEED + r"|" + _TAIL + r")"),
    re.compile(r"^cancel\s+" + _FEED),
    re.compile(r"^no\s+more\s+" + _FEED),
    re.compile(r"^(?:i|we)\s+(?:don't|dont|do\s+not|no\s+longer)\s+(?:want|need|wish\s+to\s+receive)(?:\s+(?:to\s+(?:receive|get)|you\s+to\s+" + _SEND + r"))?\s+" + _FEED),
    re.compile(r"^(?:don't|dont|do\s+not|never)\s+" + _SEND + r"\s+(?:(?:me|us)\s+)?" + _FEED),
    re.compile(r"^(?:don't|dont|do\s+not|never)\s+" + _SEND + r"(?:\s+(?:me|us))?" + _TAIL),
    re.compile(r"^(?:don't|dont|do\s+not)\s+(?:continue|keep)\s+" + _SEND + r"(?:\s+" + _FEED + r"|" + _TAIL + r")"),
]
# ---- v5 auditable clause parser (F1A/B/C) ------------------------------------------------
# 1. Current text = lines before the FIRST history/signature/forwarded-header boundary (unchanged rule).
# 2. Quotation state is carried across lines: text inside "..." or “...” (closed anywhere in the current
#    text) is DATA, never an instruction. A quote that never closes is reported (review), not obeyed.
# 3. Physical lines are joined into logical request units only at a SOFT wrap: the next line starts
#    lowercase, or the previous line ends in a word that cannot end a request (negation, auxiliary,
#    determiner, "please", "to", "want"...). Blank lines, terminal punctuation, greeting/header lines and
#    capitalised new lines after a complete line are hard boundaries.
# 4. Units split into clauses at sentence punctuation and contrast/causal words (unchanged).
# 5. A clause revokes only if a predicate consumes the WHOLE clause (object/complement understood, with an
#    explicit list of harmless trailing words). A predicate that matches only a prefix ("remove me from this
#    photo", "I don't want these emails filtered into spam") is NOT a revocation; if no explicit continuation
#    is present anywhere, the message is routed to owner review (never a silent full STOP or a silent pass).
_DANGLING = re.compile(r"(?:\b(?:don't|dont|do|does|not|never|no|longer|want|wants|need|needs|like|wish|to|be|keep|continue|please|kindly|you|me|us|i|we|the|these|those|this|my|your|any|all|more|further|of|from|with|a|an|and|or|but|stop|quit|cease|send|sending|receive|get|getting|remove|take|unsubscribe|opt|would|could|can|will)|[,—–-])\s*$")
_HEADERISH = re.compile(r"^[a-z][\w -]{0,30}:\s")
_GREETING = re.compile(r"^(?:hi|hello|hey|dear|thanks|thank\s+you|good\s+(?:morning|afternoon|evening))\b[^.!?]{0,40}[,!:]?\s*$")
_ALLOW = r"(?:\s*(?:,|please|now|anymore|any\s+more|again|immediately|asap|thanks|thank\s+you|from\s+now\s+on|for\s+good|altogether|at\s+all|ever|either|too|as\s+well|from\s+(?:you|fortress|this\s+list|the\s+list|your\s+list))\b)*(?:\s+(?:about|regarding|concerning)\b.*)?[\s,!.]*"
_FULL = [re.compile("(?:" + p.pattern + ")" + _ALLOW) for p in _REVOCATIONS]
_CESSATION = r"(?:stop(?:ped)?|end(?:ed)?|ceas(?:e|ed)|cancel(?:led|ed)?|discontinu(?:e|ed)|unsubscrib(?:e|ed)|remov(?:e|ed))"
_CONTINUE = [
    re.compile(r"^(?:please\s+)?(?:keep|continue)\s+(?:sending|send|them|it|these|those|the|my|your|fortress|emailing|texting|on)\b"),
    re.compile(r"^(?:please\s+)?(?:don't|dont|do\s+not|never)\s+(?:(?:want\s+(?:you\s+)?to|ever)\s+)?" + _CESSATION + r"\b"),
    re.compile(r"^(?:i|we)\s+(?:don't|dont|do\s+not)\s+want\s+(?:you\s+to\s+)?" + _CESSATION + r"\b"),
    re.compile(r"^(?:i|we)\s+(?:don't|dont|do\s+not|no\s+longer)\s+(?:want|need)\s+.*?\s(?:to\s+(?:be\s+)?|being\s+)?" + _CESSATION + r"\b"),
]
def _semantic(text):
    """NFKC + apostrophe folding; case is KEPT here because a capitalised new line is a wrap signal."""
    return unicodedata.normalize("NFKC", text or "").translate(_STOP_APOS)
def _blank_quotes(text):
    """Return (text with closed double/curly quotations blanked, text of any UNCLOSED quotation)."""
    out, i, n = [], 0, len(text)
    while i < n:
        ch = text[i]
        if ch in "\"\u201c":
            close = "\"" if ch == "\"" else "\u201d"
            j = text.find(close, i + 1)
            if j < 0: return "".join(out), text[i + 1:]
            out.append(" " + "".join("\n" if c == "\n" else " " for c in text[i + 1:j]) + " "); i = j + 1; continue
        out.append(ch); i += 1
    return "".join(out), ""
def _units(text):
    """Logical request units from current (pre-boundary) semantic text; see rules 3-4 above."""
    units, cur = [], ""
    for raw in text.split("\n"):
        line = raw.strip()
        if not line or re.fullmatch(r"[\W_]+", line):            # blank line or a rule/punctuation-only line
            if cur: units.append(cur); cur = ""
            continue
        if cur:
            low = cur.casefold()
            soft = not (_HEADERISH.match(low) or _GREETING.match(low)) and (line[:1].islower() or _DANGLING.search(low))
            if soft and not re.search(r"[.!?;:]\s*$", cur): cur = cur + " " + line; continue
            units.append(cur)
        cur = line
    if cur: units.append(cur)
    return [u.casefold() for u in units]
def _clauses(unit):
    unit = re.sub(r"(?<!\w)'[^'\n]*'(?!\w)", " ", unit)            # same-line single-quote spans (contractions kept)
    for clause in re.split(r"[.;!?]+|\b(?:but|however|instead|because|since)\b", unit):
        clause = clause.strip(" ,:—–")
        clause = re.sub(r"^(?:hi|hello|hey|dear)(?:\s+[^,!:]+)?[,!:]\s*", "", clause)
        clause = re.sub(r"^(?:" + _POLITE + r")+", "", clause).strip()
        if clause: yield clause
def _classify(clause):
    """'revoke' (whole clause understood), 'continue', 'partial' (a revocation verb with an object/complement
    that is not this feed), or None."""
    for c in _CONTINUE:
        if c.match(clause): return "continue"
    if any(f.fullmatch(clause) for f in _FULL): return "revoke"
    if any(p.match(clause) for p in _REVOCATIONS): return "partial"
    return None
def _analyze(text):
    """{'revoke': bool, 'review': reason|None} for one current text block (subject or body)."""
    sem = _semantic(text)
    blanked, unclosed = _blank_quotes(sem)
    kinds = [_classify(c) for u in _units(blanked) for c in _clauses(u)]
    if "revoke" in kinds: return {"revoke": True, "review": None}
    reason = None
    if unclosed and any(_classify(c) in ("revoke", "partial") for u in _units(unclosed) for c in _clauses(u)):
        reason = "opt-out wording inside an unclosed quotation"
    elif "partial" in kinds and "continue" not in kinds:
        reason = "opt-out verb with an object or complement the parser does not understand"
    return {"revoke": False, "review": reason}
def _stop_requested(line):
    """Back-compatible single-text check (a whole subject or a whole current body)."""
    return _analyze(line)["revoke"]
_HISTORY = re.compile(r"(?i)^(?:>+|on\b.*\bwrote\s*:|[-_]{2,}\s*(?:original|forwarded)\s+message|begin\s+forwarded\s+message\s*:)" )
_SIGNATURE = re.compile(r"(?i)^(?:--|sent\s+from\s+.+|(?:best(?:\s+regards)?|kind\s+regards|regards|sincerely|cheers)[,!]?)\s*$")
def _request_lines(text):
    """All current lines up to the FIRST explicit history/signature boundary (blank lines kept as paragraph
    boundaries). Never skip quoted history and resume searching later lines within it."""
    lines = (text or "").splitlines()
    for pos, line in enumerate(lines):
        stripped = line.strip()
        if _HISTORY.match(stripped) or _SIGNATURE.fullmatch(stripped): break
        # A structured forwarded header BLOCK, not an arbitrary current "Subject:" title.
        if re.match(r"(?i)^from\s*:", stripped) and any(re.match(r"(?i)^(?:sent|date|to|subject)\s*:", x.strip()) for x in lines[pos+1:pos+5]): break
        yield stripped

def _from_addr(raw):
    # parseaddr's conservative default ambiguity handling is unchanged. Display/encoded
    # words/comments do not supply a mailbox. Reject actual addresses changed by NFKC,
    # before lowercasing; never conflate a compatibility lookalike with a consented address.
    try: address = email.utils.parseaddr(raw or "")[1]
    except (TypeError, ValueError, IndexError): return ""
    if unicodedata.normalize("NFKC", address) != address: return ""
    return _addr(address)
def process_inbound(st, from_addr, to_addr, subject, text, now=None):
    """Run FIRST on every message arriving in this bot's own inbox. Stops only the person whose consented address sent
    STOP. Does NOT certify sweep completion; the native this-wake STOP gate remains open."""
    migrate(st); t = _now(now)   # (does NOT certify the STOP sweep; see mark_inbox_checked and the V5-10 plan)
    if not st["own_inbox"] or _from_addr(to_addr) != st["own_inbox"]: return {"stopped": [], "note": "not addressed to this bot's own inbox"}
    subj = re.sub(r"(?i)^\s*((re|fwd?|aw)\s*:\s*)+", "", subject or "")
    sa, ba = _analyze(subj), _analyze("\n".join(_request_lines(text)))
    if not (sa["revoke"] or ba["revoke"]):
        reason = sa["review"] or ba["review"]
        if not reason: return {"stopped": []}
        # Not understood well enough to STOP or to ignore: durable owner-review item; nobody is stopped or
        # resumed, and this is NOT a completed STOP sweep for this message.
        sender = _from_addr(from_addr)
        rids = [rid for rid, r in st["recipients"].items() if r["state"] == "active" and sender and (r.get("consent") or {}).get("destination") == sender]
        st.setdefault("stop_review", []).append({"t": t, "rids": rids, "reason": reason, "resolved": False})
        st["log"].append({"t": t, "event": "inbound_stop_review", "rids": rids, "reason": reason, "unverified": True})
        return {"stopped": [], "review_pending": True, "rids": rids, "reason": reason, "tell_owner": True, "unverified": True,
                "note": "This reply mentions opting out but the parser could not tell what it refers to. Nobody was stopped; ask the owner (or the person) whether to stop sharing. It does not count as a processed STOP."}
    sender = _from_addr(from_addr)
    hits = [rid for rid, r in st["recipients"].items() if r["state"] == "active" and sender and (r.get("consent") or {}).get("destination") == sender]
    for rid in hits: stop(st, rid, t)
    st["log"].append({"t": t, "event": "inbound_stop", "stopped": hits, "unverified": True})
    return {"stopped": hits, "tell_owner": True, "unverified": True,
            "note": "The From address was not authenticated; this could be a spoofed STOP. Sharing to that person is paused for privacy; tell the owner it was an unverified STOP so they can re-add them if it was not really them."}
def mark_inbox_checked(st, now=None):
    st["inbox_checked_at"] = _now(now)
    pending = [x for x in st.get("stop_review", []) if not x.get("resolved")]
    return {"ok": True, "stop_review_pending": len(pending)}   # pending reviews are reported, never treated as resolved
def revoke_all(st, now=None):
    for rid, r in st["recipients"].items():
        if r["state"] != "stopped": stop(st, rid, now)
    st["queue"] = []; st["sharing"] = "off"; return {"delete_routines": True}

# ---------------- CLI (locked) ----------------
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("cmd", choices=["due", "batch", "render", "claim", "result", "reconcile", "inbound", "inbox-checked", "stop", "stop-all"])
    ap.add_argument("--state", required=True); ap.add_argument("--now", type=int); ap.add_argument("--rid"); ap.add_argument("--id")
    for k in ("from", "to", "tools", "permission", "text-file", "outcome", "evidence", "subject", "attempt"): ap.add_argument("--" + k)
    a = ap.parse_args()
    try: _home(); _owned(a.state)
    except PermissionError as e: print(json.dumps({"error": str(e)})); sys.exit(2)
    with locked(a.state):
        st = load(a.state); out = None
        item = next((q for q in st["queue"] if q["id"] == a.id), None) if a.id else None
        if a.cmd == "due": out = due_batches(st, a.now)
        elif a.cmd == "batch": out = {"id": make_batch(st, a.rid, due_batches(st, a.now).get(a.rid, []), a.now)}
        elif a.cmd == "render": out = {"to": st["recipients"][item["rid"]]["consent"]["destination"], "text": render(st, item)} if item else {"error": "no such item"}
        elif a.cmd == "claim":
            ok, why = presend_gate(st, item, a.__dict__["from"], a.now, (a.tools or "").split(","), open(a.text_file).read() if a.text_file else None, a.to, a.permission) if item else (False, ["no such item"])
            out = {"ok": ok, "why": why}
            if ok: out["attempt"] = journal(item["id"])["token"]
        elif a.cmd == "result": out = mark_sent(st, item if item else a.id, a.outcome, a.now, a.attempt)
        elif a.cmd == "reconcile": reconcile(st, a.id, a.outcome, a.evidence, a.now, a.attempt); out = {"ok": True}
        elif a.cmd == "inbound": out = process_inbound(st, a.__dict__["from"], a.to, a.subject, open(a.text_file).read() if a.text_file else "", a.now)
        elif a.cmd == "inbox-checked": out = mark_inbox_checked(st, a.now)
        elif a.cmd == "stop": stop(st, a.rid, a.now); out = {"ok": True}
        else: out = revoke_all(st, a.now)
        save(a.state, st); print(json.dumps(out))
_LIFECYCLE_WRITES = {"propose","show_sample","record_consent","reconfirm","configure_sender","activate","change_timing","enqueue","project_source","reproject_source","make_batch","due_batches","stop","inbound_stop","process_inbound","mark_inbox_checked","revoke_all"}
def _guard(fn):
    import functools
    @functools.wraps(fn)
    def w(*a, **k):
        _home()
        if fn.__name__ == "presend_gate":
            with locked(_state_path()): return fn(*a, **k)
        if fn.__name__ in _LIFECYCLE_WRITES:
            st=a[0]; p=_state_path()
            with locked(p):
                if p in _active():
                    if _active()[p] is not st: raise StaleStateError("use the current transaction state object")
                    return fn(*a, **k)
                try:
                    with open(p) as f: current=json.load(f)
                except FileNotFoundError: return fn(*a, **k)  # new unsaved setup; first save is an explicit CAS
                if current.get("state_id")!=st.get("state_id"): return fn(*a, **k) # separate unsaved setup can never replace canonical via save
                if current.get("revision",0)!=st.get("revision",0): raise StaleStateError("stale lifecycle state; reload before applying this operation")
                before=json.loads(json.dumps(st)); _active()[p]=st
                try:
                    migrate(st)
                    out=fn(*a, **k)
                    save(p,st)
                    return out
                except Exception:
                    st.clear(); st.update(before)
                    raise
                finally: _active().pop(p,None)
        return fn(*a, **k)
    return w
for _n in ("propose", "show_sample", "record_consent", "reconfirm", "configure_sender", "activate", "change_timing", "enqueue",
           "sample_preview", "project_source", "reproject_source", "make_batch", "presend_gate", "mark_sent", "reconcile", "due_batches", "stop", "inbound_stop", "process_inbound",
           "mark_inbox_checked", "revoke_all"):
    globals()[_n] = _guard(globals()[_n])
if __name__ == "__main__": main()
