"""Fortress controller (scope A, owner t655u). ONE serialized, durable, append-only transaction log with epochs and
immutable baseline facts. Helpers ask the controller for authority; late callbacks/recovery only APPEND facts.

Honest limits (do not over-read):
- Path handling is NON-H1: ordinary paths under FORTRESS_HOME, no host filesystem confinement, no ancestor/relocation
  safety against other same-UID actors (H1 unverified, deferred).
- The hash chain (`prev`) detects accidental corruption/truncation only; it is NOT same-UID security.
- No trusted pre-execution entry (H2 unverified, deferred). No exactly-once claim for external effects.
"""
import os, json, fcntl, hashlib, datetime as _dt
SCHEMA = 1
class ControllerHeld(RuntimeError): pass
def _now(): return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
class Controller:
    def __init__(self, fh, instance="", lane=""):
        self.dir = os.path.join(fh, "private", "update", "controller"); self.log = os.path.join(self.dir, "log.jsonl")
        self.lockp = os.path.join(self.dir, "log.lock"); self.instance = instance; self.lane = lane
    def _entries(self):
        try:
            with open(self.log, "rb") as f: raw = f.read()
        except FileNotFoundError: return [], None
        if raw and not raw.endswith(b"\n"): raise ControllerHeld("controller log has a torn final entry; held for review (evidence kept)")
        out, prev = [], None
        for line in raw.split(b"\n")[:-1]:
            try: e = json.loads(line)
            except ValueError: raise ControllerHeld("controller log entry unreadable; held for review (evidence kept)")
            if not isinstance(e, dict) or e.get("seq") != len(out) or e.get("prev") != prev:
                raise ControllerHeld("controller log sequence/chain broken; held for review (evidence kept)")
            out.append(e); prev = hashlib.sha256(line).hexdigest()
        return out, prev
    def entries(self): return self._entries()[0]
    def append(self, kind, **fields):
        """Serialized (exclusive lock), atomic single-line O_APPEND write, fsync file + directory before returning."""
        os.makedirs(self.dir, exist_ok=True)
        with open(self.lockp, "a") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            ents, prev = self._entries()
            e = {"schema": SCHEMA, "seq": len(ents), "prev": prev, "kind": kind, "at": _now(), "instance": self.instance, "lane": self.lane, **fields}
            line = (json.dumps(e, sort_keys=True, separators=(",", ":")) + "\n").encode()
            fd = os.open(self.log, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
            try: os.write(fd, line); os.fsync(fd)
            finally: os.close(fd)
            dfd = os.open(self.dir, os.O_RDONLY)
            try: os.fsync(dfd)
            finally: os.close(dfd)
            return e
    def fold(self):
        """Pure fold of the log: current epoch per version and established baselines."""
        ep, base = {}, {}
        for e in self.entries():
            v = e.get("version")
            if e["kind"] == "epoch_open": ep[v] = {"epoch": e["epoch"], "open": True, "plan_sha256": e.get("plan_sha256")}
            elif e["kind"] == "epoch_close" and v in ep and ep[v]["epoch"] == e.get("epoch"): ep[v]["open"] = False
            elif e["kind"] == "baseline_established" and v not in base: base[v] = e
        return {"epochs": ep, "baselines": base}
    def current_epoch(self, version):
        x = self.fold()["epochs"].get(version); return x["epoch"] if x and x["open"] else None
    def open_epoch(self, version, plan_sha256, approval_scope, source_rev=None):
        cur = self.current_epoch(version)
        if cur: self.append("epoch_close", version=version, epoch=cur, reason="superseded by a new Apply")
        eid = os.urandom(8).hex(); op = os.urandom(8).hex()
        self.append("epoch_open", version=version, epoch=eid, op_id=op, plan_sha256=plan_sha256, approval_scope=approval_scope, source_rev=source_rev)
        return eid
    def close_epoch(self, version, reason):
        cur = self.current_epoch(version)
        if cur: self.append("epoch_close", version=version, epoch=cur, reason=reason)
        return cur
    def baseline(self, version): return self.fold()["baselines"].get(version)
    def establish_baseline(self, version, index_sha256, targets, plan_sha256):
        """Immutable: established ONCE at the first successful commit; later calls never replace it."""
        b = self.baseline(version)
        if b: return b
        return self.append("baseline_established", version=version, index_sha256=index_sha256, targets=sorted(targets), plan_sha256=plan_sha256)
    def fact(self, kind, **f): return self.append(kind, **f)
    def commit_fresh(self, path, revalidate_and_mutate, locked_update, **binding):
        """Controller-mediated source write (v12 R02): locked_update holds the source's exclusive lock, re-reads it FRESH and
        calls revalidate_and_mutate(fresh) which recomputes anchors/authority and returns (new_obj, rejected_list).
        Rejections (stale clocks) are appended as facts; nothing stale is committed."""
        rej = []
        def m(d):
            new, r = revalidate_and_mutate(d); rej.extend(r); return new
        ok = locked_update(path, m)
        self.append("source_commit", path_rel=os.path.basename(path), committed=bool(ok), rejected=rej, **binding)
        return ok, rej
