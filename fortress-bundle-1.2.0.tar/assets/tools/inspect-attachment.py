#!/usr/bin/env python3
"""inspect-attachment.py - pull link targets out of a suspicious attachment WITHOUT visiting them.

Supports: .pdf (pdftotext + raw /URI annotations + bounded offline page rasterization for QR), .html/.htm/.svg/.txt
(read as text only), .eml (headers + bodies + nested attachments), images (.png/.jpg/.jpeg/.gif/.webp/.bmp: QR decode;
OCR only if tesseract exists).
Never fetches any URL, never runs scripts, never renders HTML, no browser or PDF viewer. PDFs: up to MAX_PDF_PAGES
pages are rasterized locally (pdftoppm, longest side <= PDF_RASTER_PX) into images only to look for QR codes.
v12 input gate: ONE no-follow, non-blocking descriptor per input; it must be a regular file (FIFOs, devices, sockets,
directories and a symlinked final path component are refused without blocking); fstat size cap, capped read that rejects
cap+1 bytes, and a second fstat that refuses a file that changed while it was read. Only that private snapshot is parsed.
Bounds, checked BEFORE parsing: MAX_BYTES file size, extension + magic must agree (a non-image named .png is refused),
MIME structure pre-scan (boundary count/nesting) before the MIME parser runs, encoded image dimensions before decoding
and decoded dimensions after, part/depth/decoded-size/item limits. ALL parsing (images, MIME, PDF incl. its OpenCV QR decode, text) runs in ONE supervised worker job and every external
tool runs in a child of it, each under CPU/memory/file-size/open-file limits; the job has one total wall deadline,
bounded streaming stdout/stderr (killed when over the cap), and every child carries a parent-death SIGKILL. When the
kernel allows it, the job runs in fresh user+network+PID namespaces (`unshare -rn -p -f --kill-child`, verified loopback
only): killing the job kills every descendant, including ones that started a new session. Nested children re-verify the
current namespace themselves; an inherited environment marker alone never skips isolation. If namespaces are not
available the file is REFUSED by default (nothing parsed); only with the owner's approval `--allow-unisolated-network`
parses anyway and the result then says network isolation: unavailable, descendants: process-group + parent-death only.
FILESYSTEM ISOLATION IS NOT PROVIDED: the worker runs as the same user and can read/write what that user can. This is
resource limiting plus network/PID denial, not a malware sandbox; untrusted parsing should run only in a disposable
restricted environment (see `isolation.filesystem` in every report).
Any timeout, missing tool, limit, nonzero exit or crash makes the result "incomplete" (structured `incomplete_reasons`). "No links found" is never "safe".

Usage:
  python3 inspect-attachment.py FILE [FILE...] [--json] [--enrich] [--allow-unisolated-network]
    --enrich  run enrich-domain.py (RDAP age/registrar) on the extracted registered domains (no visit to the sites)
"""
import sys, os, re, json, subprocess, shutil, tempfile, email, argparse, struct, stat, threading, time, signal
from email import policy
from urllib.parse import urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
SELF = os.path.abspath(__file__)
sys.path.insert(0, HERE)
URL_RE = re.compile(rb"(?i)\b(?:https?://|www\.)[^\s\"'<>()\[\]{}\\]{3,}")
MAILTO_RE = re.compile(rb"(?i)mailto:[^\s\"'<>]+")
TEL_RE = re.compile(rb"(?i)(?:tel:)?\+?1?[\s.(-]*\d{3}[\s.)-]*\d{3}[\s.-]*\d{4}\b")
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
TEXT_EXT = {".html", ".htm", ".svg", ".txt"}
ALLOWED = IMG_EXT | TEXT_EXT | {".pdf", ".eml"}
MAX_BYTES = 15 * 1024 * 1024; MAX_DEPTH = 3; MAX_PARTS = 50; MAX_DECODED = 40 * 1024 * 1024
MAX_BOUNDARIES = 60; MAX_ITEMS = 500; MAX_WORKER_OUT = 4 * 1024 * 1024
MAX_PDF_PAGES = 5; PDF_RASTER_PX = 1600; MAX_PIXELS = 40_000_000
TOOL_CPU_S = 30; TOOL_MEM = 1024 * 1024 * 1024; TOOL_FSIZE = 64 * 1024 * 1024; TOOL_WALL_S = 60
JOB_WALL_S = TOOL_WALL_S * 3; MAX_TOOL_OUT = MAX_DECODED; MAX_ERR = 64 * 1024; RUN_TOTAL_S = 900
os.environ["OPENCV_IO_MAX_IMAGE_PIXELS"] = str(MAX_PIXELS)      # forced, not setdefault: the caller cannot raise it
for _k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OPENCV_FOR_THREADS_NUM"):
    os.environ[_k] = "1"     # single-threaded decoders: thread arenas would otherwise exceed the child memory cap
IMG_MAGIC = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF87a", b"GIF89a", b"BM")
class Refused(ValueError): pass
_fstat = os.fstat        # module alias (tests may substitute it to simulate a file changing between checks)
def _inc(notes, msg):
    """Record an incompleteness reason both as text and structurally (status never depends on English regex alone)."""
    notes.append(msg)
    lst = getattr(notes, "incomplete", None)
    if lst is not None: lst.append(msg)
class Notes(list):
    def __init__(self, *a): super().__init__(*a); self.incomplete = []

# ---------- isolation ----------
def _pdeathsig():
    try:
        import ctypes
        ctypes.CDLL(None, use_errno=True).prctl(1, signal.SIGKILL, 0, 0, 0)    # PR_SET_PDEATHSIG
    except Exception: pass
def _limits():
    _pdeathsig()
    import resource
    def cap(r, v):
        soft, hard = resource.getrlimit(r)
        v = v if hard == resource.RLIM_INFINITY else min(v, hard)
        resource.setrlimit(r, (v, v))
    cap(resource.RLIMIT_CPU, TOOL_CPU_S); cap(resource.RLIMIT_AS, TOOL_MEM); cap(resource.RLIMIT_FSIZE, TOOL_FSIZE)
    cap(resource.RLIMIT_NOFILE, 64); cap(resource.RLIMIT_CORE, 0)
class OutputCap(RuntimeError): pass
def _run(cmd, timeout, env, out_cap=MAX_TOOL_OUT, err_cap=MAX_ERR):
    """Supervised child: own process group, _limits (rlimits + parent-death SIGKILL), bounded STREAMING stdout/stderr
    (over the cap -> whole group killed, OutputCap), wall timeout -> whole group killed (TimeoutExpired)."""
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, preexec_fn=_limits, env=env, start_new_session=True)
    bufs = {"out": bytearray(), "err": bytearray()}; over = []
    def pump(stream, key, cap):
        while True:
            b = stream.read(65536)
            if not b: break
            if len(bufs[key]) + len(b) > cap:
                bufs[key] += b[:max(0, cap - len(bufs[key]))]; over.append(key); _kill(p); break
            bufs[key] += b
    ts = [threading.Thread(target=pump, args=(p.stdout, "out", out_cap), daemon=True), threading.Thread(target=pump, args=(p.stderr, "err", err_cap), daemon=True)]
    for t in ts: t.start()
    try: p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill(p); p.wait()
        for t in ts: t.join(2)
        raise
    _kill(p)     # reap anything left in the group (descendants of a finished child)
    for t in ts: t.join(5)
    if over: raise OutputCap(f"output over the {out_cap if 'out' in over else err_cap} byte cap: child killed")
    return subprocess.CompletedProcess(cmd, p.returncode, bytes(bufs["out"]), bytes(bufs["err"]))
def _kill(p):
    try: os.killpg(p.pid, signal.SIGKILL)
    except OSError: pass
_NET = None
def network_isolation():
    """Probe once: can children run in an empty network namespace? Verified by listing interfaces inside it."""
    global _NET
    if _NET is not None: return _NET
    if _only_loopback():     # derived from the CURRENT namespace, never from an inherited marker
        _NET = {"status": "enforced", "method": "already inside an empty network namespace (verified now: loopback only)", "pid_namespace": "inherited"}; return _NET
    un = shutil.which("unshare")
    if not un:
        _NET = {"status": "unavailable", "method": None, "why": "unshare not installed"}; return _NET
    try:
        p = subprocess.run([un, "-rn", "-p", "-f", "--kill-child", sys.executable, "-c", "import socket,json;print(json.dumps([n for _,n in socket.if_nameindex()]))"],
                           capture_output=True, text=True, timeout=10)
        names = json.loads(p.stdout or "null") if p.returncode == 0 else None
    except Exception as ex:
        names = None; p = None
    if names == ["lo"]:
        _NET = {"status": "enforced", "method": "unshare -rn -p -f --kill-child (user + network + PID namespace; verified loopback only)", "pid_namespace": "enforced"}
    else:
        _NET = {"status": "unavailable", "method": None,
                "why": f"empty network namespace could not be created here ({(p.stderr or '').strip()[:160] if p else 'probe failed'}); children ran with the box's normal network (no link is ever fetched by this tool, but that is not enforced)"}
    return _NET
def _only_loopback():
    try:
        import socket; return [n for _, n in socket.if_nameindex()] == ["lo"]
    except Exception: return False
def _wrap(cmd):
    """Execution path agrees with verification: skip a NEW namespace only when THIS process is verified loopback-only now
    (then children inherit it); otherwise wrap whenever the probe says namespaces work. A marker is informational only."""
    if _only_loopback(): return cmd
    return (["unshare", "-rn", "-p", "-f", "--kill-child"] + cmd) if network_isolation()["status"] == "enforced" else cmd
ALLOW_UNISOLATED = False
def _tool(cmd, timeout=TOOL_WALL_S, require_isolation=False, **caps):
    """Every child (external tools AND the parser worker job) starts here: same env scrub, wrap and supervision.
    require_isolation (used for the parser JOB): refuse unless the job will really run network-isolated (safe default);
    tools started inside an already-launched job inherit that job's status."""
    if require_isolation and not _only_loopback() and network_isolation()["status"] != "enforced" and not ALLOW_UNISOLATED:
        raise Refused("refused: network isolation is unavailable on this box, so the file was NOT parsed (safe default). "
                      "Parse only in a supported isolated environment, or re-run with --allow-unisolated-network after the owner approves.")
    env = {k: v for k, v in os.environ.items() if "proxy" not in k.lower()}
    env.pop("FORTRESS_IA_IN_NETNS", None)
    return _run(_wrap(cmd), timeout, env, **caps)

# ---------- type gate ----------
def sniff(head):
    if b"%PDF-" in head[:1024]: return "pdf"
    if head.startswith(IMG_MAGIC) or (head[:4] == b"RIFF" and head[8:12] == b"WEBP"): return "img"
    return "other"
def read_input(path):
    """Single descriptor, O_NOFOLLOW|O_NONBLOCK: regular file only, fstat cap, capped read (cap+1 rejected), re-fstat."""
    try: fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0))
    except OSError as ex:
        import errno
        if ex.errno == errno.ELOOP: raise Refused("refused: the input path is a symbolic link - not followed, not opened")
        raise Refused(f"refused: could not open input ({ex.strerror})")
    try:
        st = _fstat(fd)
        if not stat.S_ISREG(st.st_mode): raise Refused("refused: not a regular file (FIFO/device/socket/directory) - not read")
        if st.st_size > MAX_BYTES: raise Refused(f"refused: {st.st_size} bytes > {MAX_BYTES} cap (not read)")
        chunks, total = [], 0
        while total <= MAX_BYTES:
            b = os.read(fd, min(1 << 20, MAX_BYTES + 1 - total))
            if not b: break
            chunks.append(b); total += len(b)
        raw = b"".join(chunks)
        if len(raw) > MAX_BYTES: raise Refused(f"refused: file grew past the {MAX_BYTES} byte cap while being read - not parsed")
        st2 = _fstat(fd)
        if (st2.st_size, st2.st_mtime_ns, st2.st_ino) != (st.st_size, st.st_mtime_ns, st.st_ino) or len(raw) != st.st_size:
            raise Refused("refused: file changed while it was being read (size/time mismatch) - not parsed; save it again and retry")
        return raw
    finally: os.close(fd)
def precheck(path, depth=0, budget=None, raw=None):
    if depth > MAX_DEPTH: raise Refused("refused: attachments nested too deep (not opened)")
    ext = os.path.splitext(path)[1].lower()
    if ext not in ALLOWED: raise Refused(f"refused: type {ext or '(none)'} not supported - not opened")
    if raw is None: raw = read_input(path)
    size = len(raw)
    if size > MAX_BYTES: raise Refused(f"refused: {size} bytes > {MAX_BYTES} cap (not opened)")
    head = raw[:1024]
    kind = sniff(head)
    if ext in IMG_EXT and kind != "img": raise Refused(f"refused: named {ext} but the content is not a supported image (magic mismatch) - not decoded")
    if ext == ".pdf" and kind != "pdf": raise Refused("refused: named .pdf but has no PDF signature (%PDF-) - not parsed")
    if ext in TEXT_EXT | {".eml"} and kind != "other": raise Refused(f"refused: named {ext} but the content is a {kind.upper()} file - type mismatch, not parsed")
    if budget is not None:
        budget[0] += size
        if budget[0] > MAX_DECODED: raise Refused("refused: total decoded size limit reached")
    return ext, raw

def defang(u): return u.replace("http", "hxxp").replace(".", "[.]")
def host_of(u):
    if u.lower().startswith("www."): u = "http://" + u
    try: return (urlsplit(u).hostname or "").lower()
    except Exception: return ""
def reg_domain(h):
    from fortress_domain import registered_domain
    return registered_domain(h)   # None = unknown

# ---------- images ----------
def image_dims(path):
    """Width/height from the encoded header, read before any decoder runs. None if not determinable."""
    try:
        with open(path, "rb") as fh: b = fh.read(65536)
    except OSError: return None
    try:
        if b.startswith(b"\x89PNG") and b[12:16] == b"IHDR": return struct.unpack(">II", b[16:24])
        if b[:3] == b"GIF": return struct.unpack("<HH", b[6:10])
        if b[:2] == b"BM": w, h = struct.unpack("<ii", b[18:26]); return abs(w), abs(h)
        if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
            c = b[12:16]
            if c == b"VP8X": return 1 + int.from_bytes(b[24:27], "little"), 1 + int.from_bytes(b[27:30], "little")
            if c == b"VP8L": v = int.from_bytes(b[21:25], "little"); return (v & 0x3FFF) + 1, ((v >> 14) & 0x3FFF) + 1
            if c == b"VP8 ": return struct.unpack("<HH", b[26:30])[0] & 0x3FFF, struct.unpack("<HH", b[26:30])[1] & 0x3FFF
        if b[:2] == b"\xff\xd8":
            i = 2
            while i + 9 < len(b):
                if b[i] != 0xFF: i += 1; continue
                m = b[i + 1]
                if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    h, w = struct.unpack(">HH", b[i + 5:i + 9]); return w, h
                if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7: i += 2; continue
                i += 2 + struct.unpack(">H", b[i + 2:i + 4])[0]
    except Exception: return None
    return None
def qr_from_image(path):
    d = image_dims(path)
    if d and d[0] * d[1] > MAX_PIXELS: return [], f"image is {d[0]}x{d[1]} pixels, over the {MAX_PIXELS} pixel limit: not decoded (QR NOT checked)"
    try:
        import cv2
    except ImportError:
        return [], "opencv not installed (pip install --user opencv-python-headless): QR codes NOT checked"
    img = cv2.imread(path)
    if img is None: return [], "image could not be decoded (unreadable or over the decoder pixel limit): QR NOT checked"
    shape = getattr(img, "shape", None) or (0, 0)
    if shape[0] * shape[1] > MAX_PIXELS:
        return [], f"decoded image is {shape[1]}x{shape[0]} pixels, over the {MAX_PIXELS} pixel limit: QR NOT checked"
    det = cv2.QRCodeDetector(); out = []
    try:
        ok, vals, _, _ = det.detectAndDecodeMulti(img)
        if ok: out = [v for v in vals if v]
    except Exception:
        pass
    if not out:
        try:
            v, _, _ = det.detectAndDecode(img)
            if v: out = [v]
        except Exception as ex: return [], f"QR decoder failed ({type(ex).__name__}): QR NOT checked"
    return out, None
def ocr(path):
    """None = tesseract absent; '\0timeout'; '\0error:<rc>' for any nonzero/failed run; else the text."""
    if not shutil.which("tesseract"): return None
    try: p = _tool(["tesseract", path, "-", "--psm", "6"])
    except subprocess.TimeoutExpired: return "\0timeout"
    except Exception as ex: return f"\0error:{type(ex).__name__}"
    if getattr(p, "returncode", 0) not in (0, None): return f"\0error:exit {p.returncode}"
    return (p.stdout or b"").decode("utf-8", "replace")

def scan_bytes(b, found, src):
    for m in URL_RE.findall(b): found.append({"kind": "url", "value": m.decode("utf-8", "replace").rstrip(".,;"), "where": src})
    for m in MAILTO_RE.findall(b): found.append({"kind": "mailto", "value": m.decode("utf-8", "replace"), "where": src})
    for m in TEL_RE.findall(b):
        digits = re.sub(r"\D", "", m.decode())
        if len(digits) in (10, 11): found.append({"kind": "phone", "value": digits[-10:], "where": src})

def _img_ext(b):
    if b.startswith(b"\x89PNG"): return ".png"
    if b.startswith(b"\xff\xd8\xff"): return ".jpg"
    if b.startswith((b"GIF87a", b"GIF89a")): return ".gif"
    if b.startswith(b"BM"): return ".bmp"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP": return ".webp"
    return None
def mime_prescan(raw):
    """Linear scan BEFORE the MIME parser: refuse structures with too many multipart boundaries or nesting."""
    bounds = re.findall(rb'(?i)boundary\s*=\s*"?([^";\r\n]+)', raw)
    if len(bounds) > MAX_BOUNDARIES:
        return f"MIME structure has {len(bounds)} multipart boundaries, over the {MAX_BOUNDARIES} limit (depth/part limit): message NOT parsed, its parts were NOT checked"
    return None

def _run_tool_note(cmd, label, notes, timeout=TOOL_WALL_S):
    try:
        p = _tool(cmd, timeout=timeout)
    except subprocess.TimeoutExpired:
        _inc(notes, f"{label} timed out after {timeout}s: NOT checked (incomplete)"); return None
    except Exception as ex:
        _inc(notes, f"{label} could not run ({type(ex).__name__}): NOT checked (incomplete)"); return None
    rc = getattr(p, "returncode", 0)
    if rc not in (0, None):
        _inc(notes, f"{label} stopped with exit {rc} (error, CPU/memory/size limit or damaged file): results may be partial (incomplete)")
    return p

def inspect(path, notes, depth=0, budget=None):
    found = []; budget = budget if budget is not None else [0]
    ext, raw = precheck(path, depth, budget)
    if ext == ".pdf":
        for m in re.findall(rb"/URI\s*\(([^)]{1,2048})\)", raw): found.append({"kind": "url", "value": m.decode("latin-1"), "where": "pdf link annotation"})
        if re.search(rb"/ObjStm|/FlateDecode", raw): notes.append("PDF uses compressed streams: link annotations inside them are only found via pdftotext text; some may be missed")
        if re.search(rb"/JavaScript|/JS\s|/OpenAction|/Launch|/EmbeddedFile", raw): notes.append("PDF contains auto-run/JavaScript/embedded-file markers: do not open it in a full PDF reader")
        if shutil.which("pdftotext"):
            p = _run_tool_note(["pdftotext", "-l", "50", "-layout", path, "-"], "pdftotext (PDF text)", notes)
            if p is not None: scan_bytes((p.stdout or b"")[:MAX_DECODED], found, "pdf text")
        else: notes.append("pdftotext not installed: PDF text NOT checked")
        npages = None
        if shutil.which("pdfinfo"):
            p = _run_tool_note(["pdfinfo", path], "pdfinfo (page count)", notes, timeout=30)
            m = re.search(rb"(?m)^Pages:\s+(\d+)", (p.stdout or b"") if p is not None else b"")
            npages = int(m.group(1)) if m else None
        if shutil.which("pdftoppm"):
            with tempfile.TemporaryDirectory() as td:
                _run_tool_note(["pdftoppm", "-scale-to", str(PDF_RASTER_PX), "-l", str(MAX_PDF_PAGES), "-png", path, os.path.join(td, "p")],
                               "pdftoppm (local page rasterization for QR)", notes, timeout=120)
                if npages is None: notes.append(f"Page count unknown: at most the first {MAX_PDF_PAGES} pages were rasterized for QR codes; any later pages were NOT checked")
                elif npages > MAX_PDF_PAGES: notes.append(f"Only the first {MAX_PDF_PAGES} of {npages} pages were rasterized for QR codes; later pages NOT checked")
                for f in sorted(os.listdir(td)):
                    v, err = qr_from_image(os.path.join(td, f))
                    for x in v: found.append({"kind": "url" if "://" in x or x.startswith("www.") else "qr_text", "value": x, "where": f"QR on pdf {f}"})
                    if err: _inc(notes, err); break
        else: notes.append("pdftoppm not installed: QR codes inside the PDF were NOT checked")
    elif ext in IMG_EXT:
        v, err = qr_from_image(path)
        if err: _inc(notes, err)
        for x in v: found.append({"kind": "url" if "://" in x or x.startswith("www.") else "qr_text", "value": x, "where": "QR code in image"})
        t = ocr(path)
        if t is None: notes.append("OCR skipped (tesseract not installed): read any printed phone number/URL off the image yourself")
        elif t == "\0timeout": _inc(notes, "OCR timed out: printed text NOT checked (incomplete)")
        elif t.startswith("\0error"): _inc(notes, f"OCR failed ({t[7:]}): printed text NOT checked (incomplete)")
        else: scan_bytes(t.encode(), found, "OCR text in image")
    elif ext == ".eml":
        why = mime_prescan(raw)
        if why: _inc(notes, why); return found
        msg = email.message_from_bytes(raw, policy=policy.default); nparts = 0
        stack = [(msg, 0)]
        while stack:                                  # iterative, depth-tracked walk (no recursion)
            part, d = stack.pop()
            nparts += 1
            if nparts > MAX_PARTS: _inc(notes, f"Stopped after {MAX_PARTS} MIME parts (part limit); the rest NOT checked"); break
            if part.is_multipart():
                if d >= 20: _inc(notes, "MIME nesting deeper than 20 levels (depth limit): deeper parts NOT checked"); continue
                stack.extend((p, d + 1) for p in reversed(part.get_payload() or []) if hasattr(p, "is_multipart"))
                continue
            ctype = part.get_content_type(); fn = part.get_filename()
            try: payload = part.get_payload(decode=True) or b""
            except Exception: _inc(notes, f"a MIME part ({ctype}) could not be decoded: NOT checked"); continue
            budget[0] += len(payload)
            if budget[0] > MAX_DECODED: _inc(notes, "Decoded-size limit reached; remaining parts NOT checked"); break
            magic = sniff(payload[:1024])
            if not fn and (ctype.startswith("image/") or ctype == "application/pdf" or (magic in ("img", "pdf") and ctype not in ("text/plain", "text/html"))):
                ext_guess = ".pdf" if magic == "pdf" else _img_ext(payload) if magic == "img" else None
                if not ext_guess:
                    _inc(notes, f"an unnamed {ctype} part does not match its declared type (magic mismatch): NOT checked"); continue
                fn = f"unnamed-part-{nparts}{ext_guess}"     # safe local name for an ordinary unnamed/inline part
            elif not fn and ctype not in ("text/plain", "text/html") and payload:
                _inc(notes, f"an unnamed {ctype} part is not a supported type: NOT checked"); continue
            if fn:
                with tempfile.TemporaryDirectory() as td:
                    safe = os.path.join(td, re.sub(r"[^\w.-]", "_", fn)[:120] or "part"); open(safe, "wb").write(payload)
                    try: sub = inspect(safe, notes, depth + 1, budget)
                    except Refused as ex: _inc(notes, f"attachment {fn}: {ex}"); sub = []
                    for s in sub: s["where"] = f"attachment {fn}: " + s["where"]
                    found += sub
            elif ctype in ("text/plain", "text/html"):
                scan_bytes(payload, found, f"email body ({ctype})")
                for m in re.findall(rb"(?is)<a[^>]{0,2000}href=[\"']([^\"']{1,2048})[\"'][^>]{0,2000}>(.{0,2000}?)</a>", payload):
                    href, txt = m[0].decode("utf-8", "replace"), re.sub(rb"<[^>]+>", b"", m[1]).decode("utf-8", "replace").strip()
                    th = host_of(txt) if re.match(r"(?i)(https?://|www\.)", txt) else ""
                    a_, b_ = (reg_domain(th), reg_domain(host_of(href))) if th and host_of(href) else (None, None)
                    if th and host_of(href) and (a_ is None or b_ is None) and th != host_of(href):
                        notes.append(f"Link text shows {defang(th)} but goes to {defang(host_of(href))}; registered domains unknown (no PSL) - treat as mismatch")
                    elif a_ and b_ and a_ != b_:
                        notes.append(f"LINK TEXT MISMATCH: shows {defang(txt)} but goes to {defang(host_of(href))}")
    else:  # html / svg / text: read as bytes only, never rendered or executed
        scan_bytes(raw, found, "file text")
        if re.search(rb"(?i)<script|on(load|error)=|data:text/html|atob\(|window\.location", raw):
            notes.append("Contains script or redirect code (not run): a risk cue often seen in credential-phishing pages, not proof by itself. Do not open it.")
        if re.search(rb"(?i)type=[\"']?password", raw):
            notes.append("Contains a password field: a risk cue (phishing pages ask for passwords), not proof the page is fake. Never type a password into a saved page; sign in only through the real app or a typed address.")
    if len(found) > MAX_ITEMS:
        _inc(notes, f"Item limit: only the first {MAX_ITEMS} links/numbers are listed; the rest NOT listed"); found = found[:MAX_ITEMS]
    return found

INCOMPLETE = re.compile(r"(?i)NOT checked|NOT listed|timed out|incomplete|not installed|limit|could not|unreadable|partial|unknown|may be missed")
def _isolated_inspect(f, timeout=JOB_WALL_S):
    """ONE supervised job per input snapshot: all decoding/parsing (images, MIME, PDF + its QR decode, text) in a limited
    worker (fresh net+PID namespace when available), bounded streaming output, one total wall deadline."""
    try:
        p = _tool([sys.executable, SELF, "--_worker", f] + (["--allow-unisolated-network"] if ALLOW_UNISOLATED else []), timeout=timeout, require_isolation=True, out_cap=MAX_WORKER_OUT)
    except subprocess.TimeoutExpired:
        return [], [f"Parser job timed out after {timeout}s (whole job killed): file NOT checked (incomplete)"], None
    except OutputCap:
        return [], ["Parser output over the size limit (job killed): file NOT fully checked (incomplete)"], None
    out = (p.stdout or b"")[:MAX_WORKER_OUT + 1]
    if len(out) > MAX_WORKER_OUT: return [], ["Parser output over the size limit (truncated): file NOT fully checked (incomplete)"], None
    try: j = json.loads(out.decode("utf-8", "replace"))
    except Exception:
        tail = (p.stderr or b"")[-200:].decode("utf-8", "replace").strip().splitlines()[-1:] or ["no output"]
        return [], [f"Parser stopped (exit {p.returncode}; likely a CPU/memory/recursion limit): file NOT checked (incomplete). Detail: {tail[0]}"], None
    notes = list(j.get("notes", []))
    if j.get("incomplete"): notes += [n for n in j["incomplete"] if n not in notes]
    if p.returncode not in (0, None):      # v12 A05: a nonzero exit is never complete, even with valid partial JSON
        notes.append(f"Parser exited with status {p.returncode}: results are partial (incomplete)")
    return j.get("items", []), notes, j.get("refused")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("files", nargs="+"); ap.add_argument("--json", action="store_true"); ap.add_argument("--enrich", action="store_true")
    ap.add_argument("--_worker", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--allow-unisolated-network", action="store_true",
                    help="owner-approved only: parse even though no empty network namespace is available (reported as unavailable)")
    a = ap.parse_args()
    global ALLOW_UNISOLATED
    ALLOW_UNISOLATED = bool(a.allow_unisolated_network)
    if a._worker:
        sys.setrecursionlimit(400); notes = Notes()
        try: items = inspect(a.files[0], notes); print(json.dumps({"items": items, "notes": list(notes), "incomplete": notes.incomplete}))
        except Refused as ex: print(json.dumps({"items": [], "notes": list(notes), "incomplete": notes.incomplete, "refused": str(ex)}))
        except RecursionError: print(json.dumps({"items": [], "notes": list(notes) + ["Structure too deeply nested (recursion limit): NOT checked (incomplete)"], "incomplete": ["recursion limit"]}))
        return
    report = []; t0 = time.monotonic()
    for f in a.files:
        notes = []; refused = None
        try:
            left = RUN_TOTAL_S - (time.monotonic() - t0)
            if left < 5: raise subprocess.TimeoutExpired("inspect-attachment run budget", RUN_TOTAL_S)
            ext, raw = precheck(f)                      # single-FD snapshot; only this snapshot is parsed
            with tempfile.TemporaryDirectory(prefix="ia-snap-") as td:
                os.chmod(td, 0o700); snap = os.path.join(td, "input" + ext)
                with open(snap, "xb") as fh: fh.write(raw)
                items, notes, refused = _isolated_inspect(snap, timeout=min(JOB_WALL_S, left))
            notes = [n.replace(snap, os.path.basename(f)) for n in notes]
        except Refused as ex: items, refused = [], str(ex)
        except subprocess.TimeoutExpired as ex: items = []; notes.append(f"A parser timed out ({ex.cmd}): NOT checked (incomplete)")
        except OutputCap as ex: items = []; notes.append(f"Parser output cap hit ({ex}): NOT checked (incomplete)")
        except Exception as ex: items = []; notes.append(f"Inspection failed ({type(ex).__name__}): NOT checked (incomplete)")
        net = network_isolation()
        base = {"file": os.path.basename(f), "notes": notes, "visited_any_url": False,
                "isolation": {"resource_limits": f"CPU {TOOL_CPU_S}s, memory {TOOL_MEM >> 20} MB, file size {TOOL_FSIZE >> 20} MB, wall {TOOL_WALL_S}s per child",
                              "network": net["status"], "network_method": net.get("method"), **({"network_why": net["why"]} if net.get("why") else {}),
                              "descendants": "PID namespace: killing the job kills all descendants" if net.get("pid_namespace") else "process group + parent-death signal only (a grandchild that starts its own session may outlive the job)",
                              "filesystem": "NOT isolated: the worker can read/write anything this user can; use a disposable restricted environment for untrusted files",
                              "job_wall_s": JOB_WALL_S},
                "not_a_safety_verdict": "No links found does not mean safe; anything NOT checked stays unknown."}
        if refused:
            report.append({**base, "status": "refused", "refused": refused, "items": [], "registered_domains": []}); continue
        seen, uniq = set(), []
        for i in items:
            k = (i["kind"], i["value"])
            if k in seen: continue
            seen.add(k)
            if i["kind"] == "url":
                i["host"] = host_of(i["value"]); i["registered_domain"] = reg_domain(i["host"]); i["defanged"] = defang(i["value"])
            uniq.append(i)
        doms = sorted({i["registered_domain"] for i in uniq if i.get("registered_domain")})
        reasons = [n for n in notes if INCOMPLETE.search(n)]
        status = "incomplete" if reasons else "complete"
        r = {**base, "status": status, "incomplete_reasons": reasons, "items": uniq, "registered_domains": doms}
        if a.enrich and doms:
            try:
                r["enrich"] = json.loads(subprocess.run([sys.executable, os.path.join(HERE, "enrich-domain.py"), *doms, "--no-ip"], capture_output=True, text=True, timeout=120).stdout or "null")
            except Exception as ex:
                r["enrich_error"] = str(ex)
        report.append(r)
    if a.json: print(json.dumps(report, indent=2)); return
    for r in report:
        print(f"== {r['file']} [{r['status']}] (no link was opened; network isolation: {r['isolation']['network']})")
        if r.get("refused"): print("  !", r["refused"])
        for i in r["items"]:
            print(f"  [{i['kind']}] {i.get('defanged', i['value'])}   <- {i['where']}")
        if r["registered_domains"]: print("  domains:", ", ".join(defang(d) for d in r["registered_domains"]))
        for n in r["notes"]: print("  !", n)
        if not r["items"] and not r.get("refused"): print("  (no links, QR codes, or phone numbers found - not a safety verdict)")

if __name__ == "__main__":
    main()
