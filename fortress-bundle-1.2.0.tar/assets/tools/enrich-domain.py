#!/usr/bin/env python3
"""Email Fortress - "Link + header intel" for a SAVED email (never clicks the link).

  * Domain age / registrar / registrar abuse contact via RDAP (rdap.org bootstrap,
    free, no key). Subdomains are walked up until a registered domain answers
    (feed.example.com -> example.com).
  * Optional header parse (--headers FILE, a "Show original" paste): reads
    Authentication-Results (spf / dkim / dmarc / arc), From / Return-Path / Reply-To
    domains, DKIM d=, and the first external Received IP.
    v1.1 (2026-10-31, source identification): Delivered-To / X-Original-To vs To/Cc
    (random To: vs envelope recipient), ESP / bulk-sender hints, free-mail sender,
    and an official brand-domain check against $FORTRESS_HOME/data/brand-domains.json.
  * Optional IP enrichment (same pattern as email-evidence-log): ipinfo.io JSON
    (network registration org only; never city/region/country) + AbuseIPDB check URL (no score invented).

Only reads public registry data about the DOMAIN or network - never the sender's home.

Examples:
  enrich-domain.py feed.expressbikeinsurance.com
  enrich-domain.py --evidence ../evidence/primary-mail/ev-20261027-1101-oralb-icloud.json --write
  enrich-domain.py --headers /tmp/original.eml            # domains + auth + IP from headers
  enrich-domain.py example.com --offline                  # open URLs only
"""
# --- Fortress portable header (v3) ---
import os as _os, json as _j
from zoneinfo import ZoneInfo as _ZI
FORTRESS_HOME = _os.environ.get("FORTRESS_HOME")
if not FORTRESS_HOME:
    raise SystemExit("FORTRESS_HOME not set: pass this bot's own workspace (from its memory), e.g. FORTRESS_HOME=... FORTRESS_INSTANCE=... python3 tool.py")
def _check_owner():
    """Fail closed: the root must carry this bot's ownership file AND FORTRESS_INSTANCE must name that same instance."""
    try: m = _j.load(open(_os.path.join(FORTRESS_HOME, ".fortress-owner.json")))
    except Exception: raise SystemExit("FORTRESS_HOME has no Fortress ownership file: run fortress_bootstrap.py init/preflight first; refusing")
    want = _os.environ.get("FORTRESS_INSTANCE")
    if not want: raise SystemExit("FORTRESS_INSTANCE not set: pass this bot's own instance id from its memory; refusing")
    if m.get("instance_id") != want:
        raise SystemExit(f"FORTRESS_HOME belongs to Fortress instance {m.get('instance_id')}, not {want}; refusing")
_check_owner()
def _owner_tz():
    tz = _os.environ.get("FORTRESS_TZ")
    if not tz:
        try: tz = _j.load(open(_os.path.join(FORTRESS_HOME, "private", "settings.json"))).get("timezone")
        except Exception: tz = None
    if not tz:
        raise SystemExit("Owner timezone not set: run fortress_bootstrap.py init --tz <IANA zone> (ask the owner)")
    return tz
OWNER_TZ_NAME = _owner_tz()
OWNER_TZ = _ZI(OWNER_TZ_NAME)
# --- end header ---

import argparse, datetime as dt, email, email.policy, ipaddress, json, os, re, shutil, sys, urllib.parse, urllib.request, urllib.error, tempfile
from zoneinfo import ZoneInfo

PT = OWNER_TZ
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
CACHE = os.path.join(FORTRESS_HOME, "private", "cache", "rdap")
UA = "EmailFortress-enrich/1.0 (personal consumer evidence)"
CAVEAT = ("Registry data only. A new domain is a strong phishing signal; an old domain is NOT proof of safety "
          "(old domains get hijacked or resold). Privacy-redacted registrant data is normal.")


CCTLD_ABUSE = {"br": "ccTLD with no registrar layer (registro.br). Abuse: CERT.br cert@cert.br - https://www.cert.br/",
               "uk": "Nominet abuse - https://www.nominet.uk/",
               "au": "auDA complaints - https://www.auda.org.au/"}


def now_pt():
    return dt.datetime.now(PT)


def get_json(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/rdap+json, application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def clean_domain(s):
    s = (s or "").strip().lower()
    if "@" in s:
        s = s.rsplit("@", 1)[1]
    s = re.sub(r"^[a-z]+://", "", s).split("/")[0].split("?")[0].split(":")[0].strip(".>< ")
    if not re.match(r"^[a-z0-9.-]+\.[a-z0-9-]{2,}$", s):
        raise ValueError(f"not a domain: {s!r}")
    return s


def vcard_get(vc, field):
    try:
        for item in vc[1]:
            if item[0] == field:
                return item[3]
    except Exception:
        pass
    return None


def parse_rdap(d, queried):
    ev = {e.get("eventAction"): e.get("eventDate") for e in d.get("events", [])}
    created = ev.get("registration")
    out = {"domain": (d.get("ldhName") or queried).lower(), "created": created,
           "expires": ev.get("expiration"), "updated": ev.get("last changed"),
           "status": d.get("status"), "registrar": None, "registrar_iana_id": None,
           "abuse_email": None, "abuse_phone": None,
           "nameservers": [n.get("ldhName") for n in d.get("nameservers", [])][:4]}
    for ent in d.get("entities", []):
        roles = ent.get("roles", [])
        if "registrar" in roles:
            out["registrar"] = vcard_get(ent.get("vcardArray"), "fn") or ent.get("handle")
            for p in ent.get("publicIds", []) or []:
                if "IANA" in p.get("type", ""):
                    out["registrar_iana_id"] = p.get("identifier")
            for sub in ent.get("entities", []) or []:
                if "abuse" in sub.get("roles", []):
                    out["abuse_email"] = vcard_get(sub.get("vcardArray"), "email")
                    tel = vcard_get(sub.get("vcardArray"), "tel")
                    out["abuse_phone"] = tel.replace("tel:", "") if tel else None
        if "abuse" in roles and not out["abuse_email"]:
            out["abuse_email"] = vcard_get(ent.get("vcardArray"), "email")
        if "registrant" in roles:
            # Organisation name only (public registry field). Never store personal contact emails/phones.
            out["registrant_org"] = vcard_get(ent.get("vcardArray"), "fn")
    tld = out["domain"].rsplit(".", 1)[-1]
    if not out["registrar"] and tld in CCTLD_ABUSE:
        out["registry_abuse"] = CCTLD_ABUSE[tld]
    if created:
        try:
            c = dt.datetime.fromisoformat(created.replace("Z", "+00:00"))
            age = (now_pt() - c).days
            out["domain_age_days"] = age
            out["age_hint"] = ("Brand-new domain: strong phishing signal." if age < 30 else
                               "Young domain: treat with suspicion." if age < 180 else
                               "Old domain. If it has nothing to do with the brand in the message, it is likely a hacked or rented site - age does not make it safe.")
            out["age_flag"] = ("very_new_under_30d" if age < 30 else "new_under_180d" if age < 180 else
                               "under_1y" if age < 365 else "established_1y_plus")
        except Exception:
            out["domain_age_days"] = None
    else:
        out["domain_age_days"] = None
        out["age_flag"] = "unknown"
    return out


def rdap_lookup(host, offline=False):
    host = clean_domain(host)
    labels = host.split(".")
    tried = []
    res = {"input": host, "icann_lookup_url": f"https://lookup.icann.org/en/lookup?name={urllib.parse.quote(host)}",
           "checked_at": now_pt().isoformat(timespec="seconds"), "caveat": CAVEAT}
    for i in range(0, max(1, len(labels) - 1)):
        cand = ".".join(labels[i:])
        if cand.count(".") < 1:
            break
        url = f"https://rdap.org/domain/{cand}"
        tried.append(cand)
        cp = os.path.join(CACHE, cand + ".json")
        if offline:
            if os.path.exists(cp):
                res.update(json.load(open(cp)), status="cached", rdap_url=url, tried=tried)
                return res
            continue
        try:
            d = get_json(url)
            if d.get("objectClassName") != "domain":
                continue
            parsed = parse_rdap(d, cand)
            os.makedirs(CACHE, exist_ok=True)
            json.dump(parsed, open(cp, "w"), indent=2)
            res.update(parsed, status="ok", rdap_url=url, tried=tried,
                       icann_lookup_url=f"https://lookup.icann.org/en/lookup?name={parsed['domain']}")
            return res
        except urllib.error.HTTPError as e:
            if e.code == 404:
                continue
            res.update(status="error", error=f"HTTP {e.code} for {url}", tried=tried)
            return res
        except Exception as e:  # noqa
            res.update(status="error", error=str(e)[:200], tried=tried)
            return res
    res.update(status="skipped_offline" if offline else "not_found", tried=tried, domain_age_days=None,
               note="Open icann_lookup_url in a browser (no need to visit the domain itself).")
    return res


# ---------------- headers ----------------
# (v9: settings.trusted_authserv_ids / FORTRESS_TRUSTED_AUTHSERV are no longer read: a matching authserv string is not provenance)
class ProviderAuth:
    """Authentication results that the owner's OWN receiving provider returned DIRECTLY through a connector call
    (structured fields, not header text). Only an in-process adapter that just made that call may construct one; a
    pasted/forwarded header, a JSON file, a settings value or a caller boolean can never become one. No native
    adapter ships in this version, so the CLI always reports header authentication as unknown."""
    __slots__ = ("spf", "dkim", "dmarc", "arc", "provider", "message_ref", "header_from_domain")
    _VALID = {"pass", "fail", "softfail", "neutral", "none", "temperror", "permerror", "unknown"}
    def __init__(self, *, provider, message_ref, spf="unknown", dkim="unknown", dmarc="unknown", arc="unknown", header_from_domain=None, _issued_by_connector=None):
        if _issued_by_connector is not _CONNECTOR_CAPABILITY: raise PermissionError("provider authentication must come from a direct connector adapter, not from text or a flag")
        for k, v in (("spf", spf), ("dkim", dkim), ("dmarc", dmarc), ("arc", arc)):
            if v not in self._VALID: raise ValueError(k)
        self.spf, self.dkim, self.dmarc, self.arc = spf, dkim, dmarc, arc
        self.provider, self.message_ref, self.header_from_domain = provider, message_ref, header_from_domain
_CONNECTOR_CAPABILITY = object()      # module-private; a future native adapter in this module is the only holder
_FROM_CLAUSE = re.compile(r"^\s*from\s+(.*?)(?=\s(?:by|with|via|id|for)\s|;|$)", re.I | re.S)
_LIT = re.compile(r"\[(?:IPv6:)?([0-9A-Fa-f:.]+)\]|(?<![\w.:-])((?:\d{1,3}\.){3}\d{1,3})(?![\w.:-])", re.I)
def _from_peer_literals(rcv):
    """IP literals of one Received line's bounded `from` clause only: [a.b.c.d], [IPv6:...] or a free-standing dotted quad
    token (never digits embedded in a hostname label); keywords case-insensitive; nothing after `by/with/id/for/;`."""
    m = _FROM_CLAUSE.match(" ".join(rcv.split()))
    if not m: return []
    out = []
    for br, bare in _LIT.findall(m.group(1)):
        try: out.append(ipaddress.ip_address(br or bare))
        except ValueError: continue
    return out
def parse_headers(text, provider_auth=None):
    msg = email.message_from_string(text, policy=email.policy.compat32)
    def dom(h):
        v = msg.get(h)
        m = re.search(r"@([A-Za-z0-9.-]+)", v or "")
        return m.group(1).lower() if m else None
    # Header TEXT is never provenance: an authserv-id spelled like the owner's provider (even one listed in
    # settings.trusted_authserv_ids) is just a string the sender or a forwarder could write. Only a ProviderAuth
    # record from a direct connector call counts; otherwise every result is "unknown" and claims are reported as such.
    ar_list = msg.get_all("Authentication-Results") or []
    claimed = [re.findall(r"\b(spf|dkim|dmarc|arc)\s*=\s*([a-z]+)", a, re.I) for a in ar_list]
    pa = provider_auth if isinstance(provider_auth, ProviderAuth) else None
    ar_all = ""
    auth_source = f"provider record from {pa.provider} (direct connector call)" if pa else "unknown: header text is not provenance"
    def verdict(mech):
        return getattr(pa, mech) if pa else "unknown"
    dkim_d = re.findall(r"\bd=([A-Za-z0-9.-]+)", " ".join(msg.get_all("DKIM-Signature") or []))
    hdr_from = None
    mailfrom = re.search(r"smtp\.mailfrom=(?:[^@\s;]*@)?([A-Za-z0-9.-]+)", ar_all)
    ips = []; top_ip = None; rcvd = msg.get_all("Received") or []
    for n, rcv in enumerate(rcvd):
        peers = _from_peer_literals(rcv)
        ips += [str(a) for a in peers if a.is_global]
        if n == 0:
            # v12 H02: the hint is the single peer literal of the TOP hop's bounded `from` clause; private/ambiguous -> none
            distinct = sorted(set(str(a) for a in peers))
            if len(distinct) == 1 and peers[0].is_global: top_ip = distinct[0]
    # Only the TOP Received line can be the receiver's own stamp (and even that is unverified in a paste). Lower hops
    # may be forged: they are never promoted to the hint, never called the origin, and never mapped to a place.
    first_external = top_ip
    auth = {"spf": verdict("spf"), "dkim": verdict("dkim"), "dmarc": verdict("dmarc"), "arc": verdict("arc"),
            "header_from_domain": pa.header_from_domain if pa else None,
            "claimed_in_headers_unverified": [dict(c) for c in claimed if c],
            "dkim_signing_domains": sorted(set(x.lower() for x in dkim_d)),
            "spf_mailfrom_domain": mailfrom.group(1).lower() if mailfrom else None,
            "source": auth_source, "dkim_signature_present_unverified": bool(dkim_d)}
    auth["plain"] = plain_auth(auth, dom("From"))
    out = {"from_domain": dom("From"), "reply_to_domain": dom("Reply-To"), "return_path_domain": dom("Return-Path"),
           "auth": auth, "received_external_ips_unverified": ips, "first_external_ip": first_external,
           "origin_ip_status": "unverified_hint_top_received_hop_only" if first_external else "none_top_hop_has_no_public_peer",
           "reply_to_mismatch": bool(dom("Reply-To") and dom("From") and dom("Reply-To") != dom("From"))}
    out["envelope"] = envelope_check(msg)
    out["esp"] = esp_hints(msg, auth)
    out["brand_check"] = brand_check(msg.get("From") or "", dom("From"))
    out["source_why_lines"] = [x for x in (out["envelope"].get("plain"), out["esp"].get("plain"), out["brand_check"].get("plain")) if x]
    return out


ADDR = re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


def envelope_check(msg):
    """Random To: vs envelope recipient. Delivered-To / X-Original-To / Envelope-To is where the mail was really delivered."""
    env = []
    for h in ("Delivered-To", "X-Original-To", "Envelope-To", "X-Envelope-To"):
        for v in msg.get_all(h) or []:
            env += [a.lower() for a in ADDR.findall(v)]
    env = sorted(set(env))
    vis = sorted(set(a.lower() for h in ("To", "Cc") for v in (msg.get_all(h) or []) for a in ADDR.findall(v)))
    res = {"envelope_recipients": env, "visible_to_cc": vis, "to_is_undisclosed": bool(re.search(r"undisclosed", " ".join(msg.get_all("To") or []), re.I))}
    if not env:
        res["status"] = "no_envelope_header"
        res["plain"] = None
        return res
    hit = [e for e in env if e in vis]
    if hit:
        res["status"] = "match"
        res["plain"] = None
    elif not vis or res["to_is_undisclosed"]:
        res["status"] = "hidden_recipients"
        res["plain"] = ("The To line is blank or 'undisclosed recipients', and the delivery header lists your address (unverified in a paste): "
                        "if accurate, you were a hidden (Bcc) copy. Normal for some newsletters, common in bulk spam.")
    else:
        res["status"] = "mismatch"
        res["plain"] = (f"The delivery header lists {env[0]}, but the To line shows {', '.join(vis[:2])} (header text is unverified in a paste). "
                        "If accurate, you were a hidden (Bcc) copy of a mail aimed at other addresses, a common bulk-spam pattern.")
    return res


ESP_SIGS = [  # (label, regex on DKIM d= / Return-Path / Received / select headers)
    ("SendGrid (Twilio)", r"sendgrid\.net|\bX-SG-EID\b"),
    ("Mailchimp / Mandrill", r"mcsv\.net|mcdlv\.net|rsgsv\.net|mandrillapp\.com|\bX-MC-User\b"),
    ("Amazon SES", r"amazonses\.com"),
    ("Mailgun", r"mailgun\.(org|net|info)|\bX-Mailgun-"),
    ("Postmark", r"mtasv\.net|postmarkapp\.com"),
    ("SparkPost", r"sparkpostmail\.com"),
    ("Constant Contact", r"constantcontact\.com|ccsend\.com"),
    ("Klaviyo", r"klaviyomail\.com|klaviyo\.com"),
    ("HubSpot", r"hubspotemail\.net|hubspot\.com"),
    ("Salesforce Marketing Cloud", r"exacttarget\.com"),
    ("Brevo (Sendinblue)", r"sendinblue\.com|brevo\.com"),
    ("Zoho ZeptoMail / Campaigns", r"zeptomail\.|zcsend\.net"),
    ("Microsoft 365 business mail", r"outbound\.protection\.outlook\.com"),
]
FREE_MAIL = {"gmail.com", "googlemail.com", "yahoo.com", "ymail.com", "outlook.com", "hotmail.com", "live.com", "msn.com",
             "aol.com", "icloud.com", "me.com", "mac.com", "proton.me", "protonmail.com", "gmx.com", "mail.com", "zoho.com", "yandex.com", "mail.ru", "qq.com"}


def esp_hints(msg, auth):
    blob = " ".join([" ".join(auth.get("dkim_signing_domains") or []), msg.get("Return-Path") or "",
                     " ".join(msg.get_all("Received") or []), " ".join(f"{k}: " for k in msg.keys()),
                     msg.get("X-Mailer") or "", msg.get("List-Unsubscribe") or ""])
    found = [lab for lab, rx in ESP_SIGS if re.search(rx, blob, re.I)]
    from_dom = None
    m = re.search(r"@([A-Za-z0-9.-]+)", msg.get("From") or "")
    if m: from_dom = m.group(1).lower()
    free = from_dom in FREE_MAIL
    res = {"esp": found, "free_mail_sender": free, "has_list_unsubscribe": bool(msg.get("List-Unsubscribe")),
           "x_mailer": (msg.get("X-Mailer") or None)}
    bits = []
    if found:
        bits.append(f"The header text mentions {', '.join(found)} (unverified claim), a bulk-mail service companies rent. Real brands use these too, so at most a clue about HOW it was sent, not proof of who sent it")
    if free:
        bits.append(f"The From header says a free {from_dom} account anyone can create, so a company name in it means nothing")
    res["plain"] = ("; ".join(bits) + ".") if bits else None
    return res


def _brand_db():
    try:
        return json.load(open(os.path.join(FORTRESS_HOME, "data", "brand-domains.json")))["brands"]
    except Exception:
        return {}


def brand_check(from_header, from_dom):
    """Display name / From domain names a known brand -> is the registered domain one of its official ones?"""
    name = from_header.split("<")[0].lower() if "<" in from_header else ""
    rd = reg(from_dom) if from_dom else None
    db = _brand_db()
    hit = None
    for text in (name, from_header.lower()):  # display name wins over the address
        for brand, b in db.items():
            if any(re.search(r"(?<![a-z])" + re.escape(k.strip()) + r"(?![a-z])", text) for k in b["keywords"]):
                hit = (brand, b); break
        if hit: break
    if hit:
        brand, b = hit
        if True:
            official = bool(rd and from_dom not in FREE_MAIL and any(rd == d or (from_dom or "").endswith("." + d) or from_dom == d for d in b["domains"]))
            res = {"brand": brand, "category": b["category"], "from_registered_domain": rd, "official_domains": b["domains"],
                   "official": official, "note": b.get("note"), "see": b.get("see")}
            if official:
                res["plain"] = (f"The From header claims {from_dom}, one of {brand}'s real domains. Header text is unverified here, so this does not prove who sent it, and never the ask"
                                + (": real services get abused (see abused-legit-brand-pack)." if b.get("see") or b["category"] in ("payments", "big_tech") else "."))
            else:
                res["plain"] = (f"It says {brand}, but the From header says {rd or 'an unknown domain'}, which is not one of {brand}'s domains "
                                f"({', '.join(b['domains'][:3])}). The name is just text they typed.")
            return res
    return {"brand": None, "plain": None}


def plain_auth(a, from_dom):
    if a["dmarc"] == "pass":
        s = ("DMARC passed for the domain in the From line. That only means the mail really left that domain's servers. "
             "It does NOT mean the sender is the brand shown, or that the request is safe: scammers own passing domains, "
             "and real services (PayPal/QuickBooks invoices, DocuSign, Google Forms, calendar invites) pass DMARC when abused. Judge the ask, not the checkmark.")
    elif a["dmarc"] in ("fail", "softfail") or a["spf"] == "fail":
        s = "The mail failed the sender domain's own checks - the From address is likely faked."
    elif a["dmarc"] == "unknown" and not str(a.get("source", "")).startswith("provider record"):
        s = ("These headers came from a paste or forward, so any 'pass' lines in them are unverified claims anyone can type. "
             "Authentication is UNKNOWN here; judge the ask and the domains instead.")
    elif a["dmarc"] == "none" or a["dmarc"] == "unknown":
        s = "No usable DMARC verdict - the provider could not confirm the From domain."
    else:
        s = f"DMARC={a['dmarc']}."
    if from_dom and a["dkim_signing_domains"] and not any(from_dom.endswith(d) or d.endswith(from_dom) for d in a["dkim_signing_domains"]):
        s += f" A DKIM-Signature header names {', '.join(a['dkim_signing_domains'])}, not {from_dom} (unverified: a signature header is not a checked signature; often a bulk mail service)."
    mf = a.get("spf_mailfrom_domain")
    if a["spf"] == "pass" and mf and from_dom and not (mf.endswith(from_dom) or from_dom.endswith(mf)) and reg(mf) != reg(from_dom):
        s += (f" SPF passed for the bounce address domain {mf}, which is not the visible From ({from_dom}), so SPF does not vouch for the From"
              " (RFC 7489 alignment).")
    return s


def reg(d):
    from fortress_domain import registered_domain
    return registered_domain(d)   # None = unknown (no PSL); never relabel a raw host as registered


def ip_enrich(ip, offline=False):
    out = {"ip": ip, "abuseipdb_check_url": f"https://www.abuseipdb.com/check/{ip}",
           "caveat": "Network registration of a mail relay - never a sender identity, home, city or country."}
    if offline:
        out["status"] = "skipped_offline"
        return out
    try:
        d = get_json(f"https://ipinfo.io/{ip}/json")
        out.update(status="ok", network_org=d.get("org"),
                   network_org_note="network registration owner of the relay IP (not the sender, not a location)")   # v12 H03: geography never kept
    except Exception as e:  # noqa
        out.update(status="error", error=str(e)[:200])
    return out


SHOW_ORIGINAL = {
    "gmail_web": "Open the message > three-dot menu (More) > Show original. Copy the top block (or 'Copy to clipboard') and paste it here.",
    "gmail_mobile": "Gmail app cannot show original; open mail.google.com in a browser, or forward the message as an attachment.",
    "outlook_web": "Open the message > ... (More actions) > View > View message details. Copy all and paste.",
    "apple_mail_mac": "Select the message > View > Message > All Headers (or Raw Source, Option-Cmd-U). Copy and paste.",
    "icloud_web": "Open the message > reply arrow menu or ... > Show All Headers / Show Raw Message.",
    "yahoo_web": "Open the message > ... (More) > View raw message.",
    "iphone_ipad": "iOS Mail cannot show headers; forward it to the bot spam inbox or use a Mac / web.",
    "safety": "Copying headers never requires tapping a link or image in the message.",
}


AUTH_KNOWN = ("spf", "dkim", "dmarc", "arc", "header_from_domain", "claimed_in_headers_unverified", "dkim_signing_domains",
              "spf_mailfrom_domain", "source", "dkim_signature_present_unverified", "plain")
def _atomic_json(path, obj):
    d = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(prefix=".enr-", dir=d)
    with os.fdopen(fd, "w") as f: json.dump(obj, f, indent=2); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
def main():
    ap = argparse.ArgumentParser(description="Domain age (RDAP) + header auth intel for a saved email. Never visits the suspect link.",
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__.split("Examples:")[1])
    ap.add_argument("domains", nargs="*", help="Domain(s), hostnames, URLs or email addresses")
    ap.add_argument("--evidence", help="Saved ev-*.json; uses original_from_domain + links.cta_host / unsub_host")
    ap.add_argument("--headers", help="File with pasted raw headers ('Show original' / .eml)")
    ap.add_argument("--write", action="store_true", help="With --evidence: merge `domain_intel` (backup .bak-enrich) + sidecar")
    ap.add_argument("--offline", action="store_true", help="No network: open URLs + cache only")
    ap.add_argument("--no-ip", action="store_true", help="Skip ipinfo lookup of the first external Received IP")
    ap.add_argument("--coach", action="store_true", help="Print only the 'Show original' coaching steps")
    a = ap.parse_args()
    if a.coach:
        print(json.dumps({"show_original_steps": SHOW_ORIGINAL}, indent=2)); return
    ev, hosts = None, list(a.domains)
    if a.evidence:
        ev = json.load(open(a.evidence))
        for k in ("original_from_domain", "from_domain"):
            if ev.get(k): hosts.append(ev[k])
        links = ev.get("links") or {}
        if isinstance(links, dict):
            hosts += [links.get(k) for k in ("cta_host", "unsub_host") if links.get(k)]
        elif isinstance(links, list):
            hosts += [l.get("real") for l in links if isinstance(l, dict) and l.get("real")]
    hdr = None
    if a.headers:
        hdr = parse_headers(open(a.headers, errors="replace").read())
        hosts += [h for h in (hdr["from_domain"], hdr["reply_to_domain"], hdr["return_path_domain"]) if h]
    seen, results = set(), []
    for h in hosts:
        try:
            key = clean_domain(h)
        except ValueError as e:
            results.append({"input": h, "status": "invalid", "error": str(e)}); continue
        if key in seen: continue
        seen.add(key)
        results.append(rdap_lookup(key, a.offline))
    if not hosts:
        ap.error("give a domain, --evidence or --headers")
    out = {"tool": "enrich-domain", "version": "1.1", "checked_at": now_pt().isoformat(timespec="seconds"),
           "timezone": OWNER_TZ_NAME, "domains": results}
    # Collapse duplicates that resolved to the same registered domain
    reg = {}
    for r in results:
        if r.get("domain"): reg.setdefault(r["domain"], []).append(r["input"])
    out["registered_domains"] = reg
    if hdr:
        out["headers"] = hdr
        if hdr["first_external_ip"] and not a.no_ip:
            _ipx = ip_enrich(hdr["first_external_ip"], a.offline); _ipx.pop("approx", None)   # no geography attribution (org kept separately)
            out["origin_ip_hint"] = {**_ipx, "status": "unverified hint: the hop that handed mail to the top Received server; not proof of the sender origin"}
    else:
        out["show_original_coaching"] = SHOW_ORIGINAL
    why = []
    for r in results:
        if r.get("domain_age_days") is not None:
            why.append(f"{r['domain']} registered {r['domain_age_days']} days ago ({(r.get('created') or '')[:10]}) via {r.get('registrar') or 'registrar n/a'}")
    out["why_lines"] = why
    out["caveat"] = CAVEAT
    if a.write and a.evidence:
        side = a.evidence[:-5] + ".domain-intel.json"
        json.dump(out, open(side, "w"), indent=2)
        if not os.path.exists(a.evidence + ".bak-enrich"):
            shutil.copy2(a.evidence, a.evidence + ".bak-enrich")  # keep the pre-enrichment original
        ev["domain_intel"] = {"checked_at": out["checked_at"], "sidecar": os.path.basename(side),
                              "domains": [{k: r.get(k) for k in ("input", "domain", "created", "domain_age_days", "age_flag", "age_hint", "registrar", "abuse_email", "registry_abuse", "status")} for r in results],
                              "why_lines": why, "caveat": CAVEAT}
        if hdr:
            # v12 H01: every re-enrichment replaces ALL known auth/provenance fields and demotes obsolete attribution even
            # when no new hint exists. Superseded values go to a private history sidecar, never shown as current facts.
            old = {k: ev.pop(k) for k in ("origin_ip", "origin_geo", "origin_ip_hint") if k in ev}
            old_auth = ev.get("auth") if isinstance(ev.get("auth"), dict) else {}
            known = AUTH_KNOWN
            new_auth = {k: hdr["auth"].get(k) for k in known}
            ext = {k: v for k, v in old_auth.items() if k not in known and k != "legacy_extensions_unverified"}
            ext.update(old_auth.get("legacy_extensions_unverified") or {})
            if ext: new_auth["legacy_extensions_unverified"] = ext
            superseded = {k: v for k, v in old_auth.items() if k in known and v != new_auth.get(k)}
            if superseded: old["auth"] = superseded
            ev["auth"] = new_auth
            if out.get("origin_ip_hint"):          # persisted under its real (renamed) key, uncertainty kept
                h = out["origin_ip_hint"]
                ev["origin_ip_hint"] = {"ip": h.get("ip") or hdr["first_external_ip"], "status": "unverified_hint_top_received_hop_only",
                                        "abuse_check_url": h.get("abuseipdb_check_url"), "not": "sender origin or location"}
                if h.get("network_org"): ev["origin_ip_hint"]["network_org"] = h["network_org"]
            if old:
                hist_p = a.evidence + ".provenance-history.json"
                try: hist = json.load(open(hist_p))
                except Exception: hist = {"version": 1, "note": "superseded, unverified values; NOT current facts", "entries": []}
                hist["entries"].append({"superseded_at": out["checked_at"], "values": old})
                _atomic_json(hist_p, hist)
                ev["provenance_history"] = os.path.basename(hist_p)
        _atomic_json(a.evidence, ev)
        out["written"] = {"evidence": a.evidence, "sidecar": side, "backup": a.evidence + ".bak-enrich"}
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
