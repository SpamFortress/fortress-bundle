#!/usr/bin/env python3
"""label_scan.py (Gmail hardening schema 9) - Email Fortress opt-in Gmail "Likely Scam" labeler. ONE algorithm: the callable driver
`run()` and the native-tool CLI both go through step_next()/step_commit() and share the same durable in-flight
action, leases and run budgets.

Not lossless. Using only search_emails(idsOnly) ids, read_email MINIMAL envelopes and update_email_labels:
  * Activation boundary: the saved full-precision processing instant after Turn on is kept, not the owner click.
    Discovery uses `after:<ceil(saved processing instant)>`, a
    conservative upper bound for the ambiguous consent second (mail arriving during that second is not read and may
    be missed). This assumes Gmail's `after:` excludes messages at or before that second; that is NOT proven and has
    not been verified against the live backend. Ids visible during the ids-only Starting baseline are excluded without reads; this is not an atomic tap snapshot.
    Host latency and backend indexing/exclusivity are unmeasured; Starting can absorb later arrivals.
  * Saved discovery from an older version whose query starts before that cutoff is restarted (query and page token
    discarded). Older pending ids are not read until a strict ids-only search lists them again; ids it never lists
    are marked unverified and left unread.
  * Each connector call is ONE in-flight action with a nonce, run id and consent epoch, and a lease. A commit must
    repeat the nonce when an action is outstanding. No process, including the callable driver holding the file
    lock, may take over an unexpired action; a callable action whose own process is provably dead is re-read.
  * Budgets are reserved when an action is issued: <=200 reads and <=50 label ATTEMPTS per run (unknown results
    count). Re-running begin-run or the driver never resets an active run.
  * Settings are re-read at every issue and commit boundary: OFF stops every NEW call immediately (a call already
    submitted cannot be recalled).
  * Protection: the canonical private safelist is always loaded and authoritative; a caller-supplied list can only
    ADD protection. Right before a label write is issued, the canonical list is re-read and the sender re-checked;
    newly protected -> review, no write; unreadable -> stop (message and budget kept).
  * Verdict: require a direct affirmative unusual gift-tender settlement, or a causally coercive payment demand;
    quoted, retail, attributed or negated asks are unsure. Also require pressure and a brand claimed as the sender's own name (whole word, not "partner/reseller of") from a domain that
    is none of that brand's official domains. Wire/Zelle/callback requests and brand association alone are unsure.
CLI: activate --label-id L (owner-turned-on only; captures the processing instant, ids-only baseline first) | begin-run | next |
     commit --step search|read|label --nonce N (required) ... | status --settings F
"""
import json, os, re, sys, time, math, tempfile, argparse, contextlib, secrets
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fortress_domain import host_of, registered_domain, domain_matches
import fortress_domain as _fd
DEFAULTS = {"overlap_s": 2 * 86400, "discovery_pages": 4, "page_size": 500, "read_budget": 200, "label_budget": 50,
            "max_consecutive_failures": 3, "seen_retention_s": 9 * 86400, "log_retention_s": 30 * 86400,
            "action_lease_s": 15 * 60, "run_lease_s": 2 * 3600, "max_token_resets": 2}
class AuthError(Exception): pass
class ConnError(Exception): pass

# ---------------- state, ownership, disk ----------------
def new_state(activated_at, likely_scam_label_id, provenance=None, baseline="complete"):
    """Low-level constructor. `activated_at` is taken as an EXACT instant (provenance says where it came from). The
    owner-facing path is activate_begin()/the `activate` CLI, which captures the instant itself and leaves the scan
    reading nothing until the ids-only baseline completes."""
    exact = _finite(activated_at, "activation instant")
    if not _opaque(likely_scam_label_id): raise ValueError("nonempty label id required")
    st = {"version": 9, "activated_at_exact": exact, "activated_at_floor": None, "activated_at": int(math.ceil(exact)), "high_water": int(math.ceil(exact)),
            "activation_precision": "exact", "activation_provenance": provenance or {"source": "caller_supplied"},
            "activation_id": secrets.token_hex(6), "baseline": baseline,
            "hw_candidate": None, "label_id": likely_scam_label_id, "seen": {}, "pending": [], "revalidate": [], "halted": None,
            "consecutive_failures": 0, "backlog": 0, "discovery": None, "discovery_incomplete": False, "log": [], "run": None,
            "inflight": None, "to_label": None, "verify_first": [], "activation_boundary": "exclusive_upper_bound"}
    st["discovery_contract"] = _contract(st)
    return st
def _cutoff(st):
    if st.get("activation_precision") == "legacy_floor_second":   # true instant anywhere in [floor, floor+1): next second
        return int(st["activated_at_floor"]) + 1
    return int(math.ceil(float(st["activated_at_exact"])))
def _epoch(st):
    return f"{st.get('activation_id')}|{st.get('activated_at_exact')!r}|{st.get('activated_at_floor')!r}"
def _to_revalidate(st, mid):
    """Ambiguous id (legacy intent/recovery): never read until a strict ids-only search lists it again."""
    if mid is None: return
    if mid in st["pending"]: st["pending"].remove(mid)
    if mid in st.get("verify_first", []): st["verify_first"].remove(mid)
    if mid not in st.setdefault("revalidate", []): st["revalidate"].append(mid); st["revalidate"].sort()
    st["discovery"] = None; st["pending_revalidated"] = False
    if isinstance(st.get("run"), dict): st["run"]["discovery_done"] = False
def _opaque(value): return isinstance(value, str) and bool(value.strip())
def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"invalid {name}: finite numeric value required")
    return float(value)
def _contract(st):
    return {"version": 1, "epoch": _epoch(st), "cutoff": _cutoff(st), "precision": st["activation_precision"]}
def _issued_label(st):
    """Only intact V8+ issued writes retain their unknown-write recovery exception. Not a native receipt proof."""
    inf = st.get("inflight"); run = st.get("run")
    return (isinstance(inf, dict) and isinstance(run, dict) and inf.get("kind") == "label"
            and _opaque(inf.get("id")) and _opaque(inf.get("nonce")) and not inf.get("legacy")
            and inf.get("epoch") == _epoch(st) and inf.get("run") == run.get("id")
            and isinstance(inf.get("issued_at"), (int, float)) and isinstance(inf.get("expires"), (int, float)))
def migrate(st):
    if st is None: return None
    if not isinstance(st, dict): raise ValueError("state must be an object")
    old_version = st.get("version", 1)
    if type(old_version) is not int or not 1 <= old_version <= 9: raise ValueError("unsupported state schema")
    precision = st.get("activation_precision")
    if old_version < 8 and precision is None:
        ex = st.get("activated_at_exact")
        if ex is None or _finite(ex, "legacy activation") == int(ex):
            fl = _finite(ex if ex is not None else st.get("activated_at"), "legacy activation floor")
            if fl != int(fl): raise ValueError("ambiguous nonintegral legacy floor")
            st.update(activated_at_exact=None, activated_at_floor=int(fl), activation_precision="legacy_floor_second")
        else: st.update(activation_precision="exact", activated_at_floor=None)
        st.setdefault("activation_provenance", {"source": "legacy_migration", "note": "precision not recoverable if previously floored"})
    elif old_version < 8 and precision == "exact": st.setdefault("activated_at_floor", None)
    precision = st.get("activation_precision")
    if precision == "exact":
        _finite(st.get("activated_at_exact"), "exact activation")
        if st.get("activated_at_floor") is not None: raise ValueError("exact activation also has a floor")
    elif precision == "legacy_floor_second":
        fl = _finite(st.get("activated_at_floor"), "activation floor")
        if fl != int(fl) or st.get("activated_at_exact") is not None: raise ValueError("inconsistent legacy floor")
    else: raise ValueError("invalid activation precision")
    if old_version < 8:
        st.setdefault("activation_id", "legacy"); st.setdefault("activation_provenance", {"source": "legacy_unknown"})
        st.setdefault("baseline", "complete")
    if not _opaque(st.get("activation_id")): raise ValueError("activation identity missing")
    prov = st.get("activation_provenance")
    if not isinstance(prov, dict) or not _opaque(prov.get("source")): raise ValueError("activation provenance missing")
    if st.get("baseline") not in ("pending", "complete"): raise ValueError("invalid baseline status")
    if not _opaque(st.get("label_id")): raise ValueError("invalid label identity")
    base = new_state(0, st["label_id"])
    for k, v in base.items():
        if k != "discovery_contract": st.setdefault(k, v)
    for name in ("pending", "revalidate", "verify_first"):
        if not isinstance(st[name], list) or any(not _opaque(i) for i in st[name]): raise ValueError(f"invalid {name} ids")
        st[name] = list(dict.fromkeys(st[name]))
    if not isinstance(st["seen"], dict) or not isinstance(st["log"], list): raise ValueError("invalid seen/log")
    st["activated_at"] = _cutoff(st)
    st["high_water"] = max(int(_finite(st["high_water"], "high water")), st["activated_at"])
    if st.get("run") is not None and not isinstance(st["run"], dict): raise ValueError("invalid run")
    if isinstance(st.get("run"), dict):
        for k, v in {"id": "legacy", "started": 0, "pages": 0, "reads": 0, "label_attempts": 0, "errors": 0,
                     "token_resets": 0, "discovery_done": False}.items(): st["run"].setdefault(k, v)
        if "labels" in st["run"]:
            st["run"]["label_attempts"] = max(st["run"]["label_attempts"], int(st["run"].pop("labels") or 0))
        st["run"].setdefault("lease_until", int(time.time()) + DEFAULTS["run_lease_s"])
    # Neither a schema number nor old pending_revalidated=True proves strict discovery at this boundary.
    # V8 had no per-boundary proof. Re-list all unissued inherited work; preserve every id without reading it.
    proof = _contract(st)
    if old_version < 9 or st.get("discovery_contract") != proof:
        genuine_write = old_version >= 8 and _issued_label(st)
        inf = st.get("inflight")
        exempt = inf["id"] if genuine_write else None
        work = list(st["pending"]) + list(st["verify_first"])
        ti = st.get("to_label")
        if ti is not None:
            work.append(ti.get("id") if isinstance(ti, dict) else ti); st["to_label"] = None
        if inf and not genuine_write:
            if inf.get("id"): work.append(inf["id"])
            inf["legacy"] = True
            # Cancel obsolete discovery (no content read). Old content receipts remain epoch/legacy-bound and rejected.
            if inf.get("kind") in ("search", "baseline"): st["inflight"] = None
        for mid in work:
            if mid != exempt: _to_revalidate(st, mid)
        st["discovery"] = None; st["hw_candidate"] = None
        if st.get("run"): st["run"]["discovery_done"] = False
        st["discovery_contract"] = proof
    for name in ("discovery", "baseline_progress"):
        d = st.get(name)
        if d is not None:
            if not isinstance(d, dict) or type(d.get("pages")) is not int or d["pages"] < 0 or (d.get("token") is not None and not _opaque(d["token"])):
                raise ValueError(f"invalid saved {name} page metadata")
            if name == "discovery" and (not isinstance(d.get("query"), str) or not isinstance(d.get("started"), (int, float))):
                raise ValueError("invalid saved discovery query metadata")
    _clamp_discovery(st)
    st["version"] = 9; return st
def _clamp_discovery(st):
    d = st.get("discovery")
    if d:
        m = re.match(r"^after:(\d+)$", d.get("query", ""))
        if not m or int(m.group(1)) < st["activated_at"]:
            st["discovery"] = None          # broad/legacy query: restart strictly, old token discarded
def _owner(path):
    from fortress_owner import require
    return require(path)
def load(path):
    if not path or not os.path.exists(path): return None
    _owner(path); return migrate(json.load(open(path)))
def save(path, st):
    if not path: return
    _owner(path)
    d = os.path.dirname(os.path.abspath(path)); fd, tmp = tempfile.mkstemp(prefix=".ls-", dir=d)
    with os.fdopen(fd, "w") as f:
        json.dump(st, f, indent=1); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(d, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)
# Canonical process/thread + advisory process lock; reentrant for API/CLI nesting.
import threading
_LOCKS = {}; _LOCKS_GUARD = threading.Lock(); _HELD = threading.local()
@contextlib.contextmanager
def locked(path, wait=True):
    import fcntl
    path = os.path.realpath(os.fspath(path)); _owner(path); _owner(path + ".lock")
    with _LOCKS_GUARD: mutex = _LOCKS.setdefault(path, threading.RLock())
    if not mutex.acquire(blocking=wait): raise BlockingIOError("another label-scan thread holds the lock")
    held = getattr(_HELD, "paths", None)
    if held is None: held = _HELD.paths = {}
    fd = None
    try:
        if path not in held:
            fd = os.open(path + ".lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB)); held[path] = fd
        yield
    finally:
        if fd is not None:
            held.pop(path, None); fcntl.flock(fd, fcntl.LOCK_UN); os.close(fd)
        mutex.release()
def _home(): return os.environ.get("FORTRESS_HOME")
def load_settings():
    try: return json.load(open(os.path.join(_home(), "private", "settings.json")))
    except Exception: return None
def load_safelist():
    """Canonical private safelist. Raises if missing/unreadable: never silently replaced by an empty list."""
    p = os.path.join(_home() or "", "private", "safelist.json")
    v = json.load(open(p))
    if not isinstance(v, dict): raise ValueError("safelist.json is not an object")
    return v
def psl_ready(): return bool(_fd._extractor())

# ---------------- protected-sender policy ----------------
def normalize_safelist(sl):
    sl = sl or {}; addrs = {a.lower() for a in sl.get("addresses", []) if isinstance(a, str)}; doms = list(sl.get("domains", []))
    extra_words = []
    def take(cat, rows):
        if isinstance(rows, dict):
            for k, x in rows.items():
                if k in ("domains", "domain"): take(cat, x if isinstance(x, list) else [x])
                elif k in ("addresses", "address", "senders"): take(cat, [y if isinstance(y, dict) or "@" in y else y for y in (x if isinstance(x, list) else [x])])
                elif k.startswith("keywords") and isinstance(x, list): extra_words.extend(str(w) for w in x)
            return
        for r in rows or []:
            if isinstance(r, str): r = {"address": r} if "@" in r else {"domain": r}
            if not isinstance(r, dict): continue
            if r.get("address"): addrs.add(r["address"].lower())
            if r.get("domain"): doms.append({"domain": r["domain"].lower(), "subdomains": bool(r.get("subdomains")), "category": cat})
    for cat, rows in (sl.get("categories") or {}).items(): take(cat, rows)
    for cat in ("banks_and_cards", "auth_and_security", "delivery_and_orders", "health_and_pharmacy", "government", "family_and_contacts", "caregiver"):
        if cat in sl: take(cat, sl[cat])                     # legacy top-level categories
    for cat, meta in (sl.get("category_meta") or {}).items(): take(cat, meta)
    take("always_allow", sl.get("always_allow") or [])
    take("vip", sl.get("vip") or [])
    doms = [d if isinstance(d, dict) else {"domain": d, "subdomains": False} for d in doms]
    return {"addresses": addrs, "domains": doms, "brands": sl.get("brands", {}) or {}, "words": extra_words}
SECURITY_WORDS = re.compile(r"(?i)(verification code|security code|login code|one[- ]time|\botp\b|passcode|password reset|reset your password|"
                            r"sign[- ]in attempt|\b2fa\b|two[- ]factor|security alert|new device|confirm your (email|account)|magic link)")
def parse_sender(frm):
    """Exactly one unambiguous RFC mailbox; display text is NEVER an actual sender address.
    Reject defects, multiple mailboxes/groups and header injection rather than choosing first/last."""
    from email import policy
    from email.parser import HeaderParser
    from email.errors import HeaderParseError
    if not isinstance(frm, str) or not frm.strip(): return None
    # Unfold valid header folding, but do not permit a second field or control characters.
    frm = re.sub(r"\r?\n[ \t]+", " ", frm)
    if any(ord(c) < 32 and c != '\t' or ord(c) == 127 for c in frm): return None
    # RFC mailbox parsing handles quoting/escapes/comments. Additionally disallow a top-level
    # mailbox-list comma (including obsolete empty entries) for this single-From contract.
    quote = False; escaped = False; comments = 0; angles = 0
    for ch in frm:
        if escaped: escaped = False; continue
        if ch == "\\" and (quote or comments): escaped = True; continue
        if comments:
            if ch == '(': comments += 1
            elif ch == ')': comments -= 1
            continue
        if ch == '"': quote = not quote; continue
        if quote: continue
        if ch == '(': comments = 1
        elif ch == '<': angles += 1
        elif ch == '>': angles -= 1
        elif ch == ',' and angles == 0: return None
    raw_display = None
    if angles == 0 and '<' in frm and not quote and not comments:
        i = frm.rfind('<'); raw_display = frm[:i].strip()
    try:
        h = HeaderParser(policy=policy.default).parsestr("From: " + frm + "\n\n")["From"]
        if h is None or h.defects or len(h.addresses) != 1 or any(g.display_name is not None for g in h.groups): return None
        a = h.addresses[0]
        if not a.username or not a.domain: return None
        return {"address": a.addr_spec.lower(), "display": _decoded_display(raw_display, a.display_name)}
    except (ValueError, IndexError, TypeError, HeaderParseError, RecursionError): return None

def _decoded_display(raw_display, parsed):
    """RFC 2047: whitespace between ADJACENT encoded words is not part of the text (stdlib HeaderParser keeps it).
    Display text only: never used as the actual mailbox, protection, VIP or authentication input."""
    if not raw_display or "=?" not in raw_display or raw_display.startswith('"'): return parsed
    try:
        from email.header import decode_header, make_header
        d = str(make_header(decode_header(raw_display)))
    except Exception: return parsed
    if any(ord(c) < 32 or ord(c) == 127 for c in d) or "<" in d or ">" in d: return parsed
    return d
def sender_addr(frm):
    sender = parse_sender(frm)
    return sender["address"] if sender else ""
_INVISIBLE = dict.fromkeys(map(ord, "\u00ad\u200b\u200c\u200d\u2060\ufeff\u180e"), None)
def _rfc2047(raw):
    if not isinstance(raw, str) or "=?" not in raw: return ""
    try:
        from email.header import decode_header, make_header
        return str(make_header(decode_header(re.sub(r"\r?\n[ \t]+", " ", raw))))
    except Exception: return ""
def _security_text(parts):
    """Protection-only canonical text: NFKC, invisible format chars removed, every Unicode space/separator run -> one
    space, casefolded. Used only to ADD protection; never to authenticate or to remove protection."""
    import unicodedata
    t = " ".join(p for p in parts if isinstance(p, str))
    t = unicodedata.normalize("NFKC", t).translate(_INVISIBLE)
    t = "".join(" " if (ch.isspace() or unicodedata.category(ch) in ("Zs", "Zl", "Zp", "Cc")) else ch for ch in t)
    return re.sub(r" +", " ", t).casefold()
def gate(env, safelist):
    sl = normalize_safelist(safelist)
    frm = env.get("from") or ""; sender = parse_sender(frm)
    addr = sender["address"] if sender else ""; host = host_of(addr) if addr else ""
    if not addr: return "protected_review", "sender mailbox ambiguous/unparseable; authentication unknown, no write"
    if addr and addr in sl["addresses"]: return "protected_review", "exact protected/VIP address; authentication unknown"
    for d in sl["domains"]:
        if domain_matches(host, d["domain"], d.get("subdomains", False)): return "protected_review", f"protected domain {d['domain']}; authentication unknown"
    text = _security_text([frm, _rfc2047(frm), sender["display"] if sender else "", env.get("subject") or "", _rfc2047(env.get("subject") or ""), env.get("snippet") or ""])
    words = [_security_text([w]) for w in sl["words"] if isinstance(w, str) and w.strip()]
    if SECURITY_WORDS.search(text) or any(w and (w in text or w.replace(" ", "") in text.replace(" ", "")) for w in words):
        return "protected_review", "security/sign-in/reset wording; never auto-labeled, not vouched for either"
    if host and registered_domain(host) is None: return "protected_review", "registered domain unknown (no PSL); not safe to auto-write"
    return "eligible", "not a protected candidate"

# ---------------- conservative envelope-only verdict ----------------
GIFT_TEXT = r"(?:gift ?cards?|itunes cards?|google play cards?|apple (?:gift )?cards?|steam cards?)"
CRYPTO_TEXT = r"(?:bitcoin|btc|crypto(?:currency)?|usdt|ethereum|eth)"
GIFT = re.compile(r"(?i)\b" + GIFT_TEXT + r"\b")
# Explicit direct imperative only, not a third-person report or ordinary retail buy/redeem.
DEMAND = re.compile(r"(?i)^(?:(?:please|you must|you need to|you are required to)\s+)?"
                    r"(?P<verb>pay|send|transfer|buy|purchase|load)\b(?P<bridge>[^.!?\n]*?)"
                    r"(?P<rail>\b(?:" + GIFT_TEXT + "|" + CRYPTO_TEXT + r")\b)(?P<tail>.*)$")
NEG = re.compile(r"(?i)\b(?:not|no|never|nobody|nothing|without|needn't|(?:do|does|did|is|are|was|were|will|would|should|could|can|has|have|had)n['’]t)\b")
THREAT = r"(?:arrest(?:ed)?|warrant|jail|deport\w*|lawsuit|legal action|prosecut\w*|criminal charges|suspension|closure|penalt\w*|(?:lose|loss of) (?:your )?(?:account|access|service))"
CAUSAL_THREAT = re.compile(r"(?i)\b(?:or (?:else )?(?:face |risk |you (?:will |may )?(?:be )?)?|to avoid |otherwise (?:face |you (?:will |may )?(?:be )?)?)(?P<consequence>" + THREAT + r"\b)")
ACCOUNT_STATE = re.compile(r"(?i)\b(?:(?:your )?(?:account|access|service|card) (?:is |has been |will be )?)?(?:suspended|locked|frozen|disabled|terminated)\b")
RESTORE = re.compile(r"(?i)\bto (?:restore|unlock|reactivate|unfreeze|avoid suspension|avoid closure)\b")
IDENT_WORDS = {"security", "support", "team", "service", "services", "billing", "account", "accounts", "alert", "alerts", "customer",
               "care", "help", "helpdesk", "notification", "notifications", "department", "dept", "agent", "fraud", "prevention",
               "official", "inc", "llc", "ltd", "corp", "corporation", "online", "center", "centre", "desk", "verification", "the",
               "payments", "payment", "refunds", "refund", "collections", "office", "admin", "administrator", "no-reply", "noreply"}
AFFILIATION = re.compile(r"(?i)\b(partner|reseller|certified|authori[sz]ed|affiliate|dealer|consultant|agency|solutions provider|for|via|on behalf of|powered by)\b")
# These are candidate addr-spec TOKENS INSIDE A DISPLAY NAME, not mailbox extraction.
# RFC validation still decides whether a token really is an address; official-domain matching
# supplies only a claimed identity. parse_sender/gate/actual From are intentionally unchanged.
_DISPLAY_ADDRESS = re.compile(r'(?<![\w@.!#$%&\'*+/=?^`{|}~-])(?:"(?:[^"\\]|\\.)+"|[A-Za-z0-9.!#$%&\'*+/=?^_`{|}~-]+)@[^\W_](?:[\w.\-\u3002]*[^\W_])?\.?(?![\w@.\-\u3002])')
def claimed_brands(display, brand_domains):
    """A known textual identity + role words, or an official-domain display address + role words.
    All remaining text must fit the same identity grammar: unrelated businesses, affiliation and
    incidental mentions cannot inherit a claim from an email/domain token. None is authentication."""
    import unicodedata
    d = unicodedata.normalize("NFKC", display or "").translate(_APOS).strip()
    address_claims = set()
    def take_address(m):
        token = m[0].rstrip('.')   # sentence/FQDN punctuation is display syntax, never actual From
        address = parse_sender(token)
        if address is None or address["display"]: return m[0]
        host = host_of(address["address"])
        for brand, domains in brand_domains.items():
            if any(domain_matches(host, domain, True) for domain in domains): address_claims.add(brand)
        return " "               # remove validated addr-spec even if its domain claims no known brand
    d = _DISPLAY_ADDRESS.sub(take_address, d)
    if AFFILIATION.search(d): return []  # words in the residual identity, not inside addr-spec local parts
    def roles_only(text):
        text = ''.join(' ' if c.isspace() or unicodedata.category(c).startswith('P') or c in '|&+<>' else c for c in text)
        return all(w.casefold() in IDENT_WORDS for w in text.split())
    text_claims = set()
    for brand in brand_domains:
        pattern = re.compile(r"(?i)(?<![a-z0-9])" + re.escape(brand) + r"(?![a-z0-9])")
        if pattern.search(d) and roles_only(pattern.sub(' ', d)): text_claims.add(brand)
    # A bare display address or role+address can claim a brand; a merchant name ('Local Shop',
    # 'Gemini Studio') plus an address cannot. Multiple address-domain claims are retained, but
    # multiple unexplained textual brand/business words remain ambiguous under the old grammar.
    if not text_claims and not roles_only(d): return []
    claims = text_claims | address_claims
    return [brand for brand in brand_domains if brand in claims]
_APOS = dict.fromkeys(map(ord, "\u2019\u02bc\u02b9`\u00b4\u2032"), "'")   # \u2018 kept: it opens quotes
def _unquoted(text):
    """Length-independent quote framing. Apostrophes inside words are not quotes.
    Unclosed quotation consumes the remainder conservatively; RFC reply-quoted lines carry no direct demand."""
    pairs = {'"': '"', "'": "'", '“': '”', '„': '”', '‘': '’', '«': '»', '‹': '›'}
    out = []; stack = []; fence = None
    for line in text.splitlines():
        marker = re.match(r"^\s*(`{3,}|~{3,})", line)
        if marker:
            mark = marker[1]
            if fence is None: fence = mark
            elif mark[0] == fence[0] and len(mark) >= len(fence): fence = None
            continue
        if fence is not None or line.startswith(("    ", "\t")): continue
        if line.lstrip().startswith('>'): continue
        # Quote state spans lines inside each field, without a length limit.
        buf = []
        for i, ch in enumerate(line):
            apostrophe = ch in "'’" and i > 0 and i + 1 < len(line) and line[i-1].isalnum() and line[i+1].isalnum()
            if apostrophe:
                if not stack: buf.append(ch)
            elif stack:
                if ch == stack[-1]: stack.pop(); buf.append(" ")
                elif ch in pairs and ch != stack[-1]: stack.append(pairs[ch])
            elif ch in pairs: stack.append(pairs[ch]); buf.append(" ")
            elif ch in {'”', '’', '»', '›'}: buf.append(" ")
            else: buf.append(ch)
        out.append(''.join(buf))
    return '\n'.join(out)
def _heading(c):
    """Admitted non-attribution headings. A role/receipt heading is not a scam-report frame."""
    c = c.strip()
    return (not c or bool(re.fullmatch(r'(?:final notice|last warning|urgent|action (?:needed|required)|(?:overdue|past due)(?: (?:invoice|reminder|payment|balance))?|(?:your )?(?:receipt|order|order confirmation)|(?:fraud|billing|security|collections|accounts?|customer service)(?: (?:department|team|office|desk|notice)))', c, re.I))
            or bool(ACCOUNT_STATE.fullmatch(c) and not NEG.search(c)))

META_DEMAND = re.compile(r"(?i)\b(?:is|was|as) (?:an? |the )?(?:example|sample|quote|quotation|scam|fake|fraud|phishing|tactic)\b")
FRAME = re.compile(r"(?i)^(?:(?:this|our|the|an?)\s+)?(?:news(?:letters?)?|articles?|reports?|reporting|bulletins?|forwarded(?: (?:message|email))?|example|sample|warning about|how to spot|tips for spotting)\b")
ATTRIBUTION = re.compile(r"(?i)\b(?:said|says|wrote|writes|quoted|quoting|according to)\b")
def _fraud_demand(text):
    """Clause-local affirmative demand/threat grammar. Reported/quoted/negated speech stays
    conservative, while unrelated questions and receipt/role headings do not veto a direct threat."""
    # Keep interrogative punctuation attached to its own clause. Colons/newlines bind headings;
    # sentence boundaries reset ordinary incidental text but never launder an explicit report frame.
    text = re.sub(r'\s+[-—–]\s+', ':', text)
    clauses = re.finditer(r'([^.!?;:\n]+)([.!?;:\n]*|$)', text)
    prefix_ok = True; framed = False; preamble = ""; carry = ""
    for part in clauses:
        c, delimiter = part[1].strip(), part[2]
        question = '?' in delimiter
        heading = _heading(c)
        m = DEMAND.fullmatch(c)
        if m and not question and prefix_ok and not framed and not NEG.search(c) and not META_DEMAND.search(c):
            linked = bool(CAUSAL_THREAT.search(m['tail']))
            ctx = preamble or carry
            restoration = bool(RESTORE.search(m['tail']) and ACCOUNT_STATE.fullmatch(ctx) and not NEG.search(ctx))
            # An affirmative linked threat/restoration condition IS pressure. No extra urgency token needed.
            if linked or restoration: return True
            if GIFT.fullmatch(m['rail']) and m['verb'].lower() == 'pay' and re.fullmatch(r'\s*(?:with|in|by|using)\s+', m['bridge'], re.I) \
                and re.fullmatch(r'(?:final notice|past due|last warning)', preamble, re.I) \
                and re.fullmatch(r'\s*(?:now|immediately|today|within 24 hours)\s*', m['tail'], re.I):
                return True
        new_carry = c if (heading and not question and not framed and ACCOUNT_STATE.fullmatch(c) and not NEG.search(c)) else ""
        if heading and not question:
            preamble = c
        else:
            # Framing words only in framing/non-demand clauses, never a blanket word veto.
            if META_DEMAND.search(c) or (not m and (FRAME.search(c) or ATTRIBUTION.search(c))): framed = True
            prefix_ok = False; preamble = ""
        if re.search(r'[.!?;]', delimiter): prefix_ok = True; preamble = ""
        carry = new_carry          # one clause only; any intervening clause clears it
    return False
def envelope_verdict(env, brand_domains=None, explain=False):
    brand_domains = brand_domains or {}
    frm = env.get("from") or ""; sender = parse_sender(frm)
    addr = sender["address"] if sender else ""; host = host_of(addr) if addr else ""
    disp = sender["display"] if sender else ""
    import unicodedata
    text = "\n".join(_unquoted(unicodedata.normalize("NFKC", env.get(k) or "")).translate(_APOS)
                     for k in ("subject", "snippet"))
    def r(v, why): return (v, why) if explain else v
    if not sender: return r("unsure", "sender mailbox ambiguous/unparseable; never treated as an official domain")
    if not _fraud_demand(text): return r("unsure", "no direct affirmative unusual settlement/coercive payment demand; retail/quotation/negation alone is insufficient")
    claimed = claimed_brands(disp, brand_domains)
    if not claimed: return r("unsure", "display name does not present itself as a known brand")
    if registered_domain(host) is None if host else True: return r("unsure", "sender domain unknown")
    for b in claimed:
        if any(domain_matches(host, d, True) for d in brand_domains[b]): return r("unsure", f"sender is an official {b} domain")
    return r("likely_scam", f"display name presents itself as {claimed[0]} from {registered_domain(host)}, with an unusual or coercive payment demand (not authentication proof)")
def load_brand_domains():
    try:
        db = json.load(open(os.path.join(_home(), "data", "brand-domains.json")))["brands"]
        return {b: v["domains"] for b, v in db.items() if v.get("domains")}
    except Exception:
        return {}

# ---------------- the one step algorithm ----------------
def _now(now): return int(now if now is not None else time.time())
def _boot_id():
    try: return open("/proc/sys/kernel/random/boot_id").read().strip()
    except Exception: return None
def _proc_start(pid):
    try: return open(f"/proc/{pid}/stat").read().rsplit(")", 1)[1].split()[19]
    except Exception: return None
def _owner_dead(inf):
    """Only a CALLABLE driver's own process can be proven dead (same boot, pid gone or reused). A native CLI action's
    issuing process always exits right away while the connector call continues elsewhere, so it is never 'dead'."""
    o = inf.get("owner") or {}
    if o.get("driver") != "callable" or o.get("boot") != _boot_id() or not o.get("pid"): return False
    return _proc_start(o["pid"]) != o.get("start")
def _prune(st, now, cfg):
    cutoff = st["high_water"] - cfg["overlap_s"] - cfg["seen_retention_s"]
    st["seen"] = {k: v for k, v in st["seen"].items() if v["t"] >= cutoff}
    st["log"] = [x for x in st["log"] if x["t"] >= now - cfg["log_retention_s"]]
def _run_active(st, now):
    r = st.get("run")
    return r is not None and not r.get("finished") and r.get("lease_until", now + 1) > now
def begin_run(st, now=None, cfg=None):
    """Starts a new run only when no run is active AND no connector action is still leased (an expired run lease never
    discards a live action, its identity or its charged budgets). A carried label intent is re-reserved in the new run."""
    cfg = {**DEFAULTS, **(cfg or {})}; now = _now(now); migrate(st)
    if _run_active(st, now): return {"ok": False, "why": "a run is already active; its budgets are kept"}
    inf = st.get("inflight")
    if inf and inf["expires"] > now and not _owner_dead(inf):
        return {"ok": False, "why": "a connector action from the current run is still outstanding; run kept until it is committed or expires"}
    carried = 1 if (isinstance(st.get("to_label"), dict) and st["to_label"].get("env")) else 0
    st["run"] = {"id": secrets.token_hex(6), "started": now, "lease_until": now + cfg["run_lease_s"], "pages": 0, "reads": 0,
                 "label_attempts": carried, "errors": 0, "token_resets": 0, "discovery_done": False}
    if carried: st["to_label"]["run"] = st["run"]["id"]
    _prune(st, now, cfg); return {"ok": True, "run": st["run"]["id"]}
def _allowed(st, settings):
    if settings is None: return "off"                  # unreadable settings never mean on
    if settings.get("inbox_label_scan") != "on": return "off"
    if settings.get("lane") not in (None, "email"): return "wrong_lane"
    return None
def _policy(extra=None):
    """Canonical safelist (authoritative) plus, optionally, extra protection (addresses, domains AND keyword rules are
    all merged additively). Raises if canonical is unreadable."""
    canon = load_safelist()
    if not extra: return canon
    merged = json.loads(json.dumps(canon)); cats = merged.setdefault("categories", {}); cats.setdefault("caller_extra", [])
    n = normalize_safelist(extra)
    cats["caller_extra"] += [{"address": a} for a in n["addresses"]] + [{"domain": d["domain"], "subdomains": d.get("subdomains", False)} for d in n["domains"]]
    if n["words"]:
        meta = merged.setdefault("category_meta", {}).setdefault("caller_extra", {})
        meta["keywords_extra"] = list(meta.get("keywords_extra", [])) + [w for w in n["words"] if w.strip()]
    return merged
def step_next(st, settings=None, now=None, cfg=None, driver="native", safelist=None):
    cfg = {**DEFAULTS, **(cfg or {})}; now = _now(now); migrate(st)
    _prune(st, now, cfg)
    stop = _allowed(st, settings)
    if stop: return {"do": stop}
    if st["halted"]: return {"do": "halted", "reason": st["halted"]}
    if st.get("run") is None or st["run"].get("finished"): begin_run(st, now, cfg)
    r = st["run"]; inf = st.get("inflight")
    if inf:
        if inf["expires"] > now and not _owner_dead(inf): return {"do": "wait", "inflight": inf["kind"], "until": inf["expires"]}
        genuine = not inf.get("legacy") and inf.get("epoch") == _epoch(st)
        if inf["kind"] in ("label", "read") and inf.get("id"):
            if genuine and inf["kind"] == "label": _requeue_verify(st, inf["id"])   # result unknown: re-read before any rewrite
            elif not genuine: _to_revalidate(st, inf["id"])                       # ambiguous: strict ids-only re-list first
        st["inflight"] = None
    if st.get("baseline") != "complete":
        return _baseline_next(st, now, cfg, driver)
    intent = st.get("to_label")
    if intent:
        mid = intent["id"] if isinstance(intent, dict) else intent
        try: pol = _policy(safelist)
        except Exception as e:
            return {"do": "stop_run", "why": f"protected-sender list unreadable ({e}); label intent kept, nothing written"}
        env = intent.get("env") if isinstance(intent, dict) else None
        if env is None:
            st["to_label"] = None; _to_revalidate(st, mid); return step_next(st, settings, now, cfg, driver, safelist)
        if gate(env, pol)[0] == "protected_review":       # owner protected it after the read: no write, attempt refunded
            st["to_label"] = None; r["label_attempts"] = max(0, r.get("label_attempts", 0) - 1)
            _done(st, mid, "review_protected", now); return step_next(st, settings, now, cfg, driver, safelist)
        st["to_label"] = None                               # attempt was reserved with the intent; unknown results count
        return _issue(st, "label", mid, now, cfg, driver, {"tool": "update_email_labels", "args": {"messageIds": [mid], "addLabelIds": [st["label_id"]]}})
    if not r.get("discovery_done") and r["pages"] < cfg["discovery_pages"]:
        _clamp_discovery(st)
        if st.get("discovery") is None:
            since = max(st["activated_at"], st["high_water"] - cfg["overlap_s"])
            st["discovery"] = {"query": f"after:{since}", "token": None, "started": now, "pages": 0}
        args = {"query": st["discovery"]["query"], "labelIds": ["INBOX"], "idsOnly": True, "maxResults": cfg["page_size"]}
        if st["discovery"]["token"]: args["pageToken"] = st["discovery"]["token"]
        return _issue(st, "search", None, now, cfg, driver, {"tool": "search_emails", "args": args})
    if st["pending"] and r["reads"] < cfg["read_budget"]:
        mid = st["pending"][0]; r["reads"] += 1
        return _issue(st, "read", mid, now, cfg, driver, {"tool": "read_email", "args": {"messageId": mid, "messageFormat": "MINIMAL"}})
    return _finish(st, now)
def _issue(st, kind, mid, now, cfg, driver, action):
    request_limit = None
    if kind in ("search", "baseline"):
        request_limit = action["args"].get("maxResults")
        if type(request_limit) is not int or not 1 <= request_limit <= 500: raise ValueError("issued page size must be an integer in 1..500")
    n = secrets.token_hex(8)
    owner = {"driver": driver}
    if driver == "callable": owner.update(pid=os.getpid(), start=_proc_start(os.getpid()), boot=_boot_id())
    st["inflight"] = {"kind": kind, "id": mid, "nonce": n, "run": st["run"]["id"], "epoch": _epoch(st),
                      "issued_at": now, "expires": now + cfg["action_lease_s"], "owner": owner}
    if request_limit is not None: st["inflight"]["request_limit"] = request_limit
    return {"do": kind, "nonce": n, "id": mid, **action}
def _requeue_verify(st, mid):
    if mid in st["pending"]: st["pending"].remove(mid)
    st["pending"].insert(0, mid); st.setdefault("verify_first", [])
    if mid not in st["verify_first"]: st["verify_first"].append(mid)
def _finish(st, now, why=None):
    r = st["run"]; r["finished"] = True
    if r.get("errors", 0) == 0 and st.get("hw_candidate"):
        st["high_water"] = st["hw_candidate"]; st["hw_candidate"] = None
    st["backlog"] = len(st["pending"]); st["discovery_incomplete"] = st.get("discovery") is not None
    out = {"do": "idle", "backlog": st["backlog"]}
    if why: out["why"] = why
    return out
def _fail(st, cfg, why):
    st["consecutive_failures"] += 1; st["run"]["errors"] = st["run"].get("errors", 0) + 1
    if st["consecutive_failures"] >= cfg["max_consecutive_failures"] and not st["halted"]: st["halted"] = "repeated_failures"
    return {"error": why}
def _done(st, mid, outcome, now):
    if mid in st["pending"]: st["pending"].remove(mid)
    if mid in st.get("verify_first", []): st["verify_first"].remove(mid)
    st["seen"][mid] = {"t": now, "o": outcome}; st["backlog"] = len(st["pending"])
    if outcome in ("labeled", "review_protected", "already_labeled"): st["log"].append({"id": mid, "o": outcome, "t": now})
    return {"outcome": outcome}
def step_commit(st, step, safelist=None, ids=None, next_token=None, mid=None, envelope=None, ok=None, error=None,
                auth_lost=False, cfg=None, now=None, settings=None, nonce=None, verdict=None):
    cfg = {**DEFAULTS, **(cfg or {})}; now = _now(now); migrate(st)
    if st.get("run") is None or st["run"].get("finished"): begin_run(st, now, cfg)
    r = st["run"]; inf = st.get("inflight")
    if inf:
        if not nonce: return {"error": "an action is outstanding: its nonce is required; ignored", "expected": inf["kind"]}
        kind_ok = inf["kind"] == step or (inf["kind"] == "baseline" and step == "search")
        if nonce != inf["nonce"] or not kind_ok or (mid is not None and inf["id"] != mid) \
           or inf.get("legacy") or inf.get("run") != r["id"] or inf.get("epoch") != _epoch(st):
            return {"error": "stale or mismatched commit; ignored", "expected": inf["kind"]}
        if step in ("read", "label"):
            if inf.get("id") is None: return {"error": "issued action has no message id; ignored"}
            mid = inf["id"]                    # identity comes from the issued record, never from the caller alone
        if step == "label" and not auth_lost and ((ok is not None and type(ok) is not bool) or (ok is True and error)):
            # Malformed evidence cannot consume an issued write or become success. Keep the original nonce,
            # lease and charged attempt; accept a corrected genuine receipt or recover as unknown on expiry.
            return {"error": "label receipt requires literal True for success, False/None for failed/unknown; contradictory error refused", "protocol_error": "label_receipt"}
        baseline = inf["kind"] == "baseline"
        st["inflight"] = None
    else:
        # Only actions issued by `next` can be acknowledged. There is no nonce-free receipt path (an unissued intent
        # can never be marked labeled, and nothing is recorded under a missing id).
        return {"error": "no outstanding issued action; call next first; ignored"}
    if step == "search" and not error and not auth_lost:
        limit = inf.get("request_limit")
        if type(limit) is not int or not 1 <= limit <= 500 or not isinstance(ids, list) or len(ids) > limit or any(not _opaque(i) for i in ids) or (next_token is not None and not _opaque(next_token)):
            # Unknown/malformed page is NOT an empty successful page. Keep cursor, queues, page/read budgets
            # and high-water unchanged. Only the failed issued action is consumed; three failures halt.
            return {**_fail(st, cfg, "malformed/oversize page receipt: explicit ids list within the issued request limit (1..500) and optional nonempty string token required"), "protocol_error": "page"}
    if step == "read" and not error and not auth_lost:
        if not isinstance(envelope, dict) or any(envelope.get(k) is not None and not isinstance(envelope[k], str) for k in ("from", "subject", "snippet")) or not isinstance(envelope.get("labels", []), list) or any(not _opaque(i) for i in envelope.get("labels", [])):
            return _fail(st, cfg, "malformed MINIMAL envelope receipt; message kept, no label")
    if baseline and not auth_lost:
        return _baseline_commit(st, ids, next_token, error, now, cfg)
    if auth_lost:
        st["halted"] = "auth_lost"
        if step in ("read", "label") and mid: _requeue_verify(st, mid) if step == "label" else None
        return {"halted": True}
    if step == "search":
        d = st.get("discovery")
        if d is None: return {"error": "no discovery in progress"}
        if error:
            if "token" in error.lower() and r.get("token_resets", 0) < cfg["max_token_resets"]:
                d["token"] = None; d["started"] = now; r["token_resets"] = r.get("token_resets", 0) + 1
                return {"restart": "invalid token; discovery restarts from the first page"}
            r["discovery_done"] = True; return _fail(st, cfg, error)
        pend = set(st["pending"]); rev = set(st.get("revalidate", []))
        for i in ids or []:
            if i in rev: rev.discard(i); st["pending"].append(i); pend.add(i); continue    # strict search confirmed it
            if i not in st["seen"] and i not in pend: st["pending"].append(i); pend.add(i)
        st["revalidate"] = sorted(rev)
        d["token"] = next_token or None; d["pages"] += 1; r["pages"] += 1; st["consecutive_failures"] = 0
        if not d["token"]:
            st["hw_candidate"] = d["started"]; st["discovery"] = None; r["discovery_done"] = True
            for i in st["revalidate"]: st["seen"][i] = {"t": now, "o": "unverified_not_read"}
            st["revalidate"] = []; st["pending_revalidated"] = True
        st["backlog"] = len(st["pending"]); return {"pending": len(st["pending"])}
    if step == "read":
        if error: return _fail(st, cfg, error)
        st["consecutive_failures"] = 0
        stop = _allowed(st, settings)
        if stop: return {"do": stop, "note": "nothing recorded; message stays pending"}
        if st["label_id"] in (envelope.get("labels") or []): return _done(st, mid, "already_labeled", now)
        if mid in st.get("verify_first", []): st["verify_first"].remove(mid)
        try: pol = _policy(safelist)
        except Exception as e: return {"error": f"protected-sender list unavailable ({e}); not labeling", "do": "stop_run"}
        g, why = gate(envelope, pol)
        if g == "protected_review": return _done(st, mid, "review_protected", now)
        v = verdict(envelope) if verdict else envelope_verdict(envelope, load_brand_domains())
        if v != "likely_scam": return _done(st, mid, "no_label_" + str(v), now)
        if r.get("label_attempts", 0) >= cfg["label_budget"]: return {"do": "stop_run", "why": "label attempt budget used"}
        r["label_attempts"] = r.get("label_attempts", 0) + 1     # reserved now (refunded only if no write is ever issued)
        st["to_label"] = {"id": mid, "v": 9, "run": r["id"], "env": {k: envelope.get(k) for k in ("from", "subject", "snippet")}}
        return {"do": "label", "note": "call next: it re-checks the protected list and issues the write"}
    if step == "label":
        if ok is True: st["consecutive_failures"] = 0; return _done(st, mid, "labeled", now)
        _requeue_verify(st, mid); return _fail(st, cfg, error or "label failed/unknown")
    raise ValueError(step)

# ---------------- callable driver over the same steps ----------------
def _run_steps(st, conn, verdict=None, safelist=None, now=None, cfg=None, path=None, settings=None):
    """conn.search_ids(q,label_ids,token)->(ids,next); conn.envelope(id)->dict; conn.add_label(id,label).
    Uses the shared in-flight action, leases and run budgets; never clears or resets them. With a path, settings are
    re-read from disk at every boundary (fixed `settings` only for pure in-memory use)."""
    cfg = {**DEFAULTS, **(cfg or {})}; now = _now(now); migrate(st)
    if st["halted"]: return {"status": "halted", "reason": st["halted"]}
    S = (lambda: load_settings()) if path else (lambda: settings if settings is not None else {"inbox_label_scan": "on"})
    reads = labels = 0; err = None; complete = False; status = None; first = True
    inherited = st.get("run") is not None and not st["run"].get("finished")
    while True:
        a = step_next(st, S(), now, cfg, driver="callable", safelist=safelist); save(path, st)
        if first and a["do"] == "idle" and inherited:
            # the inherited run had nothing left to do and is now finished: this wake starts its own run
            first = False; continue
        first = False
        if a["do"] in ("baseline", "search"):
            try:
                result = conn.search_ids(a["args"]["query"], ["INBOX"], a["args"].get("pageToken"))
                ids, nxt = result if isinstance(result, (tuple, list)) and len(result) == 2 else (None, None)
                o = step_commit(st, "search", ids=ids, next_token=nxt, now=now, cfg=cfg, nonce=a["nonce"], settings=S())
                if "error" in o: err = f"{a['do']}:{o['error']}"
                elif a["do"] == "search" and not nxt: complete = True
            except AuthError: step_commit(st, "search", auth_lost=True, now=now, cfg=cfg, nonce=a["nonce"])
            except ConnError as e:
                o = step_commit(st, "search", error=str(e), now=now, cfg=cfg, nonce=a["nonce"])
                if "error" in o: err = f"{a['do']}:{e}"
        elif a["do"] == "read":
            mid = a["args"]["messageId"]
            try:
                env = conn.envelope(mid); reads += 1
                o = step_commit(st, "read", mid=mid, envelope=env, safelist=safelist, settings=S(), now=now, cfg=cfg, verdict=verdict, nonce=a["nonce"])
            except AuthError: step_commit(st, "read", mid=mid, auth_lost=True, now=now, cfg=cfg, nonce=a["nonce"]); o = {}
            except ConnError as e:
                step_commit(st, "read", mid=mid, error=str(e), now=now, cfg=cfg, nonce=a["nonce"]); err = f"read:{e}"; o = {}
            if o.get("do") == "stop_run": st["run"]["discovery_done"] = True; save(path, st); break
            if o.get("do") in ("off", "wrong_lane"): status = o["do"]; save(path, st); break
        elif a["do"] == "label":
            mid = a["args"]["messageIds"][0]; save(path, st)
            try:
                conn.add_label(mid, st["label_id"]); labels += 1
                step_commit(st, "label", mid=mid, ok=True, now=now, cfg=cfg, nonce=a["nonce"])
            except AuthError: step_commit(st, "label", mid=mid, auth_lost=True, now=now, cfg=cfg, nonce=a["nonce"])
            except ConnError as e: step_commit(st, "label", mid=mid, error=str(e), now=now, cfg=cfg, nonce=a["nonce"]); err = f"label:{e}"
        elif a["do"] == "wait":
            status = "busy"; break
        elif a["do"] in ("off", "wrong_lane", "halted", "stop_run"):
            status = a["do"]; break
        else:
            break
        save(path, st)
        if err or st["halted"]: break
    if st["run"] and not st["run"].get("finished") and status not in ("busy",) and not st.get("inflight"): _finish(st, now)
    save(path, st)
    if st["halted"] == "auth_lost": return {"status": "halted", "reason": "auth_lost", "reads": reads, "labels": labels}
    if status: return {"status": status, "reads": reads, "labels": labels, "backlog": len(st["pending"])}
    return {"status": "error" if err else "ok", "error": err, "reads": reads, "labels": labels, "backlog": len(st["pending"]),
            "discovery_complete": complete, "high_water": st["high_water"]}
def run(st, conn, verdict=None, safelist=None, now=None, cfg=None, path=None, settings=None):
    """Owned path boundary reloads under the canonical lock, never serializes a caller's stale snapshot.
    Without path this is explicitly a trusted pure in-memory simulator, not a durable/native entrypoint."""
    if not path: return _run_steps(st, conn, verdict, safelist, now, cfg, settings=settings)
    _owner(path)
    with locked(path, wait=False):
        current = load(path)
        if current is None: return {"status": "not_activated"}
        out = _run_steps(current, conn, verdict, safelist, now, cfg, path=path)
        if st is not None: st.clear(); st.update(current)
        return out
def run_locked(path, conn, verdict=None, safelist=None, now=None, cfg=None):
    _owner(path)
    with locked(path, wait=False):
        st = load(path)
        if st is None: return {"status": "not_activated"}
        return run(st, conn, verdict, safelist, now, cfg, path=path)
def _baseline_next(st, now, cfg, driver):
    b = st.setdefault("baseline_progress", {"token": None, "pages": 0})
    if b["pages"] >= cfg.get("baseline_pages", 200): return {"do": "stop_run", "why": "baseline listing did not finish; scan stays inactive (nothing read)"}
    args = {"query": f"after:{st['activated_at'] - cfg['overlap_s']}", "labelIds": ["INBOX"], "idsOnly": True, "maxResults": cfg["page_size"]}
    if b["token"]: args["pageToken"] = b["token"]
    return _issue(st, "baseline", None, now, cfg, driver, {"tool": "search_emails", "args": args})
def _baseline_commit(st, ids, next_token, error, now, cfg):
    b = st.setdefault("baseline_progress", {"token": None, "pages": 0})
    if error: return _fail(st, cfg, f"baseline: {error}")
    for i in ids or []: st["seen"][i] = {"t": st["activated_at"], "o": "pre_consent"}     # ids only; never read
    b["pages"] += 1; b["token"] = next_token or None; st["consecutive_failures"] = 0
    if not b["token"]:
        st["baseline"] = "complete"; st["baseline_completed_at"] = now; st.pop("baseline_progress", None)
        return {"baseline": "complete"}
    return {"baseline": "listing", "pages": b["pages"]}
def activate_begin(path, label_id, clock=time.time, settings=None):
    """The owned activation entrypoint (CLI `activate`). Call only after the owner's explicit Turn on was saved.
    Captures the helper's OWN processing instant at full float precision (provenance: processing clock, not the
    owner's click time), persists it with a fresh activation id, and leaves the scan reading nothing until the
    ids-only baseline (driven by next/commit) completes. Refuses when settings are not on or a state already exists."""
    _owner(path)
    if _allowed({}, load_settings()) or (settings is not None and _allowed({}, settings)):
        return {"error": "labels are not turned on by the owner; nothing activated"}
    if not _opaque(label_id): return {"error": "the owner's own Likely Scam label id is required"}
    if os.path.exists(path): return {"error": "already activated; turn off and clear state to re-activate"}
    # Sample at most once per candidate, outside the lock (an injected clock may block). This is processing
    # time, NOT click capture or the later save instant. A losing racing candidate never returns an identity.
    t = _finite(clock(), "processing clock")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with locked(path):
        if _allowed({}, load_settings()): return {"error": "labels are off; nothing activated"}
        if os.path.exists(path): return {"error": "already activated; concurrent activation kept"}
        st = new_state(t, label_id, provenance={"source": "helper_processing_clock", "precision": "float_seconds",
                          "captured": "after owner Turn on was saved in settings; before exclusive create/save",
                          "not": "owner click time; host latency is unmeasured"}, baseline="pending")
        save(path, st)
        return {"ok": True, "activation_id": st["activation_id"], "cutoff": st["activated_at"], "baseline": "pending"}
def activate(st, conn, cfg=None, max_pages=200):
    """Compatibility IN-MEMORY baseline adapter, not owner authorization. Uses the same nonce/typed page
    protocol; owned durable callers use activate_begin then run_locked. Never reads or labels."""
    cfg = {**DEFAULTS, **(cfg or {}), "baseline_pages": max_pages}; migrate(st)
    if st.get("inflight"): return False
    st["baseline"] = "pending"
    while st["baseline"] != "complete":
        a = step_next(st, {"inbox_label_scan": "on"}, cfg=cfg, driver="callable")
        if a["do"] != "baseline": return False
        try:
            result = conn.search_ids(a["args"]["query"], ["INBOX"], a["args"].get("pageToken"))
            ids, nxt = result if isinstance(result, (tuple, list)) and len(result) == 2 else (None, None)
            o = step_commit(st, "search", ids=ids, next_token=nxt, nonce=a["nonce"], cfg=cfg)
        except AuthError:
            step_commit(st, "search", auth_lost=True, nonce=a["nonce"], cfg=cfg); return False
        except ConnError as e:
            step_commit(st, "search", error=str(e), nonce=a["nonce"], cfg=cfg); return False
        if o.get("error"): return False
    return True
def resume(st): st["halted"] = None; st["consecutive_failures"] = 0
def status_line(st, settings):
    if (settings or {}).get("inbox_label_scan") != "on" or st is None: return "Likely Scam labels: Off"
    if st.get("halted"): return f"Likely Scam labels: Paused ({st['halted']}) - nothing is being labeled until you say resume"
    if st.get("baseline") != "complete": return "Likely Scam labels: Starting - marking mail already in your inbox (ids only, nothing read); not labeling yet"
    sched = (settings or {}).get("label_scan_schedule")
    if not sched: return "Likely Scam labels: Turned on but no schedule is set up yet - not running"
    if not psl_ready(): return "Likely Scam labels: On but the domain parser (tldextract) is missing, so nothing can be auto-labeled; mail goes to review"
    return f"Likely Scam labels: On ({sched}); backlog {st.get('backlog', 0)}" + ("; still listing older mail" if st.get("discovery") else "")
def main():
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd", required=True)
    for n in ("next", "begin-run"): sp.add_parser(n).add_argument("--state", required=True)
    ac = sp.add_parser("activate"); ac.add_argument("--state", required=True); ac.add_argument("--label-id", required=True)
    c = sp.add_parser("commit"); c.add_argument("--state", required=True); c.add_argument("--step", required=True, choices=["search", "read", "label"])
    c.add_argument("--ids-file"); c.add_argument("--next-token"); c.add_argument("--id"); c.add_argument("--envelope-file"); c.add_argument("--nonce")
    c.add_argument("--ok", action="store_true"); c.add_argument("--error"); c.add_argument("--auth-lost", action="store_true")
    c.add_argument("--safelist", help="extra protection only: merged on top of the canonical list, can never remove protection")
    s = sp.add_parser("status"); s.add_argument("--state", required=True); s.add_argument("--settings", required=True)
    a = ap.parse_args()
    try: _owner(a.state)
    except PermissionError as e: print(json.dumps({"error": str(e)})); sys.exit(2)
    if a.cmd == "activate":
        print(json.dumps(activate_begin(a.state, a.label_id))); return
    with locked(a.state):
        try: st = load(a.state)
        except (ValueError, TypeError, KeyError) as e:
            print(json.dumps({"error": "invalid saved scan state: " + str(e)})); return
        if st is None: print(json.dumps({"status": "not_activated"})); return
        settings = load_settings()
        if a.cmd == "status": print(status_line(st, json.load(open(a.settings)))); return
        if a.cmd == "begin-run": out = begin_run(st)
        elif a.cmd == "next": out = step_next(st, settings)   # the canonical list is re-read here before any write
        else:
            extra = json.load(open(a.safelist)) if a.safelist else None
            ids = None
            if a.ids_file:
                try: ids = json.load(open(a.ids_file))
                except (ValueError, OSError): pass  # typed unknown page, never silently an empty success
            out = step_commit(st, a.step, extra, ids=ids, next_token=a.next_token,
                              mid=a.id, envelope=json.load(open(a.envelope_file)) if a.envelope_file else None,
                              ok=a.ok, error=a.error, auth_lost=a.auth_lost, settings=settings, nonce=a.nonce)
        save(a.state, st); print(json.dumps(out))
if __name__ == "__main__": main()
