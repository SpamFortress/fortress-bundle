#!/usr/bin/env python3
"""fortress_domain.py - parse a URL or email/host WITHOUT fetching it.
Uses urllib.parse for structure and the Public Suffix List (tldextract, offline bundled snapshot) for the
registered domain. If tldextract is not installed, registered_domain() returns None (= unknown): callers must
treat unknown as "review", never guess with a last-two-labels rule.
CLI: python3 fortress_domain.py URL_OR_ADDRESS [...]  -> JSON (defanged)
"""
import sys, json, ipaddress
from urllib.parse import urlsplit
_EXTRACT = None
def _extractor():
    global _EXTRACT
    if _EXTRACT is None:
        try:
            import tldextract
            _EXTRACT = tldextract.TLDExtract(suffix_list_urls=(), cache_dir=None, include_psl_private_domains=True)  # offline snapshot only
        except Exception:
            _EXTRACT = False
    return _EXTRACT
def to_ascii(host):
    host = (host or "").strip().strip(".").lower()
    if not host: return ""
    try: return host.encode("idna").decode("ascii")
    except Exception: return host
def host_of(s):
    s = (s or "").strip()
    if "@" in s and "://" not in s and "/" not in s:          # email address: domain after LAST @
        return to_ascii(s.rsplit("@", 1)[1].strip(">").strip())
    if "://" not in s: s = "http://" + s
    try: h = urlsplit(s).hostname                               # drops userinfo (user@) and :port
    except ValueError: return ""
    return to_ascii(h or "")
def is_ip(host):
    try: ipaddress.ip_address(host.strip("[]")); return True
    except ValueError: return False
def registered_domain(host_or_url):
    h = host_of(host_or_url) if any(c in (host_or_url or "") for c in "/@:") else to_ascii(host_or_url)
    if not h or is_ip(h): return None
    ex = _extractor()
    if not ex: return None
    r = ex(h)
    if not r.suffix or not r.domain: return None
    return f"{r.domain}.{r.suffix}"   # OWNER domain: private PSL suffixes respected (scam.github.io, not github.io)
def icann_domain(host_or_url):
    """Registrable domain under ICANN suffixes only (who the registrar/registry is). For github.io tenants this is
    github.io - the HOSTING provider, not the site owner. Use registered_domain() for who controls the site."""
    h = host_of(host_or_url) if any(c in (host_or_url or "") for c in "/@:") else to_ascii(host_or_url)
    ex = _extractor()
    if not h or is_ip(h) or not ex: return None
    r = ex(h, include_psl_private_domains=False)
    return f"{r.domain}.{r.suffix}" if r.suffix and r.domain else None
def is_private_tenant(host_or_url):
    o, i = registered_domain(host_or_url), icann_domain(host_or_url)
    return bool(o and i and o != i)
def domain_matches(host, scope_domain, allow_subdomains=True):
    """Exact label-boundary match. 'chase.com.evil.io' never matches 'chase.com'."""
    h, d = to_ascii(host), to_ascii(scope_domain)
    if not h or not d: return False
    return h == d or (allow_subdomains and h.endswith("." + d))
def describe(s):
    h = host_of(s)
    return {"input_defanged": s.replace("http", "hxxp").replace(".", "[.]"), "host": h, "is_ip": is_ip(h) if h else False,
            "punycode": h.startswith("xn--") or ".xn--" in h, "registered_domain": registered_domain(h) if h else None,
            "icann_domain": icann_domain(h) if h else None, "private_tenant": is_private_tenant(h) if h else False,
            "psl_available": bool(_extractor())}
if __name__ == "__main__":
    print(json.dumps([describe(a) for a in sys.argv[1:]], indent=2))
