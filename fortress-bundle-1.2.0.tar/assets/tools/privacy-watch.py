#!/usr/bin/env python3
"""privacy-os-watcher: fetch -> normalize -> hash -> diff -> report.
Usage:
  privacy-watch.py check [--id ID ...] [--category CAT] [--catalog PATH] [--dry-run]
  privacy-watch.py list
Prints JSON: {"changed":[...], "first_seen":[...], "unchanged":n, "needs_webfetch":[...], "errors":[...]}
Never messages anyone. signin_only entries are skipped. 'webfetch' entries are tried with curl;
if text is thin/blocked they land in needs_webfetch for the agent to read via WebFetch/browser.
"""
# --- Fortress portable header (v3) ---
import os as _os, json as _j
from zoneinfo import ZoneInfo as _ZI
FORTRESS_HOME = _os.environ.get("FORTRESS_HOME")
if not FORTRESS_HOME:
    raise SystemExit("FORTRESS_HOME not set: pass this bot's own workspace (from its memory), e.g. FORTRESS_HOME=... FORTRESS_INSTANCE=... python3 tool.py")
def _check_owner():
    """Fail closed: the root must carry this bot's ownership file AND FORTRESS_INSTANCE must name that same instance."""
    try: m = _j.load(open(_os.path.join(FORTRESS_HOME, ".fortress-owner.json")))
    except Exception: raise SystemExit("FORTRESS_HOME has no Fortress ownership file: run fortress_bootstrap.py init/preflight first; refusing")
    want = _os.environ.get("FORTRESS_INSTANCE")
    if not want: raise SystemExit("FORTRESS_INSTANCE not set: pass this bot's own instance id from its memory; refusing")
    if m.get("instance_id") != want:
        raise SystemExit(f"FORTRESS_HOME belongs to Fortress instance {m.get('instance_id')}, not {want}; refusing")
_check_owner()
def _owner_tz():
    tz = _os.environ.get("FORTRESS_TZ")
    if not tz:
        try: tz = _j.load(open(_os.path.join(FORTRESS_HOME, "private", "settings.json"))).get("timezone")
        except Exception: tz = None
    if not tz:
        raise SystemExit("Owner timezone not set: run fortress_bootstrap.py init --tz <IANA zone> (ask the owner)")
    return tz
OWNER_TZ_NAME = _owner_tz()
OWNER_TZ = _ZI(OWNER_TZ_NAME)
# --- end header ---

import json, sys, os, re, hashlib, subprocess, difflib, datetime, html, argparse
BASE = os.path.join(FORTRESS_HOME, "data")
STATE = os.path.join(FORTRESS_HOME, "private", "privacy-watch")
UA = "FortressPrivacyWatch/1.2 (personal policy-change checker; honest UA)"
def fetch(url):
    # --compressed so amazon.com / gzip responses decode to text
    r = subprocess.run(["curl","-sL","--compressed","-m","30","-A",UA,"-w","\n__HTTP__%{http_code}",url],capture_output=True,text=True,errors="replace")
    body, _, code = r.stdout.rpartition("\n__HTTP__")
    return int(code or 0), body
def normalize(h):
    h = re.sub(r"(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\1>", " ", h)
    h = re.sub(r"(?i)<br\s*/?>|</(p|div|li|h\d|tr|section)>", "\n", h)
    t = html.unescape(re.sub(r"<[^>]+>", " ", h))
    lines = [re.sub(r"\s+"," ",l).strip() for l in t.splitlines()]
    # drop volatile lines (timestamps, tokens, cookie banners)
    # Trace Id / Correlation Id / request GUIDs = microsoft.com false alarms
    banner = re.compile(r"(?i)(accept (all )?cookies|cookie (settings|preferences)|we use cookies|manage cookies)")
    material = re.compile(r"(?i)(sell|sale|share|sharing|advertis|partner|third[- ]part|broker|target|profil|track)")
    lines = [l for l in lines if not (banner.search(l) and len(l) < 200 and not material.search(l))]
    drop = re.compile(r"(?i)(copyright|©|visit_id|nonce|csrf|trace\s*id|correlation\s*id|request[-_ ]?id|\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b|\b\d{10,}\b)")
    return "\n".join(l for l in lines if len(l) > 2 and not drop.search(l))
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("cmd"); ap.add_argument("--id",action="append")
    ap.add_argument("--category"); ap.add_argument("--catalog",default=f"{BASE}/privacy-catalog.json"); ap.add_argument("--dry-run",action="store_true")
    a = ap.parse_args(); cat = json.load(open(a.catalog)); os.makedirs(STATE, exist_ok=True); _sp = os.path.join(STATE, "state.json"); _st = json.load(open(_sp)) if os.path.exists(_sp) else {}
    for _e in cat.get("entries", []): _e["last_hash"] = _st.get(_e["id"], {}).get("last_hash"); _e["last_checked"] = _st.get(_e["id"], {}).get("last_checked"); snap = os.path.join(STATE,"snapshots")
    os.makedirs(os.path.join(STATE, "snapshots"), exist_ok=True); snap = os.path.join(STATE, "snapshots")
    if a.cmd == "list":
        for e in cat["entries"]: print(e["id"], e["category"], e["fetch"], e["last_checked"], e["url"])
        return
    out = {"changed":[],"first_seen":[],"unchanged":0,"needs_webfetch":[],"errors":[],"skipped_signin":0}
    now = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    for e in cat["entries"]:
        if a.id and e["id"] not in a.id: continue
        if a.category and e["category"] != a.category: continue
        if e["fetch"] == "signin_only": out["skipped_signin"] += 1; continue
        try: code, body = fetch(e["url"])
        except Exception as x: out["errors"].append({"id":e["id"],"err":str(x)}); continue
        text = normalize(body) if code == 200 else ""
        if code != 200 or len(text) < 800:
            out["needs_webfetch"].append({"id":e["id"],"url":e["url"],"http":code,"chars":len(text)}); continue
        hsh = hashlib.sha256(text.encode()).hexdigest()
        cur = os.path.join(snap, f"{e['id']}.txt")
        if e["last_hash"] is None or not os.path.exists(cur):
            out["first_seen"].append(e["id"])
        elif hsh != e["last_hash"]:
            old = open(cur).read().splitlines()
            diff = [l for l in difflib.unified_diff(old, text.splitlines(), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++","---")]
            dpath = os.path.join(snap, f"{e['id']}.{now[:10]}.diff")
            if not diff: out["unchanged"] += 1
            else:
              if not a.dry_run: open(dpath,"w").write("\n".join(diff))
              out["changed"].append({"id":e["id"],"vendor":e["vendor"],"title":e["title"],"url":e["url"],"watch_for":e["watch_for"],
                                   "diff_file":dpath,"added":sum(l.startswith('+') for l in diff),"removed":sum(l.startswith('-') for l in diff),
                                   "preview":diff[:40]})
        else: out["unchanged"] += 1
        if not a.dry_run:
            if e["last_hash"] and os.path.exists(cur) and hsh != e["last_hash"]:
                os.replace(cur, cur.replace(".txt", ".prev.txt"))
            open(cur,"w").write(text); e["last_hash"] = hsh; e["last_checked"] = now
    if not a.dry_run:
        _st.update({e["id"]: {"last_hash": e.get("last_hash"), "last_checked": e.get("last_checked")} for e in cat.get("entries", []) if e.get("last_hash")})
        _tmp = _sp + ".tmp"; json.dump(_st, open(_tmp, "w"), indent=2); os.replace(_tmp, _sp)
    if False: json.dump({e["id"]: {"last_hash": e.get("last_hash"), "last_checked": e.get("last_checked")} for e in cat.get("entries", [])}, open(_sp, "w"), indent=2)
    print(json.dumps(out, indent=2, ensure_ascii=False))
if __name__ == "__main__": main()
