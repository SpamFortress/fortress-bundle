# Email letter templates (fill brackets; owner sends)

## A. California resident — Do Not Sell or Share + delete
Subject: Request to opt out of sale/sharing and delete — [email address]

I am a California resident. Under the California Consumer Privacy Act, as amended, please (1) stop selling or sharing my personal information, including the email address [email address], and (2) delete the personal information you collected from me, and direct your service providers to do the same. I gave this address only to sign up for [purpose] on [date]. Please confirm when complete.

## B. Any US state — polite stop selling/sharing (no legal claim)
Subject: Please stop sharing my email — [email address]

I gave [email address] to [company] only for [purpose] on [date]. Please remove it from all marketing lists, do not sell, rent, or share it with any third party, and tell me whether it has already been shared and with whom. Thank you.

## C. CAN-SPAM unsubscribe (commercial email)
Subject: Unsubscribe — [email address]

Please remove [email address] from all commercial email, and do not sell or transfer it to anyone.

(Recheck after 10 US business days.)

## D. GDPR / UK GDPR Art. 21 add-on
Add to the geo-packs letter:

I object to processing for direct marketing under Article 21(2) and (3). Please also confirm whether my address was disclosed to third parties (Article 15(1)(c)).

## E. After an alias leak (pairs with signup-alias-watch)
Subject: Opt-out and stop sharing — address given only for [purpose]

I provided [alias address] to [company] solely for [purpose] on [date]. Unrelated marketing from [other brand] has arrived at that same address. Please stop selling or sharing that address, remove it from partner lists, and confirm in writing. I am also disabling the address on my side.
