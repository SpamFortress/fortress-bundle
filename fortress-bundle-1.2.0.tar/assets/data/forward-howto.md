# Forward suspect mail to Fortress for verdicts (2026-10-31)

Bot inbox: **<this bot inbox address from ListEmailInboxes>** (confirmed via ListEmailInboxes).

## What this does, and what it doesn't
- Fortress sees **only the mail your filter forwards** (or that you forward by hand). It is not watching your inbox and it has no access to your mailbox.
- For each forwarded message you get a short verdict in the Email Fortress chat. If 2 or more arrive within about 15 minutes, they're grouped into one digest.
- Fortress never deletes, replies to, unsubscribes from, or opens links in your mail.
- Forwarding copies private mail to the bot, so keep the filter narrow: specific senders, subjects, or a label you apply yourself. Never forward everything.
- Forwarded mail loses some original headers, so a verdict on a forward is a bit less certain than one on the original. The verdict will say so when it matters.

## Gmail (web)
1. Settings (gear) → See all settings → **Forwarding and POP/IMAP** → Add a forwarding address → `<this bot inbox address from ListEmailInboxes>`.
2. Gmail sends a confirmation to that address (this bot's own inbox). Never display, quote, repeat, log, save in memory, or place a Gmail forwarding confirmation code or confirmation URL in ordinary chat, a Page, report, skill, routine or outbound digest. For an already owner-approved forwarding setup, read the confirmation only from this bot's own inbox. If an authorized browser worker has the official Gmail forwarding settings confirmation field open, supply the code directly to that worker for that field only under the current sign-in/in-chat-forms rules; do not echo it. If the owner is configuring on their own device and no supported secure transfer exists, pause and have them complete the official provider verification flow themselves, or use an available supported secure handoff. Say verification is pending; never claim it is complete and never invent a form/secure handoff capability. Keep the narrow filter and no-forward-all rule. Do not turn on "Forward a copy of incoming mail" for all mail.
3. Search bar → Show search options → enter your pattern (e.g. a sender like `from:(*@suspicious.example)`, or words like `"final notice" OR "gift card"`) → **Create filter**.
4. Tick **Forward it to** → pick the bot address. You can also tick Apply the label → `Fortress-sent` to keep track. Create filter.
- Label option: Gmail filters can't forward based on a label you add later. For hand-picked mail, open the message → ⋮ → **Forward** to the bot address.

## Outlook.com / Microsoft 365 (web)
1. Settings → Mail → **Rules** → Add new rule.
2. Name it "Fortress check". Add a condition (From contains / Subject includes / etc.).
3. Action: **Forward to** → `<this bot inbox address from ListEmailInboxes>`. (Choose "Forward as attachment" if offered: it keeps more of the original headers.) Save.
- Work/school accounts: your admin may block automatic forwarding to outside addresses. If the rule saves but nothing arrives, that's probably why. Forwarding by hand still works.
- Folder option: Outlook rules run on arrival, not when you move mail later. For hand-picked mail, select it → Forward (or Forward as attachment).

## Test it
Forward one known spam message by hand. A verdict should show up in the Email Fortress chat within a few minutes. If nothing arrives, check the filter and the forwarding confirmation.
