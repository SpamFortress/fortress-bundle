# Caregiver summary template

Generated from `caregiver_state.py` `render` by `generate_template.py`; live emails are only ever that render of structured fields. Never fill these by hand. These are illustrative previews, not consent or send authority. Live sender-domain context must come from the typed source projection; unvetted labels become fixed unknown context while safe counts, reasons, receipts and steps remain. Show samples through `sample_preview`/`show_sample`, never by parsing Subject headers. Contract2 previews carry an exact question scope and frozen render context: a digest-only named confirmation cannot authorize alerts. These seven illustrative renders are unchanged; they are not host-origin/approval/send proof.

## Sample weekly digest (first email)

```
Subject: Fortress update for Alex

Hi Sam,

Alex added you (Sam) to receive View-only Fortress updates about scam activity aimed at Alex. Alex chose this and can change or stop it anytime.

Fortress update for Alex (View-only), this week:
- Reported / blocked: 3
- Unsubscribed: 1
- Held for review: 2
  - acme-offers.example.com: unknown sender
  - Unknown SMS: asked for a payment
- High-risk flags: none
- Report/opt-out receipts: 1 confirmed by the company, 1 filed
- Steps taken: a report was filed; the sender was blocked

No full messages, codes, or account details are included.

To stop these emails, reply STOP to this message.
- Fortress
```

## Sample weekly digest (later emails)

```
Subject: Fortress update for Alex

Hi Sam,

Fortress update for Alex (View-only), this week:
- Reported / blocked: 3
- Unsubscribed: 1
- Held for review: 2
  - acme-offers.example.com: unknown sender
  - Unknown SMS: asked for a payment
- High-risk flags: none
- Report/opt-out receipts: 1 confirmed by the company, 1 filed
- Steps taken: a report was filed; the sender was blocked

No full messages, codes, or account details are included.

To stop these emails, reply STOP to this message.
- Fortress
```

## Sample daily digest (first email)

```
Subject: Fortress update for Alex

Hi Sam,

Alex added you (Sam) to receive View-only Fortress updates about scam activity aimed at Alex. Alex chose this and can change or stop it anytime.

Fortress update for Alex (View-only), today:
- Reported / blocked: 3
- Unsubscribed: 1
- Held for review: 2
  - acme-offers.example.com: unknown sender
  - Unknown SMS: asked for a payment
- High-risk flags: none
- Report/opt-out receipts: 1 confirmed by the company, 1 filed
- Steps taken: a report was filed; the sender was blocked

No full messages, codes, or account details are included.

To stop these emails, reply STOP to this message.
- Fortress
```

## Sample daily digest (later emails)

```
Subject: Fortress update for Alex

Hi Sam,

Fortress update for Alex (View-only), today:
- Reported / blocked: 3
- Unsubscribed: 1
- Held for review: 2
  - acme-offers.example.com: unknown sender
  - Unknown SMS: asked for a payment
- High-risk flags: none
- Report/opt-out receipts: 1 confirmed by the company, 1 filed
- Steps taken: a report was filed; the sender was blocked

No full messages, codes, or account details are included.

To stop these emails, reply STOP to this message.
- Fortress
```

## Sample immediate digest (first email)

```
Subject: Fortress update for Alex

Hi Sam,

Alex added you (Sam) to receive View-only Fortress updates about scam activity aimed at Alex. Alex chose this and can change or stop it anytime.

Fortress update for Alex (View-only), last ~15 minutes:
- Reported / blocked: 3
- Unsubscribed: 1
- Held for review: 2
  - acme-offers.example.com: unknown sender
  - Unknown SMS: asked for a payment
- High-risk flags: none
- Report/opt-out receipts: 1 confirmed by the company, 1 filed
- Steps taken: a report was filed; the sender was blocked

No full messages, codes, or account details are included.

To stop these emails, reply STOP to this message.
- Fortress
```

## Sample immediate digest (later emails)

```
Subject: Fortress update for Alex

Hi Sam,

Fortress update for Alex (View-only), last ~15 minutes:
- Reported / blocked: 3
- Unsubscribed: 1
- Held for review: 2
  - acme-offers.example.com: unknown sender
  - Unknown SMS: asked for a payment
- High-risk flags: none
- Report/opt-out receipts: 1 confirmed by the company, 1 filed
- Steps taken: a report was filed; the sender was blocked

No full messages, codes, or account details are included.

To stop these emails, reply STOP to this message.
- Fortress
```

## Sample high-risk alert (first email)

```
Subject: Fortress heads-up for Alex

Hi Sam,

Alex added you (Sam) to receive View-only Fortress updates about scam activity aimed at Alex. Alex chose this and can change or stop it anytime.

Fortress saw a gift-card payment request pattern aimed at Alex on 2026-11-07 (sender: Unknown caller). Next step: call a number Alex already has; don't use a number from the message.

No full message text is included.

To stop these emails, reply STOP to this message.
- Fortress
```
