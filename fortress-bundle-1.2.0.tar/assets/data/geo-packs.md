# Email Fortress — geo packs v1.2 · Oct 30, 2026 PT (adds HK, MY, AE, ZA, IL, TW, TH, ID, AR/CL/CO/PE; money labels synced with data/international.json; official checkers + loss hotlines)

Use after `email-setup-first` when `identity.md` region ≠ US. Order every time: **block (provider) → report → privacy letter (user OK) → money honesty**. Not legal advice. "verify" = not loaded from the box or search-only. No invented statutes; codes match `capability-matrix.md`. Mail-provider steps: Tier 1/2 harden skills, Tier 3 `regional-mail-harden`.

## Canada (CA)
- **Block:** provider harden skill.
- **Report:** forward spam to the Spam Reporting Centre — https://www.fightspam.gc.ca/src · fraud: https://reportcyberandfraud.canada.ca/ · CAFC 1-888-495-8501 (Mon–Fri 10–4:45 ET).
- **Letter:** PIPEDA withdraw-consent + access request to the sender; OPC complaint https://www.priv.gc.ca/en/report-a-concern/
- **Money:** `none_typical` (CASL private right never in force).
- **Elder:** CAFC line above.

## United Kingdom (UK)
- **Check:** a "bank" call or email asking you to ring back → hang up and dial **159** from a different phone (Stop Scams UK; participating banks/networks).
- **Report:** forward phishing to report@phishing.gov.uk (https://www.ncsc.gov.uk/collection/phishing-scams/report-scam-email). Money lost → Report Fraud (formerly Action Fraud, renamed 4 Dec 2025) https://www.reportfraud.police.uk/ · 0300 123 2040.
- **Letter:** UK GDPR Art. 21 objection to direct marketing + Art. 17 erasure; then ICO https://ico.org.uk/make-a-complaint/
- **Money:** `limited_verify` (PECR reg. 30, proven damage only).
- **Elder:** Age UK Advice Line 0800 678 1602 — https://www.ageuk.org.uk/services/age-uk-advice-line/

## EU / EEA (EU)
- **Letter:** GDPR Art. 21 objection / Art. 15 access / Art. 17 erasure; one-month reply clock; then national DPA (list: https://edpb.europa.eu/about-edpb/about-edpb/members_en). GDPR text: https://eur-lex.europa.eu/eli/reg/2016/679/oj, or the Publications Office copy https://op.europa.eu/en/publication-detail/-/publication/3e485e15-11bd-11e6-ba9a-01aa75ed71a1/language-en if EUR-Lex shows a bot check.
- **Money:** `limited_verify` (Art. 82, proven damage).
- **Germany (DE):** Verbraucherzentrale Phishing-Radar https://www.verbraucherzentrale.de/phishing-radar (forwarding address — verify on page) · BSI https://www.bsi.bund.de/ · DPA: Land authority, or BfDI https://www.bfdi.bund.de/ · Mail: GMX / WEB.DE → `gmx-webde-mail-harden`.
- **France (FR):** Signal Spam https://www.signal-spam.fr/ · Cybermalveillance https://www.cybermalveillance.gouv.fr/ · CNIL https://www.cnil.fr/fr/plaintes · Mail: Orange → `regional-mail-harden`.
- **Spain (ES):** INCIBE 017 https://www.incibe.es/linea-de-ayuda-en-ciberseguridad · AEPD https://www.aepd.es/
- **Italy (IT):** Mail: Libero → `regional-mail-harden`. **Report:** Polizia Postale "Segnala online" https://www.commissariatodips.it/segnalazioni/segnala-online/index.html (a tip, **not** a denuncia; emergencies 112/113; formal denuncia info https://www.commissariatodips.it/special/denuncia-per-reati-telematici/index.html — verify, search only). **Letter → DPA:** Garante privacy reclamo (Art. 77 GDPR; Codice artt. 140-bis–143; model form on page; PEC to protocollo@pec.gpdp.it only from a PEC address, or raccomandata A/R to Piazza Venezia 11, 00187 Roma) https://www.garanteprivacy.it/diritti/come-agire-per-tutelare-i-tuoi-dati-personali/reclamo
- **Czechia (CZ):** Mail: Seznam / Email.cz → `regional-mail-harden`. **Spam complaint:** ÚOOÚ (unsolicited commercial messages, Act 480/2004 Sb.; sender must be under Czech law; attach the full email with headers; may take months) https://uoou.gov.cz/cinnost/obchodni-sdeleni/stiznost-na-zasilani-obchodnich-sdeleni-a-overeni-stavu · posta@uoou.gov.cz / datová schránka qkbaa2n (verify — gov portal search only). **Phishing/incident:** CSIRT.CZ https://www.csirt.cz/en/incident-reporting/how-report/ (abuse@csirt.cz or form). Money lost → Police ČR (NÚKIB is not a citizen fraud desk — verify, search only).
- **Poland (PL):** Mail: WP Poczta → `regional-mail-harden`. **Report:** CERT Polska (CSIRT NASK) — forward scam SMS free to **8080** (max 3 per 4 h), email cert@cert.pl or https://incydent.cert.pl — https://www.gov.pl/web/baza-wiedzy/dostales-niepokojacy-sms-albo-email-zglos-go-do-cert-polska-csirt-nask . **Letter → DPA:** UODO complaint (natural persons; contact the controller first) https://uodo.gov.pl/pl/501/2271 · e-Doręczenia address AE:PL-67085-31860-RWFHC-35 https://uodo.gov.pl/pl/504/2246

## Australia (AU)
- **Report:** ACMA — forward spam email **unedited** to report@submit.spam.acma.gov.au · SMS spam to **0429 999 888** · forwarding ≠ complaint; complaint form https://www.acma.gov.au/spam-complaint-form (verify — search only) · unsubscribe must be honored within **5 business days**; most political messages exempt — https://www.acma.gov.au/dealing-with-spam · Scams: Scamwatch https://www.scamwatch.gov.au/report-a-scam (000 if in danger; refers to IDCARE) · Cybercrime/losses: ReportCyber https://www.cyber.gov.au/report-and-recover/report · 1300 CYBER1 (1300 292 371). (Pages loaded via fetch Oct 27; Scamwatch re-loaded via fetch 2026-10-30; box curl times out/403 — sites block that path.)
- **Letter:** APP 7 marketing opt-out; OAIC https://www.oaic.gov.au/privacy/privacy-complaints/lodge-a-privacy-complaint-with-us
- **Money:** `limited_verify` — ordinary spam: expect none (Spam Act is regulator-only). Statutory privacy tort (since 10 Jun 2025) only for serious invasions, court path, lawyer needed. Synced with phone lane 2026-10-30.
- **Elder / ID:** IDCARE 1800 595 160 https://www.idcare.org/

## New Zealand (NZ)
- **Report:** https://www.dia.govt.nz/Spam-Report-Spam · texts 7726 https://www.7726.govt.nz/ · NCSC https://www.ncsc.govt.nz/
- **Letter:** Privacy Act 2020 access/correction; https://www.privacy.org.nz/
- **Money:** `limited_verify` (UEMA civil proceedings; rare).
- **Elder:** Netsafe 0508 638 723 https://netsafe.org.nz/

## Brazil (BR)
- **Report:** CERT.br https://www.cert.br/ · forward phishing to phishing@cais.rnp.br (RNP Catálogo de Fraudes https://catalogodefraudes.rnp.br/ — loaded Oct 27) · consumer: https://www.consumidor.gov.br/
- **Letter:** LGPD Art. 18 titular request to the company; then ANPD (Art. 18 §1; §8 also consumer bodies; ANPD now "Agência Nacional de Proteção de Dados", Lei 15.352/2026) https://www.gov.br/anpd/pt-br/canais_atendimento/cidadao-titular-de-dados/denuncia-peticao-de-titular-referente-lgpd
- **Money:** `limited_verify` (LGPD Art. 42 — controller/operator must repair patrimonial or moral damage; proven damage, court path) — law text https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm (loaded via fetch; box curl "Acesso Negado").
- **Elder:** Disque 100 https://www.gov.br/pt-br/servicos/denunciar-violacao-de-direitos-humanos

## Mexico (MX)
- **Block calls/SMS:** PROFECO REPEP https://repep.profeco.gob.mx/ — register by phone **96 28 00 00** (CDMX, Guadalajara, Monterrey) or **800 962 8000** (rest of country); Teléfono del Consumidor 55 55 68 87 22. REPEP does **not** cover banks/financial, collections, political, charities, or pollsters. Email: no REPEP equivalent — provider block.
- **Report:** Policía Cibernética (SSPC) https://reportecibernetico.sspc.gob.mx/ · 088 (verify — site JS-only / 403 to fetch).
- **Letter:** ARCO rights under the LFPDPPP (new law DOF 20-03-2025, last reform 14-11-2025); authority now Secretaría Anticorrupción y Buen Gobierno (SABG) https://www.gob.mx/buengobierno — law text https://www.diputados.gob.mx/LeyesBiblio/pdf/LFPDPPP.pdf ("Procedimiento de Protección de Derechos"). Exact reply/procedure day counts: verify before drafting. (SABG SIDEC is for public-servant complaints — don't use.)
- **Money:** `none_typical` (was `uncertain`; synced 2026-10-30 — fines go to the state; civil damages theoretical only).

## Japan (JP)
- **Report:** Dekyo illegal spam https://www.dekyo.or.jp/soudan/ihan/ · Anti-Phishing Council https://www.antiphishing.jp/
- **Letter:** APPI request; PPC https://www.ppc.go.jp/
- **Money:** `none_typical`. **Help:** consumer hotline 188.
- **Mail:** Yahoo! Mail Japan → `regional-mail-harden`.

## Singapore (SG)
- **Check:** ScamShield check https://www.scamshield.gov.sg/check-for-scams/ (loaded 2026-10-30) — an app report is **not** a police report; police e-report https://eservices1.police.gov.sg/phub/eservices/landingpage/police-report.
- **Report:** ScamShield https://www.scamshield.gov.sg/ · email guide https://guide.scamshield.gov.sg/using-scamshield/submit-a-scam-report/how-to-report-a-scam-email · helpline 1799.
- **Letter:** PDPA; PDPC https://www.pdpc.gov.sg/
- **Money:** `limited_verify` (Spam Control Act 2007 https://sso.agc.gov.sg/Act/SCA2007 — verify sections).

## South Korea (KR)
- **Report:** KISA 118 https://spam.kisa.or.kr/spam/ss/ssSpamInfo.do?mi=1025 · losses: https://ecrm.police.go.kr/ · 112.
- **Clean up:** old site accounts → 개인정보 포털 (PIPC) 본인확인 내역 조회 / 웹사이트 회원탈퇴 https://www.privacy.go.kr/front/contents/cntntsView.do?contsNo=192 (loaded 2026-10-30; replaces eprivacy.go.kr; phone/iPIN sign-in).
- **Letter:** PIPA; PIPC https://www.pipc.go.kr/
- **Money:** `limited_verify` — PIPA statutory damages (up to KRW 3M) aim at data misuse/breaches; not typical for spam (synced 2026-10-30). **Mail:** Naver / Daum → `regional-mail-harden`.

## Philippines (PH)
- **Report:** CICC hotline 1326 / report@cicc.gov.ph / eGovPH eReport (verify — cicc.gov.ph 403 + Cloudflare challenge Oct 27; numbers seen only in PNA/PIA gov-news search results).
- **Letter:** Data Privacy Act; NPC https://privacy.gov.ph/file-a-complaint-2/ · complaints@privacy.gov.ph (verify — complaint page loads but address not seen in page text Oct 27)
- **Money:** `none_typical` (was `uncertain`; synced 2026-10-30).

## India (IN)
- **Report:** money lost → **1930** first (verified via cyberpolice.nic.in CFCFRMS FAQ, search 2026-10-30), keep the SMS acknowledgement, then file at https://www.cybercrime.gov.in/ within 24 h (www host loaded 2026-10-30 retry; bare cybercrime.gov.in still times out) · **Check:** Sanchar Saathi Trusted Contact Details https://sancharsaathi.gov.in/FinancialInstitutions/fiHome.jsp (loaded 2026-10-30) · CERT-In https://www.cert-in.org.in/ · Sanchar Saathi https://sancharsaathi.gov.in/
- **Letter:** DPDP Act 2023 (https://www.meity.gov.in/data-protection-framework) — rights phasing in; verify before drafting.
- **Money:** `none_typical`.

## Hong Kong (HK)
- **Block:** provider tools. **Check:** Scameter / Scameter+ (HK Police CyberDefender — emails, URLs, numbers, accounts) https://cyberdefender.hk/en-us/scameter/ (loaded 2026-10-30) — "No record" ≠ safe.
- **Report:** Anti-Scam Helpline **18222** (24 h advice; not a crime report) https://www.adcc.gov.hk/en-hk/contact-us.html → police report (999 urgent; e-Report Centre — login with HKPF Digital Services Logon or iAM Smart, help https://www.police.gov.hk/ppp_en/13_faqs/faq_erc.html, enquiries 2860 2000; loaded 2026-10-30. Form host erc.police.gov.hk times out from the box).
- **Letter:** PDPO direct-marketing opt-out / data access (40 days); PCPD https://www.pcpd.org.hk/
- **Money:** `limited_verify` (PDPO s.66 compensation for damage; rare).

## Malaysia (MY)
- **Block:** provider tools: CelcomDigi Scam Call Protection ("Suspected Scam" label); U Mobile Scam Call Alert ("Scam Alert" label, warns but does not block) https://www.u.com.my/en/faq-page/others/scam-call-alert; Maxis network firewall (automatic; report spam to 123 with number, text and time) https://www.maxis.com.my/en/faq/manage-account/privacy/ (loaded 2026-10-30). **Check:** Semak Mule (PDRM — account, phone, company) https://semakmule.rmp.gov.my/ (loaded 2026-10-30) — "No Records Found" ≠ safe.
- **Report:** money moved → **NSRC 997** (24/7 since Mar 2026; within 24 h) https://www.malaysia.gov.my/en/topics/hotline-nsrc-997 + police report · MCMC complaints https://www.mcmc.gov.my/
- **Letter:** PDPA 2010 s.43 direct-marketing objection; JPDP https://www.pdp.gov.my/ (access reply 21 days, +14 with written notice — PDPA 2010 s.31 text loaded 2026-10-30; 2024 amendments not checked).
- **Money:** `none_typical`.

## United Arab Emirates (AE)
- **Block:** provider tools. **Report:** Dubai Police eCrime https://www.dubaipolice.gov.ae/app/services/ecrime · UAE cyber safety / eCrime https://u.ae/en/information-and-services/justice-safety-and-the-law/Safety/cyber-safety-and-digital-security (both loaded 2026-10-30; u.ae links the Dubai Police eCrime site as ecrime.ae, which times out from the box, so use the dubaipolice.gov.ae link. Other emirates: MOI UAE app eCrimes platform, Abu Dhabi Police Aman https://aman.adpolice.gov.ae/, or 999). Telemarketing calls: text DNCR to 2211 or 1012 to register; text the caller number (05XXXXXXXX) to 2211 or 1012 to report — TDRA https://tdra.gov.ae/en/consumer-tool-hub/topics/telemarketing-voice-spam (loaded 2026-10-30).
- **Letter:** PDPL request (limited; verify).
- **Money:** `none_typical`.

## South Africa (ZA)
- **Block:** provider tools; DMASA opt-out (industry, not government) https://dmasa.org/
- **Report:** losses → bank fraud line, then SAPS case at a police station (SABRIC https://www.sabric.co.za/report/ loaded 2026-10-30; saps.gov.za times out from box); Information Regulator complaints https://inforegulator.org.za/complaints/
- **Letter:** POPIA s.69 consent rule — objection / access (30 days, PAIA s.56; extension possible; no reply → Information Regulator — search-cited 2026-10-30).
- **Money:** `limited_verify` (POPIA s.99 civil damages; must prove harm).

## Israel (IL) — stub
- **Block:** provider tools. **Report / letter:** Privacy Protection Authority https://www.gov.il/en/departments/the_privacy_protection_authority (verify — 2026-10-30 retry still 403 / timeout).
- **Money:** `limited_verify` — Communications Law s.30A spam damages up to ILS 1,000 per ad message without proof of damage (s.30A(j)(1); confirmed via Supreme Court decision on supremedecisions.court.gov.il 2026-10-30 — still suggest a local lawyer).

## Taiwan (TW)
- **Block:** provider tools. **Report:** **165** anti-fraud hotline (free) https://www.npa.gov.tw/en/app/artwebsite/view?id=8035&module=artwebsite&serno=ed2427e1-de0a-4f6f-8f68-8f83b604e89b · online report https://165.npa.gov.tw/#/report/statement (still 429 to box 2026-10-30; path confirmed by NPA FAQ https://www.npa.gov.tw/ch/app/faq/view?id=2144&module=faq&serno=A1078837). Bank: 緊急止付.
- **Letter:** PDPA access/deletion request.
- **Money:** `none_typical`. (No caller-ID product named.)

## Thailand (TH) — stub
- **Block:** provider tools. **Report:** AOC **1441** (24/7; press 1 to report + suspend an account; forwards to Thai Police Online) · Thai Police Online https://www.thaipoliceonline.go.th/ (loaded 2026-10-30).
- **Letter:** PDPA objection; PDPC https://www.pdpc.or.th/ (verify — 2026-10-30 retry still 403; complaint-service.pdpc.or.th also 403).
- **Money:** `none_typical`.

## Indonesia (ID) — stub
- **Block:** provider tools. **Report:** money moved → IASC (OJK Indonesia Anti-Scam Centre) https://iasc.ojk.go.id/ + police · content: https://aduankonten.id/ (both loaded 2026-10-30). **Check:** https://cekrekening.id/ (Komdigi; loaded via fetch 2026-10-30, box curl 403).
- **Letter:** PDP Law 2022 request (verify).
- **Money:** `none_typical`.

## Argentina / Chile / Colombia / Peru (AR/CL/CO/PE)
- **AR:** Block calls → Registro No Llame https://nollame.aaip.gob.ar/ · AAIP https://www.argentina.gob.ar/aaip (loaded 2026-10-30). Letter: Ley 25.326 access/deletion.
- **CL:** SERNAC No Molestar (ads/promos; not collections) https://www.chileatiende.gob.cl/fichas/28043-no-molestar-solicitud-para-no-recibir-envios-publicitarios-masivos (official ficha, loaded 2026-10-30) → request in SERNAC Portal del Consumidor (sernac.cl still times out from box; https://www.sernac.cl/portal/617/w3-article-9184.html).
- **CO:** CRC Registro de Números Excluidos (SMS, web messaging, email, calls) https://www.tramitescrcom.gov.co/tramites/publico/rne/terminosRNE.xhtml (loaded 2026-10-30) · complaints SIC https://www.sic.gov.co/ (01 8000 910165).
- **PE:** no registry needed — spam calls/messages without consent are banned (Ley 32323); complain via Indecopi Reclama Virtual https://enlinea.indecopi.gob.pe/reclamavirtual/ (gob.pe Indecopi notice loaded 2026-10-30) · Indecopi https://www.gob.pe/indecopi · ANPD https://www.gob.pe/anpd (loaded 2026-10-30).
- **Money:** `none_typical` (all four).

## WhatsApp / Telegram (all non-US)
Screenshot the chat with the number or @name visible, then use the app's own Report (also blocks). Never forward the scam to friends. Log it in the evidence log with any local complaint ID.

## China (CN) — limited
- Provider steps only: QQ Mail / 163 NetEase → `regional-mail-harden`. No regulator path verified; coaching from outside CN is limited.

## Russia / CIS — optional, limited
- Provider steps only: Mail.ru / Yandex → `regional-mail-harden`. No regulator or letter path offered.

## Tier 3 regional mail providers (picker → `regional-mail-harden`)
Orange (FR) · Yahoo! Mail Japan (JP) · Naver + Daum (KR) · QQ + 163 (CN) · Mail.ru + Yandex (RU/CIS) · Libero (IT) · Seznam (CZ) · WP Poczta (PL) · Fastmail · Tuta. Official help links live in that skill; 163's antispam page returned 500 (verify).
