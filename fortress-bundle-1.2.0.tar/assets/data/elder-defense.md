# Elder / high-risk defense — checklist (blank · Oct 27, 2026)

Optional. Loads the **elder-gift-card-crypto-pack** skill. Same checklist in $FORTRESS_HOME/data/elder-defense.md. Fill only with the owner's OK — no personal details required to use the pack.

## Optional age band (band only — never date of birth)
- [ ] ☐ 60–79  ☐ 80+  ☐ skip / prefer not to say
  - If 80+: prioritize phone harden first (carrier screening, Silence Unknown Callers) — FTC: phone has the highest median loss for that age.

## Habits (Y / N / not yet)
- [ ] Family safe-word exists: ☐ Y ☐ N ☐ not yet — **presence only. The word itself is never stored, typed in chat, or posted.**
- [ ] Known official callback habit: owner calls back only on numbers they already have (card back, statement, official app): ☐ Y ☐ N ☐ not yet
- [ ] "Gift cards / crypto / wire / cash courier = stop and call someone" rule agreed: ☐ Y ☐ N
- [ ] Owner knows remote-access requests ("let me into your computer") = hang up: ☐ Y ☐ N
- [ ] Owner knows "we can get your money back for a fee" = recovery scam: ☐ Y ☐ N
- [ ] Trusted person to call before any unusual payment: ☐ named (name kept by owner, not here) ☐ none
- [ ] Caregiver sharing (Caregiver View, **caregiver-view-act**): ☐ off (default) ☐ View-only (default when on) — View and Act is later opt-in, not remote control
- [ ] Instant high-risk alerts to caregiver: ☐ off (default) ☐ on
- [ ] Email lane: high-risk patterns badged + logged (`email-paste-verdict`): ☐ on
- [ ] Phone/SMS lane parity (`spam-evidence-log`): ☐ on
- [ ] Voice-clone hygiene reviewed (`voice-clone-and-ai-scam-defense`): ☐ Y ☐ N
- [ ] Knows report-within-hours after a loss (bank → IC3 → FTC): ☐ Y ☐ N

## Never stored here
Safe-word · passwords · OTP/codes · PINs · SSN · Medicare number · card/bank numbers · seed phrases · date of birth.

## Review
Last reviewed (PT): ______
