# New-sender screener (coach + bot-side rule)

## Honest framing (say once)
Most mail apps have no true "unknown sender screen" for email. We use each app's sorting and spam tools, plus a bot-side check on mail you forward, paste, or (only if opted in) let us scan.

**Apple Mail ≠ Messages.** "Filter Unknown Senders" / "Screen Unknown Senders" is a **Messages** (texts) setting. It does nothing for Mail. Never coach it for email. For texts → the phone lane (`phone-setup-first`).

## Provider coaching (one step per message)
- **Apple Mail / iCloud:** VIP for known people · Categories (Primary vs Promotions) for sorting · **Move to Junk** to train · iCloud.com Mail rules for sorting known senders into folders. No unknown-sender screen exists.
- **Gmail:** Promotions tab + **Report spam** for training. A "from:(-known)" filter isn't practical; don't build one. Calendar invites from strangers: "Only if the sender is known" (`gmail-mail-harden`).
- **Outlook:** Focused Inbox (Focused / Other) + Report junk + Safe senders list (`outlook-mail-harden`).
- **Proton:** spam/block lists + Allow list (`proton-mail-harden`).
- **Yahoo / AOL / Zoho / GMX / regional:** that provider's harden skill (block, Mark as spam, allow lists).
- Never suggest a third-party "screener" app that needs full inbox access.

## Bot-side rule: held for review
Applies to mail the bot actually sees: forwards to the bot spam inbox, pastes, screenshots, or connector items only under `$FORTRESS_HOME/private/settings.json` opt-in.
1. **Safelist match is not a pass.** An exact match with unknown or failed trusted authentication → review, no automatic hold/flag/move, and no reassurance; an authenticated match is protected from automatic actions, but its request can still be a scam. Security/sign-in/reset wording from any sender is never auto-actioned. (`protected-senders`)
2. **First-seen domain:** the From domain (and real link host) has no prior row in `$FORTRESS_HOME/private/email/evidence/index.json` or receipts, and isn't safelisted.
3. **Plus lure wording** (any of): reward / prize / free gift / "you've been selected" · survey / "quick feedback for $" · gift card · urgency ("final notice", "within 24 hours", "account suspended") · unexpected invoice / renewal / "call to cancel".
4. Both 2 and 3 → verdict card **`Suspicious` · held for review**, via `email-paste-verdict` formatting (badge → one-line advice → Why → buttons). Run `$FORTRESS_HOME/tools/enrich-domain.py` for domain age (one Why line).
5. Buttons: **Junk it** (primary, coached in their app) · Looks fine, keep · Not sure, tell me more. Never auto-delete, block, report, or unsubscribe.
6. Gift card / crypto / wire / remote access / family emergency → `elder-gift-card-crypto-pack` (high-risk path; caregiver instant alert only if set up via `caregiver-view-act`).
7. Brand on `$FORTRESS_HOME/private/breach-watch.json` → firmer, per `hibp-breach-watch`.
8. Rotating-sender campaign (same lure, new domain each time) → note `likely same campaign`; Move to Junk on every copy is the main signal (later-build notes (d)).
9. "Looks fine, keep" → note the domain as seen (evidence row `verdict: Looks safe`). Don't add it to the safelist unless the owner asks (`protected-senders`).

## Cold-email / sales outreach (light)
A real person pitching (no lure wording) → not held. Coach: Junk or block that sender, or for business addresses an auto-reply/filter rule they write themselves. Never send replies for them.

## Privacy
Read sender, subject, link hosts, and unsubscribe links only. No bodies are stored beyond the one-line quoted Why.
