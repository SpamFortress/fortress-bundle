# GMX + WEB.DE harden (Tier 2)

GMX and WEB.DE run the same United Internet platform; WEB.DE help is German-only. Steps verified from the box Oct 27, 2026. Answer in the user's language; quote German menu names for WEB.DE. One step per message; receipts; never auto-delete.

## GMX (English help)
1. **Spam / Not Spam** — click Spam on undetected junk; Not Spam to rescue. Trains the personal filter; external content in spam isn't shown (tracker-safe).
   https://support.gmx.com/email/spam-and-viruses/spam-protection.html
2. **Allowlist / Blocklist** — Email → Settings → Mail Security. Add domains (e.g. `domain.com`) for rotating newsletter senders. Allowlist = the user's named protected senders (or save them in Contacts). Filter rules run before these lists.
   https://support.gmx.com/email/spam-and-viruses/allowlist-blocklist.html
3. **Fake GMX mail** — real GMX writes from `support@corp.gmx.com` / `service@corp.gmx.com`. Anything else claiming "GMX invoice / account deactivation" → mark spam; report via the Postmaster contact form / Report Phishing button described on the page.
   https://support.gmx.com/email/spam-and-viruses/fake-receipts.html

## WEB.DE (German help)
1. **Spam / Kein Spam** — grey bar above the open email → Spam (sender goes to the Sperrliste); envelope-with-tick = Kein Spam (sender goes to the Erwünscht-Liste).
   https://hilfe.web.de/email/spam-und-viren/spamschutz.html
2. **Sperrliste / Erwünscht-Liste** — initials icon → E-Mail-Einstellungen → Sicherheit → Sperrliste → enter address/domain → Speichern. Erwünscht-Liste for protected senders (up to 5,000 entries).
   https://hilfe.web.de/email/spam-und-viren/sperrliste-verwalten.html · https://hilfe.web.de/email/spam-und-viren/sperrlisten.html
3. Subscribed newsletters can't be blocked via Sperrliste — use the Abmelden link (real newsletters only).

## Then
protected-senders → identity + who-sold tip. Geo: Germany → `$FORTRESS_HOME/data/geo-packs.md` (DE: BfDI / state DPA, BSI, Verbraucherzentrale Phishing-Radar).
