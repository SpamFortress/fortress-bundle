# Elder gift-card & crypto pack

One calm card for high-risk money scams on **phone, SMS, and email**. Shared by Phone Spam Fortress and Email Fortress. Defensive hygiene, not a guarantee. Pair with `voice-clone-and-ai-scam-defense` and `email-paste-verdict`. Checklist: `$FORTRESS_HOME/data/elder-defense.md`. Caregiver: `the caregiver-view-act state ($FORTRESS_HOME/private/caregiver/state.json)`.

## 1. Patterns — high risk when pressure/urgency + any of:
| Pattern | What it sounds like |
|---|---|
| **Gift card** | Pay a fine/bill with Apple, Google Play, Steam, Visa/Vanilla — read the numbers |
| **Crypto / crypto ATM** | Move savings to a "safe account" via Bitcoin ATM, QR, crypto app |
| **Wire / bank transfer** | Wire today or the account is frozen |
| **Cash courier / mail cash** | Courier will pick up cash; cash in a box |
| **Grandparent / family emergency** | "It's me — jail/hospital, don't tell Mom" (voice may be AI-cloned) |
| **Government imposter** | IRS / SSA / Medicare needs payment or your number is suspended |
| **Tech-support / remote access** | PC hacked; install this app; type a refund amount |
| **Bank callback text** | Card locked — reply YES / call this number |
| **Romance / friend-online payment** | Never met; needs money for travel/customs/medical/investment |
| **Recovery scam** | "We can get your money back" for a fee / fake law firm or agency after a prior loss |
| **Image / "I recorded you" blackmail** | "Pay or I send your photos/chat to your family" — often after an online romance or a "wrong number" text that moved to Telegram/WhatsApp → **don't pay, don't reply, screenshot the threat, report to FTC (reportfraud.ftc.gov) and IC3 (ic3.gov); never pay a paid "removal" firm** |
| **Off-platform push** | "Text me on Telegram/WhatsApp/Signal", a `t.me`/`wa.me` link or QR — high risk; don't open |
| **"Your money is in danger" move** | Government/bank says move savings now to protect it |

## 2. Coach (calm, one step)
1. **Stop.** Don't pay, don't read codes, don't install, don't grant remote access.
2. **Hang up / don't tap / don't reply.**
3. **Call back only on a number you already have** (card back, official app, saved contact).
4. **Ask for the family safe word** if they have one (see §2b) — never store the word itself.
5. **Tell someone you trust** before any money moves.
6. **If money already moved** — gift-card company / bank / ATM operator using numbers you already have; keep receipts; then report. **Never promise money back.** Anyone offering recovery for a fee is another scam.

## 2b. Family safe word + live-call script
**Safe word (coach only).** Help the household pick a secret word or challenge question together, in person — not by text/email, nothing posted online. FBI tip: "Create a secret word or phrase with your family to verify their identity" (https://www.ic3.gov/PSA/2024/PSA241203). **Never ask for, accept, or store the word** — only a tick in `$FORTRESS_HOME/private/identity.md` → `- [x] Family safe word set (YYYY-MM-DD)`. If typed here: "Please don't send it — I've ignored it; consider a new one." Full coach: `voice-clone-and-ai-scam-defense`.

**Widget offer** after any family-emergency / grandparent verdict or caregiver setup: **Set a family safe word reminder** · **Already have one** · **Skip for now** (coach only; reminder text never contains the word; parent creates any reminder routine).

**Live-call script** (print large; keep by the phone):
1. "I'll hang up and call you right back." Then hang up — even if the voice sounds exactly right.
2. Call the real number you already have for them. No answer? Call another relative or friend.
3. Still on the line? Ask for the safe word. Don't give hints.
4. Wrong word, refuses, "no time," or more pressure → hang up.
5. Never pay by gift card, crypto, wire, or cash courier because of a call.
6. Tell someone you trust now; report at reportfraud.ftc.gov (and ic3.gov if money moved).
Basis: FTC "Don't trust the voice… Use a phone number you know is theirs" (https://consumer.ftc.gov/consumer-alerts/2023/03/scammers-use-ai-enhance-their-family-emergency-schemes) and FBI PSA I-120324-PSA.

## 3. After any logged loss — report within hours
1. Call the bank/card issuer (number on the card).
2. File https://www.ic3.gov/ (FBI) — fast reports sometimes help freeze funds.
3. File https://reportfraud.ftc.gov/
4. Texts → 7726. Local police if a courier is coming or danger.
5. National Elder Fraud Hotline **833-372-8311** (60+); AARP Fraud Watch **877-908-3360**.

## 4. US report ladder (also when no loss yet)
FTC ReportFraud · IC3 · Elder Fraud Hotline · AARP · 7726 · 911 if in danger.

## 5. International
Use `$FORTRESS_HOME/data/geo-packs.md` — do not invent numbers.

## 6. Caregiver alerts (consent ON only)
Calm, short, no scare: gift-card ask, Medicare imposter, remote-access, fake grandchild. Never ALL CAPS or blame.

## 7. Bot actions
Badge Scam/Suspicious; tag `elder_high_risk`; log evidence; never auto-delete/report/send. Draft reports on request.

## 8. Limits
Never ask seed phrases, OTPs, passwords, SSN, Medicare number, card numbers, or the safe-word. Cannot reverse crypto/wire or clean a PC. Never promise refunds.

## Recovery after a loss + impersonation law (shared with Phone Fortress, added 2026-10-27)
- If money or codes already went: load **after-click-loss-recovery** (ordered card by payment type: Reg E debit/bank claim, credit card dispute, wire recall within 72h, gift card company + receipt, crypto IC3/Chainabuse; IdentityTheft.gov). Draft-when-ready; owner sends.
- Quote for elders: "No real government agency or company will tell you to move your money to 'protect it,' or to pay with gift cards, crypto, or a wire." FTC gift card guidance: https://consumer.ftc.gov/articles/avoiding-and-reporting-gift-card-scams
- **FTC Impersonation Rule, 16 CFR Part 461**: impersonating a government agency (461.2) or a business (461.3) is illegal; name it in FTC report text: https://www.ecfr.gov/current/title-16/chapter-I/subchapter-D/part-461
- **Reg E (12 CFR 1005.6)** for debit/bank transfers: report fast; statement items within 60 days. https://www.consumerfinance.gov/rules-policy/regulations/1005/6/
- Wire/closing scams: call your bank from the number on its site or card right away and ask for a wire recall (see **after-click-loss-recovery**). "Recovery" callers after a loss are a second scam: never pay them.
