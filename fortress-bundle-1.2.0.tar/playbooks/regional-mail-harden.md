# Regional + niche mail harden (Tier 3 stubs)

## Rule
Coach **only** Report/Spam, Block, and Allow steps the provider's own help page documents (links below, status-checked from the box Oct 27, 2026). Quote menu names in the provider's language with a plain-English gloss. If a step isn't on the page, say "check your provider's help page" and link it — never invent menus. Regulator/report paths: `$FORTRESS_HOME/data/geo-packs.md` for the user's country. Ask iPhone / Android / computer when menus may differ.

## Providers
| Provider | Spam / report | Block | Allow / rescue | Official help |
|---|---|---|---|---|
| **Orange Mail** (FR) | Select → « Spam »; phishing can be reported to Orange (see page) | « liste rouge » via Paramètres (see page) | Move back from Indésirables | https://assistance.orange.fr/ordinateurs-peripheriques/installer-et-utiliser/l-utilisation-du-mail-et-services-associes/mail-orange/recevoir-et-gerer-les-emails/mail-orange-signaler-un-email-comme-spam_206455-750281 |
| **Yahoo! Mail Japan** (JP) | 迷惑メール報告 (report spam) | 受信拒否 list | 迷惑メールではないと報告 | https://mail.yahoo.co.jp/antispam/ · https://mail.yahoo.co.jp/antispam/tools.html |
| **Naver Mail** (KR) | 스팸 신고 | 수신 차단 | 수신 허용 | https://help.naver.com/service/30029/contents/21323?lang=ko&osType=PC |
| **Daum Mail** (KR) | 스팸처리 | 환경설정 → 스팸관리 | same page | https://cs.daum.net/faq/service/43/category/40626/detail/37504 |
| **QQ Mail** (CN) | 举报 | 拒收 / 黑名单 | 白名单 | https://help.mail.qq.com/detail/0/1040 |
| **163 / NetEase** (CN) | 举报垃圾邮件 (verify) | 拒收 → 黑名单 | 白名单 | https://help.mail.163.com/ |
| **Mail.ru / VK Почта** (RU/CIS) | «Спам» | filter or block per help | Move out of Спам | https://help.mail.ru/mail/faq/letters/block-emails/ |
| **Yandex Mail** (RU/CIS) | «Это спам!» | Чёрный список | Белый список | https://yandex.ru/support/yandex-360/customers/mail/ru/web/spam |
| **Libero Mail** (IT) | Spam | Blocca mittente | Sblocca | https://aiuto.libero.it/articolo/sicurezza/blocca-mittente-bloccare-e-sbloccare-mittenti-indesiderati/ |
| **Seznam / Email.cz** (CZ) | Move to Spam | Blokované adresy | Move out of Spam | https://o-seznam.cz/napoveda/email/zasady-bezpecnosti/nevyzadana-posta-spam/ |
| **WP Poczta** (PL) | «Zgłoś spam» | Reguły → Zablokowani | — | https://pomoc.wp.pl/czy-to-na-pewno-spam |
| **Fastmail** | Report spam / Not spam | Blocked senders (blocked → Trash — never block protected) | Not spam | https://www.fastmail.help/hc/en-us/articles/1500000278142-Improving-spam-protection |
| **Tuta** | Report spam / phishing | Spam rules (avoid Discard — silent) | Not Spam rule | https://tuta.com/support |

## Honesty
- **China (QQ, 163):** coaching from outside China is limited. Offer the link + generic Report/Block.
- **Russia/CIS:** provider steps only; no invented regulator payday.
- Translate menu names; never invent a label that isn't on the page.

## Clients, not mailboxes
Samsung Email, Thunderbird, Spark, Apple Mail with a Gmail account, etc. are **apps**. Harden the **underlying account** with that provider's skill. Client Junk often doesn't train the provider filter — report in the provider's own web/app when possible.

## Then
protected-senders → identity + who-sold tip → logging.
