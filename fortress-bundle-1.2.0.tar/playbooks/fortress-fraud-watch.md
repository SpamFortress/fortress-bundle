# Fortress fraud watch

Quiet weekday leads for Phone + Email Fortress. Surface **Be advised** only for material owner-relevant risk. Fortress verifies; owner never chases official pages.

**Local catalog:** $FORTRESS_HOME/data/fraud-watch-allowlist.json on the owner’s own computer. Core official pages: consumer.ftc.gov/consumer-alerts; fcc.gov/news-events/headlines; irs.gov/newsroom; ssa.gov/scam; cisa.gov/news-events/cybersecurity-advisories; ic3.gov/PSA; fcc.gov/consumers/guides/stop-unwanted-robocalls-and-texts; aarp.org/money/scams-fraud. Public early signals: FCC, ConsumerFTC, IRSnews, SocialSecurity, FBI, CISAgov, haveibeenpwned plus locally relevant official state/regional accounts. Never point an importer at publisher private paths; catalog copy is separate from private logs. No World Monitor.

Not legal advice. Factual, protective, short. No scare framing or empty daily digests.

## Quiet rules
- Stay silent when nothing material. Fit owner OS, carrier, mailbox, state/country, elder mode; skip unrelated waves.
- One alert at a time; group related extras. Got it removes banner; Notes kept; auto-clear about 7 days.
- Idle strip on available Pages: `Quiet — weekday fraud watch is on. A yellow or red bar appears here only when something hits your lanes.`
- Active strip: yellow for Leading/Context/advisory; red for serious money/account takeover or Confirmed wave. One chat ping per alert, not each run.

## Lanes
Phone: calls/texts/SIM/robocalls. Email: phishing/breach/mailbox. Shared: tax, elder gift cards, crypto, family emergencies, SSA/Medicare, voice clones. Paired: Phone owns Shared, Email skips duplicate; alone each owns lane plus Shared.

## Expanded coverage v2
Read version 3+ catalog (about 16–24 lane handles). Local/regional/scam-wave sources are Leading until Confirmed. Core official pages plus catalog `official_confirm_primary`/`official_confirm_hints`; non-US `non_us_stub.regions` official alert/checker pages and loss-first local hotline. Do not clone foreign scam databases into confirmed fact. Keep US and non-US legal/regulatory framing separate. Optional red check OFF. Opt in only for ~1–2h after fixed core, serious money/account takeover/gift-card/SIM checks; never replaces fixed morning.

## Lead to Confirmed
1. **Leading**: multiple credible relevant signals or official account posts; say unconfirmed, keep checking officials.
2. **Confirmed**: official agency/company security/regional checker agrees; include actual checked URL.
3. **Context**: official disagreement/nuance, visible with what it adds.
4. **Drop/replace**: social wrong and officials absent. Remove wrong claim; keep independent stood-alone official fact if there is one. Random single post never makes a banner.

## Routine
1. Load skill and actual local catalog. Read owner residence rather than guessing.
2. Fetch official primary pages for material last-24h items. Optional public X only early signal; honor read-only X guides and tools.
3. US topic queries need US agency/language/geographic anchors; exclude unrelated countries. One handle one lane.
4. Nothing relevant → collapsed Notes only, no chat. Material hits → safe action, source, status; banner and one chat ping. Later runs refine/upgrade/drop.
5. Custom schedules each check; adaptive timing only by explicit opt-in, no missed material alerts. Pair does not double-ping.

## Hooks
Money/IDs clicked → after-click-loss-recovery; gift cards/crypto/family emergency → elder-gift-card-crypto-pack; voice cloning → voice-clone-and-ai-scam-defense; mail takeover -> mailbox checklist. Inspect on demand, never new daily scanning loops. No automatic regulator filing, open-ended world news, follow-on-X or streaming.
