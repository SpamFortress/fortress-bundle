# Proton Mail harden

## Purpose
Coach Proton's own tools one step at a time before bot logging. Steps from Proton Support (verified from the box Oct 27, 2026). Proton already blocks trackers by default; most of the work is Report phishing + allow/block lists.

## Standing rules
- One step per message; receipts; never auto-delete; phishing → Report phishing, never unsubscribe.
- Real Proton mail carries the **Official** badge; anything claiming to be Proton without it is phishing → Report phishing. The badge applies to Proton only. Other brands never get it, so its absence on a bank email means nothing either way.
- Privacy line once.

## Steps (in order)
1. **Report phishing** — open message → More (…) → Report phishing → Confirm (sends message + headers to Proton's security team). Same on iOS/Android.
   https://proton.me/support/report-phishing
2. **Spam, Block and Allow lists** — mark spam to train; Block list for repeat senders; **Allow list** for the user's named protected senders.
   https://proton.me/support/spam-filtering · https://proton.me/support/block-sender
3. **Link confirmation** — keep it on: Proton shows the real destination before opening a link. Coach: read the domain in the pop-up; if it isn't the brand's real domain, cancel.
   https://proton.me/support/link-confirmation
4. **Tracker protection** — confirm "Block email tracking" is on (spy-pixel removal, IP hidden; web also strips known link trackers).
   https://proton.me/support/email-tracker-protection
5. **Ask before images** (optional, belt-and-braces) — Settings → All settings → Proton Mail → Email privacy → turn off Auto show remote images; then Load per message. Per-platform setting (not synced).
   https://proton.me/support/protonmail-images
6. Hand off to `protected-senders`, identity + who-sold tip (Proton/SimpleLogin aliases per company — verify current plan limits on Proton Support before promising).

## Receipts
Each action → receipt: what, where (Proton), when (owner timezone), what happens next.
