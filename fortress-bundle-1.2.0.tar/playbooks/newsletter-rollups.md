# Newsletter rollups

Quiet coaching to clear real newsletters in batches, using the mail app's own tools. This is for mail the owner **knowingly signed up for**. Spam and phishing go to the provider harden skill and `email-paste-verdict`, not here.

## Gate (check first, in order)
1. Provider harden done? If not → `email-setup-first` / the provider's harden skill first.
2. Protected senders seeded (`protected-senders`, `$FORTRESS_HOME/private/safelist.json`)? If not → do that first. Banks, 2FA, shipping, pharmacy, government, and family mail are never batch-moved or unsubscribed.
3. Say once: "I read sender, subject and unsubscribe links only. I never sell or share your mail."

## Hard rules
- One primary action per message. Wait for "done" before the next step.
- Never auto-unsubscribe, delete, block, or move. The owner taps.
- **Never unsubscribe inside phishing or a spoofed lure.** Unsubscribe only when the From domain matches a brand they knowingly joined. Anything doubtful → Junk/Report only (`email-paste-verdict`).
- Prefer "move" or "keep latest" over Delete, so nothing is lost.
- Skip anything in `$FORTRESS_HOME/private/safelist.json`.

## Provider steps (pick the one they use)
**Gmail** (`gmail-mail-harden` holds exact paths)
1. **Manage subscriptions**: web left menu → More → Manage subscriptions; app Menu → Manage subscriptions. Rolling out gradually; it may not appear yet. Sorted by how much each sender mails, so start at the top.
2. Or the **Unsubscribe** link next to the sender name at the top of a message (Gmail's own header link, not one inside the body).
3. Expect a few days for it to stop. Gmail's one-click is a sender guideline (about 48h), not law. Blocking does not unsubscribe.

**Apple Mail / iCloud** (`apple-mail-harden`)
1. **Categories** (Primary / Transactions / Updates / Promotions) keep promos out of Primary. That's sorting only, not a spam filter.
2. Real newsletter → the **Unsubscribe** banner Mail shows at the top of the message.
3. Unknown or doubtful → **Move to Junk**. Never tap links inside it.
4. Apple Mail has no unknown-sender screen ("Filter Unknown Senders" is a Messages setting for texts), so don't offer it.

**Outlook** (`outlook-mail-harden`)
1. **Sweep**: select a message from the list sender → Sweep → "keep only the latest" or "move all to a folder", once or for all future mail. Coach move/keep-latest before Delete.
2. Real list → the Unsubscribe option Outlook shows above the message.

**Yahoo / AOL / others**: use that harden skill's Subscriptions view / Unsubscribe step. Regional providers → `regional-mail-harden`.

## Batch pattern (calm)
- Ask: "Top 5 senders first, or just the noisiest one?" Default: one sender per message.
- After each unsubscribe, offer to log a receipt (`email-report-receipts`, type Unsubscribe, `one_click: true` when Gmail one-click). That starts the clocks in `enforced-unsub-recheck`.
- After 5 or so: "Good stopping point. Want to keep going another day?"

## Optional weekly rollup message
Only if the owner chose **Chatty** (`fortress-voice`) or asked for it in their own words. Otherwise stay quiet; status Page counts only.
- One short message: "This week: <n> unsubscribes waiting, <n> honored, <n> repeats. Next suggested: <one sender>." One primary action.
- Repeats after an unsubscribe go to `enforced-unsub-recheck`, not here.
- The parent owns any routine. This skill only suggests it.

## Related
`enforced-unsub-recheck` · `email-report-receipts` · `who-sold-my-address` / `signup-alias-watch` (newsletter you never joined arriving at an alias) · `do-not-sell-email`.
