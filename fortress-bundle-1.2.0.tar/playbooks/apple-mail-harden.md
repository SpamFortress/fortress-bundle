# Apple Mail harden

## Purpose
Coach the user through Apple's own Mail and iCloud tools, one step at a time, before any bot logging. Calm, short, no scareware. Apple stays the filter; we coach and keep receipts.

## Standing rules
- Accuracy first: steps below come from Apple Support (links at the end). If a menu name differs on the user's version, say so and point to the Apple page rather than guess.
- Filter Unknown Senders / Screen Unknown Senders is a Messages (texts) feature, not a Mail feature. Never offer it for email. Mail's sorting is Categories (Primary, Transactions, Updates, Promotions), which is not a spam filter.
- Never auto-delete. Note that on iOS 26 / macOS 26 mail from a blocked sender goes to Trash, so suggest blocking only true junk, never a bank, 2FA, shipping, pharmacy, gov, or family sender (see protected-senders).
- One step per message; confirm, then offer the next. Log a receipt for each report or block (email-report-receipts).
- Privacy line: "I read sender, subject and unsubscribe links only. I never sell or share your mail."
- Closest thing Apple Mail has to a screener: put real people in **VIP**, keep Categories on so Primary stays short, and use Move to Junk on every stranger lure. For an elder household, add the habit "first email from someone new that wants money or a code → show the bot or family first."
- Apple Mail may show a brand logo (BIMI) for some senders. A logo means the domain is real, not that the request is safe; a missing logo means nothing.

## Step 1 — Protect Mail Activity (Mail Privacy Protection)
Hides the user's IP address and stops senders from seeing when mail is opened (tracking pixels). It does not cover links or attachments.
- iPhone / iPad: Settings > Apps > Mail > Privacy Protection > turn on Protect Mail Activity. (Needs Limit IP Address Tracking on for the Wi-Fi network: Settings > Wi-Fi > info next to the network.)
- Mac: Mail > Settings > Privacy > select Protect Mail Activity. If they keep it off, they can instead choose Hide IP Address and Block All Remote Content separately.
- Protect Mail Activity covers opens and IP only. Tracking **links** still report a click, so the habit stays "don't click links in marketing you didn't ask for; type the site yourself."

## Step 2 — Report Junk vs Unsubscribe (decision tree)
1. Is it from a real brand they knowingly signed up for, and the From domain matches that brand? Use Mail's Unsubscribe banner (or the brand's own preference page). Expect a few days. Log a receipt.
2. Unknown sender, spoofed brand, prize / survey / reward, urgency, gift card, crypto, or a mismatched domain? Move to Junk only. Never tap Unsubscribe or any link inside it. Optional: forward obvious phishing that impersonates Apple to reportphishing@apple.com.
3. The same junk keeps coming from one address? Block that sender (Step 3).
4. Real mail landed in Junk? Move it back to Inbox (marks it not junk) and add the sender to protected senders and VIP if important.
- Move to Junk: use Mail's Move to Junk / Junk action on the message (iPhone message actions or swipe menu; Mac toolbar Junk button). If the label differs on their version, point to the Apple guide instead of guessing.

## Step 3 — Block a sender
- iPhone (Mail): open a message from the sender, tap their address, View Contact Card, then Block this Contact.
- Mac (Mail): select the message, click the arrow next to the sender's name, then Block this Contact.
- iOS 26 / macOS 26 central list: Settings > Privacy & Security > Blocked Contacts (Mac: System Settings > Privacy & Security > Blocked Contacts). Blocking applies on every device signed in to the same Apple Account; blocked mail goes to Trash.
- Older versions manage blocks in Settings > Mail > Blocked (iPhone) or Mail > Settings > Junk Mail > Blocked (Mac).
- A VIP must be removed from VIP before it can be blocked.
- Rotating From addresses make one-address blocks weak; say so calmly and keep Move to Junk as the main signal.

## Step 4 — VIP for must-see senders
Add family, caregiver, and key real senders as VIP so they appear with a VIP flag and in the VIP mailbox. Pair with protected-senders ($FORTRESS_HOME/private/safelist.json). VIP is a highlight, not a spam bypass.

## Step 5 — Hide My Email (iCloud+)
Unique random addresses that forward to the user's inbox; best tool for who-sold-my-address.
- Sign in with Apple: choose Hide My Email when creating an account; addresses end in @privaterelay.appleid.com or @private.icloud.com.
- See them: iPhone Settings > [name] > Sign in with Apple, or Settings > [name] > iCloud > Hide My Email (iCloud+). Mac: System Settings > [name] > iCloud > Hide My Email.
- Mac Mail can send from Hide My Email: hover the From field, choose Hide My Email (one recipient per address).
- When they make one, add a row to $FORTRESS_HOME/private/identity.md alias map and $FORTRESS_HOME/private/who-sold/map.json aliases[] with the company it was given to.

## Output
- One calm confirm per step ("Protect Mail Activity is on. Next: one-tap Junk vs Unsubscribe?").
- Update status Page Setup item "Mail app tightened" when Steps 1–3 are confirmed by the user.

## Sources (Apple Support)
- Hide My Email with Sign in with Apple: https://support.apple.com/en-us/105078
- Protect email privacy in Mail on Mac: https://support.apple.com/guide/mail/protect-email-privacy-mlhlp1205/mac
- Flag or block emails in Mail on iPhone: https://support.apple.com/guide/iphone/flag-or-block-emails-iph3caefa61/ios
- Block, screen, and filter communications: https://support.apple.com/guide/personal-safety/block-screen-and-filter-communications-ipsac1e87c54/web
- Use Mail Privacy Protection on iPhone: https://support.apple.com/guide/iphone/use-mail-privacy-protection-iphf084865c7/ios

## Calendar invite spam (added 2026-10-27)
Open the invite → **Report Junk** → **Delete and Report Junk** (don't Accept/Decline). Stop in-app invites: icloud.com/calendar › Settings › receive invitations as **email**. Delete unknown **Subscribed Calendars** (Settings › Calendar › Accounts). Full card: `calendar-invite-spam`.
## Is my iCloud still mine? (added 2026-10-27)
icloud.com/mail › Settings › **Mail Forwarding** should be off unless you set it, and **Rules** should have no unknown "Forward to." Check that the account.apple.com trusted phone numbers are all yours. Full card: `mailbox-takeover-check`.
