# Do Not Sell — email

Calm, honest: opt-outs **limit future** selling/sharing by the company you ask. They don't recall copies already sold, and they don't stop a buyer who already has the address — that's what alias deactivation + block is for (`signup-alias-watch`). Drafts only; the user sends. No legal advice; no promised outcomes or money.

## Hard rules
- Only write to the company the user actually gave the address to (or a named broker the user chooses). Never invent the buyer.
- Send nothing in the user's name. Draft → user OK → user submits → receipt.
- Never ask for SSN, DOB, card numbers, passwords. If a form demands ID, tell the user and let them decide.
- Use the company's **own** privacy link/form found on its website — not a guessed address.
- Residency decides which law applies. Don't cite California rights as rights to a non-Californian (it's still fine to *ask* a company to stop).

## Enough to draft
Ready when you have: the email/alias; the company it was given to (not Unknown); purpose and approx date of signup (or “unknown date”); residency (state/country) for template choice. A privacy URL found on that company’s site is a plus — look it up before drafting when possible.

## Proactive prompt (do not wait for them to remember)
On a who-sold Confirmed/Likely hit, a leaked alias with no opt-out yet, or a Waiting opt-out past its window with a new hit:
1. One calm line naming company + alias.
2. **Widget** — Draft Do Not Sell letter · Deactivate alias only · Log only · Not yet.
3. On Draft → fill Template A–E from `$FORTRESS_HOME/data/letter-templates.md` by residency → show draft / draft card. Owner sends.

Weekly/monthly routines that surface these cases use the same widget.

## Flow
1. Identify who got the address (who-sold map or user). If Unknown → offer block + alias for future signups (no seller letter).
2. Find the company's opt-out path: "Do Not Sell or Share", "Your Privacy Choices", Privacy policy, marketing preferences, or CAN-SPAM Unsubscribe (phishing → Report only).
3. Check enough-to-draft; prompt with widget.
4. Draft (templates below by residency).
5. User sends. Log receipt with recheck window.
6. Weekly/monthly watches for new third-party mail after the window.

## US hooks (verify in-session before citing)
- **CAN-SPAM** (all US commercial email): stop within **10 business days**; after opt-out, sender may not sell/transfer the address (15 U.S.C. § 7704(a)(4)).
- **CCPA/CPRA** (California residents only): opt out of sale/sharing (max 15 business days); know/delete (45 days). GPC browser signal. DROP one-request for registered data brokers: https://privacy.ca.gov/drop/
- **Other states**: do not cite a state law until its official AG/statute page is opened in-session. Polite ask still works. Idaho has no documented Do Not Sell statute in this bot — §48-603E is bulk-email deception, not opt-out-of-sale.

## International → $FORTRESS_HOME/data/geo-packs.md
GDPR/UK Art. 21 marketing objection; Canada PIPEDA/CASL; AU APP 7; etc.

## Templates (user sends)
**A. CA resident Do Not Sell + delete** — cite CCPA; stop selling/sharing + delete for [email], purpose, date.
**B. Any US state (polite, no legal claim)** — remove from lists; do not sell/rent/share; ask if already shared.
**C. CAN-SPAM unsubscribe** — remove from commercial email; do not sell/transfer; recheck +10 business days.
**D. GDPR/UK Art. 21** — use geo-packs letter + Art. 15(1)(c) ask about disclosures.
**E. After alias leak** — see $FORTRESS_HOME/data/letter-templates.md Template E.

## Brokers
CA residents: DROP. Everyone else: phone-lane data-broker opt-out pattern — open each broker's own privacy page; no unverified URL lists.

## Free US email opt-out (ANA eMPS) + no national Do Not Email list
- **There is no national "Do Not Email" registry.** The FTC told Congress in 2004 that one would not work (spammers would use it as a list of live addresses). Anyone selling "Do Not Email registration" is a scam or a marketer.
- **ANA Email Preference Service (eMPS)** is the free industry opt-out for US consumers: https://www.ims-dm.com/cgi/optoutemps.php. It's free, lasts **ten years**, and sends a verification code (enter it within 60 minutes). Member marketers remove matching addresses from *unsolicited* prospect lists. It won't stop companies you already do business with, criminals, or political mail.
- Coach: the owner fills the form themselves (it shares the address with member companies for suppression). Log in `$FORTRESS_HOME/private/identity.md` → `## Hardening checklist`: `- [x] ANA eMPS registered for <address> (YYYY-MM-DD; renew YYYY+10)`. Ticks/dates only.
- Combine with per-company Do Not Sell letters (this skill) and data-broker removals (`data-broker-opt-outs`).
