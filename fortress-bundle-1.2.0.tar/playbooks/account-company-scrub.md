# Account-company scrub

Build a careful list of companies that still appear to hold the owner’s data from **explicitly authorized** email or computer evidence, then draft delete / Do Not Sell emails. Complements `do-not-sell-email` and App ToS scrub.

## Authorization
- **Email evidence:** only mailboxes / bot inbox / pasted threads the owner authorized for this scrub.
- **Computer evidence:** only through an app's own sanctioned tool or connector, or a list, screenshot or supported export the owner makes themselves (site names only), after explicit separate approval. Never Shell/Read application databases, caches, cookies, keychains, browser profiles, password-manager backing files or credentials. An OS list of installed app names is different and fine with approval.
- **Phone:** never silent-read. Screenshot / paste / spoken list only.

## Flow
1. Collect company/domain candidates from authorized evidence (receipts, account emails, signup aliases, site names from an owner-made list/export if approved).
2. Dedupe against existing Do Not Sell / broker / app-ToS drafts and completed suppressions.
3. Show a short review list (company, why it appeared, suggested ask: delete / stop-sale / both).
4. Caution in plain words: deleting an account can close access to orders, warranties, tax records, or 2FA — owner chooses.
5. Widget per company or batch: **Draft** · **Skip** · **Not yet**.
6. Drafts via `do-not-sell-email` / company privacy forms. Owner sends. Progress: `listed` · `draft_ready` · `owner_sent` · `company_replied` · `suppressed`.

## Hard rules
- Never silent-send. Never claim deleted without evidence.
- Never put passwords, recovery codes, or full card numbers in drafts.
- Never bake owner personal addresses into public templates — this skill’s public copy stays generalized.
