# After a click / after a loss: recovery card

**Saved anchors (so the dates keep counting on later checks):** when the owner gives a date that starts a time limit, save it in `$FORTRESS_HOME/private/<lane>/recovery/incidents.json`. Concrete example of a valid file (a wire sent on Nov 3, 2026, 2:15 PM Mountain):

```json
{"version": 1, "items": [{"incident_id": "inc-20261103-wire", "kind": "wire72", "anchor_at": "2026-11-03T14:15:00-07:00", "anchor_what": "wire sent"}]}
```

Pick exactly ONE `kind` per incident: `wire72` (wire sent), `rege2bd` (card/access device loss noticed), `rege60` (statement showing an unauthorized transfer was sent) or `credit60` (card statement showing the error was sent). Replace the example id/time/what with the owner's real values; `anchor_at` is the owner's time with its UTC offset. Append to `items` (never overwrite another incident or an owner-supplied anchor) and check that the saved file still parses as JSON (`python3 -m json.tool <file>`) before saying it is saved. `deadline-clocks.py list` re-reads it every run and writes each incident's clock back. Set `done_at` when the owner says it is handled. Which rule applies (for example, Regulation E covers unauthorized transfers, and a payment the owner made after being tricked may not be covered) is for the bank or a lawyer to decide: the dates are reminders, not legal conclusions or a promise of a refund.

## Open with (always)
"**You're not in trouble, and moving fast helps. Do these in order. I'll draft the reports; you send them.**" No blame, no "you should have".

## Step 0: Stop the bleeding (minutes)
- Remote access was given → turn off Wi-Fi/unplug, uninstall the remote tool, don't let "support" back on.
- Password typed into a fake page → change it **on the real site** (type the address) + anywhere it's reused; turn on 2FA; run **mailbox-takeover-check**.
- One-time code shared → assume that account is open: change password, sign out other sessions.
- Never pay a "recovery" service, "lawyer," or "FBI agent" who contacts you. Real help is free.

## Step 1: Money, by payment type (call the number on the card or the bank's app, not any number from the scammer)
| Paid with | Do now | Rule / deadline |
|---|---|---|
| **Debit card / bank transfer / Zelle from bank** | Report it to the bank right away; ask for a written claim number | **Reg E** covers **unauthorized** electronic transfers (someone else moved the money, or you were tricked into giving a code/credentials they used). A payment **you made yourself** after being deceived may not be covered; banks and the CFPB treat these differently, so ask the bank to review it anyway and escalate to the CFPB if refused. **12 CFR 1005.6** limits: report a lost/stolen card within 2 business days → max $50; later → up to $500; report statement items within **60 days** or risk unlimited loss. Bank must investigate (12 CFR 1005.11). https://www.consumerfinance.gov/rules-policy/regulations/1005/6/ |
| **Credit card** | Dispute the charge / chargeback; cancel card | Fair Credit Billing: dispute in writing within 60 days of the statement. CFPB guide: https://www.consumerfinance.gov/ask-cfpb/how-do-i-dispute-a-charge-on-my-credit-card-bill-en-61/ |
| **Wire** | Call your bank **now**: ask for a **wire recall** and that they contact the receiving bank (Financial Fraud Kill Chain). Ask about a Hold Harmless Letter. Then file at IC3 | Best within **72 hours**. https://www.ic3.gov/ |
| **Gift card** | Call the card brand's number on the back; ask to freeze funds; keep the card + receipt | FTC: https://consumer.ftc.gov/articles/avoiding-and-reporting-gift-card-scams |
| **Crypto / crypto ATM** | Screenshot wallet address + TXID; report to the exchange/ATM operator; IC3; optional Chainabuse https://www.chainabuse.com/report | Recovery offers afterward are scams |
| **Check / cash / courier** | Bank stop-payment; police report for couriers | IC3 |

## Step 2: Identity (if SSN, license, account numbers, or a mailbox were exposed)
- **IdentityTheft.gov** recovery plan + FTC Identity Theft Report: https://www.identitytheft.gov/
- Free credit freeze at all 3 bureaus (see **mailbox-takeover-check** checklist); IRS IP PIN.
- Unexpected hard inquiry or new account alert, or need to thaw for a real application → **credit-freeze-planner**.
- Bank/card alerts on.

## Step 3: Reports (bot drafts; owner files)
- **FTC**: https://reportfraud.ftc.gov/. If the scammer pretended to be a government agency or a business, say so. The **FTC Impersonation Rule, 16 CFR Part 461** (461.2 government, 461.3 business) makes that illegal and lets the FTC seek money back. https://www.ecfr.gov/current/title-16/chapter-I/subchapter-D/part-461
- **IC3** (FBI) for any loss, wire, or crypto: https://www.ic3.gov/. Include every identifier (emails, phones, wallets, TXIDs, bank names, account numbers the scammer gave).
- Takedown of the link/domain → **phish-takedown-drafts**.
- Elders / gift card / crypto wording → **elder-gift-card-crypto-pack**; packets → **regulator-scam-packet**.

## Draft-when-ready
Show one widget: "Bank claim script, FTC report text, IC3 text: ready. Open?" Owner copies/sends; log receipts (`email-report-receipts`, `destination: bank_claim | ftc | ic3 | identitytheft_gov`). Start clocks with `$FORTRESS_HOME/tools/deadline-clocks.py` for Reg E 60 days, credit dispute 60 days, wire 72h.

## Bank claim script (fill-in)
"I'm reporting a fraudulent [debit/transfer/wire] on [date] for $[amount] to [payee]. I was deceived by someone impersonating [who]. I'm asking you to review this under Regulation E if it applies, and under your fraud policy if not [or: recall the wire and contact the receiving bank]. Please give me a claim number and tell me when I'll hear back."

## Never
Collect full card numbers, SSN, passwords, or codes. Promise money back. Auto-file.

## Outside the US (country ≠ US only; added 2026-10-30)
US users: ignore this section; the steps above are unchanged. Non-US users: skip Reg E, FTC, IC3, and IdentityTheft.gov. Same opener, same Step 0. Then, in order:
1. **Bank or card first.** Call the 24/7 fraud number on the card or in the bank's app (never one from the message). Ask them to stop or recall the payment and give a claim number. The user calls; the bot never contacts a bank.
2. **National hotline** (`$FORTRESS_HOME/data/international.json` → `regions.<cc>.loss_recovery`):
   - **SG:** ScamShield Helpline **1799** (24/7; overseas +65 6869 1799). It can connect you to DBS/POSB, UOB, OCBC, Citibank, Maybank, StanChart, HSBC. It cannot file a police report → police e-report.
   - **MY:** NSRC **997** (24/7). Call within 24 h of the transfer. Still make a police report.
   - **IN:** **1930** right away (the first hour matters). Keep the SMS acknowledgement number; file the full complaint on www.cybercrime.gov.in within 24 h.
   - **UK:** a "bank" call → hang up and dial **159** from a different phone. Losses → **Report Fraud** 0300 123 2040 / reportfraud.police.uk.
   - **AU:** **IDCARE** 1800 595 160 (free help), then **ReportCyber** (cyber.gov.au, 1300 292 371); Scamwatch report helps warnings.
   - **HK:** Anti-Scam Helpline **18222** (24 h advice and stop-payment help, not a crime report) → police report (999 if urgent).
   - **TW:** dial **165**, or the 165 online report; ask the bank for an emergency stop (緊急止付).
   - **BR:** stolen phone → **Celular Seguro** alert (recovery or full block of IMEI, line, partner accounts), then a **B.O.** with the state Polícia Civil — the alert does not replace the B.O. Pix: ask the bank to start MED (Mecanismo Especial de Devolução, BCB) and contest the Pix in the bank app fast.
   - **CA:** Canadian Anti-Fraud Centre 1-888-495-8501. **NZ:** Netsafe 0508 638 723 + Police 105. **TH:** AOC 1441. **ID:** IASC (iasc.ojk.go.id) + police. **AE:** Dubai Police / UAE eCrime. Others: local police.
3. **Police report** where the hotline is not one. Save every reference ID in `email-report-receipts` with its `report_window_days`.
4. Recovery offers afterward are scams everywhere. Never promise money back.
