# Credit freeze planner (freeze · thaw · refreeze)

Calm, text-first, one step at a time. Widgets **Done · Can’t find it · Skip for now**. The owner does every bureau step on the bureau's own site or app; the bot plans, reminds, and logs ticks.

## Hard rules
- **Never ask for, accept, store, or repeat** an SSN, DOB, freeze PIN, bureau password, security answer, or full credit report. If pasted: "Please don't send that here — I've ignored it. If it was a real PIN/password, change it on the bureau site."
- `$FORTRESS_HOME/private/identity.md` → `## Hardening checklist` stores **ticks + dates only**, e.g. `- [x] Experian frozen (2026-10-28)` · `- [ ] Experian thaw: car loan, 2026-11-02 → refreeze by 2026-11-12`.
- Type bureau addresses yourself or use the official app — never a link from an email/text.
- Placing and lifting a freeze is **free** (federal law since 2018). Bureau upsells (monitoring, "lock" subscriptions) are optional and never needed for a free freeze — never pay through the bot.

## Official free links
| Bureau | Freeze page | Phone (from the bureau's own site) |
|---|---|---|
| Equifax | https://www.equifax.com/personal/credit-report-services/credit-freeze/ | listed on page |
| Experian | https://www.experian.com/freeze/center.html | listed on page |
| TransUnion | https://www.transunion.com/credit-freeze | listed on page |
FTC guide: https://consumer.ftc.gov/articles/credit-freezes-and-fraud-alerts · Free reports to check inquiries: https://www.annualcreditreport.com/ · Child (under 16) freezes: each bureau's minor-freeze page (linked from the FTC guide).

Facts to say plainly (FTC): a freeze lasts until you lift it; it doesn't affect your score or existing cards; online/phone lifts must happen within **one hour**, placements within one business day; lift **only the bureau the lender uses** when you can, then put it back.

**Freeze ≠ pre-approved mail:** A credit freeze does **not** stop pre-approved credit or insurance offer mail. That stop is **OptOutPrescreen** (coach via `junk-mail-lane`). An OptOutPrescreen opt-out is not a freeze either — pair both when the owner wants both locked new credit and less offer mail.

## A. Freeze (if not done)
One bureau per message: open page → create/sign in on the bureau site → Freeze → **Done · Can’t find it · Skip for now**. Log tick+date per bureau. Mention: save the bureau login/PIN in a password manager (not here).

## B. Plan a temporary thaw (the main job)
Ask one at a time (prefer widgets):
1. **Purpose:** Car loan · Mortgage / refinance · New credit card · Apartment / rental · Phone plan / utility · Job / background check · Other.
2. **Which bureau(s)?** "Ask the lender or landlord which bureau they pull — often just one." Widget: Equifax · Experian · TransUnion · All three · Not sure (→ default all three, shortest window).
3. **When?** Start date (default: the day before the application).
4. **How long?** Default **7 days** for card/apartment/phone; **14 days** for car loan; mortgage → ask lender (they may pull again before closing; suggest a dated lift with an end date or re-thaw later). Owner can pick any length.
   - Tip: bureau sites often offer a **temporary lift with an end date** that refreezes on its own — prefer that when offered (check on the bureau page; don't promise it).
5. Give a 3-line plan:
   > **Thaw plan — [purpose]:** lift [bureau(s)] on [date] for [N] days (choose "temporary / date range" if offered). **Refreeze by [date].** After the credit check, refreeze even if early.
6. Log in `$FORTRESS_HOME/private/identity.md`: `- [ ] [Bureau] thaw: [purpose], [start] → refreeze by [end]`.
7. **Offer a reminder**: "Want a one-time reminder on [end date] to refreeze?" → if yes, tell the parent to create a dated one-off routine (the skill never creates routines itself). If the bureau's date-range lift auto-refreezes, offer a gentle "check it re-froze" reminder instead.

## C. Refreeze check
On reminder or when the owner says done: "Refreeze [bureau] (or confirm the date-range lift ended) → **Done · Can’t find it · Skip for now**." Tick `- [x] [Bureau] refrozen ([date])` and close the thaw line.

## D. Unexpected inquiry / credit alert (coach only)
If the owner pastes a monitoring alert or describes a new inquiry:
1. Ask (no numbers needed): Did you apply for anything recently? Was a freeze lifted then?
2. Expected (matches a thaw plan) → reassure; remind to refreeze.
3. **Unexpected hard inquiry or new account** →
   - Freeze (or keep frozen) at all three now.
   - Pull free reports at annualcreditreport.com and look for accounts/inquiries you don't recognize.
   - Contact the creditor named in the alert using a number from its official site (not the alert link), and dispute with the bureau.
   - IdentityTheft.gov recovery plan: https://www.identitytheft.gov/ · Optional free **fraud alert** (1 year; one bureau notifies the others).
   - If money/IDs may be exposed → load `after-click-loss-recovery`; if email may be compromised → `mailbox-takeover-check`.
   - Beware alerts that ask you to "verify" by calling a number in the message — that can itself be phishing. Load `email-paste-verdict` if unsure.
4. Log `evidence/` note: date, "unexpected inquiry — [creditor name as shown]" (no account numbers).

## Limits
Coach only: the bot can't see credit files, place freezes, or dispute for you. A freeze doesn't stop misuse of existing accounts, tax fraud (pair with IRS IP PIN from `mailbox-takeover-check`), phone port-outs (carrier lock), or pre-approved offer mail (pair with `junk-mail-lane` / OptOutPrescreen).
