# Email paste verdict

## Purpose
Turn a paste, screenshot, link, QR, or forwarded spam-inbox message into one firm (or honest Not sure) verdict with evidence and one next step. Matches the locked Email Fortress design bar.

## Standing rules
- Order: **Badge → one-line advice → Why (quoted) → buttons**.
- Firm when confident; say **Not sure** when not. Never hedge every case.
- Prefer false-alarm avoidance: bank / pharmacy / gov / delivery / family / OTP / password-reset → protect; hold doubtful mail for review; never auto-delete.
- Color: red only for confirmed scam or destructive action; pair with icon + word.
- Quiet confirm after logging.

## Badges
`Scam` | `Suspicious` | `Looks safe` | `Not sure`

## Elder-clear first line (always for Scam / high-risk Suspicious)
Lead with a short, plain line so someone who is unsure still sees the action:
- **Scam:** "**Scam — do not tap any links, do not call any number in this message, and do not send money or codes.**"
- **Suspicious (gift card / crypto / wire / remote access / recovery):** same line, then "If unsure, hang up and call a number you already have."
- Never full-screen scareware, countdowns, ALL-CAPS walls, or emoji spam. Firm and calm beats panic.

## Why block
2–4 flags max. Each quotes the exact phrase or shows the **real URL** behind a link. Plain words ("fake sender address", not "SPF fail" alone).

## Originating IP enrichment (when headers available)
When the paste or forward includes `Received:` / originating IPs (not private `10.*` / `192.168.*` / `127.*`):
1. In a paste or forward nothing proves which `Received:` line the owner's provider added. `enrich-domain.py --headers` gives `first_external_ip` only from the **top** `Received:` line (an unverified hint); if that line has no public IP the hint is empty. Lower lines may be forged: never use them, never call any of them the origin.
2. Look up with `curl -sS https://ipinfo.io/<IP>/json` (or `ipinfo <IP>` if installed). Record the network owner (org/ISP) only, labeled as network registration; never city, region or country as the sender's location.
3. Optionally open/link `https://www.abuseipdb.com/check/<IP>` for report counts — do not invent scores.
4. Add at most **one** Why line naming only the relay's network owner: e.g. "The top relay is on *Network Org*'s network (unverified hint from a pasted header; not the sender and not a location)". Never give a city, region or country.
5. Never plot who-sold map pins from IP geo. Never claim street-level accuracy.

## Source identification (header mode, coach-ready Oct 31 2026)
Use when the verdict is Not sure / Suspicious, the owner asks "who really sent this?", or a brand name is in the From line. One short step per message; the owner copies, the bot reads. Copying headers never needs tapping anything in the message.

### 1. Get "Show original" (one step for their app)
`python3 $FORTRESS_HOME/tools/enrich-domain.py --coach` prints the steps. Say only the one for their app:
- **Gmail (computer):** open the message → ⋮ More → **Show original** → **Copy to clipboard** → paste here. Gmail app on a phone can't; use mail.google.com in a browser.
- **Outlook (web / new Outlook):** open the message → ⋯ → **View** → **View message details** → copy all.
- **Apple Mail (Mac):** View → Message → **All Headers** (or Raw Source, Option-Cmd-U).
- **iCloud.com:** ⋯ → Show All Headers / Raw Message. **Yahoo:** ⋯ More → **View raw message**.
- **iPhone/iPad Mail:** can't show headers; forward the mail to the bot spam inbox or use a computer.
Save the paste to a file and run `$FORTRESS_HOME/tools/enrich-domain.py --headers <file>` (adds domain age, auth, envelope, ESP, brand check, origin IP).

### 2. Read the lines that matter (plain words, only the ones that change the verdict)
| Header | Plain meaning |
|---|---|
| **Delivered-To** (or X-Original-To) | The address the mail was really delivered to: the envelope recipient. |
| **Received** | The relay trail, newest at top. In a paste none of it is verified; only the top line's IP is used, as an unverified hint (never the sender's origin or location). |
| **Return-Path** | The hidden bounce address. Often a mail service (e.g. sendgrid.net), not the brand. |
| **From** | What the app shows. The display name is just typed text; only the part after @ counts. |
| **Reply-To** | Where your reply really goes. Different from From = flag ("replies go to *domain*, not the sender"). |

### 3. SPF / DKIM / DMARC in plain words
Pasted or forwarded headers never verify authentication: `headers.auth` is `unknown` and any pass/fail lines appear only under `claimed_in_headers_unverified` (an authserv name that matches the owner's provider is still just text; a DKIM-Signature header is not a checked signature). Say "Authentication is unknown from a paste" and judge the ask. The meanings below are for explaining what those words mean. Read `headers.auth.plain` and say one sentence:
- **SPF:** "Was this server allowed to send for the *bounce* address?" It checks Return-Path, not the From you see.
- **DKIM:** "Did a domain put a tamper-proof signature on it?" Say which domain signed (`dkim_signing_domains`); a bulk-mail service signing is normal and not the brand vouching.
- **DMARC:** "Does the From domain match what SPF or DKIM proved?" This is the one that matters for "is the From faked?"
- DMARC **failed** → "The From address is likely faked."
- DMARC **passed** → "It really left *domain*'s servers. That does **not** make it safe: scammers own passing domains, and real services (PayPal/QuickBooks invoices, DocuSign, Google Forms, calendar invites) pass DMARC when a scammer uses them." Never present a pass as reassurance; judge the **ask** (pay, call, sign in, scan, reply).
- **SPF pass on a different bounce domain:** if `spf_mailfrom_domain` ≠ visible From: "SPF passed for *bounce-domain*, not for *From-domain*, so it doesn't vouch for who it claims to be." (RFC 7489 alignment.)
- Gmail blue checkmark = BIMI with a verified mark certificate (verified brand). Missing checkmark proves nothing.

### 4. ESP hints when visible
`headers.esp.plain` names the bulk-mail service when DKIM d=, Return-Path, Received, or service headers show it (SendGrid, Mailchimp/Mandrill, Amazon SES, Mailgun, Postmark, SparkPost, Constant Contact, Klaviyo, HubSpot, Salesforce Marketing Cloud, Brevo, Zoho, Microsoft 365). Say: "Sent through *ESP*, a bulk-mail service companies rent. Real brands use these too, so it's a clue about how it was sent, not who sent it." Free-mail From (gmail.com, outlook.com, yahoo.com…) with a company name → "a free account anyone can make; the company name means nothing." ESP known + clear abuse → the ESP's abuse inbox is a takedown option only via `phish-takedown-drafts` verified rows; never guess an abuse address.

### 5. Random To: vs envelope recipient
`headers.envelope.status`:
- `mismatch` → "It was delivered to you, but the To line shows *other addresses*. You were a hidden (Bcc) copy of a mass mailing, a common spam pattern."
- `hidden_recipients` → blank / "undisclosed recipients" To = Bcc. Normal for some newsletters; a bank or a person writing only to you would name you.
- `match` → say nothing.
Caveats: forwarding, aliases, plus-tags, and Hide My Email change Delivered-To legitimately (plus-tag / alias hit → `who-sold-my-address`). If the owner forwarded it to the bot inbox, Delivered-To is the bot inbox, so ask for Show original from their own mailbox instead.

### 6. Official brand domain check
`headers.brand_check` compares the brand in the display name or address with `$FORTRESS_HOME/data/brand-domains.json` (banks, US gov, payments, Apple/Google/Microsoft/Amazon, crypto: Coinbase, Kraken, Binance, Gemini, Crypto.com, OpenSea, MetaMask, Ledger, Trezor, plus callback-bait brands like Norton/McAfee/Geek Squad). Rules to coach:
- Read the **registered domain** with the **fortress-tools** `fortress_domain.py` helper (URL parser + Public Suffix List; handles user@host tricks, ports, punycode). If it can't tell, say the host is unclear and treat as Suspicious. `chase.com.secure-login.xyz` is secure-login.xyz. A domain that only contains the brand word (`opensea-drop.io`, `apple-id-help.net`) is not the brand.
- **Not official** → Why line: "It says *Brand*, but it came from *domain*, which isn't one of *Brand*'s domains. The name is just text they typed."
- **Official** → never reassurance: "That proves the address, not the ask." Unexpected invoice / share / call-to-cancel from a real service → `abused-legit-brand-pack` (brand patterns live there, not here).
- Not on the list ≠ fake (subsidiaries, vendors): say "not one we know for *Brand*" and judge the ask.
- **Gov:** US federal mail is .gov; IRS and SSA don't start contact by email/text asking for money or personal info. Non-US: `$FORTRESS_HOME/data/brand-domains.json` → `non_us_gov_suffixes` + `$FORTRESS_HOME/data/international.json` checkers.
- **Crypto (any exchange, wallet, NFT marketplace; OpenSea is just one):** a seed / recovery phrase ask, "sync" or "validate your wallet," or a surprise airdrop claim → `Scam`, whatever the domain. → `elder-gift-card-crypto-pack` if money moved.

### 7. Domain age + origin IP
- **Domain age (From domain or real link host):** `$FORTRESS_HOME/tools/enrich-domain.py <domain-or-host>`; the bot looks it up, the user never opens the link. At most one Why line: "*domain* was registered *N* days ago" (under 30 days = strong flag). Old domain + unrelated brand → "looks like a hacked or rented site"; age never makes mail safe.
- The top-hop hint (`first_external_ip`, unverified) from the same parse feeds the network-owner lookup above; it is not the origin.

### Why-line budget
Header mode adds at most **2** Why lines total (pick from `headers.source_why_lines`, auth plain, domain age, origin IP; strongest first). Log `envelope.status`, `esp.esp`, and `brand_check` fields in the evidence log entry.

## Cold outreach & mass-mailer pitches
A real person or sales tool pitching ("quick question", "15 minutes this week?", SEO/web-design/lead-gen offers, follow-up #3) with no money/code/call-back ask → badge `Looks safe` (not a scam, just unwanted sales mail; keep to the existing four badges). One-line advice: "Sales outreach, not a scam. Junk it or block the sender. Don't reply, since replies confirm the address is live." Tells for bulk tools (Why line, max one): "sent via" bulk-sender line, tracking-style link host, a footer with a postal address + unsubscribe. CAN-SPAM covers commercial cold mail: a real unsubscribe link from a matching domain is OK to use (log a receipt → `enforced-unsub-recheck`). If the From domain rotates per message, use the rotating-sender playbook. Business mailbox: the owner may write their own rule (e.g., subject contains "quick question" + not from contacts → folder). Never send replies for them.

## Rotating senders (same lure, new From every time)
Signs: same subject or lure (e.g., a brand "reward"), but a different From domain on each copy, often newly registered (run enrich-domain for age). Tell the owner calmly: blocking one address won't keep up. Plan, one step per message: (1) **Report spam / Move to Junk on every copy**. That's the strongest signal to the provider. (2) Optional keyword rule the owner creates on a phrase that repeats in the lure or footer (Gmail filter "has the words" → Skip Inbox + label "Held"; Outlook Rule → move to Junk; iCloud.com rule), never routed to Delete, and never on words a protected sender uses. (3) If one sending **domain** repeats across copies, block the domain (Outlook Blocked domains; Gmail filter from:(@domain)). (4) Log each copy with the same campaign tag; who-sold stays Unknown. (5) Still arriving after 3+ reports in a week → alias tip (`who-sold-my-address`).

## Off-platform bait, spoofed senders & sextortion (pasted texts/emails/screenshots)
- **Off-platform push = high-risk `Suspicious` at minimum** (`Scam` with any money/threat): `t.me/`, `telegram.me/`, `wa.me/`, `chat.whatsapp.com/`, `signal.me/`, `signal.group/`, "text me on Telegram/WhatsApp/Signal", or a QR to a chat app. Quote the exact line. **Never coach opening, scanning, or "just checking" the link.** Run `python3 $FORTRESS_HOME/tools/extract-identifiers.py --text "<paste>" --from "<sender>"` for handles, links, wallets, payment tags (no fetching).
- **Sender-type chip** (texts): short code / toll-free / long code (10DLC possible) / **email-to-SMS** (sender is an email address) / alphanumeric. Explain in one line; never claim a 10DLC registration status.
- **Spoofed-looking sender:** a display name or caller ID saying "Chase"/"IRS" from a personal-looking number or an unrelated domain → "likely spoofed — the name is just text they typed." Signals, not proof.
- **Sextortion / "I recorded you" / "I know your password"** → `Scam` badge; first line: "Don't pay, don't reply, don't delete — screenshot it." Don't pay, don't reply, screenshot, report FTC (reportfraud.ftc.gov) / IC3 (ic3.gov); no paid removal firms. For bluff emails quoting an old password: change that password wherever it's used; check it yourself at Have I Been Pwned (never type it to the bot).
- **Fake helpers:** any "sextortion helpline / removal / we'll track them" ad or reply asking for a fee → warn (FTC sued Digital Forensics Corp., Oct 2026).
- **iMessage:** for scams don't reply at all (even STOP); Report Junk + 7726.

## Real service, fake person (verdict rule)
Mail can be **genuinely sent by PayPal, Intuit/QuickBooks, Square, DocuSign, Dropbox, Google (Forms/Docs/Calendar, and Google security / account alerts), Microsoft, Apple, or Zelle-bank systems** and still be a scam, because the *scammer* created the invoice, share, form, invite, **or the text that rode inside a real Google alert**. DMARC/DKIM pass, the blue check may show, and links go to the real service. Verdict on the **ask**, not the sender:
- Badge `Scam` (or `Suspicious`) when a real-service message carries: an unexpected invoice/charge you didn't make, "call us to cancel/dispute," a note field with a phone number, a shared doc that asks you to sign in to view, or a payment request from a stranger.
- Why line: "This really came from PayPal's system, but a stranger wrote the invoice. PayPal won't ask you to call a number in an invoice note."
- Next step: open the real app/site yourself and check whether there's actually a charge; don't pay the invoice or request; report via the service's verified inbox (e.g., phishing@paypal.com) from `$FORTRESS_HOME/data/brand-abuse-directory.json`.
- Full pack (per-service patterns, quick test, reporting rows, already-acted path): load `abused-legit-brand-pack`.

## Google app-password name alerts (genuine Google, scam payload)
Scammers put scam text (fake McAfee/$399 invoice, "call this number," etc.) in the **name of a Google app password**. Google then sends a **real, signed** security alert that includes that name. The alert is often forwarded to the victim. DMARC/DKIM pass because it really left Google.
- Badge `Scam` when a Google security / account / "new app password" style alert includes an unexpected phone number, invoice amount, "call to cancel/refund," or similar ask that Google itself would not put in an alert.
- Why lines (pick 1–2): "The From line is real Google — that does not make the ask safe"; "The phone number / invoice text is rider content (often from an app-password name), not a Google support line"; "The Check activity / Manage account buttons only open your own Google Security page, where nothing looks wrong because nothing was breached — that dead end is deliberate."
- First line: "**Scam: don't call any number in this Google alert.** Open Gmail or myaccount.google.com yourself (bookmark or app) and review Security there."
- Do **not** treat a DMARC pass or `no-reply@accounts.google.com` / similar as reassurance. Do **not** coach calling the number "just to check."
- Extract any phone number → `$FORTRESS_HOME/tools/enrich-number.py` (one Why chip max). If they already called → `after-click-loss-recovery`.
- Related: callback phishing below; gmail-mail-harden honesty note on the same beat.

## Callback phishing (phone number only, no link)
"Your $599 Geek Squad / Norton / McAfee / PayPal / Amazon renewal: call 1-8xx to cancel." No link means link scanners score it as clean, and it may pass DMARC (often a free-mail account, a real invoicing service, **or a genuine Google alert carrying rider text** — see app-password name alerts above).
- Badge `Scam` when: an unexpected charge/renewal + a phone number to "cancel/refund" + no real account context. First line: "**Scam: don't call the number in this email.** Check your real account or card statement instead."
- Extract the number and run the phone lane `python3 $FORTRESS_HOME/tools/enrich-number.py <number>` (FCC complaint count, carrier). One Why line max.
- If they already called: remote access or a "refund" overpayment = load `after-click-loss-recovery`.

## Attachments, QR codes, images
Never open attachments or scan QR codes on the owner's device to "check." Run `python3 $FORTRESS_HOME/tools/inspect-attachment.py <file>` (PDF/HTML/SVG/EML/image; QR decode; link-text mismatch; never visits links). Full guidance: `safe-attachment-qr-inspect`.

## Buttons
One primary (Report it / Block sender / Keep — always allow) + at most two secondary. Offer thumbs when useful.

## Elder / gift-card / crypto / recovery
If urgency + gift card, crypto ATM, wire, secrecy, remote access, "we can get your money back", or "call this number now": high-risk → load `elder-gift-card-crypto-pack`. Coach hang up / don't pay / call known number.

## After verdict
- Brand on `$FORTRESS_HOME/private/breach-watch.json` (status watching) → at least `Suspicious` for sign-in/verify/refund/call asks; one Why line naming the breach date (`hibp-breach-watch`).
- First-seen domain + prize/survey/gift-card/urgency wording → "held for review" card per `new-sender-screener`; a safelist match is not a pass (review, no automatic action, no reassurance, per `protected-senders`); never auto-delete.
- **Country ≠ US only:** add one line, "Also check on <official tool>", from `$FORTRESS_HOME/data/international.json` → `regions.<cc>.checker` (HK Scameter · MY Semak Mule · SG ScamShield check — an app report is not a police report · IN Sanchar Saathi Trusted Contact Details · UK "bank" call → hang up, dial 159). US: skip this line.
- **WhatsApp / Telegram (country ≠ US only):** coach "screenshot the chat with the number or @name showing, then use the app's own Report (it also blocks)". Never forward the scam to friends. Save the screenshot to the evidence log; in SG the ScamShield app can check WhatsApp/Telegram messages.
- Log via `email-evidence-log` / `spam-evidence-log` (include IP enrichment fields when gathered)
- Report packaging + `email-report-receipts`
- Plus-tag / Hide My Email → `who-sold-my-address`
- Offer letter drafts via `do-not-sell-email` or letters pack when opt-out fits
- Link host / sending domain known → offer `phish-takedown-drafts` (draft-when-ready)
- Password shown in the email → change passwords + mailbox-takeover-check if flood or takeover signs; "new bank details" wire ask → stop and call the bank on a number you already have, then after-click-loss-recovery; reset/sign-in alerts you didn't trigger → `mailbox-takeover-check`

## Auto path (bot spam inbox)
When mail arrives at the owner's Grok Bot spam inbox (forwarded junk): read the thread, run this verdict, message the user in chat with Badge + elder-clear first line + Why. Never click links. Never auto-delete from their real mailbox.

## Anti-patterns
No OS pop-ups inside Apple Mail or Messages (we cannot inject those). No password asks in chat. No silent deletes.

## Caregiver email (only through caregiver-view-act)
Memory flags, a Vault email, or drafts being turned off are never permission to email anyone. When `$FORTRESS_HOME/private/caregiver/state.json` has active people:
- After a material Scam / Suspicious / report / block / held-for-review, **queue** structured fields only with `caregiver_state.py` `enqueue` (counts, sender domain, a fixed reason code); for a gift-card / crypto / wire / remote-access / family-emergency / government-demand / romance-money pattern, also queue a `high_risk_alert` (pattern code, local day, sender domain, next-step code) for people whose consented scope includes alerts.
- Do **not** send from here. The caregiver routine dispatches through `claim` (exact render, re-resolved consented address, tools present, app send permission, durable reservation) and handles timing and STOP. Never full messages, codes, links or bank/medical detail.
- Tell the owner in chat only after a caregiver email was actually sent.
- Nobody active → do nothing here.
