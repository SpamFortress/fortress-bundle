# Settlement and breach claims

Broader than TCPA-only. Watch open spam / breach / privacy settlements and similar claims; match eligibility clues to known carrier, email, apps, and logged evidence; draft form fields + official administrator link (“this one looks like it fits you”).

## Process
1. Prefer **official claims-administrator / court pages** over aggregator blogs.
2. Store under `$FORTRESS_HOME/private/settlement-ledger.json (seed list: $FORTRESS_HOME/data/settlements-public.json)` / `$FORTRESS_HOME/private/breach-watch.json` with `status` open|closed|unknown, claim window, official URL, `last_checked`.
3. Match as a **hint** only (same company, dates, product). Never a guarantee.
4. On a plausible match: show eligibility clues + official link + widget **Draft claim fields** · **Remind me** · **Not for me**.
5. Draft fields the form asks for from vaulted identity **only with explicit OK** per claim. Owner submits on the official site (or approves each assisted step).
6. Pair with `hibp-breach-watch` / `mailbox-takeover-check` when a breach notice starts the path.

## Known closed / not a join path (keep honest)
- **AT&T / related settlement claim window closed Dec 18, 2025** — payments may still be pending for people who already filed; **not** a new join path. Say so plainly if asked.

## Hard limits
- No outcome or dollar promises.
- Never auto-join, auto-file, or auto-submit.
- Not legal advice.
- TCPA-specific demand letters stay in `tcpa-demand-letter` / `tcpa-settlement-watch`.
