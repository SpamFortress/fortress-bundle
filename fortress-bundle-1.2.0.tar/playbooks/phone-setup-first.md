# Phone setup first

## When this runs
Trigger on: "set up my phone", first-run / starting fresh, or device/carrier spam blockers. **Layer 1** before broker opt-outs or demand letters unless they explicitly skip.

## Coach style (locked)
- **Text first.** One short step with **current** menu labels from Apple / Google / carrier help — never older firmware wording (e.g. do **not** say only "Silence Unknown Callers" as a lone toggle on modern iPhone).
- **One step per message.** Widget: **Done** · **Can’t find it** · **Skip for now** (make Can’t find it / Need help as visible as Skip).
- **Pictures only after Can’t find it** (or "help me" / "can’t locate"). Then send a step-by-step path board from the **same current labels**, optionally ask them to snap their screen so you can circle the real control. Do **not** auto-generate art on every step.
- If a label on their phone differs from this skill, **believe their screen**, update coaching for that user, and note drift for the monthly path-check routine.
- Link official help when unsure; never invent a menu name.
- **No scareware.** Say what a toggle does and what turning it off costs. Never "your phone is spying," forensics-friend stories, or pressure.

## First-run wizard (quiet ticks)
Track progress on the status Page checklist; one short chunk at a time:
1. Phone/carrier hardening (this skill)
2. Identity pack + vault
3. Bot confirmation inbox claimed
4. **Optional: browse through your own computer** — only if this app offers routing the bot's browser through the owner's computer, explain what it does and ask; skip if not offered or declined. Never use other IP workarounds.
5. First opt-out batch (10 free sites)
6. First spam paste (forward-this-spam)

Do not dump the whole wizard in one message.

## Order (always)
0. **Country first** (one tap) if not saved. US → steps below exactly as written. Not US → load `international-privacy-packs` and use "Outside the US" below instead of the 7726 and US-carrier lines.
1. Ask OS + carrier if unknown.
2. On-device call + text protections (paths below).
3. Carrier spam app/settings.
4. **Quiet phone privacy beat** (iPhone or Android paths below) — after spam filters, before bot-from-phone tips. Skip for now is fine.
5. Confirm what’s on; note skips.
6. How to use this bot from the phone for logging.
7. Then: evidence, reverse ID, opt-outs, demand prep.

## iPhone (current — verify vs Apple Support)
Source pattern: [Manage unknown callers](https://support.apple.com/en-us/111106) (paths checked Oct 2026).

**Calls — Screen / silence unknowns**
1. Open **Settings**
2. Tap **Apps**, then **Phone** (Phone is under Apps on current iOS; not always on the Settings root)
3. Under **Screen Unknown Callers**, choose one:
   - **Ask Reason for Calling** (strong default coach) — caller must say why before it rings
   - **Silence** — unsaved numbers go to voicemail / Recents without ringing
   - **Never** — rings normally (weak for spam)
4. Under **Call Filtering**, optionally turn on **Unknown Callers** (moves unknowns into their own list — *different* from Screen Unknown Callers) and **Spam** (carrier spam/fraud list when offered)

**FaceTime (optional):** Settings → Apps → **FaceTime** → **Silence Unknown Callers** if present.

**Texts (iOS 26)**
- Settings → Apps → **Messages** → Unknown Senders → **Screen Unknown Senders** on (also Messages → Filters → Manage Filtering). Unknown texts move to the **Unknown Senders** filter without alerts. Turn **Filter Spam** on too if shown.
- **Allow Notifications** (same section, US/BR/IN): choose which screened texts can still alert: **Time Sensitive** (codes, alerts, urgent requests; on by default), Personal, Transactions, Promotions. Allowed ones show in the main list for **8 hours**, then move back to Unknown Senders.
- **Honest catch:** "Time Sensitive" is decided by the phone, not by whether the sender is real. Scam texts dressed as urgent (toll due, package held, bank lock) can still ring through and sit in the main list. Habit: an urgent text from an unknown number is never a reason to tap; check in the real app or paste it to me. Keep Time Sensitive **on** if they get sign-in codes by text. For an elder who mostly gets codes by app, leaving only Time Sensitive on (Promotions off) is the quiet setup.
- Report Junk on spam; forward spam SMS to **7726**. Mark as Known only for people they recognize.

### Honest limit — SMS / iMessage auto-block
Apple and Google do **not** let this bot remotely block or delete SMS/iMessage threads. Never say “I’ll auto-block that for you.” Best we can do:
1. Coach Filter / Screen unknown senders + Report Junk + carrier spam tools.
2. Walk them through blocking one number on-device (one short step).
3. Keep an optional owner-maintained **block list** in Notes (numbers they already blocked) for evidence / recheck — not a live remote block.
4. Logging + 7726 / FCC drafts still work from a paste or screenshot.

**Do not coach the obsolete single toggle** "Settings → Phone → Silence Unknown Callers" as the only path — that wording and Settings-root Phone placement are outdated on current iOS.

### iPhone — quiet privacy beat (after call/text harden)
Offer once: *A few privacy switches that cut what the phone keeps or shares — under 4 minutes, skip any you want.* Official bases: [Location Services](https://support.apple.com/en-us/102515), [App Tracking](https://support.apple.com/en-us/102420), [Analytics sharing](https://support.apple.com/en-us/108971). One step per message.

1. **Significant Locations** (place history used for Suggestions) — Settings → Privacy & Security → Location Services → System Services → **Significant Locations** → turn off → clear history if shown. Trade-off: less useful "frequent places" suggestions.
2. **App Tracking** — Settings → Privacy & Security → Tracking → turn off **Allow Apps to Request to Track**.
3. **Improve Siri & Dictation** (and other Improve / Share analytics switches you don’t want) — Settings → Privacy & Security → Analytics & Improvements → turn off **Improve Siri & Dictation** (label may read Improve Siri & Apple Intelligence). Optionally off: Share iPhone Analytics, Share With App Developers.
4. **Safari Hide IP** — Settings → Apps → Safari → **Hide IP Address** → **From Trackers** (or From Trackers and Websites if they prefer).
5. **Precise Location** — for apps that don’t need curb-level accuracy: Settings → Privacy & Security → Location Services → tap the app → turn off **Precise Location**. Keep on for maps / rides / navigation they actually use.

After a major iOS update, re-offer steps 1–3 first (users report Significant Locations and analytics switches can need a re-check). Hand off rumor posts to **privacy-os-watcher** — verify on Apple’s pages before coaching.

## Android — Google Phone / Pixel
Sources: [Caller ID & spam](https://support.google.com/phoneapp/answer/3459196), [Call Screen](https://support.google.com/phoneapp/answer/9118387), [Messages spam](https://support.google.com/messages/answer/9327903).

**Calls (Phone by Google)**
1. Open the **Phone** app
2. Tap **More** (⋮) → **Settings** → **Caller ID and spam** (wording may be "Caller ID & spam")
3. Turn on **See caller ID & spam**
4. Turn on **Filter spam calls** when shown (Pixel Call Screen devices may use **Spam and Call Screen** / protection levels instead — follow their screen)

**Pixel Call Screen (when available):** Phone → Settings → Spam and Call Screen / Call Screen → pick protection level.

**Texts (Google Messages)**
1. Open **Messages**
2. Profile → **Messages settings** → **Protection & Safety** → **Spam and scam protection**
3. Prefer **Standard** or **Enhanced** (not No protection)

**Samsung / other skins:** Phone app → Settings → spam / smart call / caller ID — use on-device labels; Don’t invent Pixel-only names.

### Android — quiet privacy beat (after call/text harden)
Offer once, same tone. Exact labels vary by OEM — believe their screen.
1. **Ads / personalization** — Settings → Google → Ads (or Privacy → Ads) → Delete advertising ID / opt out of Ads Personalization when shown.
2. **App activity / tracking-style controls** — Settings → Privacy (or Security & privacy) → turn off unused activity / personalization switches they don’t want.
3. **Location history / timeline** (if present) — Google account → Data & privacy → Location History / Timeline → pause or delete; app Location → Precise off when not needed.
4. Hand OS-update rumors to **privacy-os-watcher**.

## Carrier tools
- T-Mobile / many Mint: Scam Shield (or Mint spam tools)
- Verizon: Call Filter
- AT&T: ActiveArmor
- Other: carrier app → search spam / scam / call filter

Guide taps; the user changes the settings. Later reminders: **carrier-and-ai-call-screening**.

## Outside the US (country ≠ US only; added 2026-10-30, built-ins 2026-10-31)
Same iPhone/Android call and text steps, with these swaps (data: `$FORTRESS_HOME/data/international.json` → `regions.<cc>.carrier_tools`):
- **Spam text forward:** UK and NZ → 7726 (their own free service). AU → 0429 999 888. IN → TRAI DND (START 0 to 1909) and Chakshu. SG → ScamShield app. Elsewhere → the phone's own Report Junk / Report spam only. Never coach the US 7726/FCC path.
- **Phone built-ins first (as of 2026-10-31, subject to change; data: `phone_builtins`).** Ask the phone model, then offer only one whose list includes their country:
  - **Pixel 9 or newer — Scam Detection (calls):** AU, CA, FR, DE, IN, IE, IT, JP, MX, SG, ES, UK; SIM from that country, phone in that country. Phone app → **More** → **Settings** → **Scam Detection** → turn on. Off by default; it beeps so the caller knows. ([Google help](https://support.google.com/phoneapp/answer/15654065?hl=en))
  - **Samsung Galaxy — Scam detection (calls):** with One UI 9 in JP, CA (English/French), IN (English/Hindi). Phone → **⋮** → **Settings** → **Scam detection**. Varies by model and language; if missing, use Phone → Settings → **Call screening** or **Caller ID and spam protection**.
  - **iPhone (iOS 26) — Ask Reason for Calling:** same path as the iPhone steps above; Apple lists it for English in AU, CA, IN, IE, NZ, SG, ZA, UK; French CA/FR; German DE; Japanese JP; Korean KR; Portuguese BR; Spanish MX/ES; Cantonese HK; Mandarin TW. Not while roaming. Not listed: Italy and most other EU countries → use **Silence** instead. ([Apple availability](https://www.apple.com/ios/feature-availability/))
  - Country not listed → Silence/Filter unknown callers + carrier rows only.
- **Carrier, free settings only:** UK O2 Call Defence (on by default, eligible plans) · EE Call Protect blocklist (Digital Home Phone) · Vodafone 7726 + landline anonymous-call reject · Three: no network filter — text CALL + the number to 7726, block on the phone · BT landline **Call Protect** (free; dial 1572 or My BT; can send withheld/international/unrecognised calls to junk voicemail) · Sky landline **Sky Talk Shield** · Virgin Media landline: TPS + handset block (its Anonymous Caller Rejection is paid — mention only if asked). AU Vodafone shows **"Warning: Suspected Scam"** on some calls — let it go to voicemail. MY CelcomDigi Scam Call Protection (automatic, "Suspected Scam" label) · Maxis free network firewall for international calls/texts (report spam via 123) · U Mobile free Scam Alert label (warns only, does not block). AU Telstra Scam Protect (automatic) · Optus ScamWise in My Optus. HK: networks warn on "+852" calls from abroad ("Call is from outside Hong Kong"). Others → carrier app, search spam / scam (verify).
- **Read the sender label:** AU "Unverified" (since 1 Jul 2026) and SG "Likely-SCAM" mean an unregistered sender name — caution, not proof. Bank text with that label → don't tap; open the bank app yourself.
- **JP landline:** free international-call stop — call 0120-210-364 from that landline (about a week to start; blocks all calls from abroad, so check with family overseas first).
- **IN:** from 1 Nov 2026 caller names (CNAP) show by default on 4G/5G; a shown name is not proof of who is speaking. **CNAP check (setup, then monthly):** on the next unknown call, does a name show? Calls from abroad should read "International Call". No name after 1 Nov 2026 → update the phone, ask the operator; no app needed. Record yes / no / not yet. Check a "bank" number on Sanchar Saathi Trusted Contact Details.
- **Government apps (free, official; user installs if they want):** SG **ScamShield** — reports go to the Singapore Police Force for review, but are **not** a police report. HK **Scameter+** (HK Police) — Call Alert + Website Detection; tips go to the Police. IN **Sanchar Saathi** — Chakshu reports, connections in your name, lost-phone block. Fortress never installs or signs anyone in.
- **Never** suggest installing caller-ID apps (Truecaller, Getcontact, Whoscall). Their unlist pages are in the opt-out catalog only. (Exceptions live in `international-privacy-packs`: the Truecaller Scam Checker *web page* as a labelled company extra check after the official one, and the caregiver mirror where a family names apps as their own choice.)
- **WhatsApp / Telegram scams:** screenshot the chat with the number showing, then the app's own Report (also blocks).

## Using this bot from a phone
1. Open this chat on mobile.
2. Spam text: paste body/screenshot + number + time ("forward this spam").
3. Spam call: date/time, number, what was said, answered?
4. Log STOP replies for revocation tracking.
5. Enable chat notifications for CAPTCHA handoffs and monthly reappearance alerts.

## After hardening
Phone filters cut volume; bot still logs evidence, reverse-IDs, STOP, 7726/FCC, demand letters (approval), broker opt-outs + monthly rechecks.
- After an iOS / Android update, or when an online post says an update turned something on, run **privacy-os-watcher**: official release notes only, coach new privacy toggles (ads, search / diagnostics / bug-report sharing, Significant Locations / tracking) text-first with Done · Can’t find it · Skip for now.

## Skip path
"Skip phone setup" / "already done" / **Skip for now** → note it, continue to identity / logging / opt-outs. Skipping must feel safe — no shame, offer harden again when they paste spam or say "set up my phone."
