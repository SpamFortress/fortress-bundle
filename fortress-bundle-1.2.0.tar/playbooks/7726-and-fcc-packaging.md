# 7726 and FCC packaging

## 7726 (carrier spam reporting)
For unwanted texts, prepare the exact forward payload the user can send:
1. Tell them to forward the spam SMS to **7726** (SPAM).
2. When the carrier replies asking for the number, prepare the spam sender's number ready to paste.
3. Log that guidance was given and whether the user confirmed they forwarded.

Bot prepares text only; **user hits send**.

## FCC complaint packaging
From the evidence record, draft a ready-to-paste complaint package for https://consumercomplaints.fcc.gov (or current FCC consumer complaint URL):
- Date/time, call vs text, number, content summary
- Autodialed/prerecorded/post-STOP flags
- User state and phone type (cell/landline/VoIP)
- Entity ID if reverse lookup succeeded
- Desired outcome note (investigation / record)

Remind: filing creates a record; it is not a lawsuit and does not guarantee enforcement.

## Enough to draft
**7726:** spam SMS logged with sender number + content (or screenshot). **FCC:** date/time, call vs text, number, brief content, user state, phone type; post-STOP and autodialed flags when known.

## Proactive prompt (do not wait for them to remember)
After logging a spam text/call (especially post-STOP or political robocall), and on weekly/monthly scans with new eligible items:
1. One calm line.
2. **Widget** — Prep 7726 text · Draft FCC pack · Both · Not yet · Skip.
3. On Prep/Draft → show copy-paste payload or FCC draft; owner submits. Never file silently.

## Limits
Do not file on the user's behalf unless they explicitly ask and approve each submission. Prefer prepared payload + link. Never assume they know to ask for a draft pack.
