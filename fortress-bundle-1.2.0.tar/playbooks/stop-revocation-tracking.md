# STOP revocation tracking

## Priority
Post-STOP contact is **highest-priority** evidence. Treat it as such in logs, monthly summaries, and demand packaging.

## On STOP
1. Capture the exact STOP (or vendor-specified) text. If it is **not sent yet**, save it only as `stop_planned_text` / `stop_planned_at` with `stop: {"sent": false}`. Planned text never starts a clock.
2. Only **after the owner confirms it was actually sent**: store `stop_at` (the confirmed send time, user's timezone), `stop_text`, `stop_channel` (SMS/call instruction), `stop: {"sent": true, "stop_at": ...}`, linked `evidence_id` and spam number. Keep older confirmed records as they are.
3. If they have not sent STOP yet, give one-line copy-paste text and ask them to confirm after sending; until they confirm, `stop.sent` stays `false` (an explicit `false` always wins over any leftover `stop_at`).

## On subsequent contact
1. Match by number, short code, or clearly same campaign thread. Never match two contacts just because both lack a caller ID (unknown/blocked number); keep unknown-caller contacts as separate evidence with that uncertainty, and add them to `post_stop_contacts` only if the owner confirms it was the same caller.
2. Create/update record with `post_stop: true`, `hours_after_stop`, and full content.
3. Flag prominently in chat confirmation and in monthly political/spam scans.
4. **Proactive prompt** — do not wait for them to remember draft cards. First do the method / category / confirmed-date review in the 10-business-day section below. If that review holds and there is enough for **tcpa-demand-letter** and/or **7726-and-fcc-packaging**:
   - Short note: post-STOP + hours_after_stop.
   - **Widget**: Draft demand letter · Prep 7726/FCC · Both · Not yet · Skip.

## Enough for those drafts
Same checklists as those skills (logged dates, number, STOP timestamps, content). Missing pieces → widget that asks for the gap, not silence.

## 10-business-day clock (FCC revocation rule)
Source: FCC 26-67, Federal Register 91 FR 67214 (Oct 26, 2026), **effective Nov 25, 2026**, 47 CFR 64.1200(a)(10)–(11): https://www.federalregister.gov/documents/full_text/html/2026/10/26/2026-21821.html
- A valid revocation must be honored within a reasonable time, **not more than 10 business days** after it is received.
- **Before Nov 25, 2026:** any reasonable method of revoking counts.
- **From Nov 25, 2026:** a caller may designate one exclusive method (automated key-press opt-out on the call, reply-text words, or its own opt-out website/number) **if it clearly discloses that method on the call or in the text**; then it need not process other methods. If it designates **reply text**, any of stop, quit, end, revoke, opt out, cancel or unsubscribe must be honored even if only one is shown. If the caller designated nothing, any reasonable method still counts.
- Scope: revoking in reply to an informational (non-marketing) message may cover only that category; revoking in reply to marketing covers all of that caller's marketing.
- Log separately: the raw facts (what was sent, when, the exact opt-out disclosure shown, which method was used, later contacts) and any conclusion. Never send STOP to an obvious scam number or an iMessage/RCS chat from an unknown sender; block and report instead.
- Educational, not legal advice; state laws and courts vary; never promise money.
- After STOP is logged, run `python3 $FORTRESS_HOME/tools/deadline-clocks.py list --write` → stores `clocks.stop_10bd` {start, deadline, status} (owner timezone labels) in the ev JSON. Business days skip weekends + US federal holidays (observed); day 1 = first business day after STOP (owner local time).
- One-off check: `python3 $FORTRESS_HOME/tools/deadline-clocks.py compute --kind stop --start <stop_at> --contact <later contact>`.
- Status meanings: `running` · `repeat_within_window` (still log `post_stop: true`; TCPA analysis may still use it, courts vary) · `deadline_passed_no_repeat` (keep watching) · `repeat_after_deadline` → **review first** (the helper says REVIEW): check the confirmed revocation date, the method used vs any method the caller clearly disclosed, and whether the messages were informational or marketing. Only then offer the draft-when-ready widget, and state facts ("contact N business days after the confirmed revocation") rather than a legal conclusion.
- Record later contacts either as new ev files from the same number (auto-matched) or in `post_stop_contacts: [{"at": ...}]` on the original ev.
- Texts: keep the 7th Cir. / circuit caveat from the demand-letter skill. Not legal advice.

## Multi-number
STOP is per destination number; keep revocation state under each protected number folder (see multi-number household skill).
