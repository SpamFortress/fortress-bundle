# Abused-legit brand pack (real service, fake person)

## The core idea
Scammers open real accounts on real services and send through them. The mail truly leaves PayPal, Docusign, QuickBooks, Square, Dropbox, or Google, so DMARC/DKIM pass, a Gmail blue check may show, and links go to the real site. **The sender is genuine. The person behind the ask is not.** Give the verdict on the **ask**, never on the sender.

## Quick test (any yes → `Scam` or high-risk `Suspicious`)
1. A charge, invoice, or renewal they don't recognize?
2. A phone number to "cancel", "dispute", or "get a refund", especially in a note, memo, or name field?
3. A shared doc, form, or e-sign envelope from someone they don't know, or one that asks them to sign in to "view"?
4. A money request or "send it back, we overpaid you" from a stranger?
5. A calendar invite with a payment, prize, or phone number in it?
6. A Google security alert whose text includes an invoice amount or phone number (app-password name trick)? Full rule in `email-paste-verdict`.

## Patterns by service
| Service | Typical abuse | What real looks like |
|---|---|---|
| PayPal | Invoice / money request with "call us if you didn't authorize" in the note | PayPal never asks you to call a number in an invoice note. Check activity in the PayPal app. |
| Docusign | Envelope from a stranger: "review the document", then a sign-in page; or a fake Docusign email with an attachment | Real envelopes come from docusign.net and never carry attachments. Review in your own Docusign account. |
| Intuit / QuickBooks | Invoice for "Geek Squad / Norton / renewal" with a phone number | Real Intuit mail is @intuit.com. Intuit won't ask for passwords or codes by email. |
| Square | Invoice, estimate, or contract for services you didn't buy | Don't pay or reply. Check your own records. |
| Dropbox | "<Name> shared a file with you" from someone unknown → sign-in page | Don't open shares from unknown people, even if the notice is genuine. |
| Google Forms / Docs | Form or doc asking for passwords, card numbers, or "account verification" | Google Forms carry a "never submit passwords" note. Real companies don't verify accounts through a Form. |
| Google Calendar | Invite auto-added with a prize, payment, or number | Report spam in Calendar. Turn on "Only if the sender is known" (`gmail-mail-harden`). Apple: Report Junk (`apple-mail-harden`). |
| Zelle / bank | "Payment pending, send to unlock" or "we sent too much, send it back" | Zelle has no "pending until you pay" step. Call the bank on a number you already have. |

## Official domains (fold, not duplicate)
The official-domain list for these services and for banks, US gov, Apple/Google/Microsoft/Amazon, and crypto (OpenSea is one example among Coinbase, Kraken, Binance, Gemini, Crypto.com, MetaMask, Ledger, Trezor) lives in `$FORTRESS_HOME/data/brand-domains.json`. `$FORTRESS_HOME/tools/enrich-domain.py --headers` returns `headers.brand_check`; coaching is in `email-paste-verdict` → Source identification §6.
- **Official domain + odd ask** → this pack (real service, fake person).
- **Brand name on a non-official domain** (lookalike, free-mail account, brand word inside another domain) → plain impersonation, not this pack: `Scam` / `Suspicious` in `email-paste-verdict`.
- Bulk-mail service in the headers (SendGrid, Amazon SES, Mailchimp…) is a clue about how it was sent, never who sent it.

## Verdict card (via `email-paste-verdict` order)
- **First line (Scam):** "**Scam: don't pay, don't call the number, don't sign in from this message.** Open the real <service> app yourself and check."
- **Why (pick 1–2):** "This really came from <service>'s system, but a stranger wrote the invoice/share/note." · "The phone number is in a note field anyone can type into." · "Passing security checks only proves which system sent it, not who's asking."
- **One primary button:** *Check it in the real app* (coach: open the app or type the site; never the message's link). Secondary: *Report it* · *Not sure*.
- Never present DMARC pass, the blue check, or "links go to paypal.com" as reassurance.

## Reporting (owner sends; we draft)
- Use **only** the `verified` rows in `$FORTRESS_HOME/data/brand-abuse-directory.json` (e.g. PayPal `phishing@paypal.com`; any brand → APWG `reportphishing@apwg.org`, Netcraft `scam@netcraft.com`; URL → Google Safe Browsing form).
- Docusign / Intuit / Square / Dropbox inboxes are candidates in `$FORTRESS_HOME/data/brand-abuse-directory.json (unverified_additions)` and must be promoted to `verified` before going into a draft. Until then, use APWG / Netcraft.
- Before a forward: "Forwarding shares your address and the headers with them. That's normal for these inboxes."
- Log via `email-evidence-log` (pattern `abused_legit_service`, service name) and `email-report-receipts`.

## If they already acted
Paid, called, signed in, gave a code, or allowed remote access → `after-click-loss-recovery` (ordered steps by payment type). Gift card / crypto / wire → `elder-gift-card-crypto-pack`.

## Never
Never tell them to call the number "just to check", pay "to make it stop", or sign in through the message. Never ask for passwords or codes. Never auto-report or auto-delete.
