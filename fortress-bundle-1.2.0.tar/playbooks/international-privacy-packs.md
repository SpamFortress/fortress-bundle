# International privacy packs

Use when the user's country of residence is not the US. Data: `$FORTRESS_HOME/data/international.json` (v4: regions + `capability`, `checker`, `loss_recovery`, `carrier_tools`, `report_windows`, `gov_apps`; top-level `phone_builtins`, `company_checkers`, `caregiver_mirror` added 2026-10-31). Email lane: `$FORTRESS_HOME/data/geo-packs.md`. Human view: `$FORTRESS_HOME/data/capability-matrix.md`. Not legal advice. (Merged with the old `international-privacy-packs-2` on 2026-10-30.)

## Rules (always)
- Free official paths only: government registries, regulator forms, or the company's own privacy page or DPO address. Never pay. Never use paid "removal" services or lookalike registries.
- Never collect national ID numbers, passports, passwords, or payment details. Date of birth only if the user OKs it for that one form. Share only the fields a form needs. Try CAPTCHAs yourself first; SMS codes and national e-ID logins (ID-porten, BankID, ClaveÚnica, Singpass…) are done by the user on the official site or through the platform's secure form, never typed in chat (sign-in skill path).
- **US TCPA, the US DNC registry, 7726-as-US-carrier-report, and TCPA damages never apply here** (UK and NZ have their own free 7726 — that one is fine). Never draft a TCPA demand or damages math for a non-US resident.
- The user changes phone and carrier settings. The bot coaches, one short step at a time.
- Money: read `capability.money`:
  - `none_typical`: say there is no private per-call claim. Fines go to the state.
  - `limited_verify`: a court compensation route exists (GDPR Art. 82, UK DPA 2018 s.168/PECR reg. 30, AU privacy tort, NZ HRRT, BR Juizados danos morais, SG PDPA s.48O, KR PIPA, HK PDPO s.66, ZA POPIA s.99, IL spam law). Harm or the statute's conditions must be shown; no fixed per-call amount. Suggest a local lawyer or consumer body. Draft nothing that promises money.
- Only run entries whose `countries` match the user's country (`"*"` = any). Skip `verified:false` entries unless the user opens the page themselves. Never guess a URL.
- Caller-ID apps (Truecaller, Getcontact, Whoscall) are never recommended as products. Their **unlist** pages are offered as opt-outs only. User approves each submit; OTP via the sign-in skill; never auto-submit. Two narrow exceptions, both labelled: the free **Truecaller Scam Checker web page** as an optional *extra* check after the official checker (see "Company extra check"), and naming company apps in the **caregiver mirror** as the family's own choice. Neither is a recommendation.
- Fortress never installs an app, signs anyone in, links a family account, or flips a setting for anyone. It coaches; the user (or their family) does it.
- Coverage of phone built-ins and apps is always stated as "as of 2026-10-31, subject to change" (or the newer re-verify date in the JSON). Never promise a feature is on a given phone.

## Pick the country
1. Read `$FORTRESS_HOME/private/identity.md` "Country of residence" (ISO 2-letter). Ask once if missing (one tap). Region/province matters for CA (Quebec Law 25), AU state, EU member state.
2. Extra international numbers in the identity pack get the pack for that number's country (e.g. a UK SIM → TPS), only with the user's OK.

## Pick the region
- CA → `ca` · GB → `uk` · EU/EEA (incl. NO) → `eu`, filtered by `countries` · AU → `au` · NZ → `nz`
- BR → `br` · MX → `mx` · AR/CL/CO/PE → `latam`
- JP → `jp` · SG → `sg` · KR → `kr` · PH → `ph` · IN → `in`
- HK → `hk` · MY → `my` · AE → `ae` · ZA → `za` · TW → `tw` (promoted/added 2026-10-30)
- TH/ID/IL → `other.regions_stub`
- RU → `ru` (information only, see the caution)
- Anything else → `other`. Research the national DNC register and DPA on official domains; add as `verified:false` until loaded.
- US → stop and use the US skills.

## Region cheat sheet (2026-10-30)
- **Canada:** DNCL; Spam Reporting Centre; OPC; CAI (Quebec); Anti-Fraud Centre 1-888-495-8501. CASL private right never in force.
- **UK:** TPS/MPS, 7726, ICO nuisance-calls form, Ofcom, Open Register opt-out. **Bank call? Hang up, dial 159** from a different phone. Losses → Report Fraud 0300 123 2040. Landline: BT Call Protect (free, dial 1572), Sky Talk Shield, Virgin Media (TPS + handset block; its Anonymous Caller Rejection is paid, mention only). Ex-directory via your provider (BT 0330 123 4150, free).
- **EU/EEA:** GDPR Art. 21 / 17 / 15. DPA via EDPB. Lists: ES Lista Robinson; IT Registro delle Opposizioni; BE donotcallme.be; SE NIX-Telefon; NO Reservasjonsregisteret; IE NDD. FR Bloctel ended 11 Aug 2026 (consent rule, 33700). NL opt-in.
- **Australia:** Do Not Call Register, ACMA, OAIC (incl. the APP 7 direct-marketing opt-out guide: tell the business to stop; Spam Act/DNCR issues go to ACMA). "Unverified" sender label since 1 Jul 2026. Vodafone AU "Warning: Suspected Scam" call banner. Losses → bank, IDCARE 1800 595 160, ReportCyber.
- **New Zealand:** Marketing Association DNC (marketing.org.nz only), DIA Spam/7726, OPC.
- **Brazil:** Não Me Perturbe, ANPD, consumidor.gov.br, PROCON. Phone stolen → Celular Seguro alert + B.O.
- **Mexico:** REPEP (PROFECO). CONDUSEF REUS (unverified). Data protection now under Secretaría Anticorrupción y Buen Gobierno.
- **Argentina:** No Llame (AAIP). **Chile:** SERNAC No Molestar (ChileAtiende ficha loads; sernac.cl may time out). **Colombia:** CRC Registro de Números Excluidos; SIC. **Peru:** no registry needed — calls/messages without consent are banned (Ley 32323); complain via Indecopi Reclama Virtual.
- **Japan:** no DNC list; refuse once; 188; PPC. Landline: free international-call stop 0120-210-364.
- **Singapore:** DNC Registry; PDPC; ScamShield check + 1799; ScamShield app (reports go to SPF for review; still not a police report). "Likely-SCAM" sender label.
- **South Korea:** donotcall.go.kr; KISA 118; PIPC; delete old site accounts on privacy.go.kr (웹사이트 회원탈퇴, which replaces eprivacy.go.kr).
- **Philippines:** NPC; CICC 1326 (verify); NTC.
- **India:** TRAI DND 1909, Chakshu, Sanchar Saathi Trusted Contact Details + Sanchar Saathi app, 1930 + www.cybercrime.gov.in. CNAP caller names on 4G/5G from 1 Nov 2026 — run the CNAP check below.
- **Hong Kong:** OFCA DNC (1835000), PCPD, Scameter / Scameter+ app, Anti-Scam Helpline 18222 (advice, not a crime report).
- **Malaysia:** Semak Mule, NSRC 997 (24/7), MCMC, JPDP. Carrier: CelcomDigi "Suspected Scam"; U Mobile "Scam Alert" (warns only); Maxis network firewall (automatic).
- **UAE:** TDRA + DNCR: text DNCR to 2211 or 1012; report a telemarketer by texting its number to 2211 or 1012, Dubai Police eCrime (dubaipolice.gov.ae; ecrime.ae may not load); other emirates: MOI UAE app or 999.
- **South Africa:** Information Regulator, DMASA (industry).
- **Taiwan:** 165 anti-fraud hotline + 165 online report. PDPA.
- **Thailand (stub):** AOC 1441, Thai Police Online, PDPC. **Indonesia (stub):** IASC (OJK), aduankonten.id. **Israel (stub):** Privacy Protection Authority (verify).
- **Russia:** carrier tools only; information only; never file for the user.

## Official checkers (`checker`)
Coach the user to type the number, link, or account into the official tool themselves. "No record" never means safe. HK Scameter · MY Semak Mule · SG ScamShield check (an app report is **not** a police report) · IN Sanchar Saathi Trusted Contact Details · UK 159 for any "your bank" call. Paste-verdict and link skills add one "Also check on …" line from this field.

## Company extra check (`company_checkers`)
Only after the official checker above, and only if the user wants a second opinion: **Truecaller Scam Checker** (truecaller.com/scam-checker) — say "this is a company tool, not an official one". Free web page; no app, no account. "No insights" or "Safe" never means safe. Never send it instead of the official checker, never suggest installing the app. India first (it launched there in-app); works for any country number.

## Loss recovery (`loss_recovery`)
If money, a card, or a code already left: bank 24/7 fraud line first (number on the card or app, never from the message), then the national hotline, then the police report. The bot never calls a bank or hotline for the user. Details in `after-click-loss-recovery` → "Outside the US".

## Carrier tools (`carrier_tools`)
Free native carrier and phone settings only, coaching-only. UK O2/EE/Vodafone/Three + 7726, BT Call Protect, Sky Talk Shield, Virgin Media (free part only); AU Telstra Scam Protect, Optus ScamWise, Vodafone AU "Suspected Scam" banner, reading "Unverified"; JP landline international-call stop; IN DND + CNAP; HK +852 alert; SG "Likely-SCAM". Rows with `type: phone_builtin` point to the built-ins below. US tools stay in `carrier-and-ai-call-screening`.

## Phone built-ins by country (`phone_builtins`) — as of 2026-10-31, subject to change
Free, built into the phone. Ask which phone first (Pixel / Samsung Galaxy / iPhone / other), then offer only the one that lists their country. One step at a time; the user taps.
- **Pixel Scam Detection (calls):** Pixel 9 or newer in AU, CA, FR, DE, IN, IE, IT, JP, MX, SG, ES, UK (Pixel 6+ in US). SIM from that country, phone in that country. Phone app → More → Settings → Scam Detection → on. Off by default; it beeps so the caller knows. Not for contacts.
- **Samsung Scam Detection (calls):** One UI 8.5+ in US; One UI 9 adds JP, CA (English/French) and IN (English/Hindi). Phone → ⋮ → Settings → Scam detection. Varies by model and language. Elsewhere: Phone → Settings → Call screening or Caller ID and spam protection.
- **iPhone Call Screening (iOS 26, "Ask Reason for Calling"):** English in AU, CA, IN, IE, NZ, SG, ZA, UK (and US/PR); French CA/FR; German DE; Japanese JP; Korean KR; Portuguese BR; Spanish MX/ES; Cantonese HK; Mandarin TW. Settings → Apps → Phone → Screen Unknown Callers → Ask Reason for Calling. Not while roaming. Italy not listed.
- No built-in listed for the country → Silence/Filter unknown callers and the carrier rows only. Never suggest a third-party caller-ID app instead.

## Government apps (`gov_apps`)
Free, official; the user installs them if they want (Fortress never installs or signs in).
- **SG ScamShield app:** blocks police-listed numbers, filters scam SMS. Reports made in the app **go to the Singapore Police Force / authorities** for review and can get a number blocked for everyone — but an app report is **not** a police report; after a loss also file a police e-report.
- **HK Scameter+ (HK Police):** search a number/link; Call Alert and Website Detection check on the phone against a daily scam list; Public Intelligence sends tips to the Police (still not a crime report).
- **IN Sanchar Saathi (DoT):** Chakshu report from the call log, connections in your name, CEIR lost-phone block, IMEI check, report international calls showing +91. Marketing (UCC) complaints still go to the operator within 7 days.

## India CNAP check (after 1 Nov 2026)
In setup and each monthly recheck for IN numbers: ask the user to look at the next unknown call — does a caller **name** (from the SIM's KYC) show on their 4G/5G phone? Does a call from abroad show "International Call"? If no name shows after 1 Nov 2026, coach: update the phone software, check with the operator; don't buy an app. Record yes/no/not yet + date. A shown name is not proof the caller is honest.

## Caregiver mirror (`caregiver_mirror`)
When a family member helps an elder, Fortress's own checklist comes first. If they ask about apps, name these as **the family's own choice**, with the privacy trade-off, no endorsement: Truecaller Family Protection (company app; family group, remote hang-up on Android; uploads contacts), Whoscall (company app, Asia), and the government apps above (ScamShield SG, Scameter+ HK, Sanchar Saathi IN). Fortress never installs, signs in, links family accounts, or turns anything on.

## Reply clocks (`report_windows`)
Save each request/complaint with its reference ID and `report_window_days` (see `email-report-receipts`). Defaults:
- GDPR / UK GDPR: 1 month (extendable 2 more). Then DPA / ICO.
- LGPD (BR): 15 days for the full answer. Then ANPD / PROCON.
- PIPEDA (CA): 30 days (extendable 30). Then OPC.
- AU: org gets 30 days, then OAIC; follow up if OAIC has not acknowledged in ~30 days (verify).
- NZ Privacy Act: 20 working days.
- India: UCC complaint to the operator within 7 days of the call/SMS; after 1930, file on www.cybercrime.gov.in within 24 h.
- SG: DNC wait 21 days before a PDPC complaint; PDPC replies ~5 working days.
- HK PDPO access: 40 days. MY PDPA access: 21 days (+14 with notice; s.31). Others: `null` → say "no fixed clock — check back in 30 days".
Nothing is auto-sent. Reminders only.

## Batch workflow
1. Confirm country, numbers, and confirmation email (bot inbox +tag if allowed).
2. **Block:** registries first (DNC/TPS/DNCR), then carrier tools, then directories and caller-ID unlists (Truecaller/Getcontact — user approves each), then marketing brokers. No form → draft a GDPR/PIPEDA/APP-style erasure + objection email to the DPO for the user to approve.
3. **Report:** local regulator or scam report; save the complaint ID.
4. **Letters:** objection/erasure/access to persistent callers; regulator complaint after the reply clock.
5. **Money:** follow `capability.money` wording exactly. Never promise money.
6. Work 10–20 entries per batch. Status: submitted / needs_email_confirm / needs_captcha / needs_user / blocked / not_found / already_removed / skipped / paid_only. Record date, fields sent, reference IDs, recheck date (~60–90 days). Never claim removal without page or email evidence.
7. Evidence logging (`spam-evidence-log`) still applies: skip TCPA fields; record the local report instead.

## Monthly international recheck
When country ≠ US these steps apply **instead of** the US steps 4 (DNC), 5 (7726/FCC/state AG clocks), and 7 (IC3/FTC queue). Phone Fortress’s `monthly-spam-fortress-recheck` routine runs them when country ≠ US; Email Fortress has no monthly recheck routine (run these steps manually when the owner asks):
- **I-4 Registry:** for each number, re-confirm the national register (TPS, DNCL, DNCR, NCPR/DND, REPEP, Não Me Perturbe, OFCA DNC, SG DNC, KR donotcall…) is still active: user checks the official page or the bot loads it (no login). Note registers that expire (e.g. none renew silently — record last-checked date). Any marketing call from a company after the register date → log it and point to the local report route (ICO / ACMA / DNCL / TRAI UCC within 7 days) — never TCPA.
- **I-5 Reply clocks:** list every saved request/complaint with its reference ID, sent date and `report_window_days`; flag overdue ones and draft the next step (DPA / ICO / OAIC / OPC / ANPD / PCPD) for approval. `null` window → "check back at 30 days". Also flag regulator complaints with no acknowledgment after ~30 days. Draft only; nothing is sent.
- **I-6 India CNAP (IN numbers only, after 1 Nov 2026):** run the CNAP check above; record names showing yes/no/not yet; update `in.carrier_tools` CNAP `verified_at` from an official page.
- **I-7 Scam/loss queue:** any open national report (Report Fraud, ReportCyber, IDCARE, 1930/cybercrime.gov.in, NSRC 997, 165, police e-report, Anti-Fraud Centre, Celular Seguro/B.O.) → remind the user to check status with their reference ID; if money left in the last 30 days, re-show the bank → hotline → police order. App tips (ScamShield, Scameter+ Public Intelligence, Chakshu) are not police reports — say so if one is the only report.
- **I-8 Phone built-ins re-verify:** reload the Pixel, Samsung and Apple pages in `phone_builtins`; update each `countries` list and `as_of` date. If the user's country was added → offer the step once; if removed → tell them once. Also re-ask whether their phone's feature is still on after a software update.
- Re-search directories and caller-ID unlists; summarize new / still-gone / failed. Re-verify any `verify` item touched this month (ACMA register; O2/Three menus). Parked verify rows (IL, TH, PH, RU) are not chased unless the owner asks.
US users: the routine stays exactly as before.
