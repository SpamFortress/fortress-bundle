# Protected senders

## Purpose
Make sure must-get-through mail is never blocked, junked, bulk-moved, or unsubscribed by any Email Fortress step. Source of truth: `$FORTRESS_HOME/private/safelist.json`.

## Standing rules
- Never invent domains. Only add a domain or address the user names, or one read from a real message they pasted/forwarded and confirmed as theirs.
- The user names their own banks, card issuers, pharmacy, carriers, and stores. Ask; do not guess from their state or anything else.
- Match on the authenticated From domain (DMARC aligned), never the display name.
- `auth_and_security.keywords_subject` (verification code, password reset, sign-in, security alert) always stay, even when a domain is unknown: such mail is held for review, never auto-junked.
- No passwords, account numbers, or card numbers ever. Domain or address only.
- Calm copy; one category per message.

## Process
1. Read $FORTRESS_HOME/private/safelist.json and show the categories: banks_and_cards, auth_and_security, delivery_and_orders, health_and_pharmacy, government, family_and_contacts, caregiver.
2. Coach one category at a time: "Which banks or card companies email you? Names are fine; I'll confirm the real domain from a message you forward."
3. For each name, get the real sending domain from a real message (Delivered email, header From) or the company's official site the user confirms. Record domain + note + asOf_pt.
4. Government: note IRS does not start contact by email; only add real .gov senders the user actually deals with.
5. Family / caregiver: addresses the user gives. Also suggest Apple VIP (or provider equivalent).
6. `always_allow`: one-off addresses the user wants never touched.
7. `near_misses`: whenever real mail was found in Junk or nearly actioned, log `{date_pt, from_domain, what_happened, fix}` and add the sender to the right category.
8. Save, update `updated_pt`, and mark status Page "Protected senders added" done only after at least banks + auth are seeded.

## Provider notes
- Apple Mail / iCloud: add key people as VIP; move real mail out of Junk to train the filter; never block a protected sender (blocked mail goes to Trash on iOS 26 / macOS 26). See apple-mail-harden.
- Gmail: mark as Important; create a filter on the sender with "Never send it to Spam" (and optionally Mark as important). Not spam on anything misfiled.
- Outlook: Safe senders list. Yahoo: Not spam / contacts. Proton: Allow list. GMX: Allowlist. WEB.DE: Erwünscht-Liste. Zoho: Anti-Spam Allowlist. AOL: Not Spam. Tier 3: only what that provider's official help documents.

## Output
Short confirm per category: "Banks: 2 added (from forwarded mail). Auth keywords stay on." No empty lists shown.

## One safelist file (all Fortress skills and helpers use this)
`$FORTRESS_HOME/private/safelist.json`, version 2: `categories` (banks_and_cards, auth_and_security, delivery_and_orders, health_and_pharmacy, government, family_and_contacts, caregiver; each a list of `{address}` or `{domain, subdomains}` entries), `brands` (name → official domains), `vip` (addresses or domains), `auth_keywords: on`, `near_misses`. Older flat files are migrated by `fortress_bootstrap.py preflight` without dropping entries. Proposed changes to the owner's list are shown and saved only after the owner says yes.

## How a match works (all Fortress skills use this)
- Addresses and domains are separate lists. An **address** entry matches only that exact address. A **domain** entry matches that registered domain exactly; subdomains only if the owner said so for that entry (`subdomains: true`). Compare with the **fortress-tools** `fortress_domain.py` helpers (URL parser + Public Suffix List), never by substring or "last two labels". `chase.com.secure-x.io` is not `chase.com`.
- **Authenticity is separate from safety.** A match only means "looks like a protected sender". It is trusted only when the receiving provider's own Authentication-Results show DMARC pass aligned to that domain (or DKIM pass with d= that domain). A copied/forwarded Authentication-Results header, or a DKIM-Signature merely being present, is not a pass.
- When authentication is unknown or failed and the mail matches a protected entry: **review, no automatic action** (no label, no unsubscribe, no report). Tell the owner it may be real or a spoof and how to check (open the app/site yourself).
- A domain that merely looks like a protected one gets no protection and is checked normally.
- The label scan never sees authentication results (Gmail minimal envelope), so protected matches there are always review / no write.
- **Security wording from anyone** (verification/sign-in codes, password resets, new-device or security alerts), even from a domain we have never seen: no automatic action (no label, unsubscribe or report). That is not reassurance either; Fortress doesn't vouch for it. VIP entries get the same protection as category entries.
- "On the safelist" never means "safe": an exact match with unknown or failed authentication is **review, no automatic action, no reassurance**; an authenticated match is protected from automatic actions, and its request can still be a scam (abused real services).
