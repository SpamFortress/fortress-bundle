# Privacy and OS update watcher

## Purpose
Core harden **maintenance** for Phone + Email Fortress, not a niche pack. Companies change privacy policies and ship updates that quietly turn on ad targeting, data sharing, AI "connected apps", or analytics and bug-report uploads. This skill watches **official** pages for that, and when something does change, it tells the owner in plain English and walks them to the exact toggle.

Not legal advice. Official vendor pages are the source of truth.

## Quiet rule (locked)
Message the owner **only** when:
1. A **material** change is found that plausibly affects **this owner**, or
2. The owner forwards a policy email or post, or says they updated their phone, computer, or app.

No "nothing changed" messages in Quiet mode. In Chatty mode, one short weekly line is OK. Record every check on the status board Notes (collapsed).

## What counts as material
- **Ads**: new or expanded ad targeting or personalization, cross-app or cross-device tracking, ads based on purchases, location, or search.
- **Selling / sharing**: new sharing with partners, affiliates, or data brokers; "sale" or "share" definitions widened; new opt-out-only (default-on) programs, such as carrier "Personalized" / "Custom Experience" programs.
- **Connected apps / AI**: new exceptions that let connected data (mail, photos, contacts, location, wallet) be used to train models, go to human review, or reach third parties. Examples: Gemini Personal Intelligence / Connected Apps, Search content connections, Apple Intelligence extensions.
- **Analytics / bug reports**: diagnostics, usage, "improve" sharing, search logs, or crash reports set to **ON by default** or widened.
- **New Settings toggles** after an OS or app update that leak search, location, diagnostics, contacts, or call/text history, especially ones that are ON by default.

**Not material**: reworded text with the same meaning, layout changes, new date only, security-only patches, cosmetic features. Stay silent on those.

## Sources
- Catalog: `$FORTRESS_HOME/data/privacy-catalog.json` (official URLs by category: mail_cloud, phone_os, carriers, stores_platforms, desktop_browser).
- Script: `python3 $FORTRESS_HOME/tools/privacy-watch.py check [--category C] [--id ID]` → JSON `changed / first_seen / needs_webfetch / errors`. The first run sets a baseline only. Never alert on `first_seen`.
- Snapshots and diffs: `$FORTRESS_HOME/private/privacy-watch/snapshots/`.
- **Rumors, X posts, Reddit, news** are **leads only**. Before telling the owner anything, verify the claim against the vendor's official policy, help, or release-notes page. If you can't verify it, say so plainly ("reports say X; Apple's page doesn't confirm yet") and don't coach a toggle that doesn't exist. Viral "friend in forensics / turn off number 3" posts are leads: strip the scare story, map to real Settings paths (Significant Locations, Tracking, Improve Siri, etc.), and coach only what Apple / Google document.

### Website-read order
1. Connector, if one exists for that vendor.
2. WebFetch or the script (`curl` + normalize).
3. Browser + script (for JS-heavy or bot-walled pages; `fetch: webfetch` entries).
4. Screenshots **last**, only to confirm a label on screen.
Never sign in to vendor accounts to read a policy. `signin_only` entries are links for coaching only.

## Flows

### A. Weekly routine (quiet)
1. Run the script over the catalog. For each `needs_webfetch` item, read it with WebFetch, or the browser if needed. Compare it with the stored snapshot text yourself, then save the new text and hash.
2. For each `changed` item, read the diff plus the live page section and judge whether it is material (above).
3. Release-note check: `kind: release_notes` entries (iOS updates, Google System release notes, Android bulletins, Pixel). If a **new OS version** appears, scan its notes for privacy-relevant new features or defaults (flow C).
4. **Fit to the owner**: match against their profile (phone OS and carrier, mail providers, platforms they mentioned). Skip vendors they don't use.
5. If something is material and fits, send **one** grouped message (format below). Otherwise stay silent and log it in Notes.

### B. Owner forwards a policy email or pastes a post
1. Start with **email-paste-verdict**. Many "we updated our privacy policy" emails are phishing. Never open their links. Get the vendor's official page from the catalog or by typing the domain yourself.
2. If it's real, find the official policy and its changelog or archive, compare with the snapshot (or read the "what's changed" summary), and apply the material test.
3. Reply with the format below. If it isn't material: "This one's mostly wording. Nothing new is turned on for you."
4. **Catalog grows**: if the forward revealed a new official URL (new product policy, new changelog page), add it to `$FORTRESS_HOME/data/privacy-catalog.json` with `notes: "added from owner forward <date>; verified official domain + HTTP 200"`. Never add third-party mirrors.

### C. Owner says they updated their phone or OS (or the weekly check finds a new version)
1. Confirm the device and version (iOS / Android brand / Windows), with a widget when you can.
2. Read the official release notes for that version, plus the matching settings-help pages in the catalog (analytics sharing, location, tracking, ads, Apple Intelligence / Gemini, usage & diagnostics).
3. Coach **only privacy-relevant new or changed defaults**: at most 3–5 checks, highest-impact first. **Never scareware**: no "your phone is spying on you" language and no pressure. Say plainly what each toggle does and what turning it off costs, if anything.
4. If a lead (for example an X post) claims a new update turned something on, verify it on Apple's, Google's, or the vendor's page, or by walking the owner to the setting and asking what it shows, before you call it real.
5. **iPhone post-update recheck (when iOS):** after verifying labels still match Apple Support, offer the same calm beat as **phone-setup-first** — Significant Locations (System Services), Allow Apps to Request to Track, Improve Siri & Dictation / Analytics & Improvements, Safari Hide IP Address, Precise Location per app. Prefer paths from [Location Services](https://support.apple.com/en-us/102515), [App Tracking](https://support.apple.com/en-us/102420), [Analytics sharing](https://support.apple.com/en-us/108971). Users sometimes need to re-check Significant Locations and analytics switches after a major update; say that plainly without claiming Apple "resets spy switches on purpose."
6. **Android post-update recheck:** Ads personalization / advertising ID, Location History or Timeline if present, Precise location per app — OEM labels win.

## Message format (every alert)
1. **What changed** — one or two plain sentences, with the official link.
2. **Does it hit you?** — yes / probably / no, and why (their OS, carrier, or account).
3. **Fix path** — text first, one step per message, current labels from the official help page. Example: *Settings → Privacy & Security → Analytics & Improvements → Share iPhone & Watch Analytics → off*. Widget: **Done · Can’t find it · Skip for now**. Pictures or path boards only after **Can’t find it**.
4. If a carrier or company opt-out needs a form or letter, offer it as a draft-when-ready card (**draft-when-ready** / **do-not-sell-email**). **Never silent-send.**

## Keep harden skills current
If an official page shows a Settings label that **drifted** from what a harden skill says (**phone-setup-first**, **carrier-and-ai-call-screening**, `*-mail-harden` such as **gmail-mail-harden**, **apple-mail-harden**, **outlook-mail-harden**), coach the owner with the **new** label, then update that harden skill's step text so it matches the official page. Note the change in Notes.

## Hard rules
- Not legal advice. No predictions about lawsuits, fines, or payouts.
- Official vendor pages only as sources. Rumors are leads.
- Never ask for passwords, SSN, or government ID. Never sign in to the owner's vendor accounts to "check for them". Walk them through it.
- Never change settings, submit opt-outs, or send letters without the owner's OK.
- Quiet by default: no alert fatigue. Group several changes into one message.
