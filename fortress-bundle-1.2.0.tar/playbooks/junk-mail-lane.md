# Junk mail lane (physical mail)

Same Fortress style: short steps in chat; the owner changes settings and submits forms, you only coach. Widgets **Done · Can’t find it · Skip for now**. Skip is always fine — no shame, no nag. US core.

## Hard rules
- **Never ask for, accept, or store an SSN, DOB, card number, or account number.** OptOutPrescreen asks for SSN/DOB (optional per FTC); that is a **DIY card** — the owner types it on the official site themselves. If they paste one here: "Please don't send that here — I've ignored it."
- Identify the sender **only from what's visible** (brand, return address, permit/indicia, 1-800, URL printed on the piece). If it isn't legible, say so and ask for a closer photo of the return address or back panel. **Never invent** a company, phone number, or URL.
- Never type a URL or call a number printed on a suspicious piece (fake "final notice", fake car warranty, fake check). Use the company's official site you navigate to yourself. Scammy mail → load `elder-gift-card-crypto-pack` or `email-paste-verdict` verdict style.
- Letters / removal emails: **draft-when-ready**; nothing is sent, mailed, or submitted without the owner's explicit OK.
- Never pay through the bot. DMAchoice mail registration has a small fee → DIY card only, owner decides.
- Don't store the photo's personal details beyond sender + piece type + date; redact the owner's account/offer numbers in logs.

## Free official vs paid / fake (say once when coaching opt-outs)
- **There is no national Do Not Mail list.** The USPS cannot stop ordinary Marketing Mail for you.
- **"Refused / Return to sender"** on Marketing Mail usually does nothing — carriers don't process those the way they do First-Class.
- Prefer **free official** paths below (OptOutPrescreen, publisher remove, Catalog Choice, DMAchoice, Valpak/official coupon sites, Yellow Pages opt-out, USPS Informed Delivery / Form 1500).
- **Paid removal apps** (e.g. PaperKarma and similar) are optional convenience tools — never required, never recommended as the primary path.
- **Never call or visit an "opt-out" number or URL printed on a scam-looking piece.** Look up the real company yourself.
- Look-alike "DMA registry" or "national mail stop" sites that aren't dmachoice.org / optoutprescreen.com are fake or unnecessary.

## 1. Quick verdict from the photo (2–3 lines)
- **What it is:** prescreened credit/insurance offer · catalog · magazine/subscription · coupon/"Resident" mailer · mortgage-protection / final-expense / car-warranty junk · donation/charity · political mailer · phone-book/directory · possible scam.
- **Who sent it:** brand + return address/phone if visible (quote it). Otherwise "can't read the sender — snap the return address?"
- **Best free stop:** one line from the table below.

## 2. Removal paths (free first)
| Piece | Free stop | Notes |
|---|---|---|
| **Pre-approved credit / insurance ("prescreened") offer** | **OptOutPrescreen** https://www.optoutprescreen.com/ or 1-888-5-OPT-OUT (1-888-567-8688) | Run by Equifax, Experian, TransUnion, Innovis. **5-year** online, or **permanent** (start online, then print/sign/mail the Permanent Opt-Out Election form). Processed in ~5 days; mail can take weeks to slow. DIY card — owner enters personal info. FTC: https://consumer.ftc.gov/articles/what-know-about-prescreened-offers-credit-and-insurance . **A credit freeze does not stop these offers** — freeze and opt-out are separate (`credit-freeze-planner`). |
| **Mortgage-protection / final-expense / "car warranty" / similar insurance junk (not from credit bureaus)** | Contact the mailer on the return address / official site; scam look-alikes → elder pack | These often come from deed, mortgage, or vehicle lists — **OptOutPrescreen will not stop them**. If the owner just applied for a mortgage: since **2026-03-05** the Homebuyers Privacy Protection Act restricts credit-bureau "trigger leads" sold after a mortgage application; leftover junk may still arrive from older lists — still contact the mailer. |
| **Catalog / retailer mailer** | Publisher's own "remove me from mailings" (privacy page, mailing-preferences page, or the customer-service number on the catalog's back cover / order form) | Most catalogs honor a request with the customer/key code printed near the label. Free alternative aggregator: **Catalog Choice** https://www.catalogchoice.org/ (free account; owner signs up). Heavy catalog/prospect volume → also coach Acxiom / Epsilon / Data Axle / LexisNexis from the data-broker catalog (`data-broker-opt-outs`). |
| **Magazine offers, donation, retail promos (no relationship)** | **DMAchoice** https://www.dmachoice.org/ | Stops most prospect mail from ANA members for **10 years**. Fee (as of 2026-10-31; check the live register page): **$8 online / $9 by mail** → DIY card, owner's choice. Mail-in: DMAchoice Consumer Preferences, P.O. Box 900, Cos Cob, CT 06807 (check/money order to ANA). DMAchoice Email Preference Service is **free**. Does **not** cover prescreened offers, political mail, "Resident/Occupant" mail, unaddressed mail, or companies you already buy from. |
| **"Resident / Current Occupant" mailers / coupon books** | Contact the mailer directly (name on the indicia/return). **Valpak:** https://valpak.com/remove-address · RedPlum/Vericast: find the official remove page on their site | DMAchoice doesn't cover these. Removal can take several weeks. |
| **Company you already do business with** | Its account settings or customer service: "stop promotional mail" | Opt-out lists don't override existing relationships. |
| **Political mailer** | Campaign/committee contact on the piece | Exempt from DMAchoice; log tag `political` if the owner tracks it. |
| **Yellow Pages / print phone directory** | Industry opt-out hub **https://www.optoutyp.com/** (or the publisher listed on the book) | Directory delivery only — not a general junk-mail stop. |
| **Sexually oriented ads** | USPS **PS Form 1500** (Prohibitory Order and/or listing): paper at any Post Office; electronic listing option at https://www.usps.com/soa/ when available | Narrow tool — only sexually oriented advertising, not ordinary junk. |
| **Deceased relative / dependent in care** | DMAchoice Deceased Do Not Contact / Do Not Contact for Caretakers (free) | Gentle wording. |

FTC overview (cite when helpful): https://consumer.ftc.gov/articles/how-stop-junk-mail

## 3. First-run short coach (offer once; then only on request)
Say: *A few free official moves cut most junk mail. Want to go one at a time?*
1. **OptOutPrescreen** (stops pre-approved credit/insurance offers). Pick **5 years** online, or **permanent** (online + signed mail form). *The site may ask for SSN/DOB — you type that on the official site, never here.* Log whether they chose 5-year or permanent, and whether the permanent form was mailed. → **Done · Can’t find it · Skip for now**
2. **Catalogs**: next catalog that arrives, snap the back cover — I'll find the publisher's free remove path. Optional: Catalog Choice (free). → **Done · Skip for now**
3. **DMAchoice** (optional; **$8 online / $9 mail** for 10 years as of 2026-10-31 — check live page; free for email preference) — owner decides. → **Done · Skip for now**
4. *Optional tip:* **USPS Informed Delivery** (free) emails a preview of letter-size mail so you can spot junk or stolen-mail patterns: https://www.usps.com/manage/informed-delivery.htm — owner signs up; identity check happens on USPS. → **Done · Skip for now**
5. *If directories keep arriving:* Yellow Pages opt-out https://www.optoutyp.com/ → **Done · Skip for now**
"Can't find it" → one short picture or exact page path (e.g. OptOutPrescreen → "Click here to Opt-In or Opt-Out").

## 4. Logging + light receipt (ticks + dates; channel=physical)
- Per piece: append to `$FORTRESS_HOME/private/junk-mail/log.jsonl` one line: `{"at": ISO, "channel": "physical", "piece": "prescreen|catalog|magazine|coupon|insurance_other|donation|political|directory|scam", "sender": "<as printed>", "path": "optoutprescreen|publisher|catalogchoice|dmachoice|direct|valpak|optoutyp|usps1500|broker", "status": "coached|owner_done|drafted|skipped", "recheck": ISO+60d}`.
- Coach ticks also go to `$FORTRESS_HOME/private/optout-log.json` → `items` with `"channel": "physical"` and `"site": "OptOutPrescreen"` / `"DMAchoice"` / publisher.
- Phone `$FORTRESS_HOME/private/identity.md` → `## Hardening checklist`: e.g. `- [x] OptOutPrescreen 5-year (2026-10-27); renew ~2031-10` or `- [x] OptOutPrescreen permanent form mailed (YYYY-MM-DD)` — never the SSN/DOB used. Also `- [x] DMAchoice mail (YYYY-MM-DD); renew +10 yrs` when done.
- **When the owner taps Done:** one short receipt in chat — what path, date logged, recheck ~60 days later. No separate receipt skill; keep it to 1–2 lines.
- **Recheck**: if the same sender keeps mailing 60–90 days after a logged removal, offer a short follow-up letter (draft-when-ready). The monthly Fortress recheck reads overdue `recheck` dates and OptOutPrescreen expiry / permanent-form status.

## 5. Draft-when-ready letter (publisher remove)
> Subject: Please remove me from your mailing list
> Please remove the name and address below from all promotional mailing lists, and do not rent, sell, or share it. Customer/key code from the label: [code]. Name: [name]. Address: [address]. Thank you.
Owner sends or mails it. Bot never sends without explicit OK.

## Cross-notes
- **Freeze ≠ opt-out:** An OptOutPrescreen opt-out is not a credit freeze. A freeze does not stop pre-approved mail. Pair both when the owner wants less offer mail *and* locked new credit (`credit-freeze-planner`).
- **Data brokers behind catalogs:** Acxiom (https://www.acxiom.com/optout/ or https://isapps.acxiom.com/optout/optout.aspx), Epsilon (https://legal.epsilon.com/dsr/), Data Axle (https://www.data-axle.com/privacy-rights-request/), LexisNexis (https://optout.lexisnexis.com/) — coach via `data-broker-opt-outs`; never collect SSN here.

## International
Limited. US paths above are US-only. If residence isn't US, use only what `international-privacy-packs` / `$FORTRESS_HOME/data/international.json` already lists for that country (e.g. a national mail-preference service, if listed). If nothing is listed, say: "I don't have a verified mail-preference registry for your country — contact the sender directly." **Don't invent registries.**

## Limits
Cuts most, not all, mail. Prescreen opt-out won't stop offers from non-bureau lists or companies you deal with. Never promise zero junk mail.
