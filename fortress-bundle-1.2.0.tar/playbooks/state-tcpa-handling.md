# State TCPA handling (US residents)

Use when the user's US state matters: demand letters, AG complaints, state do-not-call lists, or mini-TCPA rules. Data: `$FORTRESS_HOME/data/us-states.json` (50 states + DC + PR/GU/VI notes). Human view: `$FORTRESS_HOME/data/capability-matrix.md`. Not legal advice.

## Rules
- Use the user's **state of residence** from `$FORTRESS_HOME/private/identity.md`. Never default to California, Florida, or "federal only." If the state is missing, ask before drafting anything state-specific.
- US residents only. For a non-US resident, stop and use `international-privacy-packs`. Never apply TCPA damages to them.
- A money path is a **claim framing**, never a promise of money received. Every demand letter needs the user's explicit approval before it is sent, by email or certified mail.
- Cite only `statute_refs` and URLs that appear in the state entry. Entries in `verified_urls` were loaded on their `verified_at` date. `sources` from tcpa.com are **secondary**, so label them that way and suggest checking the official statute before sending.
- If `last_checked` is more than 6 months old, or the status is `uncertain`, say the state law needs re-checking.

## Steps
1. Load the state entry by `code`.
2. **Block pillar.** Do these every time:
   - National DNC registry status (`dnc-registry-check`).
   - The state list from `state_dnc_or_telemarketing_notes`, where the state has its own. The own-list states are FL (FDACS), MO, OK, LA (PSC), IN, CO, MA, PA, TX (PUC), AL/GA/MS (PSC), and TN.
   - Carrier tools. When `carrier_cdr_note` is set, remind the user to save call-detail records or a screenshot of their carrier history.
3. **Letters / complaints pillar:**
   - The AG complaint at `ag_complaint_url`. If it is empty (NC today), use the verified NC telephones page and tell the user the form link is unverified.
   - An FCC complaint (`fcc_reminder`).
   - The FTC (reportfraud.ftc.gov).
   - A stop/opt-out letter or an internal-DNC request.
4. **Money pillar.** Choose by `mini_tcpa_or_private_action.status`:
   - **strong**: draft the federal TCPA count plus the state count, using the amounts in `notes` (for example FL FTSA $500 up to treble; VA $500/$1,000/$5,000 escalating; MD up to $500; TX 305.053 $500/$1,500; MA up to $5,000 knowing; WA $1,000 for repeated violations; GA up to $1,000; OK $500; NC $500/$1,000/$5,000; SC $1,000/$5,000; NH $1,000; ND $2,000; MO $5,000; AL $2,000; AK $500 / 3x; CT $500 recorded messages; UT $500).
   - **limited**: draft federal TCPA only. Mention the state statute only if its precondition fits the facts (a purchase, a loss, repeated violations, an autodialer/ADAD).
   - **none / uncertain**: draft federal TCPA only. State the limitation plainly.
5. **State-specific traps** (from the data):
   - **FL:** for texts, the user must first reply STOP and allow a 15-day cure period. The autodialer definition is narrow (selection AND dialing).
   - **NY:** 399-z has no private action. 399-p/349 carry only $50–$1,000, and state-court class recovery is barred.
   - **CA:** the DNC remedy is small claims only and cannot be aggregated.
   - **WA:** CEMA texts carry $100 since 2026 c 135, not $500. 80.36.390(13) needs *repeated* violations.
   - **IL/IN/WI:** under the 7th Cir. 2026 decision (secondary source until opinion is read), texts are not "calls" for the federal DNC claim. The federal 227(b) robocall/autodialer theory may still apply, so check it.
   - **ID:** state private action only if the user *bought something* through the call (48-1007; ICPA 48-608 needs a loss). Otherwise use federal TCPA plus an Idaho AG complaint. Idaho uses the national registry as its state list.
   - **PA:** the TRA has no private action. Act 47 of 2026 (effective about Oct 18, 2026) adds texts and limits calling to 9am–7pm with no Sundays or holidays. That supports complaints, not damages.
6. Record the jurisdiction, the statute refs used, and the verification date in the evidence log and the letter metadata.

## Refreshing data
Re-verify URLs with a browser user agent. Set `verified_at` only after a successful load of the official page. If a page blocks the box, keep the old date or mark it unverified, and never guess a replacement URL.
