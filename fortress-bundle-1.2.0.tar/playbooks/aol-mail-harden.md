# AOL Mail harden (Tier 2)

AOL shares Yahoo's mail platform, so steps look like Yahoo's. Steps from AOL Help, verified from the box Oct 27, 2026. One step per message; receipts; never auto-delete; never block a protected sender.

1. **Mark Spam** — select email → Spam. Trains AOL; future mail from that sender goes to Spam. AOL's own advice: never interact with spam, including its unsubscribe link.
   **Not Spam:** Spam folder → select → Not Spam (future mail from that sender reaches Inbox — AOL's allow tool for protected senders).
   https://help.aol.com/articles/aol-mail-spam-and-privacy
2. **Unsubscribe from a trusted list** — when you click Spam on a list AOL trusts, it may offer Unsubscribe; fine for real newsletters only.
3. **Block senders** — open/select email → More → Block Senders → (optional delete existing) → OK. Unblock: Settings → More Settings → Security and Privacy.
   https://help.aol.com/articles/block-and-unblock-email-addresses-in-new-aol-mail
4. **Spoofed-mail and "phishy" warnings** — a yellow banner when a familiar display name uses a new address, or a Reply-To differs. Coach: if unsure, click Report, not "It's safe".
   https://help.aol.com/articles/additional-security-features-in-aol-mail
5. Hand off to protected-senders → identity + who-sold tip.
