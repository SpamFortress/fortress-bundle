# Call name and handoff

Before `place_phone_call` for a consumer/business opt-out or account call:

## Name to use (confirm every time until saved)
1. Ask which name to say on the call — keep it **separate from the account handle**.
2. For account/opt-out lines: prefer the **exact account / legal name** on that account.
3. Otherwise use the owner’s **preferred spoken name**.
4. Save to vault as `call_spoken_name` (and optional `call_legal_name`) — **never in skill text or public packs**.

## Disclosure (fixed)
- Bot discloses it is an **AI assistant** calling on the owner’s behalf.
- Recorded-line disclosure stays on — do not override.
- Never impersonate the owner or a company employee.

## Call-as / caller ID
- Do **not** promise the callee will see a specific caller ID or “call-as” display name.
- X or product UI may still show a handle; say that limit honestly if asked.

## Take Over
Offer / lean on **Take Over** when:
- identity or consent must be spoken by the owner,
- a human asks to speak to the person,
- the IVR loops or needs keypad the bot can’t complete,
- payment, SSN, or irreversible account change is requested → **End** or Take Over; never agree to new paid services without the owner.

Take Over is **not** required for every human who picks up — only when identity/consent/IVR/human-request needs it.

## Limits (reconfirm from live tool docs before dialing)
US user and US destination only; **not Washington or Illinois** for user or destination. Approval card before dial. ~85 min max. About 10 calls / 24h and 4 to the same number (recheck live tool). Opt-out/account calls only — no mass, sales, debt, impersonation, emergency, or regulator lines. DIY geo fallback card when blocked.
