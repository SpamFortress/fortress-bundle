# Draft when ready

## Purpose
Standing habit across Phone + Email Fortress: when the file is ready, **you** prompt a draft card (or ask what’s missing). People forget they can ask.

## Surfaces
- Dangerous scams → **regulator-scam-packet** (IC3 / FTC)
- TCPA demand → **tcpa-demand-letter** (+ **certified-mail-demand-prep** if paper)
- Carrier / FCC → **7726-and-fcc-packaging**
- Post-STOP → **stop-revocation-tracking**
- Political → **political-spam-handling**
- Do Not Sell / alias leak → **do-not-sell-email** + **who-sold-my-address**
- Resubscribe after unsub → **enforced-unsub-recheck**

## Clock triggers (check every logging turn + weekly)
Run `python3 $FORTRESS_HOME/tools/deadline-clocks.py list --due`. Any clock with `needs_action: true` is a ready item:
- `stop` + `repeat_after_deadline` → widget: Draft demand · Prep 7726/FCC · Both · Not yet (cite the 10-business-day FCC window and dates from the clock).
- `unsub` + `repeat_after_deadline` → enforced-unsub-recheck widget (Junk/block · FTC draft · Not yet).
- `gmail48` repeat → Gmail Report spam coach first.
- `unsub` + `deadline_passed_no_repeat` → quiet "honored" one-liner; mark receipt Done.
Enrichment chips (`number_intel.status_chips`, `domain_intel.why_lines`) may be quoted in drafts only as stored; never re-state counts from memory.

## Pattern
1. Check that skill’s **enough to draft** list.
2. Short calm note (counts / what’s ready).
3. **Question widget** — Draft … / Prep … / What’s missing / Not yet / Skip. Never prose-only for the ask.
4. On Draft → show text or open draft card. Owner sends. Never silent auto-file or auto-mail.
5. Gaps → widget options that collect the missing piece, then draft.

## When
Same turn as logging; weekly/monthly routines when new ready items appear. Quiet mode still means one message + widget — not silence when a draft is ready.

## Never
Invent facts, send without OK, or assume the owner knows draft cards exist.
