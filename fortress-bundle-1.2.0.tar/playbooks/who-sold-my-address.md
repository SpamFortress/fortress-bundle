# Who sold my address

## Purpose
Map tagged/aliased recipient addresses to the company they were given to, catch when an unrelated brand starts mailing that address, and help the user act. Plain confidence labels. Never accuse without evidence. Includes signup watch (alias *before* the signup) + routine hooks.

## Standing rules
- Patterns: `name+site@`, Apple Hide My Email / Sign in with Apple, SimpleLogin, Proton, Firefox Relay.
- Confidence: **Confirmed by tag** | **Likely** (+tag) | **Unknown**.
- A hit proves the address left that company (sale, share, partner, or breach) — not which. Payment/shipping "on behalf of" is not a leak.
- One primary action: Turn off this address / Draft opt-out / Log only.
- Never invent a seller. Never claim silent iCloud inbox watching — only forwarded/pasted mail + receipts.

## Enough to draft Do Not Sell
Ready when confidence is Confirmed or Likely **and** the company the alias was given to is known (not Unknown), plus the alias and approx signup purpose/date if logged. Then run **do-not-sell-email** prompt — **widget**, don't wait for them to ask.

## Process A — Signup watch (before the email is given)
1. Offer a one-site address (`signup-alias-watch`).
2. Coach Hide My Email / +tag / Relay / etc.
3. Log aliases[] + $FORTRESS_HOME/private/who-sold/signup-log.json + $FORTRESS_HOME/private/identity.md.
4. Skip / caution for bank, tax, gov, medical, important password-reset addresses.

## Process B — Spam on an alias
1. Read To / Delivered-To.
2. Match aliases / signup-log.
3. State confidence + company that was given the alias.
4. **Widget** (proactive): Deactivate alias · Draft Do Not Sell · Log only · Not yet.
5. Update incidents, receipts, Who-sold Page.

## Process C — Routine hooks
- **Weekly (Mon):** new forwards vs active aliases → incident + calm message + draft widget when enough; post-opt-out hit → Failed.
- **Monthly (1st):** portfolio review — stale watches, leaked without opt-out → same Do Not Sell widget when enough.

## Privacy
Unknown is valid. No HQ pin unless verified.
