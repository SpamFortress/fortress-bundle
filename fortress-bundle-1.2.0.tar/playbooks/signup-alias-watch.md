# Signup alias watch

Goal: get ahead of a company that sells or shares an email address after a one-purpose signup. The trick is that each site gets **its own address**. If marketing from a different brand later lands on that address, we know who leaked it, and the user can switch that one address off without touching their real inbox.

Honest limit: on Apple iCloud there is no mail connector. I only see mail the user **forwards or pastes** (plus receipts already logged). I never say I'm "watching the inbox" silently. The weekly and monthly routines look at what was forwarded/pasted since the last run.

## Hard rules
- Never store passwords, security answers, account numbers, or one-time codes. An alias address + who it was given to + date is all we log.
- Only log aliases the user tells me about (or creates with me in chat). Never guess.
- Never invent a seller, buyer, or "data partner". Unknown is a valid answer.
- Never disable an alias, block, report, or send an opt-out for the user. Coach the steps; drafts only; user OK every time.
- Protected senders (`$FORTRESS_HOME/private/safelist.json`) — banks, 2FA, password resets, pharmacy, government, family — never get swapped to throwaway aliases without the user choosing it, and never get auto-actioned.

## 1. Before you give an email (coach, ~30 seconds)
Trigger phrases: "I'm signing up for…", "applying for…", "they want my email", "entering a contest", "getting a coupon".

Say: "Quick tip before you type your email — want a one-site address for this? If it ever gets sold, we'll know exactly who did it and you can switch it off."

Pick the user's tool (one, not a menu wall):

| Service | How | Strength as evidence | Official help |
|---|---|---|---|
| **Apple Hide My Email** (iCloud+) | Safari offers it in the email field; see §5 | Strong — random, one-site address | https://support.apple.com/guide/iphone/use-hide-my-email-iphbb888fde2/ios |
| Sign in with Apple → Hide My Email | Address ends `@privaterelay.appleid.com` or `@private.icloud.com` | Strong | https://support.apple.com/en-us/105078 |
| Plus-tag (`name+sitename@…`) | Add `+sitename` before the @ | Weak/Likely — marketers can strip or guess tags | Gmail: https://support.google.com/mail/answer/22370 |
| SimpleLogin | Create an alias in the app/extension | Strong | https://simplelogin.io/docs/ |
| Proton aliases / Proton Pass | Create alias in Proton | Strong / Medium | https://proton.me/support/addresses-and-aliases |
| Firefox Relay | Create a mask at relay.firefox.com | Strong | https://relay.firefox.com/ |

Then: "Give **that** address to the site, not your main one."

When **not** to use an alias (say so plainly): bank, tax, government benefits, doctor/pharmacy, job applications where the employer must reach you reliably, password-reset address for an important account.

## 2. Log the alias (who-sold map)
Append to `$FORTRESS_HOME/private/who-sold/map.json` → `aliases[]` (never overwrite rows): address, given_to, date_given_pt, service, active, purpose, note. Also add a watch row to `$FORTRESS_HOME/private/who-sold/signup-log.json` and mirror in `$FORTRESS_HOME/private/identity.md`. Confirm in one line.

## 3. What a sale / share looks like
| Pattern | Confidence |
|---|---|
| Random alias given to one company receives marketing from a different brand | **Confirmed by tag** |
| Plus-tag receives mail from an unrelated brand | **Likely** |
| Same company, now "partner offers" | Same company — check privacy settings |
| Bare primary address | **Unknown** |
| Payment/shipper clearly serving the original signup | Not a leak (service provider) |

Wording: "This address was only given to <company>. Mail from <other brand> means it got out from there — sold, shared, or leaked."

## 4. After a leak (one primary action, user OK)
1. **Disable the alias** (Hide My Email: Settings → [name] → iCloud → Hide My Email → Deactivate). Warn if they still need the original company's mail.
2. **Junk + block** the third-party sender. Phishing → Report, never Unsubscribe.
3. **Draft a Do Not Sell / opt-out** (`do-not-sell-email`). User sends.
4. **Log** incident, alias inactive if disabled, receipts.

## 5. iOS Hide My Email (Apple official)
Requires iCloud+. In Safari: tap email field → Hide My Email → Continue. In Settings: [name] → iCloud → Hide My Email → Create New Address. No iCloud+? Offer plus-tag (weaker) or a free alias service.

## 6. Automation hooks
Weekly alias leak watch (Monday) and monthly alias portfolio review — quiet when nothing found. Inputs: forwarded/pasted mail + receipts only on iCloud.

## Never
Silent inbox scanning, storing passwords/codes, inventing sellers, disabling aliases or sending letters for the user, or treating a service provider as a buyer.
