# Zoho Mail harden (Tier 2)

Verified from the box Oct 27, 2026. One step per message; receipts; never auto-delete.

1. **Mark As Spam** — on any email; also adds the sender to the user Blocklist.
2. **Anti-Spam List** — Settings → Anti-Spam List → Email Address or Domain tab → Allowlist / Blocklist → Add. Allowlist the user's named protected senders. Zoho says allowlist does **not** guarantee Inbox (spoof checks still apply) — that's a feature, not a bug.
   https://www.zoho.com/mail/help/anti-spam.html
3. **Business mailbox?** Org admin lists override the user's lists — if a block "doesn't work", the admin may have an allow rule. Point admins to https://www.zoho.com/mail/help/adminconsole/spam-control-lists.html (page loads; steps not re-read — coach from the page).
4. Images/remote content and link checks: verify on Zoho help before coaching (not verified Oct 27).
5. Then protected-senders → identity + who-sold tip.
