# Enforced unsubscribe recheck

US law: after an opt-out request, a sender may not send further commercial email covered by that request **more than 10 business days** after receiving it. 15 U.S.C. § 7704(a)(4)(A) (CAN-SPAM; govinfo text: https://www.govinfo.gov/content/pkg/USCODE-2023-title15/html/USCODE-2023-title15-chap103-sec7704.htm). Other countries: use `$FORTRESS_HOME/data/geo-packs.md` (e.g. Australia ACMA: unsubscribe honored within 5 business days). Political, transactional, and charity mail may fall outside commercial rules. Say so, and don't promise enforcement.

## Clocks (run, don't eyeball)
```
python3 $FORTRESS_HOME/tools/deadline-clocks.py list --due      # open/overdue unsub + Gmail 48h clocks
python3 $FORTRESS_HOME/tools/deadline-clocks.py list --write    # store clocks + recheck_after_pt on receipts
python3 $FORTRESS_HOME/tools/deadline-clocks.py compute --kind unsub --start <sent_at> --contact <repeat>
```
- `unsub`: 10 US business days (federal holidays excluded) after the request → CAN-SPAM line above.
- `gmail48`: when the receipt has `one_click: true` or the where/destination mentions Gmail (Manage subscriptions / one-click), a 48-hour expectation clock. **This is a Gmail sender guideline, not law.** A repeat after 48h → coach Gmail **Report spam** first (provider recourse). Regulator drafts only after the 10-business-day clock also passes.
- Log repeats on the receipt as `repeat_contacts: [{"at": ...}]` so the tool classifies them (`repeat_within_window` vs `repeat_after_deadline`).
- `repeat_after_deadline` on `unsub` = Enough-to-draft trigger below.

## Hard rules
- Never auto-unsubscribe, auto-delete, auto-report, or auto-block. Every action needs the user's OK (per batch is fine).
- Never open or use links inside the messages being checked. Never use an unsubscribe link in a message that looks like phishing; Report phishing instead.
- Protected senders (`$FORTRESS_HOME/private/safelist.json`) are never flagged.
- No legal threats in the user's name; no promises of fines or payouts.
- **Quiet mode:** nothing due or nothing repeated → no message. Update status Page counts only (asOf in the owner timezone).

## Inputs (and honest limits)
- Receipts log (`email-report-receipts`, `$FORTRESS_HOME/private/email/receipts/index.json`): unsubscribe entries with `sent_at` (UTC instant + owner-timezone label), sender, domain(s), campaign tag, `one_click`.
- Evidence index: `$FORTRESS_HOME/private/phone/evidence/index.json` on Phone Fortress, `$FORTRESS_HOME/private/email/evidence/index.json` on Email Fortress, plus mail the owner forwarded to the bot inbox or pasted since the request.
- Held-for-review items only if `$FORTRESS_HOME/private/settings.json` opt-in exists.
- iCloud has no connector here. Never claim to have scanned the inbox. A run sees only what was forwarded, pasted, or logged.

## Enough to draft (optional FTC / geo report)
Ready when you have: original unsub date + receipt; repeat date; sender/domain/campaign match; what the repeat looked like (subject/snippet). Loss amount not required for commercial resub reports.

## Flow
1. **Find due receipts:** run `$FORTRESS_HOME/tools/deadline-clocks.py list --due`. Unsubscribe receipts ≥ 10 US business days old (non-US: `$FORTRESS_HOME/data/geo-packs.md` window) with status `Waiting` → `Check due`. Also surface `gmail48` overdue ones.
2. **Match repeats:** same sender address, same domain, or same campaign tag. For rotating domains, match brand/footer/campaign tag as in the who-sold Oral-B case and mark it `likely same campaign`. It's never certain unless the headers match.
3. **No repeat seen** → receipt `No repeat observed` with the observation scope (what the bot could see: forwards, pastes, connector items under opt-in). That is not proof the sender stopped. Mark `Done — honored` only when the owner confirms nothing arrived in their inbox, or a connector check under an existing opt-in covered the window.
4. **Repeat found** → one calm message for the whole batch, e.g.
   > "<Sender> sent again on <date>, <n> business days after you unsubscribed on <date>."
   Then a **widget** (don't wait for them to remember drafts):
   - Junk + block coach (primary) · Log only · Draft FTC / regulator report · Not yet
5. On Junk/block OK: coach steps from the provider harden skill. Log in `email-evidence-log` with `post_unsub_repeat: true`, both dates, and the business-day count. Receipt → `Failed — repeat after unsub`.
6. On Draft report: US → FTC https://reportfraud.ftc.gov/ draft card. Non-US → `$FORTRESS_HOME/data/geo-packs.md` regulator line. The owner submits.
7. 3+ repeats in 30 days from the rotating campaign → suggest a Hide My Email / plus-tag alias (`who-sold-my-address`) + a Do Not Sell draft prompt if enough info (`do-not-sell-email`).

**"Pause without unsubscribing" / keep trashing a list.** If the owner wants a list gone from view but doesn't want to unsubscribe (or the unsub failed), coach the app's own rule, which the owner creates: Gmail filter "from:sender → Skip the Inbox / Delete"; Outlook **Sweep** ("move all future" to a folder, preferred over delete) or a Rule; Apple/iCloud.com Mail rule → move to folder. Never on a protected sender. Log it as a receipt `type: rule` so the monthly recheck can still count repeats as evidence.

## Monthly add-on (1st of month run only)
- **Full resub sweep:** every receipt marked `Done — honored` or `No repeat observed` → any mail from that sender/domain since? → reopen as `Failed — resubscribed` with dates (catches quiet re-adds after the first window).

## Optional fold-in: weekly alias leak scan (same Monday run)
If the owner approved it (`$FORTRESS_HOME/private/settings.json` § Strengthened weekly prompt), after step 7 compare recipients of new evidence with `$FORTRESS_HOME/private/who-sold/map.json` aliases and `$FORTRESS_HOME/private/who-sold/signup-log.json`. A third-party hit → incident row (random alias = Confirmed by tag; +tag = Likely), signup → `leaked`, and include it in the **same** single message with one offer (deactivate alias / block / Do Not Sell draft). Past-window `optout` receipt with a new hit → `Failed`. Never deactivate, block, or send; never invent a buyer. See `who-sold-my-address` / `signup-alias-watch`.

## Output
- Receipt state updates + one-line entry for the weekly caregiver summary (counts only; only if `caregiver-view-act` is on).
- Status Page counts with asOf in the owner timezone.
