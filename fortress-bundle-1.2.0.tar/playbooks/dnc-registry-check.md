# DNC registry check

## Scope
National Do Not Call Registry (donotcall.gov). Registration lasts a long period but verification / confirmation emails and status checks still matter for evidence.

## Process
1. Confirm which phone number(s) to check from the vault identity pack.
2. Guide or drive the official donotcall.gov verification / registration flow.
3. Try CAPTCHAs yourself first; hand off only if you can't. Codes go through the platform's secure form or the owner types them on the official site; never ask for them in chat.
4. Log: date checked, number(s), result (registered / not / pending), screenshot or confirmation text if available, next reminder date.
5. Never use unofficial paid "DNC" services.

## Reminders
On monthly fortress routines, remind the user to re-verify status and keep confirmation records with the evidence store.
