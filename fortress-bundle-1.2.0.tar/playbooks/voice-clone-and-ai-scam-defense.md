# Voice clone and AI scam defense

## Family safe word / challenge (coach; never store the word)
A short secret word or question the household agrees on in person, so anyone can check "is it really you?" on a scary call. The FBI recommends exactly this: *"Create a secret word or phrase with your family to verify their identity."* (FBI IC3 PSA I-120324-PSA, https://www.ic3.gov/PSA/2024/PSA241203).

Coach in 4 short steps (widgets **Done · Can’t find it · Skip for now**):
1. **Pick it together, in person or on a call you started** — not by text/email/social. Something odd and unguessable (not a pet's name, street, school, or anything posted online).
2. **Optional challenge question** instead of/in addition to the word (e.g. a shared memory only the family knows). Agree that the person in trouble must say it **without being prompted with hints**.
3. **Tell who's included** — kids, grandparents, caregivers. Older relatives get the live-call script below on paper by the phone.
4. **Don't post it, text it, or save it in a shared note.** Change it if it's ever used or overheard.

**Storage rule:** **never** ask for, accept, or store the word or answer. If the owner types it: "Please don't send it here — I've ignored it. Consider picking a new one." Store only a tick: `$FORTRESS_HOME/private/identity.md` → `## Hardening checklist` → `- [x] Family safe word set (2026-10-28)` (who's covered, optional: "Me, Mom, kids").

**Widget offer** (after a voice-clone / family-emergency verdict, or during setup): **Set a family safe word reminder** · **Already have one** · **Skip for now** → coach steps above only. If they want a nudge to set it with relatives later, offer a one-time reminder routine (parent creates it); the reminder text never contains the word.

## Live-call script (read it, keep it by the phone)
If someone calls claiming to be family (or a lawyer, police, hospital for family) in trouble:
1. **"I'm going to hang up and call you right back."** Then hang up — even if the voice sounds exactly right.
2. **Call the real number you already have** for that person (saved contact). No answer? Call another family member or friend who'd know.
3. If you can't hang up yet: **ask for the safe word.** Don't hint at it.
4. **Wrong word, won't say it, "no time," or more pressure → hang up.** Real family will understand.
5. **No money, gift cards, crypto, wires, or cash couriers** on the strength of a call. Ever.
6. **Tell someone you trust** right away, then report at https://reportfraud.ftc.gov/ (and https://www.ic3.gov/ if money moved).
Basis: FTC "Don't trust the voice. Call the person who supposedly contacted you… Use a phone number you know is theirs" (https://consumer.ftc.gov/consumer-alerts/2023/03/scammers-use-ai-enhance-their-family-emergency-schemes) and FBI PSA I-120324-PSA ("hang up… call the phone number directly"; family secret word).

## Basic guidance (include when relevant)
- If a call claims urgent family emergency: **hang up** and call back on a known-good number you already have — do not trust caller ID.
- Do not send money, gift cards, or codes based on a voice call alone.
- Unexpected "verify your account" calls: hang up; use the official app or website you navigate to yourself.
- Short-clip risk: a few seconds of voice can be cloned. It's fine to let unknown numbers go to voicemail / carrier or OS call screening; consider limiting public voice/video posts.

## Spoofed caller ID & "verified" calls
- **Caller ID can be faked** — a call can show your bank's, the police's, a family member's, or **your own** number. Seeing a familiar number proves nothing; a phone can't prove a spoof, only show signals.
- **"Verified" / check mark** (STIR/SHAKEN) means the carrier vouched the caller may use that number — not that the caller is honest. **No badge** means nothing either way. Neither replaces hanging up and calling back.
- **Golden rule:** hang up, then call the number on your card, statement, or saved contact — never the number that called, never a number they give you.
- **Off-platform push:** "let's move to Telegram / WhatsApp / Signal", a `t.me/` or `wa.me/` link, or a QR → high risk. Don't open it; log it (`spam-evidence-log`, `off_platform_bait`).
- **Rotating numbers:** a new number with the same story is the same operation — log into the same campaign; blocking each is fine but won't stop the pool.
- **Fake "proof" video/voice or "I recorded you" threats:** AI can fake a voice or face. **Don't pay, don't reply, screenshot the threat, report to FTC (https://reportfraud.ftc.gov/) and IC3 (https://www.ic3.gov/); never pay a "removal" or "recovery" firm.**
- **Protect the number itself:** carrier lock (T-Mobile Port Out Protection · Verizon Number Lock + SIM Protection · AT&T Wireless Account Lock) plus a strong account passcode. A SIM PIN does not stop a remote SIM swap.

## Limits
Defensive hygiene, not a guarantee against scams. Pair with carrier / OS call-screening guidance (`carrier-and-ai-call-screening`) and `elder-gift-card-crypto-pack` when money is requested.
