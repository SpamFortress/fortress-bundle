# Multi-number household

## Model
Identity pack may list multiple numbers. Each gets:
- `phone_id` (short label: primary-cell, home-landline, kid-phone, voip, etc.)
- type: cell | landline | voip | unknown
- owner/label (self or household member first name/relationship only — minimize PII)
- linked evidence path: `$FORTRESS_HOME/private/phone/evidence/<phone_id>/`
- protected numbers: `$FORTRESS_HOME/private/household.json` → `phones[]` `{phone_id, label, type, number_e164}` (add/remove here when the owner adds or drops a number; evidence stays in each lane's evidence index)

## Family / member picker
When more than one person or number is on file, open with a clear picker: **Me / Dad / Partner / …** (labels the user already gave). CAPTCHA handoffs, DIY cards, and opt-out logs must state **whose** listing. Never invent household members.

## Rules
- Opt-outs and DNC checks run per number the user marks for protection.
- Demand letters can cover one number or a household set when evidence supports it; still need explicit send approval.
- Landline vs cell matters for TCPA framing — record type accurately; ask if unknown.

## Brazil: Celular Seguro trusted person (BR only; added 2026-10-30)
If a household member lives in Brazil, mention once: in the free gov.br **Celular Seguro** app each person can register **Pessoas de Confiança**. A trusted person can raise the stolen-phone alert for them (Telefones de Confiança → device → Alerta; recovery mode or full block of IMEI, line, partner accounts). The alert does not replace a B.O. at the state Polícia Civil. The user sets this up; the bot only coaches. Source: https://www.gov.br/mj/pt-br/acesso-a-informacao/acoes-e-programas/celular-seguro/tutorial-1 (checked 2026-10-30).
