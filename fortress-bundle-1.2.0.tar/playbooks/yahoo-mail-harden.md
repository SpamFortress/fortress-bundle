# Yahoo Mail harden

## Purpose
Coach Yahoo's own tools one step at a time before bot logging. Steps from Yahoo Help (verified from the box Oct 27, 2026; Yahoo is rolling out "New Yahoo Mail", so menus may differ — link the Yahoo page if so). AOL Mail has similar tools; verify on AOL Help before coaching AOL steps.

## Standing rules
- One step per message; receipts; never auto-delete; phishing → spam, never unsubscribe.
- Blocking sends future mail away from Inbox — never block a protected sender.
- Privacy line once.

## Steps (in order)
1. **Mark as spam** — select email → Mark as spam. Trains Yahoo's filter and routes future mail from that sender to Spam. For a trusted mailing list Yahoo may offer **Unsubscribe** instead — fine for real newsletters, never for lures.
   **Not spam:** Spam folder → select → Not spam (future mail from that sender goes to Inbox — this is Yahoo's closest "allow" tool for protected senders).
   https://help.yahoo.com/kb/manage-spam-mailing-lists-yahoo-mail-sln36724.html
2. **Block addresses** — More options → Settings → Security and Privacy → Blocked addresses → Add → Save (up to 1,000 addresses). Weak against rotating From; use Mark as spam on each copy.
   https://help.yahoo.com/kb/new-yahoo-mail/block-unblock-email-addresses-yahoo-mail-sln36701.html
3. **Subscriptions view** (real newsletters) — left side Views → Subscriptions → select → Unsubscribe. It may not list every sender.
   https://help.yahoo.com/kb/SLN36325.html (Views; verify the Subscriptions section on the user's version)
4. **Expectations** — Yahoo's own tips: don't reply to unknown senders, don't interact with mail in Spam, avoid sites claiming to remove you from spam lists. Unsubscribes can take days (Yahoo's own marketing mail: up to 10 days — https://help.yahoo.com/kb/SLN5154.html).
5. Images/remote content: verify current Yahoo setting on Yahoo Help before coaching (not verified Oct 27).
6. Hand off to `protected-senders`, identity + who-sold tip.

## Receipts
Each action → receipt: what, where (Yahoo), when (owner timezone), what happens next.
