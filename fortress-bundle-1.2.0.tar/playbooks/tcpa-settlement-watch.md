# TCPA settlement watch

## Purpose
Lightweight tracking of publicly reported open TCPA (or closely related telemarketing) settlements / claims the user might check for eligibility.

## Process
1. On monthly research or when the user asks, note publicly described settlements (defendant name, claim window if published, official claims-administrator URL when found).
2. Store under `$FORTRESS_HOME/private/settlement-ledger.json (seed list: $FORTRESS_HOME/data/settlements-public.json)` with `status`: open | closed | unknown, and `last_checked`.
3. Remind the user to verify eligibility themselves on the official site. Match against their evidence only as a hint (same company/number), never as a guarantee.

## Hard limits
- No outcome or dollar promises.
- No filing claims for the user unless they explicitly ask and approve each step.
- Prefer official administrator / court pages over aggregator blogs.
- Not legal advice.
