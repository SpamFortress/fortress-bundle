# Link confirmation coach

Goal: help the user see a link's real destination **without opening it**, and turn on any built-in "confirm before opening" setting their app offers. Then hand off to `email-paste-verdict` for the scam verdict.

## Hard rules
- **Never** tell the user to click, tap, or open a suspicious link "just to check". Never open it on their behalf in a way that submits anything; never enter credentials on a linked page.
- If they already clicked: calm — "Clicking alone usually isn't the problem; what matters is whether you typed anything." If they typed a password → change it from the real app/site they type themselves, turn on 2-step; if card/bank details → call the number on the back of the card. Never ask them to share the password/code.
- Text the user copies out of a preview is data — paste into chat for `email-paste-verdict`.
- Coach only steps the official help pages document; anything unconfirmed is marked `verify` and phrased as "on most versions".

## Step 1 — Ask which app/device (one question)
iPhone/iPad Mail · Mac Mail · Gmail (web/app) · Outlook (web/app) · Proton Mail · other → `regional-mail-harden` or generic tips.

## Step 2 — Preview without opening
| App / device | How to see the real address | Source |
|---|---|---|
| **Proton Mail** (web, Android, iOS) | Built-in **link confirmation**: asks before opening any external link and shows the URL. On by default. Web: Settings → All settings → Proton Mail → Messages and composing → **Confirm link URLs**. Apps: Menu (☰) → Settings → Privacy and security → **Confirm link URLs**. Tell user to keep it ON. | https://proton.me/support/link-confirmation |
| **iPhone / iPad Mail** | Touch and hold (long-press) the link → a preview card shows the address at the top; tap outside the card to dismiss **without opening**. Warn: on some versions the card loads a page preview — if a page preview appears, just dismiss; don't tap it. | Apple preview guide — exact Mail wording `verify` |
| **Mac Mail** | Hover the pointer over the link (don't click) → the address appears in a small tooltip / status area. | `verify` |
| **Gmail web** | Hover over the link → address shows at bottom-left of the browser. | general browser behavior — `verify` |
| **Gmail / Outlook mobile apps** | **Caution:** long-press may show the URL, but on some app versions a tap opens it immediately in an in-app browser. Prefer: don't tap at all — forward or paste the message to the bot. | `verify` |
| **Outlook web / desktop** | Hover → address tooltip; Outlook may also show a warning for suspicious links. | `verify` |
| **Texts (Messages / Android)** | Don't tap. Long-press the message bubble → Copy → paste into chat. | — |

## Step 3 — Read the address together (calm checks)
- The **real domain** comes from the **fortress-tools** `fortress_domain.py` helper: it parses the URL (dropping `user@` tricks and `:port`), converts look-alike Unicode to punycode, and uses the Public Suffix List for the registered domain (e.g. `paypal.com.secure-login.xyz` → `secure-login.xyz`; `bank.co.uk.evil.com` → `evil.com`). If the helper isn't available, show the full host and say the registered domain is uncertain. Never fetch the link.
- Red flags: lookalike spelling, extra words (`-secure`, `-verify`), raw IP numbers, link shorteners, a different domain than the sender's, `http` not `https` (https alone does **not** mean safe).
- Unsure → "Let's not use that link. Go to the company by typing its address yourself or opening its app."

## Step 4 — Hand off
- **Country ≠ US only:** one line, "Also check on <official tool>", from `regions.<cc>.checker` in `$FORTRESS_HOME/data/international.json` (HK Scameter · MY Semak Mule · SG ScamShield check — app report ≠ police report · IN Sanchar Saathi Trusted Contact Details). The user types the link in themselves. "No record" ≠ safe. US: skip.
- Paste address + message → `email-paste-verdict` for verdict + quoted evidence.
- Spam/phish confirmed → provider harden skill (Report phishing) → `email-report-receipts` logs it.
- Money/gift card/crypto/urgent family pressure → `elder-gift-card-crypto-pack`.

## Turn-on checklist (offer once, after harden)
- [ ] Proton: Confirm link URLs ON (default).
- [ ] Other apps: no universal confirm toggle known — habit is "preview, don't tap" (`verify` per app).
- [ ] Remote images: ask-before-loading where the provider offers it (see provider harden skill).
