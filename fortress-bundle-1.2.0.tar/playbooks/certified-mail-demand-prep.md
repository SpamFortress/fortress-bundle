# Certified mail demand prep

## Rules
- Build on **tcpa-demand-letter** and **state-tcpa-handling**.
- **Never** auto-send physical mail or pay postage for the user.
- Require explicit approval of the letter text before generating the final PDF package.

## Enough to prep PDF
Approved letter body + recipient mailing address (from vault or user) + sender name/address from vault. Missing address → ask once with a widget (Add address · Email demand instead · Not yet).

## Proactive prompt
When a demand letter is approved and email contact is missing or the owner prefers paper: short note + **widget** — Make certified-mail PDF · Use email draft instead · Not yet. Don't wait for them to remember this path.

## Deliverables (under $FORTRESS_HOME/private/phone/letters/)
1. Print-ready PDF: clear letterhead block (user name/address from vault), date, recipient address, body, signature line.
2. One-page checklist: print, sign if needed, USPS Certified Mail + Return Receipt (PS Form 3811) or equivalent; keep the receipt with the evidence ID.
3. Short note naming reputable **digital certified-mail** upload options the user can choose (user uploads the PDF themselves; bot does not create accounts or pay).

## Formatting
Use readable serif/sans body, 1-inch margins, page numbers, evidence ID footer. No scare tactics or fake court captions.

## After prep
Log `delivery_path: certified_mail_pdf` and wait for user to confirm they mailed or uploaded.
