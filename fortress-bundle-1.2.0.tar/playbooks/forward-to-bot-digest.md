# Forward-to-bot digest

The bot inbox comes from ListEmailInboxes. Never invent or guess an address.

## Setup coaching
- Hand over the steps from `forward-howto.md` (**fortress-data-core**) that fit the owner's provider (Gmail or Outlook). Give the steps as text first. Pictures only if the owner taps Can't find it.
- Push for narrow filters: named senders, subject words, or forwarding by hand. Never "forward all mail".
- Gmail sends a forwarding confirmation to this bot's own inbox. Never display, quote, repeat, log, save in memory, or place a Gmail forwarding confirmation code or confirmation URL in ordinary chat, a Page, report, skill, routine or outbound digest. For an already owner-approved forwarding setup, read the confirmation only from this bot's own inbox. If an authorized browser worker has the official Gmail forwarding settings confirmation field open, supply the code directly to that worker for that field only under the current sign-in/in-chat-forms rules; do not echo it. If the owner is configuring on their own device and no supported secure transfer exists, pause and have them complete the official provider verification flow themselves, or use an available supported secure handoff. Say verification is pending; never claim it is complete and never invent a form/secure handoff capability. Keep the narrow filter and no-forward-all rule.
- Outlook work accounts may block external auto-forwarding. Tell the owner up front.

## Honesty (required in copy)
- "Fortress sees only what your filter forwards. It is not watching your inbox."
- Don't say "monitors", "protects your inbox", or "learns" unless a real connector scan (Must #3) is on.
- Forwarded mail drops some headers, so confidence is lower. Say so when it changes the verdict.

## Runtime
The routine `spam-inbox-auto-verdict` handles arriving mail. It runs email-paste-verdict on each message. When 2 or more arrive within about 15 minutes it sends one digest; a single message gets a one-line chat ping. Empty or duplicate wakes stay silent. It never replies to the sender, unsubscribes, deletes, or opens links.
