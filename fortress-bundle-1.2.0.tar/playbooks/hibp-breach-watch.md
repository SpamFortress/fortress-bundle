# HIBP breach watch (DIY, free)

## Why
After a breach, scammers send "verify your account", "refund", or "security alert" mail pretending to be the breached company, often using real details from the leak. Knowing which brands leaked lets us expect that mail and be firmer about it.

## Hard rules
- **No paid API.** The HIBP API needs a paid key. We do not call it, scrape it, or ask the owner for one. DIY only: the free Notify Me page plus our own brand list.
- **Owner enters their own address** at https://haveibeenpwned.com/NotifyMe. The bot never submits the form for them.
- **Never ask for or accept a password**, even "to check it". If they type one in chat: tell them calmly not to share it, suggest changing it, and don't store it. (HIBP's Pwned Passwords page exists, but only the owner uses it, on their own device.)
- No SSN, card, or bank numbers. `$FORTRESS_HOME/private/breach-watch.json` holds brands and dates only, never addresses.
- Calm tone. A breach notice is common and usually means "watch for phishing", not "you've been robbed".

## Flow A: first-time setup (one step per message)
1. "Want a free heads-up if your email shows up in a future breach? Have I Been Pwned has a Notify Me page. You type your address there yourself, then click the confirmation email they send you." Link: https://haveibeenpwned.com/NotifyMe
2. After they say done: bump `notify_me.addresses_enrolled_count` and `last_coached_pt` (count only). Remind them: the confirmation email comes from Have I Been Pwned and they asked for it, so clicking that one is fine.
3. Optional, only if they ask about past breaches: they can search their address on the HIBP home page themselves. We never ask which breaches they're in. They can tell us brand names if they want them watched.

## Flow B: a breach is mentioned (HIBP alert, company notice, news, owner says so)
1. **Check the notice itself first.** A "you were breached" email can be phishing. Run `email-paste-verdict` if it was pasted or forwarded. Real HIBP notices come from haveibeenpwned.com and never ask for a password or payment. Real company notices tell you to go to their site yourself.
2. **Add the brand** to `$FORTRESS_HOME/private/breach-watch.json` → `brands[]` with: `brand`, official `domains` (read from the brand's own site, never from the notice's links), `source`, `breach_date`, `data_types`, `added_pt`, `expect_phishing_until` (default +180 days), `status: watching`.
3. **One primary action**, picked by data type:
   - password or hash leaked → "Change that password on the real site or app (typed yourself), plus anywhere you reused it." Then offer 2-step sign-in.
   - email + name/phone/address only → "Nothing to change. Just expect fake '<brand>' mail for a while. Forward anything doubtful to me."
   - SSN, DOB, or financial data → offer `credit-freeze-planner` (owner decides).
4. Tighten protections for this brand (below). Confirm quietly: "Added <brand> to your watch list."

## While a brand is on the watch list
- **Verdicts (`email-paste-verdict`):** mail claiming to be a watched brand that asks you to sign in, verify, claim a refund or credit, or call a number gets at least `Suspicious`, with one Why line: "<Brand> had a breach on <date>; scammers often follow up pretending to be them." Correct use of personal details doesn't make it real. Next step: open the real app or site yourself.
- **Protected senders (`protected-senders`):** if the brand is on the safelist, keep it there (real mail must still arrive) but note its **exact** sending domains. Look-alike domains never inherit protection. If someone asks to add a watched brand to the safelist, add only the official domains.
- **Fraud watch:** if `fortress-fraud-watch` sees a live wave for a watched brand, it can mention it in its normal banner. No extra alert from this skill.
- Log each matching verdict in `hits[]` (evidence id + verdict only).

## Monthly recheck (step "Breach watch")
- `watching` rows past `expect_phishing_until` with no hits in 60 days → `quiet` (no message).
- New hits this month → one line in the monthly report.
- `notify_me.addresses_enrolled_count == 0` and never coached → one gentle reminder at most, then don't repeat for 90 days.
- Nothing to say → quiet mode.

## Related
`mailbox-takeover-check` (if a breach comes with a strange sign-in or forwarding rule) · `credit-freeze-planner` · `email-paste-verdict` · `protected-senders` · `after-click-loss-recovery` (if they already entered details).
