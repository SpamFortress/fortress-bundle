# Reverse number identification

## Purpose
After (or while) logging spam evidence, attempt public identification of the real company, campaign, committee, or vendor behind the calling/texting number.

## Process
1. Take the number exactly as shown (normalize for search; keep original in the record).
2. Run public reverse lookups and free people-search / business-search results only. Never pay for lookup tools. Never call the spam number back.
3. Cross-check message branding, "paid for by", CNAM-style clues, short-code registries, and known vendor patterns.
4. Store with the evidence record:
   - `id_status`: identified | partial | spoofed_or_untraceable | not_attempted
   - `entity_name`, `entity_type` (company / campaign / committee / lead-gen / unknown)
   - `sources` (URLs or site names + date checked)
   - `confidence`: high | medium | low
5. Flag spoofed/untraceable clearly when lookups conflict or point to unrelated consumers.

## Number enrichment (public complaint data + block carrier)
After the reverse-lookup step, run (or confirm spam-evidence-log already ran):
```
python3 $FORTRESS_HOME/tools/enrich-number.py --evidence <path-to-ev.json> --write
python3 $FORTRESS_HOME/tools/enrich-number.py +1NNNNNNNNNN            # ad-hoc, prints JSON only
```
Add to the reverse-ID `sources` list: FCC open data (checked date + hit count), FTC DNC scan scope, and "original block carrier: <company> (may have ported)". A CLEC like Bandwidth/Peerless/Twilio suggests a VoIP/texting platform — say "likely a texting/VoIP platform number", never name it as the sender.
Short codes (5–6 digits): the tool skips FCC/FTC and returns the CTIA registry link (https://www.usshortcodes.com/). Coach HELP only for legitimate-looking brand programs, never suspected scams.
Optional: FCC Robocall Mitigation Database (https://fccprod.servicenowservices.com/rmd?id=rmd_listings) to see whether the block carrier filed a mitigation plan — browser look-up, record only what you read.

## Spoofed and rotating numbers (honest ID)
- **A phone cannot prove a spoof — only show signals.** Use `id_status: spoofed_or_untraceable` when signals are strong (own number shown; real owner never called; "bank/IRS" from a consumer/VoIP block with CNAM mismatch). Reverse-lookup results then describe the **innocent owner of the borrowed number**; say so and never name them as the caller.
- **STIR/SHAKEN:** "Verified" = carrier attests the caller may use the number (not that they're honest); no badge = no information. FCC background: https://www.fcc.gov/call-authentication , spoofing: https://www.fcc.gov/spoofing (Truth in Caller ID Act — spoofing with intent to defraud is illegal; some spoofing is legal).
- **Rotating numbers usually aren't spoofing** — they're number pools (cheap VoIP/10DLC/email-to-SMS). Identify the **campaign**, not each number: same script/link/handle/wallet → one `campaign_id` (`$FORTRESS_HOME/tools/extract-identifiers.py --scan --write`). Shared identifier ≠ attribution.
- **Block carrier hints:** a CLEC/VoIP block (e.g., Bandwidth, Onvoy/Inteliquent, Twilio, Telnyx, Peerless) on a "bank" call = mismatch signal (numbers port, so it's a hint). Optional: `--rmd-removed-list` flags block carriers matching FCC Robocall Mitigation Database removals (FCC RMD: https://fccprod.servicenowservices.com/rmd ; removed providers' traffic must be blocked by other carriers). Enrichment flag only.
- **Short codes:** look up at https://usshortcodes.com/ (a matching brand ≠ safe message; check content). **10DLC:** not publicly verifiable per number — don't claim "registered" or "unregistered". **Email-to-SMS:** sender is an email address; trace is not possible from the phone.
- **Never:** call back, reply, open `t.me`/`wa.me`/`signal.me` links, message the handle, or try to locate the person behind a sextortion/extortion number. Identifiers go to IC3 / platform reports only.
- **Number-takeover defense (SIM swap / port-out), when the owner worries "they could take my number":** turn on the free carrier lock — **T-Mobile: Port Out Protection** (per line, T-Life or T-Mobile.com; https://www.t-mobile.com/support/plans-features/help-with-t-mobile-account-fraud) · **Verizon: Number Lock + SIM Protection** (My Verizon → Security, or *611; https://www.verizon.com/support/port-out-faqs/) · **AT&T: Wireless Account Lock** (AT&T app; https://www.att.com/support/article/wireless/000102016/). A **SIM PIN** only locks the physical SIM in a lost phone — it does **not** stop a remote SIM swap or port-out; the account lock + account passcode does. FCC rules (2023) require carriers to authenticate before SIM changes/port-outs and notify you.

## Limits
Caller ID is often spoofed. A failed or conflicting lookup is a valid result — record it; do not invent an entity.
