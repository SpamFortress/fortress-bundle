# Email report receipts

## Purpose
Every report and real unsubscribe gets a receipt: what we did, where it went, when (user TZ), reference ID, what happens next. Status filters: Done / Waiting / Failed — needs you. Gold standard abroad: ScamShield-style feedback; US often has none — our log fills the gap.

## Standing rules
- User still presses Send on outbound reports unless they explicitly asked to skip draft.
- Be honest: "Blocked (sender ignored the request)" vs real unsubscribe.
- Expectation: senders may take days; set a check-back date.
- Quiet confirm + Status Page Receipts list update.

## Receipt fields
- action: report_spam | report_phishing | unsubscribe | block | regulator
- destination: e.g. provider spam, report@phishing.gov.uk, APWG, FTC ReportFraud, carrier
- filed_at owner timezone
- reference_id (provider ticket or our `rcpt-YYYYMMDD-…`)
- next: what to expect + follow-up date
- status: done | waiting | failed
- sent_at: only when the request actually went out (one-click/link/mail confirmed). A filing that failed or was never sent (`status: failed` with no `sent_at`, or `sent: false`) never starts an honor clock; a request that was sent and later marked failed because the sender kept mailing keeps its `sent_at`.

## Process
1. Package the report (user sends).
2. Append to `$FORTRESS_HOME/private/email/receipts/index.json`.
3. Show receipt card in chat (one calm card).
4. On failure, status Failed — needs you with the exact next DIY step.

## Anti-patterns
No fake "47 threats blocked" counters. No dark-pattern cancel language.

## Takedown and recovery destinations (added 2026-10-27)
Use these `destination` values for receipts from `phish-takedown-drafts` and `after-click-loss-recovery` (one receipt per destination, after the owner sends):
`registrar_abuse` (save the registrar ticket #), `hosting_abuse` (+ `cc: cert@cert.br` for .br), `apwg`, `netcraft`, `safe_browsing` (web form, no ticket), `brand:<directory id>`, `telegram` (abuse@telegram.org or @notoscam), `chainabuse` (report URL), `bank_claim` (claim #), `card_dispute`, `wire_recall`, `ftc` (report #), `ic3` (complaint ID), `identitytheft_gov`, `ana_emps`.
"What happens next" lines: registrars/hosts usually act or reply in 1–5 business days; APWG/Netcraft/Safe Browsing don't reply individually; FTC/IC3 don't investigate single cases but share with law enforcement; banks must resolve Reg E claims within 10 business days (or provisionally credit and take up to 45 days).

## International complaint IDs and reply clocks (country ≠ US; added 2026-10-30)
Applies to phone and email receipts. For each non-US report or rights request also save:
- `country` (ISO 2-letter) and `destination` (e.g. `ico`, `report_fraud_uk`, `dpa:<cc>`, `opc`, `oaic`, `reportcyber`, `idcare`, `anpd`, `procon`, `scamshield`, `spf_police`, `nsrc_997`, `in_1930`, `cybercrime_gov_in`, `chakshu`, `adcc_18222`, `hk_police`, `tw_165`, `celular_seguro`, `bo_policia_civil`, `pdpc_sg`, `caller_id_unlist`)
- `complaint_id` (the regulator's or hotline's reference / acknowledgement number; ask the user to paste it)
- `report_window_days` from `regions.<cc>.report_windows` (GDPR/UK GDPR 30, LGPD 15, PIPEDA 30, AU OAIC 30, NZ 20 working days, IN UCC 7 to file / 1 day after 1930, SG DNC 21 wait; unknown → `null` and "check back in 30 days")
- `check_back_on` = filed date + window (owner timezone)
When the date passes, remind once: "Your <destination> report <complaint_id> is past its reply window. Check status at <official page>?" Draft the next step (DPA/regulator) only if the user asks. Nothing is auto-sent. US receipts: unchanged.
