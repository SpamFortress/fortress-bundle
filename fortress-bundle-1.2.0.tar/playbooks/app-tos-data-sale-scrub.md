# App ToS / data-sale scrub

Find apps that look like they sell or share personal data, then draft Do Not Sell / delete requests. **Drafts only.** Honest progress states. Never claim sent, deleted, or “data gone” without evidence of the company’s reply.

## Inputs (required)
- **Phone / tablet:** owner provides App Privacy Report, Settings privacy labels, or a pasted app list / screenshots. **Never silent-read the phone.**
- **Computer inventory:** only after an **explicit separate approval** naming the computer and what may be listed (installed apps). No silent inventory. No vault dumps into the pack.
- **Never** read application databases, caches, cookies, keychains, credential stores or password-manager files with Shell/Read. App data only through that app's own sanctioned tool or connector; otherwise the owner supplies a list, screenshots or the app's own export. An approved computer inventory lists installed app **names** only.

## Flow
1. Collect the list from the approved input.
2. For each app/company: note privacy-label “Data Used to Track You” / “Data Linked to You” sell/share cues, or ToS/privacy language the owner pasted. Prefer the company’s own privacy / Your Privacy Choices page.
3. Dedupe with `do-not-sell-email` and account-company scrub — one draft per company when possible.
4. Widget: **Draft Do Not Sell / delete** · **Skip** · **Log only**.
5. On Draft → use `do-not-sell-email` templates by residency. Owner sends.
6. Progress states only: `listed` · `draft_ready` · `owner_sent` (needs their confirmation) · `company_replied` · `suppressed`. Never invent a reply.

## Hard rules
- No claim that data was deleted or sales stopped without the company’s written confirmation.
- No mass auto-email. No passwords, SSN, or payment through this bot.
- Paid “app scrubber” services → DIY card only.
