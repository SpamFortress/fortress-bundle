# Email evidence log

## Purpose
Structured evidence for spam/phish email suitable for reports and opt-out letters. Not a TCPA statutory calculator — ordinary CAN-SPAM has no consumer private payday.

## Standing rules
- Quiet one-line confirm after save.
- Never auto-delete mail.
- User OK before any outbound letter or report send.
- Update Email Fortress status Page counts after logging.
- Political/nonprofit lists: log honestly; STOP often ignored — coach Report + receipt.

## Capture fields
- Date/time (user TZ), mailbox_id / household label
- From, Reply-To, Subject, To/Delivered-To (note plus-tags)
- Body excerpt or screenshot paths
- Auth plain: SPF/DKIM/DMARC pass/fail in plain words when available
- Unsubscribe / STOP text and time; post-unsub contact flag
- Category: marketing | phishing | political | transactional-suspicious | other
- who_sold: tag → company + confidence (confirmed_by_tag | likely | unknown)
- Report receipt ids when filed
- **origin_ip_hint** `{ip, status: unverified_hint_top_received_hop_only, abuse_check_url}`: the IP in the top `Received:` line only, if public; never the sender's origin, never a place. Older `origin_ip` / `origin_geo` fields are replaced by it when re-enriched.
- AbuseIPDB check URL `https://www.abuseipdb.com/check/<IP>` + any report count you verified (never invent)

## Originating IP lookup
1. Use only the public IP in the **top** `Received:` line (`first_external_ip`); if that line has none, there is no hint. Lower lines may be forged and are never used.
2. Optional `curl -sS https://ipinfo.io/<IP>/json`: keep the network owner (org) only; do not store city, region, country or loc.
3. Link AbuseIPDB check page; only store report counts you actually read.
4. Caveat in the log note: an unverified relay hint, **not** where the sender is. Do not drive who-sold map pins from this.

## Domain + header enrichment
When the From domain, a link host, or raw headers exist (never click the link):
```
python3 $FORTRESS_HOME/tools/enrich-domain.py --evidence <ev.json> --write          # From + cta/unsub hosts
python3 $FORTRESS_HOME/tools/enrich-domain.py --headers <pasted-headers.txt>         # auth + IP + domains
```
- Stores `domain_intel` {domain, created, domain_age_days, age_flag, registrar, abuse_email} + sidecar `*.domain-intel.json` (backup `.bak-enrich`). RDAP via rdap.org (free); subdomains walk up to the registered domain.
- With headers: also fills `auth` {spf, dkim, dmarc, plain, source} (from pasted headers always `unknown`; claims are not verification) and `origin_ip_hint` (unverified top-hop hint, no location) — same rules as the lookup above.
- Registrar abuse email is for a user-approved takedown draft only; never auto-send.

## Unsubscribe clock
When an Unsubscribe is logged (receipt `action: unsubscribe`, `sent_at`), run `python3 $FORTRESS_HOME/tools/deadline-clocks.py list --write` → `recheck_after_pt` = +10 US business days; Gmail one-click adds a 48h clock. Repeats → `repeat_contacts` on the receipt + `post_unsub_repeat: true` here.

## Process
1. Treat paste/screenshot/"forward this spam" as intake; ask only for gaps.
2. Save under `$FORTRESS_HOME/private/email/evidence/<mailbox_id>/` and update `$FORTRESS_HOME/private/email/evidence/index.json`.
3. Run paste-verdict if not already done; who-sold if tags present; IP enrichment when headers allow.
4. Confirm briefly; offer report receipt + optional letter draft.

## Privacy
Keep logs private. Do not email evidence unless user-approved packaging.

## Takedown + new-pattern hooks (added 2026-10-27)
- New `pattern` values: `email_bomb`, `password_extortion`, `calendar_spam`, `callback_phish`, `real_service_abuse`, `wire_instructions_change`, `attachment_phish`, `qr_phish`.
- Optional fields: `links.attachment_hosts[]`, `links.qr_target`, `callback_number`, `crypto_wallets[]`, `telegram_handles[]`, `takedown_bundle` (path to `letters/takedown/<id>/`).
- Never log passwords (log `password_shown: true` only), codes, SSNs, or intimate images.
- After save: if `links.cta_host` or a sending domain exists and `domain_intel` is filled, draft-when-ready prompt → `phish-takedown-drafts`.
