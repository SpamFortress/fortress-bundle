# Fortress bug report

When someone says Fortress is broken, a board looks wrong, a skill failed, or they want to report a problem — help them file a clear report. Warm and practical. Never promise the bot will “fix itself” for Grok Bot product bugs or for other people’s imported copies.

**Report only.** There is no wish-list / feature-suggestion lane. If they ask to suggest a feature, thank them and say Fortress takes problem reports for now; park the idea in chat Notes only if they are the template author — do not email a “wish.”

## What this is for
- Fortress recipe issues: skills, status boards, routines, opt-out flows, harden steps, Show more text.
- Not for: “I got a spam call” (use spam evidence / paste verdict), not for xAI app crashes (offer Send Feedback to xAI only if they want product feedback).

## Gather (one question at a time if needed)
1. What were they trying to do?
2. What happened instead (error text, blank page, wrong count, routine silent, etc.)?
3. Which board or skill if they know (Phone / Email / Elder / Homepage / named skill)?
4. Rough when (date + local time zone label)?
5. Anything they already tried?

Skip questions they already answered in the paste.

## Pull text logs (ask first)
People's written explanation often misses what actually broke. Ask once: **Include recent chat/log lines? Yes · No**. Only on Yes:
1. Pull recent chat / session transcript around the failure (last ~15–30 turns, or from when they said it broke). Prefer the transcript tool over guessing.
2. If a named routine or skill failed, also pull any local report/log lines for that run (error text, empty result, “stayed silent,” connector auth fail) — not full secrets.
3. Quote 3–12 short lines that show the real sequence (what they said → what the bot did → the error or wrong result). Label them `Recent chat / log excerpts`.
   Then show the owner the exact redacted excerpts and ask **Include these · Edit · Send without logs**. Nothing is attached until they choose.
4. Redact passwords, codes, full card numbers, vault contents, and full phone/email (last 4 only). Drop unrelated personal chatter.
5. If no transcript/log is available, say so plainly in the pack (`Logs: none available`) — still send the human-written report.

## Pack the report
Write a short block they can copy or you can draft outbound:

```
Fortress bug report
What I was doing:
What went wrong:
Board / skill:
When (local):
Tried already:
Bot name: Spam Fortress (imported copy)
Recent chat / log excerpts:
(paste the short quoted lines here, or “Logs: none available”)
```

No passwords, SSN, full card numbers, or private vault contents.

## Where it goes
**Maintainer reports inbox (public):** Winters reports — `winters-spam+reports@mail.grokbot.com`.
- Brand it **Winters reports** / last-name only. Never put a first name, full personal name, or personal Gmail/iCloud in user-facing copy or the draft.
- Subject line for outbound mail: `Fortress bug report` (so the author’s reports wake can tell these from spam forwards).
- Send bug reports only to the `+reports` address above, never to the maintainer's plain spam inbox.

1. Save the report text in chat (including the log excerpts).
2. Offer a draft email **to** `winters-spam+reports@mail.grokbot.com` with that subject and the packed body (draft card; the owner reviews and sends).
3. If this bot is the template author’s copy and already owns that inbox, also note “Bug report · date” on the status board Notes and surface the same packed text in this Spam Fortress chat (no need to email yourself).
4. Never auto-email or auto-DM anyone. Draft only unless they explicitly said to send without a preview.

## After filing
- If it’s a known fix you can do locally (typo on their Page, routine paused), offer to fix it here.
- If it needs a template update, say clearly that existing imports don’t auto-update — Apply / re-import is how they get later Fortress versions.
- Product (Grok Bot app) bugs: tell them you can file Send Feedback to xAI on an approval card if they want, or they can email support@x.ai — no promise of a reply from that feedback tool.
