# Mailbox takeover check

Purpose: help owner spot places mailbox/account takeover can hide. Coach steps; owner changes settings. Never request, store, or repeat password, OTP, recovery key, SSN, IP PIN, carrier PIN or security answer. Save ticks/dates only in private `$FORTRESS_HOME/private/identity.md` / hardening checklist. iCloud is coach-only without connector.

## Inspect (one click / on demand)
When owner asks Inspect or Check Gmail/phone for risks, run now — **never schedule a daily automated Inspect**. No passwords/codes/SSN. Both lanes when paired or asked. Email checks mail hiding places; phone checks carrier and device. Type official addresses/use real apps, never links in email.

1. Review signed-in devices (remove anything unknown).
2. Recovery email/phone (all must belong to owner).
3. Mailbox forwarding and POP/IMAP.
4. Rules/filters that forward, delete, archive or hide bank/security mail.
5. Delegates, third-party app access and app passwords.
6. Carrier call/text forwarding, number-port-out lock and SIM-change protection.
7. Check 2FA/passkey, credit freezes and IRS IP PIN as appropriate.

Gmail checklist: open `https://myaccount.google.com/security-checkup`; review Your devices; Ways we can verify it's you; Gmail Settings forwarding/POP-IMAP, filters/blocked addresses; Delegation and third-party app access. Apple: `https://account.apple.com` / iPhone Settings owner-name → device list; Sign-In & Security recovery; iCloud Mail Settings forwarding and Rules. Outlook: Microsoft account Devices, Security info/Recovery, Outlook Mail forwarding and Rules; Yahoo Account Security recent activity and mailboxes.

## If something is wrong
If unknown forwarding, rule, device or recovery entry: stop checklist, remove bad item from trusted device, change unique mailbox password (don't share it), sign out other sessions, enable passkey/authenticator 2FA, review account recovery and carrier. Check banking/card shopping accounts by official app/typed address. Load after-click-loss-recovery when money or IDs exposed; log date and tick only.

## Harden
- [ ] 2FA/passkey or authenticator (SMS second-best)
- [ ] Owner-controlled recovery email and phone
- [ ] Unique mailbox password in password manager
- [ ] Owner optionally HIBP Notify Me `https://haveibeenpwned.com/NotifyMe`
- [ ] Credit freeze at all three: `https://www.equifax.com/personal/credit-report-services/credit-freeze/`, `https://www.experian.com/freeze/center.html`, `https://www.transunion.com/credit-freeze`; credit-freeze-planner for temporary thaw
- [ ] IRS IP PIN `https://www.irs.gov/identity-theft-fraud-scams/get-an-identity-protection-pin`
- [ ] Bank/card alerts for transactions/new payees

## Carrier lock
SIM PIN in phone settings locks physical SIM, not remote swap. Ask carrier for account-level port-out lock and SIM-change/SIM-swap protection; unlock before switching/upgrading. Verizon Number Lock + SIM Protection; AT&T Wireless Account Lock; T-Mobile Port Out Protection + SIM Protection; other carriers ask for equivalent. Verify current carrier guidance before navigating exact menus. Sudden No service/SOS plus reset emails → call carrier from another phone immediately. Do not claim lock stops all fraud.

Breaches: change compromised site password + 2FA; record brand and expect_phishing_until +180d in private breach-watch; breached-brand ask gets additional caution, real app only. Card/SSN exposure → credit-freeze-planner / after-click-loss-recovery.

Finish calm summary of ticks/dates. Optional six-month reminder only if owner asks; no automatic inbox/control-plane changes.
