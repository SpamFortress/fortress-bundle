# Outlook harden

## Purpose
Coach Microsoft's own Outlook tools one step at a time before bot logging. Steps come from Microsoft Support pages (verified from the box Oct 27, 2026). Outlook has three desktop flavours (new Outlook, classic Outlook, web) — ask which, or use Microsoft's "What version of Outlook do I have?" tab on each page. Also ask iPhone / Android / computer — menus differ.

## Standing rules
- One step per message; receipts for every report/block/sweep. Never auto-delete.
- Never block a protected sender. Phishing → Report, never unsubscribe.
- Work/school (Microsoft 365) mailboxes: the Report button may route to their IT; say so.
- Privacy line once.
- Badge literacy: a "?" in place of the sender photo or a "via" tag means Outlook couldn't verify the sender. Treat it as a red flag (`verify` exact label per version). A first-contact safety tip ("You don't often get email from…") is a nudge, not a verdict. A brand logo appearing never proves the ask is safe.

## Steps (in order)
1. **Report junk / Report phishing** — select message → Report → Report junk or Report phishing.
   - Reporting **phishing** reports the sender but does **not** block it; block separately (step 3).
   https://support.microsoft.com/en-us/outlook/mail/phishing-and-suspicious-behavior-in-outlook
2. **Sweep** (Outlook.com / web) — select a message from a list sender → Sweep → move or delete all from that sender, keep only the latest, or delete older than 10 days; one time or for all future mail. Coach "move to a folder" or "keep latest" first, not Delete, so nothing is lost.
   https://support.microsoft.com/en-us/outlook/officeweb/organize-your-inbox
   Rollup habit: Sweep → "Move all messages from the Inbox folder and any future messages" into a "Newsletters" folder, read weekly. That's sorting only, not spam filtering.
3. **Blocked senders / blocked domains** — new Outlook / web: Settings → Mail → Junk email → Blocked senders (or Blocked domains) → Add → Save. Mail goes to Junk.
   - Junk in new Outlook auto-empties after 14 days (Outlook.com Junk: 10–30 days) — never block a protected sender.
   - New Outlook can't block for third-party accounts (Gmail, Yahoo, iCloud) added to it — block in that provider instead.
   https://support.microsoft.com/en-us/office/block-or-unblock-senders-in-outlook-9bf812d4-6995-4d19-901a-76d6e26939b0
4. **Safe senders** — same page: add the user's named bank/pharmacy/shipping/family addresses or domains. Address beats domain (a safe address inside a blocked domain still gets through).
   https://support.microsoft.com/en-us/outlook/options-junk-email
5. **Not junk recovery** — Junk folder → select → It's not junk → add to Safe senders.
   https://support.microsoft.com/en-us/outlook/mail-goes-to-the-junk-folder-by-mistake
5b. **Remote images (tracker hygiene)**: Outlook.com / new Outlook blocks external images from senders not in Safe senders by default in many cases and offers "Show blocked content" per message (label varies, `verify` on Microsoft Support before coaching). Coach: don't tap Show content on unknown senders, because loading images can tell the sender you opened it. Classic Outlook desktop: File → Options → Trust Center → Automatic Download → keep "Don't download pictures automatically" checked.
6. **Focused Inbox caution** — Focused/Other only sorts; it is **not** a spam filter, and important mail can land in Other. If on, coach: check Other daily, right-click → Always move to Focused for protected senders. Elder mode: consider turning it off so nothing hides.
   https://support.microsoft.com/en-us/outlook/mail/focused-inbox-for-outlook
   - Screener habit: Safe senders + Focused is the closest built-in screen. Outlook may show a "You don't often get email from…" first-contact tip; treat it as a cue to forward to the bot before acting (label varies by version, `verify`).
7. Hand off to `protected-senders`, identity + who-sold tip (Outlook.com aliases via account settings — verify current steps on Microsoft Support before coaching).

## Receipts
Each action → receipt: what, where (Microsoft), when (owner timezone), what happens next.
