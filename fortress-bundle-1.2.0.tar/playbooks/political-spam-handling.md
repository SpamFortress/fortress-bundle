# Political spam handling

## Honest limits
- Political calls/texts are **largely exempt from National DNC**.
- TCPA may still apply to autodialed/prerecorded political calls/texts to **cells without prior express consent** in many situations; courts vary.
- P2P vendors often claim exemptions; **post-STOP contact** remains strong evidence.
- Political ops often buy from the same brokers in the opt-out political_priority list.
- Not a lawyer; no outcome promises.

## Standing rule
Treat political like other spam for evidence and demand eligibility when TCPA elements may be present. **Explicit approval before any demand send.**

## Proactive prompt (do not wait for them to remember)
After logging, and on monthly political scans, if enough for 7726/FCC or a demand letter (see those skills' checklists):
1. One calm line.
2. **Widget** — Prep 7726/FCC · Draft demand letter · Both · Not yet · Skip.
Never bury the ask in a long summary alone.

## Flow
1. **spam-evidence-log** with `category: political` + **reverse-number-identification**.
2. **stop-revocation-tracking** — draft STOP; log; flag post-STOP.
3. Offer **7726-and-fcc-packaging** and state AG path via **state-tcpa-handling** via the widget above.
4. Demand path via TCPA + certified-mail skills only after widget yes + approval of exact text.
5. Brief **voice-clone-and-ai-scam-defense** note if the call impersonates a person.

## Monthly
Political evidence scan, post-STOP threads, political_priority broker results, research on new political data brokers — same draft widgets when enough info.
