# Phish takedown drafts

Turns one saved phishing evidence item into **draft** abuse reports for the impersonated brand, the hosting network and the registrar. Never sends, never visits the phishing link.

1. Needs a saved evidence file (from **email-evidence-log**) with the From domain, the defanged link hosts and the brand.
2. Run the **fortress-tools** helper: `python3 $FORTRESS_HOME/tools/takedown-drafts.py --evidence <file> [--brand <id>]`. `--hosting` (optional, ask first) does a public DNS-over-HTTPS + RDAP lookup on the **host name only**; the page itself is never fetched.
3. Destinations come only from `$FORTRESS_HOME/data/brand-abuse-directory.json` → `verified` entries (each has a source URL and check date) or the registrar abuse address returned by RDAP. Entries under `unverified_additions` are not used until their source page is re-read and confirms the address. Never invent an abuse address.
4. Show the owner each draft (destination, subject, body with defanged links, evidence lines with owner-timezone times). Nothing is attached or sent until they approve each one. Send only through the normal approved send path; log a receipt with **email-report-receipts**.
5. Don't include the owner's personal details beyond what they approve; the default is no name and the bot's own inbox as the reply address.
