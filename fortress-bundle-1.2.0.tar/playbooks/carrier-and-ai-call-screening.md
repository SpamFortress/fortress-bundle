# Carrier and AI call screening

## Standing rule
**Always-on blocking is specialty software** — carriers, phone OS, and apps like Nomorobo / Hiya / RoboKiller. Fortress does **not** build a caller-ID network or answer-bot. We **coach** these on day one, then own evidence, STOP, 7726/FCC, demand letters, and broker opt-outs when something still gets through.

For **first-time or "set up my phone"** flows, run **phone-setup-first** instead of this abbreviated reminder.

Advise settings only. **Do not claim to control** the user’s phone or carrier account unless they explicitly ask you to drive a signed-in session and approve each step.

**SMS/iMessage:** Fortress cannot remotely auto-block texts. Coach Filter unknown senders / Report Junk / carrier tools; optional Notes block-list for numbers the owner already blocked. Never promise remote SMS block.

**Labels:** use **current** Apple / Google / carrier wording (same as Phone setup first). Text first; pictures only if they say Can’t find it / Need help. Never coach obsolete "Silence Unknown Callers" as the sole iPhone path.

## Day-one coach (pick their carrier)
- **T-Mobile / Mint (T-Mobile network):** Scam Shield (or Mint’s spam tools if any — many MVNOs have little beyond the network). Turn on suspected-spam silencing and scam ID when available.
- **AT&T:** ActiveArmor — spam block / unknown screening.
- **Verizon:** Call Filter — spam and fraud filtering.
- **Other / unknown:** open the carrier account app → search "spam", "scam shield", "call filter".

## On-device (same day) — current labels
- **iPhone:** Settings → **Apps** → **Phone** → **Screen Unknown Callers** (Ask Reason for Calling or Silence) + Call Filtering **Unknown Callers** / **Spam** as offered; Messages unknown-sender filter; Report Junk; FaceTime Silence Unknown Callers if present.
- **Pixel / Phone by Google:** Phone → Settings → Caller ID and spam → Filter spam calls; or Spam and Call Screen / Call Screen protection levels.
- **Samsung:** smart call / spam protection in Phone app settings (use on-device names).

## Optional paid specialty (not required)
Nomorobo, Hiya Premium, RoboKiller, Truecaller — extra pre-ring blocking. Mention once if the owner still gets heavy robocalls after carrier + OS; never imply Fortress replaces them.

## Also
- Voice-clone family code word when relevant (**voice-clone-and-ai-scam-defense**)
- Carrier CDRs beat screenshots for serious claims
- After a spam call/text still lands → **spam-evidence-log** + draft-when-ready for 7726/FCC/demand

Keep monthly reminders short. Quiet mode: one line unless they ask to walk through settings.
