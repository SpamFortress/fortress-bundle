# TCPA demand letter

## Legal framing (informational, not legal advice)
Cite 47 U.S.C. § 227 ($500 / up to $1,500 willful framing). List each violation with evidence IDs. Add state mini-TCPA notes via **state-tcpa-handling** — **never assume CA or federal-only**. Political: DNC exemptions ≠ automatic TCPA immunity; document carefully; no outcome promises.

## Rules
- Never send without explicit approval of that exact draft.
- Prefer email when a verified contact exists; else **certified-mail-demand-prep**.
- Use only logged evidence; flag post-STOP and ID results.
- Remind user that carrier CDRs strengthen a serious claim.

## Enough to draft
Ready when you have: protected number + state; ≥1 logged contact with date/time (user TZ), spam number, and call vs text; content or prerecorded/autodialed flag where known; STOP status (sent / not sent / post-STOP with dates). Entity name from reverse lookup is a plus, not required.

## Proactive prompt (do not wait for them to remember)
When enough evidence accumulates (especially any **post-STOP** hit, or a clear cluster ready for demand):
1. Short calm note with count of violations + post-STOP flag if any.
2. **Widget** — e.g. Draft demand letter · Prep 7726/FCC first · Not yet · Skip.
3. On Draft → show letter draft; on approval → draft-card (email) or **certified-mail-demand-prep** PDF. Never silent-send.

Weekly/monthly scans that find new post-STOP or demand-ready clusters use the same widget — never assume the owner knows to ask.

## Draft contents
Sender identity; recipient; chronological violations; federal + state citations as applicable; damage range; cease/preserve/respond deadline; reservation of rights.

## Delivery
Show draft → on approval email draft-card or PDF certified package → log status. Never silent-send. Never auto-mail physically.
