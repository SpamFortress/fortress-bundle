# Spam evidence log

## Purpose
Capture structured evidence for every spam call or text, suitable for TCPA claims under 47 U.S.C. § 227. Political → `category: political`. Multi-number → store under the correct `phone_id` folder.

## Standing rules
- Political messages are logged and demand-eligible like other spam when TCPA elements may apply; **always** require send approval.
- After capture, run Reverse number identification and STOP revocation tracking when STOP is involved.
- **Proactive:** after each save, if enough info exists for 7726/FCC, a demand letter, or (dangerous patterns) regulator IC3/FTC, prompt with a **widget** — don't wait for the owner to remember draft cards. See those skills' enough-to-draft checklists.
- Remind once when building a serious claim: **carrier CDRs beat screenshots**.
- Update the Phone Spam Fortress status Page after logging (counts + geography).
- **Quiet mode:** one short confirm (ID status, geo, post-STOP) + widget when draft-ready. No essay.

## Forward-this-spam shortcut
Treat any of these as a complete intake ask:
- Pasted SMS body / call screenshot / "forward this spam" / voice-memo description of a call
Extract what you can; ask only for missing critical fields (time if absent, which phone_id if multi-number). Then auto: save evidence → reverse ID → geography → status Page → draft widget if ready.

## Capture fields
- Date/time (user TZ), call vs text, category, phone_id / household member label
- Number, content/transcript, autodialed/prerecorded indicators
- STOP text/time; `post_stop` flag
- Consent status; screenshots; reverse-ID block
- State of user for complaint routing
- Caller/sender geography: `in_user_state` | `elsewhere_us` | `outside_us` | `unknown` — prefer `unknown` when spoofed/unclear

## Number enrichment (after every save)
Run right after the evidence file is saved (same turn, quiet):
```
python3 $FORTRESS_HOME/tools/enrich-number.py --evidence <path-to-ev.json> --write
```
- Writes `number_intel` into the ev JSON + sidecar `ev-*.number-intel.json` (backup `.bak-enrich`).
- Sources (free, keyless or free key): FCC Unwanted Calls open data (count of complaints listing this number), FTC DNC reported-calls window scan (consumer area code), original block carrier (localcallingguide / NANPA data).
- Surface at most one chip line in the confirm, e.g. "51 other FCC complaints list this number" or "0 FCC complaints (doesn't clear it)". Never invent counts — if a source errors, say "lookup unavailable" and give `fcc_open_url`.
- Caveat always available: public aggregates only, consumer-reported, not proof of illegality; block carrier may have ported.
- Use FCC counts in 7726/FCC and demand drafts as "you are one of N complainants" — only when `fcc_hits_summary.hits` > 0.
- Offline / rate-limited: add `--offline` (links + cache), or `--fcc-csv <bulk CSV>`; set `FTC_API_KEY` (free api.data.gov) to lift the DEMO_KEY limit.

## STOP clock (when STOP is logged)
```
python3 $FORTRESS_HOME/tools/deadline-clocks.py list --write
```
Stores `clocks.stop_10bd` (deadline = STOP date + 10 US business days, 47 CFR 64.1200(a)(10)). Mention the deadline date in the confirm once.

## Spoof, rotating numbers & off-platform bait (log these every time)
Extra capture fields (ask only if missing; never block on them):
- `cnam_display` (name the phone showed), `claimed_identity` (who they said they were), `stir_shaken` (`verified` if the carrier showed a check/"Verified", `none` if not, `unknown`), `sender_type`, `callback_test` (only if the owner called the **known** number of the claimed org, never the caller's number).
- **Spoof signals — signals only, a phone cannot prove a spoof.** Mark `spoof_likely: true` and `geography: unknown` when any strong signal: caller ID shows the owner's **own number**; the real owner of the shown number says they never called; or a "bank / IRS / SSA / police" call shows a **consumer cell or VoIP block** (`number_intel.block_carrier` is a CLEC/VoIP platform) and the name shown (CNAM) doesn't match. Same area code + prefix as the owner = neighbor-spoof pattern (medium).
- **STIR/SHAKEN coaching:** "Verified"/check means the originating carrier vouched the caller may use that number — identity, **not** intent (scammers use real numbers too). **No badge proves nothing** (many networks/phones never show it). Neither one decides the verdict.
- **Own number spoofed:** log it, don't call back; FCC complaint path exists ("my own number is being spoofed") — draft via the 7726/FCC widget.
- **Rotating numbers = one campaign.** If the same script, link, handle, wallet, or payment tag shows up from a new number, file it in the same campaign folder (`campaign_id`). Run `python3 $FORTRESS_HOME/tools/extract-identifiers.py --scan --write` after saving; it links records by shared identifier or near-identical script. **Shared identifier ≠ attribution** — it's one operation, not a named person.
- **Off-platform bait = high risk:** any `t.me/`, `telegram.me/`, `wa.me/`, `chat.whatsapp.com/`, `signal.me/`, `signal.group/`, "text me on Telegram/WhatsApp/Signal/Snap/Kik", or a QR to a chat app → tag `off_platform_bait`, `pivot_platform: <app>`. **Never coach opening the link, scanning the QR, or "checking who it is".** Wrong-number / "my phone is broken, text me on…" openers are the classic setup for romance, crypto, and sextortion.
- **Sender type** (from the raw sender, no lookups needed): 5–6 digits = **short code** (CTIA-registered brand programs; look up at https://usshortcodes.com/ — scams rarely use them); 800/833/844/855/866/877/888 = **toll-free** (verified toll-free texting exists, still spoofable on calls); ordinary 10-digit = **long code**, may be **10DLC** (business texting registered with The Campaign Registry — not publicly checkable per number); sender shows as an **email address** = **email-to-SMS gateway / iMessage-by-email** (cheap, disposable, a common scam route — STOP does nothing); letters only = **alphanumeric sender ID** (not supported on US carriers → usually international).
- **Sextortion / image threats** → don't pay, don't reply, screenshot, report FTC (reportfraud.ftc.gov) / IC3 (ic3.gov); no paid removal firms. Tag `category: sextortion`, `danger: true`, `regulator_queue: both`. Screenshot the threats only — never store images.
- **iMessage scams:** any reply (even STOP) can turn links live and confirms the number. For scams: **Report Junk** + forward to **7726** (SMS) and don't reply. STOP stays for legit-looking marketing only.
- Enrichment honesty: in spoof cases FCC/FTC counts describe the **displayed** number's real owner; keep zeros logged as zero and say so ("0 complaints — doesn't clear it, and the number may be borrowed").

## Process
1. Prefer the forward-this-spam shortcut; ask only for gaps.
2. Save under `$FORTRESS_HOME/private/phone/evidence/<phone_id>/` and update household index.
3. Never call the spam number back.
4. Confirm briefly; if enough for a pack/letter, show the widget (7726/FCC · demand · regulator if dangerous · Not yet).

## Privacy
Keep logs private. Do not email evidence unless packaging a user-approved demand.

## Outside the US (country ≠ US only; added 2026-10-30)
US users: everything above is unchanged. Non-US users:
- Log the same date, number, content, and screenshot fields. Skip TCPA fields and the US STOP 10-business-day clock; record `local_report` (destination + complaint ID) instead and the region's `report_window_days`.
- **WhatsApp / Telegram lane:** ask for a screenshot with the number or @username and time showing, then coach the app's own Report (it also blocks). Never forward the scam to friends or groups. SG: the ScamShield app can check WhatsApp/Telegram. IN: report via Chakshu (Sanchar Saathi). Money moved → `after-click-loss-recovery` → "Outside the US".
- Alphanumeric sender labels: AU "Unverified" / SG "Likely-SCAM" → log the label as `sender_label`.
