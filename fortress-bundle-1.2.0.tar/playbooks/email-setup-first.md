# Email setup first

## When this runs
Trigger on: "set up my email", first-run email, "how do I stop junk mail", or a new mailbox added. This is **Layer 1** for the email lane, mirroring phone-setup-first. Runs before any unsubscribe list, bulk cleanup, inbox scan, letters, or evidence packaging unless the user explicitly skips.

## Standing rules
- Design bar: one primary action per message, no scareware, never auto-delete, receipts for every report/unsub/block. No “calm setup” pitch — just clear short steps.
- Quiet mode: short confirms. Free until proud.
- Privacy line once: "I read sender, subject and unsubscribe links only. I never sell or share your mail."
- **You change the settings; I only coach.** Never say “flip yourself,” “flips yourself,” or “text-first steps you flip yourself.” User-facing: “short steps in chat; you change the settings, I only coach.” Nothing is sent, deleted, or unsubscribed in their name without an explicit OK.
- Never jump to unsubscribe lists first. Unsubscribe is step-5-and-later, and never inside a phishing lure (Report only).
- Auto-check honesty: while `inbox_label_scan` is off — "Fortress checks mail you paste or forward." While on — "Fortress checks new mail on its set schedule while labels are on and not paused (status from label_scan.py status)." Always — "Labels are a second opinion, not a guarantee." Never turn the flag on from Quiet/Chatty, onboarding, pairing, or caregiver.

## First-run wizard (quiet ticks)
Track progress on the Email Fortress status Page checklist. One short chunk per message; tick quietly as each finishes.

0. **Country first** (one tap) if `$FORTRESS_HOME/private/identity.md` has none. US → continue exactly as below. Not US → note the region; after step 4 use `$FORTRESS_HOME/data/geo-packs.md` + `international-privacy-packs` (block → report → letter → money) instead of US FTC/IC3 steps.
1. **Which mail app?** Ask once, button-style, Tier 1 first; "More providers…" expands Tier 2 + 3.
   - **Tier 1:** Gmail · Apple Mail / iCloud · Outlook / Hotmail / Microsoft 365 · Yahoo · Proton
   - **Tier 2:** AOL · GMX / mail.com · WEB.DE · Zoho
   - **Tier 3 (regional / niche, link-coached):** Orange (FR) · Yahoo! Mail Japan · Naver / Daum (KR) · QQ / 163 NetEase (CN — limited) · Mail.ru / Yandex (RU/CIS) · Libero (IT) · Seznam / Email.cz (CZ) · WP Poczta (PL) · Fastmail · Tuta
   - **Other:** generic Report/Block/Allow + provider help link. Never guess menu names.
   - **Apps aren't mailboxes:** Samsung Email, Thunderbird, Spark — ask whose address (@gmail, @outlook…) and harden that account.
   - Multiple accounts: most-junk first. Work/school: coach Report only; IT may control the rest.
2. **Device path:** ask **iPhone / iPad**, **Android app**, or **computer / web** — same mailbox, different taps; coach the matching path in that provider's harden skill.
3. **Run that provider's harden skill only:**
   - Gmail → `gmail-mail-harden` (includes the **two AI/inbox-access switches**: **A** Google Account → Search Services Personalization → Connected Content Apps → Disconnect Workspace/Photos; **B** Gmail → See all settings → General → Manage Workspace smart feature settings → **Smart features in other Google products** off. Optional: Gemini Connectors and My Ad Center. Plain protective framing, not "AI reads everything by default". Skip OK) · Apple/iCloud → `apple-mail-harden` · Outlook → `outlook-mail-harden` · Yahoo → `yahoo-mail-harden` · Proton → `proton-mail-harden`
   - AOL → `aol-mail-harden` · GMX / mail.com / WEB.DE → `gmx-webde-mail-harden` · Zoho → `zoho-mail-harden`
   - Tier 3 → `regional-mail-harden`
4. **Protected senders** → `protected-senders`. User names banks; OTP keywords always pass.
5. **Identity + who-sold alias tip** → `$FORTRESS_HOME/private/identity.md` + per-company alias for next sign-up.
6. **Then logging** → paste/forward → verdict / evidence / receipts. Default honesty line: Fortress checks mail you paste or forward.
7. Only after 1–6 (or skip): **newsletter cleanup** using the app's own tools, one sender per message: Gmail **Manage subscriptions** (sorted by volume) or the header Unsubscribe link; Outlook **Sweep** (keep latest / move all to a folder); Apple Mail **Categories** + the Unsubscribe banner; Yahoo/AOL Subscriptions view. Want a "daily digest" instead of 20 newsletters? There's no universal rollup feature. Closest: route a keep-list into a folder or label with a rule they create (Gmail filter → label + Skip Inbox; Outlook Sweep "move all future"; iCloud.com rule) and read that folder once a week. Fortress can send a short weekly "what's waiting / unsubscribes honored" line only if the owner chose Chatty. Then letters only with user OK.
8. **Optional — Gmail scam labels** (never required; never auto-on). Offer only after steps 1–6 and only when a **Gmail** connector is connected for this owner. Load **opt-in-inbox-label-scan** and follow its Turn on card exactly: Likely Scam label only, minimal envelope reads, protected senders never labeled. Outlook, Check First and Marketing labels are not offered in this release. No dry-run week; no retrospective scan.

## Status Page ticks
After harden: Mail app tightened. After safelist: Protected senders added. What next = next unfinished step only.

## Skip path
"Skip email setup" / "already done" / "just check this one email" → note skip, go to requested step. Offer setup again later if junk keeps arriving.

## After hardening
Provider filters cut volume; bot still verdicts, logs, maps who-sold, drafts letters only with user OK.
- If a “we updated our privacy policy / terms” email arrives (or the owner forwards one), verdict it first, then hand off to **privacy-os-watcher** to check what changed on the official page (ads, sharing, connected apps / AI, analytics defaults).
- **New-sender screen (honest version).** Most mail apps can't hold email from strangers until you approve it, and Fortress can't do it silently for you either. What we can do: (1) keep protected senders on the allow/VIP list so real mail always lands; (2) use the app's own sorting: Gmail Primary vs Promotions, Outlook Focused/Other (elder: consider Focused **off** so nothing hides), Apple Categories, Proton Allow list; (3) any **first-time sender** that asks for money, a code, a call-back, a gift card, or "verify your account" gets forwarded or pasted to me first. I'll give a verdict marked `Suspicious · held for review` and won't delete anything. Apple's "Screen Unknown Senders" is a **Messages** (texts) setting. It does nothing for Mail, so never coach it for email.
