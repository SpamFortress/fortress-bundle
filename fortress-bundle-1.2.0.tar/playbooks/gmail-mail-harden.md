# Gmail harden

## Purpose
Coach Google's own Gmail tools one step at a time before any bot logging. Gmail stays the filter; we coach and keep receipts. Steps below come from Google's Gmail Help / Privacy Policy pages (re-verified Oct 29, 2026). If a menu differs on the user's device (web / Android / iPhone), say so and link the Google page rather than guess.

## Coach style
- **Text first** with **current** Google Help labels. One step per message.
- Widget: **Done** · **Can’t find it** · **Skip for now**.
- **Pictures only after Can’t find it** — then path boards matching the labels below, or circle their screenshot. Do not auto-draw every step.
- If their UI wording differs, believe their screen and link Help.

## Standing rules
- Receipt for each report/block/unsub (email-report-receipts).
- Never auto-delete. Never unsubscribe inside a phishing or spoofed lure — Report only.
- Never block or filter-to-Spam a protected sender (bank, 2FA, password reset, shipping, pharmacy, gov, family).
- Privacy line: "I read sender, subject and unsubscribe links only. I never sell or share your mail."

## Steps (in order)
1. **Report spam** — open the message (or tick it) → **Report spam**. Trains Gmail. Mistake? Open Spam → message → **Report not spam**.
   https://support.google.com/mail/answer/1366858
2. **Report phishing** — for fake bank/brand/"verify your account" mail: open it → More (three dots) → **Report phishing**. Don't click links or reply.
   https://support.google.com/mail/answer/8253
3. **Manage subscriptions** (real newsletters only) — web: left menu → More → **Manage subscriptions**; app: Menu → **Manage subscriptions**. Rolling out gradually; may not appear yet.
   **Expectations:** it can take a few days for the sender to stop; new mail from an unsubscribed sender goes to Spam with a banner; some senders send you to their website instead. Blocking does **not** unsubscribe you — blocked mail just goes to Spam.
   https://support.google.com/mail/answer/15621070
   **Keep-but-quiet newsletters:** Inbox type Default with Promotions/Updates tabs on keeps lists out of Primary. For a weekly read, a filter: from:(list) → Apply label "Read weekly" + Skip the Inbox. The owner creates it; never filter a protected sender.
4. **Block** a repeat junk sender — open message → More → **Block** "[sender]". Future mail goes to Spam. Weak against rotating From addresses (use Report spam on every copy instead).
   https://support.google.com/mail/answer/8151
   Cold-email waves from many addresses: Block won't keep up. Report spam on each, and optionally a filter on a repeated footer phrase or sending domain → Skip Inbox to a "Sales" label (owner creates; review weekly).
5. **Ask before showing images** (tracker hygiene)
   - **Computer:** gear → **See all settings** → General → **Images** → **Ask before displaying external images** → **Save Changes**.
   - **Android app:** Menu → Settings → account → **Images** → Ask before displaying external images.
   https://support.google.com/mail/answer/145919
6. **Google AI & inbox access — two switches** (Personal Intelligence / smart features) — optional but offer every Gmail harden; Skip is fine. Two separate settings in two places; turning off only one leaves the other on. Coach A, then B, one per message.
   **Why (one calm line):** Gmail content reaches other Google AI only if a sharing setting is on; Google's privacy policy (effective Oct 16, 2026) still says no Gmail/Drive/Photos content for personalized ads **unless** you connect those apps to services that support ads. Connected Search may use summaries, excerpts and inferences (not your raw inbox line-by-line) for personalization **including ads**, and some of that data can be used to train AI and seen by human reviewers. Connecting content apps to Search is opt-in (off unless you chose Connect). The "Smart features in other Google products" setting may already be on outside the EEA/UK/Switzerland/Japan. AI Mode and Ask Maps still work without connecting.
   **Switch A — Connected Content Apps (Search services)** — Google Account; web is easiest.
   1. Google Account → **Search Services Personalization**.
   2. **Additional Personal Intelligence** → **Connected Content Apps**.
   3. If **Google Workspace** (Gmail / Calendar) or **Google Photos** shows connected, choose **Disconnect** for any they don't want feeding Search, Maps (Ask Maps), Shopping and ads. Keep only what they knowingly want.
   Note: Google says these Search settings are being updated, so the wording may differ. Believe their screen.
   Help: https://support.google.com/websearch/answer/16859283
   **Switch B — Workspace smart features → other Google products** — Gmail on a **computer** (some of these switches only change from a web browser).
   1. Gmail → gear → **See all settings** → **General** tab → scroll to **Google Workspace smart features**.
   2. Click **Manage Workspace smart feature settings**.
   3. Turn off **Smart features in other Google products**. Google lists Personal Intelligence in the Gemini app and in Search services among what this setting feeds, plus Maps reservations and Wallet passes. **Save**.
   4. Same screen, their choice: **Smart features in Google Workspace** (Gemini in Gmail/Docs, Gmail events added to Calendar). Turning it off loses those features.
   5. Separate box on the General tab: **Smart features in Gmail, Chat, and Meet** (Smart Compose, Smart Reply, summary cards, **Primary/Social/Promotions tabs**). Off is fine, but warn first that it removes inbox tabs and package/travel cards. Not needed to close the cross-product path.
   Help: https://support.google.com/mail/answer/10079371
   **Optional C — Gemini app connectors** (only if they use Gemini): gemini.google.com → sidebar **Customize** (or More → Customize) → **Connectors** → Gmail (and Calendar / Drive / Photos if listed) → More options → **Disconnect**. Help: https://support.google.com/gemini/answer/13695044
   **Optional D — My Ad Center:** https://myadcenter.google.com/ → turn off personalized ads. This alone does **not** disconnect inbox/photos. A and B are the actual fixes.
   **Honest framing:** Don't say "Gmail AI reads every email by default." Say: "Two settings decide whether your mail is shared with Google's AI in Search and other apps. Let's check both." If both were already off, say so plainly and log it.
   Widget after each switch: **Done** · **Can’t find it** · **Skip for now**. On Can’t find it, re-link that switch's Help page and ask for a screenshot of their Connected Content Apps or Workspace smart features screen. Don't invent a menu name. Phone users: Switch B can be done in the Gmail app (Settings → account → Data privacy / Google Workspace smart features) but labels vary. If it isn't there, coach the computer path.
7. **Protected senders** — two Gmail tools:
   - **Important markers**: mark the user's bank / pharmacy mail as Important. https://support.google.com/mail/answer/186543
   - **Filter with "Never send it to Spam"** for each protected sender domain the user names (Search options → From: domain → Create filter → tick Never send it to Spam). Never invent domains. https://support.google.com/mail/answer/6579
8. Hand off to `protected-senders`, then identity + who-sold tip (Gmail +tag: `name+store@gmail.com`; tags can be stripped → counts as Likely, not Confirmed).

## Badges & banners (what they do and don't mean)
- **Blue verified checkmark** next to a sender = the brand set up BIMI with a verified mark certificate. It proves the mail came from that brand's domain, **not** that the ask is safe (real PayPal/DocuSign systems get abused). **No checkmark proves nothing**: most real senders don't have one.
- **Yellow / red "Be careful with this message"** banners = Gmail's own warning. Trust the warning over the content; Report phishing.
- **"via <domain>"** or a "?" avatar = sent through another service or not authenticated; slow down.
- Look-alike display names ("PayPal Support" from a gmail.com address) beat any logo. Read the actual address.

## Honesty notes
- Report spam / Report phishing go to Google, not a regulator. For losses, US users also file at ReportFraud.ftc.gov / ic3.gov (email-report-receipts logs where it went).
- Gmail sender rules for bulk senders exist (https://support.google.com/mail/answer/81126) — they're why one-click unsubscribe usually works for big brands, not a guarantee.
- Connected-apps ads: Google says advertisers don't get your inbox or Photos library; sensitive-category ad targeting (race, religion, sexual orientation, health) stays off. The opt-outs that matter are **Switch A (disconnect content apps)** and **Switch B (Smart features in other Google products off)**. My Ad Center alone is not enough. Disconnecting does not delete Search Services History, which they can manage at https://myactivity.google.com/ if they want. Viral posts about AI reading every email often overstate it. Stay calm and accurate, and quote Google Help.

## Google security alerts with rider scam text (app-password name)
A **real** Google security / account alert can still be a scam payload. Attackers set an app password whose **display name** is the scam (fake McAfee invoice, "call 1-8xx to cancel," etc.); Google then emails a genuine signed alert that includes that name. Victims often get a forward of that alert. DMARC passes; the official Google buttons only open the user's own Security page (nothing looks wrong), so the phone number is left as the only "fix."
- When coaching Gmail harden or a paste of a Google alert: **never** treat From=`accounts.google.com` / no-reply as proof the ask is safe. Judge the ask.
- Coach: don't call any number in the alert; open **myaccount.google.com** → Security (or the Gmail app account Security) yourself via bookmark/app; Report phishing on the message; revoke unknown app passwords under Security → How you sign in to Google → App passwords (if shown).
- Hand off paste/screenshot verdicts to `email-paste-verdict` (Google app-password name alerts section). If they already called the number → `after-click-loss-recovery`.

## Receipts
`receipts/` entry per action: what, where (Google), when (owner timezone), what happens next ("Gmail learns; unsub can take a few days"; for step 6 note Switch A Connected/Disconnected + which apps, Switch B other-products On/Off (+ Workspace / Gmail smart features if changed), Gemini connectors if touched).

## Calendar invite spam
Google Calendar › Settings › Event settings › **Add invitations to my calendar → "Only if the sender is known"** (https://support.google.com/calendar/answer/13159188). Spam event → ⋮ › **Report as spam** (https://support.google.com/calendar/answer/13155911). Never Accept/Decline a spam invite.
