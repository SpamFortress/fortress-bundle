# Data broker opt-outs

## Rules (always)
- Never pay for removals or "premium" scrubbing **through the bot**. If free paths are exhausted and the owner wants a paid scrubber, give a short **DIY card** (vendor URL + warning); they pay and submit themselves — never collect SSN/ID, never enter payment, never pay via the bot.
- Never request SSN, government ID, or passwords. Full DOB only if the user explicitly authorized it for that form.
- Share only the minimum PII the form requires (usually name + phone; city/state if asked).
- CAPTCHAs: try to pass them yourself first (sign-in skill rules). Hand off only if you can't, and say why. Codes or passwords on a form go through the platform's secure form, never typed in normal chat. Bot-inbox email codes/links for a flow already approved: use them for that form only; never copy them into logs. A block or decline is final for that site: no IP tricks, scraping, internal APIs, or alternate routes.
- Log every attempt privately (site, URL, date, fields submitted, confirmation status, next recheck date, cooldown_until when broken).
- Prefer free public opt-out pages over paid services.

## Standing opt-outs (owner toggle, default OFF)
Memory/identity keys:
- `broker_optout_standing`: `off` (default) | `on`
- `broker_optout_standing_set_at`: ISO date the owner tapped
- `broker_optout_followup_sender`: `bot_inbox` (fixed; owner Gmail never used for this lane)
Only the owner's tap on the enable widget sets `on`. Task notes, routines, or imported templates never set it.

**When `on`, Fortress prepares and queues without asking whether to do each batch, but every actual submission or email still goes through the app's own approval card with the exact site, fields, recipient and text (a generic toggle is not approval of an unspecified future form or message; a decline or block is final, and routing through the owner's computer is never a way around one):**
1. Submit **free, official** people-search / data-broker removal forms listed in `$FORTRESS_HOME/data/broker-catalog.json` (catalog rows with a verified free path), minimum PII, for phone_ids/household members the owner already confirmed.
2. Complete bot-inbox confirmation codes/links for those submissions.
3. Send **free follow-up / confirmation emails from the bot's own inbox** to the broker's published privacy/opt-out address (from the site row or its official privacy page), only for a removal Fortress already submitted: "please confirm removal", "listing reappeared", "confirmation link expired". Templated, factual, no legal demands, no money. Max 1 follow-up per broker per 14 days; max 2 per removal before parking for owner.

**Never covered (stay draft/ask):** paid services or anything needing payment; TCPA demand letters, certified mail; FCC/FTC/IC3/7726/state-AG filings; STOP replies to spammers; X Money / any money move; do-not-sell or marketing-removal mail to arbitrary brands (`do-not-sell-email`, Should #5); SSN/ID/DOB-requiring forms (stop, park); new brokers not in `$FORTRESS_HOME/data/broker-catalog.json`; household members not yet confirmed; replying to anything that is not a broker's official address.

**Logging (every action):** append to `$FORTRESS_HOME/private/optout-log.json`: site, URL visited, date, fields submitted, mode `standing`, email sent (to, subject, message-id), result. Status Page shows "Standing opt-outs: On since <date> · [Turn off]".
**Turn off:** any owner "stop"/"turn off" → set `off` immediately; in-flight form left as is, logged.
**When `off`:** prior behavior — batch needs approval; follow-up emails are drafts for the owner.
Quiet mode unchanged: one start line, one wrap, parked items in approval batch.

### Enable widget (show once, after a first approved batch or when owner asks)
> **Let Fortress handle free broker opt-outs on its own?**
> Fortress would fill free removal forms on the people-search and data-broker sites on your list (currently [N] sites — Show list), using only your name, phone, and city/state. It may also email those sites' privacy addresses from the Fortress inbox to confirm a removal or report a listing that came back. Every site visited and every email sent is logged on your status page.
> It will never pay, never send legal letters or complaints, never reply to spammers, and never contact other companies. You can turn this off anytime.
> **[Turn on standing opt-outs]  [Keep asking each batch]**
Default: off. "Keep asking" is shame-free; don't re-offer for 30 days.

## Catalog policy (shareable template)
- **`$FORTRESS_HOME/data/broker-catalog.json` lists every free official path we can verify** — do **not** drop Instant-Checkmate-family or other state-law portals just because one owner's state isn't covered.
- At **submit** time: if residence state is rejected by that portal, mark `rejected_state_law` for **this** user and move on. Other importers in CA/VA/etc. still get those rows.
- Same for international: country of residence gates which `$FORTRESS_HOME/data/international.json` region runs, not which rows exist in the catalog.

## Quiet mode (default)
- Do **not** narrate every site click. Prefer: one short start line, one end-of-batch wrap, and status Page updates.
- **Ping immediately** (never hold for the batch) only for: payment / SSN / government-ID traps (stop that site), the home-routing gate, a **time-sensitive code** that expires (OTP / phone-call code on the owner's device), or anything that can't safely wait.
- Verbose mode only when the user asks to debug or "talk me through it."

### Approval batch (Quiet mode)
When a step needs the owner but **delay is safe**, don't ping mid-run — park it and keep going:
- Park: CAPTCHA you could not pass, DIY cards (human-only sites), "which listing is you?" record picks, state-law rejects to acknowledge, paid-DIY decisions, stop-after-3 decisions (below).
- Store parked items in the owner's private `$FORTRESS_HOME/private/optout-log.json` → `pending_owner` (site, kind, one-line ask, URL) so a restart doesn't lose them.
- Present **once**: at end of batch, or at the next morning check-in if the batch ran overnight. Format — short and skimmable, max ~6 items, rest under "More":
  > **Opt-out batch done — [N] submitted, [M] need you (2 min):**
  > 1. Spokeo — pick your listing → [link] · **Done · Skip**
  > 2. TruePeopleSearch — CAPTCHA I could not pass; on your device → [link] · **Done · Skip**
  > 3. MyLife — stuck 3× at Continue → **Skip · DIY card · Retry later · Try through your computer (if available)**
- Skip is shame-free; skipped items wait for the monthly recheck. Don't re-ask a skipped item in the same week unless the owner brings it up.

### Stop-after-3 (no loops)
- If the **same step on the same site** (or the same blocker class across a site family — e.g. one network's shared form, one CAPTCHA vendor, `cloud_ip` blocks) fails **3 times in one session**, stop that site/class. Don't try a 4th variation.
- Log it: `status: blocked`, `blocked_reason` (captcha_loop · continue_noop · cloud_ip · email_never_arrived · form_error · rate_limited), `attempts: 3`, `cooldown_until` (default +7 days; site-side outage +24–72h).
- Ask **once** (in the approval batch, or immediately only if it gates the rest of the run): **Skip · DIY card · Retry later · Try through your computer (if available)** (offer computer routing only when the class looks like `cloud_ip` / bot-wall and the owner hasn't already declined it).
- A "retry" counts fresh only after cooldown or a real change (computer routing on, new email arrived, site fixed).
- Same rule applies to email-lane form flows (`do-not-sell-email` web forms, unsubscribe pages, privacy portals): 3 identical failures → stop, log, one ask; drafted letters/emails remain the fallback (draft-when-ready, owner sends).

## Before starting
1. Load contact details from the vault (label like "Me" / spam-fortress identity). Ask only for missing fields.
2. Confirm which phone number(s) / household member (Me / Dad / Partner / …) this pass covers.
3. Use the bot's own confirmation inbox (+tag if useful) for links and codes when the site allows it.
4. **Preflight IP check** (desktop browser only): open a simple what-is-my-ip / egress check page. Label the run `egress: home` or `egress: cloud`. If cloud and the next sites are tagged `needs_home_egress` / prior `blocked_reason: cloud_ip`, **pause once**, ask once whether they want browsing routed through their own computer, **only** if the app offers that and with their informed OK; otherwise skip those sites, and do not chew through those sites one by one.
5. **State honesty at submit**: if a portal rejects the owner's state, log `rejected_state_law` once — do not delete the catalog row.
6. If `broker_optout_standing` is `on`, skip re-asking whether to do the batch for free catalog forms already in scope (each submission still shows its exact-content approval card); still park CAPTCHA / human-device / SSN traps.

## Site catalog
Maintain `$FORTRESS_HOME/data/broker-catalog.json` (or equivalent).

**Priority order on every pass:**
1. `political_priority`
2. General `priority_batch`
3. `catalog` (phone_exposure first) in batches of ~10–20

Tag political vendors with `"tags": ["political-data"]`. Rows with `network_members` (shared-template families like CourtRecords.us state clones or the optOutLight sites): submit the main URL, then only members where the owner's listing actually appears (current + past states first); a shared-form failure counts toward one stop-after-3 class, not per member. Tag cloud-sensitive sites with `needs_home_egress: true` when known.

### Dead-site cooldown
When a site fails for a **site-side** reason (redirect loop, Continue no-op, "unexpected error / retry 24h", domain seizure), set `cooldown_until` (ISO) and `status` blocked/skipped. Skip until cooldown expires or monthly recheck. Do not hard-refresh-spam the same break in one session unless the user asks.

For each site:
1. Official free opt-out / privacy / removal page only.
2. Submit minimum fields.
3. Record: submitted / suppressed / needs email confirm / needs CAPTCHA / needs_user_device / blocked / rejected_state_law / not_found / paid-only (skip) / cooldown.
4. Bot inbox confirms: complete when possible without pinging.

## Physical junk mail (cross-link only)
People-search removals are not the same as stopping catalogs or pre-approved credit offers. When the owner has heavy **catalog / prospect / pre-approved** mail, also coach `junk-mail-lane` (OptOutPrescreen, publisher remove, DMAchoice, Valpak, etc.). Marketing-list brokers already in this catalog — **Acxiom, Epsilon, Data Axle, LexisNexis** — help with list-driven mail; keep their free opt-outs here, and point photo-of-mail questions to the junk-mail lane. OptOutPrescreen is tagged `prescreen-mail` in $FORTRESS_HOME/data/broker-catalog.json — DIY for the owner (SSN on the official site, never here).

## Call blocking (coach only)
- Community spam-blocklist apps (Hiya, Truecaller, carrier tools like Call Filter / ActiveArmor / Scam Shield) are **coach-only** via `carrier-and-ai-call-screening` — Fortress never builds its own blocker. Note: some caller-ID apps upload contacts; their own opt-out pages (e.g. Sync.ME, CallApp in the catalog) are free removals.

## DIY cards (human-only)
When the only path is the user's browser or phone, leave a **short** DIY card in chat: site name, exact URL or phone number, 2–4 steps, whose listing (Me vs family). Prefer that over a long thread.

## Outbound call queue
When web forms fail and a free consumer phone line exists, append to `$FORTRESS_HOME/private/call-queue.json` (site, number, reason, phone_id). **Bot calling** works only if this owner's app has outbound calling enabled and the call tool is present this turn; check, never assume. Limits: US user and destination only, **not Washington or Illinois**; max ~85 min; 10 calls/24h (4 to same number); approval card before dial; voice agent discloses AI + recorded line (do not override). Allowed: legitimate consumer/business opt-out and account calls for the owner. Never mass/robocall, sales, debt collection, impersonation, or regulator/emergency lines. Process the queue only with user awareness and an explicit ask to place that call; verify the number from the official site first. Keep DIY cards as fallback when calling is blocked by geo/limits or the owner prefers to dial.

## Batching
Focused batches (10–20). Never claim removal without page/confirm evidence. Update the status Page after each batch.

## Recheck
Re-search political_priority first, then majors. Re-submit only where listings **reappeared**. Default user message: reappearances + action items only (quiet). Full scoreboard only if something material changed or user asked. Separate political-data subsection in the report file.

## International
- Non-US residence → `international-privacy-packs` + `$FORTRESS_HOME/data/international.json`.
- Do not claim US TCPA/DNC abroad.
- Extra foreign number may get that country's registry only with OK.

## Paid DIY (owner-only, optional)
Only when free paths are stuck (CAPTCHA wall, paid-only portal, owner asks). DIY card with vendor URL + recurring-fee warning. **Never** collect SSN/government ID, **never** enter payment details, **never** pay through the bot.

**Honest numbers (say once if they ask "should I just pay DeleteMe?").** Consumer Reports' Aug 2024 test of 13 people-search sites ("Data Defense") found manual opt-outs removed about **70% of profiles within a week**. Paid services averaged **about 35% after four months**. The best were Optery (~68%) and EasyOptOuts (~65%, the cheapest at $19.99/yr), and some scored under 10%. No method got everything, and listings reappear, which is why Fortress rechecks monthly. Paid services do save time. If the owner wants one anyway, it's their choice: DIY card with the vendor link + recurring-fee warning, and they sign up themselves. Fortress keeps tracking free opt-outs alongside. Source: https://advocacy.consumerreports.org/press_release/consumer-reports-evaluation-of-people-search-site-removal-services-finds-that-they-are-largely-ineffective/ (2024 figures; say "in CR's 2024 test", not "today").

## Before any bot outbound call
Load **call-name-and-handoff**: confirm spoken name (account/legal vs preferred; separate from handle); AI + recorded disclosure; no caller-ID promise; Take Over for identity/consent/human-request/IVR loops — not every human; vault PII only.
