# Regulator scam packet (FBI IC3 / FTC)

## Purpose
Filter truly dangerous scams out of ordinary junk, tag them, compile a packet, and **draft** reports for [IC3](https://www.ic3.gov/) and/or [ReportFraud.ftc.gov](https://reportfraud.ftc.gov/). The owner submits (or presses Send on a draft card). Never silent auto-file.

## Why not auto-send weekly
IC3 and FTC forms are sworn consumer complaints. They need the owner's identity, accurate loss amounts, and their attestation. Auto-posting without review risks false reports, duplicates, and filing in the wrong name. Compile + draft is the honest automation; submit only with OK.

## What goes in the queue (dangerous)
Gift card / crypto ATM / wire / cash courier / remote access / recovery scam / government impersonation / family-emergency (possible voice clone) / romance payment pressure / **sextortion or image blackmail** (`category: sextortion` — don't pay, don't reply, screenshot, report IC3 first, FTC if money moved or a paid "helper" was involved; include the `$FORTRESS_HOME/tools/extract-identifiers.py --ic3` paste block; never attach images; no paid removal firms) / off-platform pivot with payment demand — with `elder_high_risk` when relevant.

## What stays out
Ordinary marketing spam, political mail/calls, OTP and password resets, protected senders, anything `Looks safe` / thin `Not sure`.

## Tags (evidence JSON)
`danger`, `elder_high_risk`, `regulator_queue: ic3|ftc|both`, `regulator_status: queued|drafted|submitted|skipped`

Queue files: `$FORTRESS_HOME/private/email/regulator-packets/queue.json` and the phone twin.

## Enough-to-draft checklist
A queue item (or batch) is **ready to draft** when you have:
- Date(s) and channel (call / text / email)
- Sender number, From address, or domain (or “unknown / spoofed”)
- Pattern tag (gift card, crypto, wire, etc.)
- What they asked the person to do (quoted or paraphrased from evidence)
- Money lost: yes / no / unknown — and amount + how paid if yes

Missing only optional extras (screenshots already logged, exact time zone, caregiver note) still counts as enough. Missing loss amount when they said money left, or missing what was asked, is **not** enough — ask for those first.

## Proactive prompt (do not wait for them to remember)
People forget you can open a draft card. **You** ask.

1. On verdict/log → if dangerous pattern, add queue row (date, channel, sender/number, pattern, loss Y/N/unknown, evidence id).
2. **Same turn as tagging** (and again on weekly/monthly runs): send a short note, then a **widget** — never bury the ask in prose alone.
   - If **enough to draft**: prompt like “Ready to draft an IC3 / FTC card from what’s logged?” Options: Draft IC3 · Draft FTC · Draft both · Not yet · Skip this one.
   - If **not enough**: prompt like “This looks reportable — what’s still missing?” Options that match gaps (e.g. Add loss amount · Paste more detail · Skip for now) plus allowCustom when needed.
3. Weekly: if new queued items → one calm message with count + the same widget (enough → draft card; not enough → what’s missing).
4. On yes / Draft …: write `YYYY-MM-packet.md` summary + draft complaint text; open the draft card (or paste in chat) for the owner to submit. Mark `drafted`.
5. After owner says submitted → mark `submitted` + receipt via email-report-receipts / spam evidence.

## After a money loss
Same day: bank (number on card) → IC3 → FTC. Do not wait for the weekly batch. Still use the widget so they see the draft-card path.

## Never
Invent losses, file as the owner without OK, include unrelated people, promise freezes/refunds, or assume they know to ask for a draft card.
