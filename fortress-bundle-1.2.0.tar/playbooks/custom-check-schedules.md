# Custom check schedules

Quiet by default. Each check has its own local-time schedule; do not change the core fraud watch without an explicit ask.

## Defaults (owner local time)
| Check | Default | Notes |
|---|---|---|
| Fraud watch (core weekday) | ~08:00 weekdays | Fixed mornings unless changed |
| Optional fraud red recheck | OFF | 1–2h after core; serious money/account themes only |
| Fortress update check | weekly | Quiet when nothing new |
| Marketplace scout | weekly or monthly as set | Ideas only; never auto-add bots |
| Privacy / OS watcher | weekly | Official pages; only material changes |
| Inbox label scan | weekdays ~08:00 + ~17:00 | Only after connector + explicit Turn on; Gmail initially |
| Monthly spam / opt-out recheck | monthly | Quiet unless action needed |

## Change
1. Ask which check, local time (or day), and time zone if unknown.
2. Confirm one line: “I’ll run **<check>** at **<time> <tz>**.”
3. Get the saved routine; change only that check’s schedule, usual flexible timing, and instruction. Preserve all triggers/controls.
4. Save short `check_schedules` preference.

## Adaptive timing — opt-in only
With owner yes, nudge quiet checks away from busy blocks they named, within same-day window. Record allowed window and named busy times. Don't hold a material fraud alert past the owner's allowed window (checks can still miss things). Fixed core remains unchanged unless owner explicitly changes it. No invented reading or learning of behavior.

## Hard rules
- Keep quiet when nothing material; existing Chatty update exception still applies.
- No new watcher bots, bot-to-bot chains, fresh-chat loops, or automatic new scanning.
- No usage-architecture cuts under this skill.
- Gmail labels each importer requires their own Gmail connector and explicit Turn on; never inherits publisher account.
