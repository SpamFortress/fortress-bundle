# Safe attachment / QR inspect

Pulls link targets out of a suspicious attachment or QR image **without visiting anything**: no browser or PDF viewer, no HTML rendering, no scripts or macros run. PDFs are rasterized locally (first 5 pages, bounded size) only to look for QR codes.

## When
The owner pastes, uploads or forwards a PDF, HTML/SVG, .eml or image (including a QR code) and asks if it's safe.

## How
1. Save the file only under `$FORTRESS_HOME/private/inspect/` (max 15 MB; larger → say it's too big and stop).
2. Run `python3 $FORTRESS_HOME/tools/inspect-attachment.py <file> --json` (**fortress-tools**). It reads text and link annotations, decodes QR codes from images (and from locally rasterized PDF pages), never executes scripts or macros, never renders HTML, and defangs every host. Before parsing it opens the file once without following links, refuses anything that is not a regular file (or that changes while being read), checks the 15 MB size cap and that the file's real signature matches its type (a `.pdf` without a PDF signature, or a non-image named `.png`, is refused). All parsing (images, email, PDF and its QR decode, text) runs in one limited worker job (CPU, memory, file-size, output and total time limits); unnamed or inline images/PDFs inside emails are checked too, and anything skipped is listed as NOT checked. The result's `isolation.network` says `enforced` only when the job ran in an empty network namespace verified on this box. If isolation is unavailable the file is **refused by default**; re-run with `--allow-unisolated-network` only after the owner approves, and then tell them network isolation was unavailable. `isolation.filesystem` is always **not isolated**: say so if asked whether the file was sandboxed. Office files with macros, archives, executables and password-protected files are **not opened**: say "I can't safely look inside this type; don't open it."
   - `status` is `complete`, `incomplete` or `refused`. With `incomplete`, read each note (missing tool, timeout, page/part/pixel/size limit, parser stopped) and tell the owner what was NOT checked. A refused or incomplete file is unknown, never safe.
   - HTML/SVG notes about a password field or script code are **risk cues**, not proof a page is fake; judge with the rest of the evidence.
3. Optional `--enrich` looks up domain age/registrar via public RDAP for the **registered domains** only, never the URL.
4. Report each target as host + registered domain (from `fortress_domain.py`, Public Suffix List) with a plain verdict, using **link-confirmation-coach** rules. If OCR/QR tools are missing or the file was truncated, say what couldn't be checked; never imply it's clean.
5. Delete the saved file after 7 days unless the owner keeps it as evidence.

## Never
Open the file in a viewer or browser, click or fetch an extracted link, or forward the attachment anywhere.
