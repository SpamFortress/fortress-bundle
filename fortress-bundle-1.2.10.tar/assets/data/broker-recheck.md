# Monthly broker / people-search recheck

PII-free search order, result labels, report template, and blocker classes for the existing 1st-of-month recheck. Personal details stay in the Vault. Instance catalogs (`sites.json`, `optout-log.json`) are never shipped in a feed patch.

As of 2026-11-10 PT. Follow this file when present; otherwise follow the Recheck section of `data-broker-opt-outs`.

## Honest limit

This is a monthly check of Fortress's free official catalog, not continuous removal across hundreds of brokers, and not a guarantee of removal. A quiet month means nothing was confirmed — not "nothing relisted." Listings reappear, which is why the recheck exists. Never say "you're removed from the internet." Only "not found today" or "submitted, waiting on confirmation."

Consumer Reports' Aug 2024 "Data Defense" test found manual opt-outs removed about 70% of profiles within a week; paid services averaged about 35% after four months. Source: https://advocacy.consumerreports.org/press_release/consumer-reports-evaluation-of-people-search-site-removal-services-finds-that-they-are-largely-ineffective/

## When it runs

Folded into the existing **Monthly spam fortress recheck** (1st of the month, owner local time). Not a second monthly job. Email's unsubscribe / who-sold / Do Not Sell steps stay as they are.

## Search order (each monthly run)

1. `political_priority`
2. `priority_batch` (also called priority / majors)
3. Every site already submitted, suppressed, or confirmed-removed for this owner (the ones most likely to relist)
4. A rotating slice of the rest of the verified people-search catalog, so the long tail is visited over a few months rather than all rows in one session

**Rotating slice:** take the remaining verified people-search rows (not already covered in 1–3). Skip rows still in cooldown, unpaid/paid-only, or dead. Sort by a stable catalog id. Let `N` be 15 (or fewer if the list is shorter). Let `i = (month_number - 1) * N` (month_number is 1–12 in the owner's local calendar). Take `N` rows starting at `i % len(list)`, wrapping around. Do not invent sites that are not in the catalog.

International residence uses `sites-international.json` and the existing I-4…I-8 branch, unchanged.

## Preflight (mandatory)

Label the run `egress: home` or `egress: cloud`. Do not chew through `needs_home_egress` sites on cloud — park them as "needs you" (try with home routing). Load identity from the Vault. Ask only for missing fields. Never write name, phone, address, DOB, or other personal details into skills, `data/` files, memory, or the public repo.

Honor `cooldown_until` and stop-after-3. Do not hard-refresh-spam the same break in one session.

## Result labels (one per site in scope)

Record exactly one of:

- **found** — a listing that appears to be the owner (or a confirmed household member) is present. Say whether it looks still present, new, or unchanged if you can tell.
- **not found** — a real search completed and no matching listing was shown.
- **blocked** — the page could not be checked (bot-wall, 403, Cloudflare interstitial, CAPTCHA, blank page, connection closed, redirect loop, site-side error).
- **needs you** — a human step is required (CAPTCHA on the owner's device, "which listing is you?", home routing, DIY card, paid/SSN portal).

**A 403, CAPTCHA, interstitial, blank page, or connection-closed is never "not found."** Do not call a light curl probe a completed search.

## Re-submit rules

Re-submit only where a listing **actually reappeared**, and only on a verified free official URL.

**Always ask the owner before any re-submit, even when standing opt-outs are on.** Standing-on still allows first-time free catalog forms without a per-batch ask (existing rule). Monthly reappearances are not covered: prepare the steps and wait for a tap. Paid services, SSN/ID forms, new brokers, and unconfirmed household members still need a draft/ask.

Bot-inbox confirmation codes/links: complete quietly. Codes on the owner's device: ping immediately. Never pay. Never request SSN, government ID, or passwords.

## Report template (owner-facing)

Quiet if nothing reappeared and nothing is parked. Log the run on the status Page Notes either way.

If something reappeared or needs a human, one short wrap, for example:

> **Monthly opt-out recheck — [N] still clear, [M] came back, [K] need you:**
> 1. [Site] — your listing is back → [link] · **Re-submit · Skip · DIY**
> 2. [Site] — CAPTCHA on your device → [link] · **Done · Skip**
> 3. [Site] — blocked from this network; try with home routing or a DIY card.

Use the existing approval-batch widgets: Done · Skip · DIY card · Retry later · Try with home routing. Skip is shame-free. Max ~6 items, rest under "More".

Never a claim of complete removal. "Still clear" means "not found today" on a completed search.

## Blocker classes (do not invent a bypass)

Describe classes, never an owner's private records:

- **Device CAPTCHA / reCAPTCHA walls:** official consumer form exists, but the web form is blocked by CAPTCHA quota or a human-only widget. Coach a DIY card on the owner's own phone or a home-routed browser after cooldown. Example class: Spy Dialer's consumer page (https://www.spydialer.com/consumers/) is a known recaptcha-wall case. Do not invent a bypass. A bounced support email is not a new path.
- **Cloud / bot walls:** Cloudflare interstitials, "you have been blocked," 403/CAPTCHA on cloud egress, connection-closed, blank pages. Park; offer home routing when the class looks like `cloud_ip` / bot-wall and the owner has not already declined it.
- **Human CAPTCHA / device:** `needs_user_device` rows (including some people-search families). Hand to the owner.
- **Site-side breakage:** redirect loops, unexpected submit errors, domain seizures, dead domains now serving unrelated content. Honor `cooldown_until` and stop-after-3.
- **State-law portals:** keep the catalog row; mark `rejected_state_law` for this owner only, at submit time.
- **Paid-only or SSN portals:** DIY card, never filled by the bot.
