# iCloud "Anyone with the link" shares: what changes in iOS 27.3

Checked against Apple Support on 2026-11-10. Steps are Apple's own wording. You change the settings yourself; Fortress only walks you through them.

## What changes
Apple says: "Starting in version 27.3 or later of iOS, iPadOS, macOS, and visionOS, items shared using Anyone with the Link will be checked by Apple for harmful content."

Apple also says that when you share an item with Anyone with the Link, "the item is no longer end-to-end encrypted, even if the owner or participants have turned on Advanced Data Protection."

## Who this affects
- People on iOS, iPadOS, macOS or visionOS 27.3 or later who share iCloud items with "Anyone with the link". Apple's examples are "a photo in iCloud Photos or a file in iCloud Drive."
- Apple's note covers only Anyone with the Link shares. It doesn't describe "People you choose" shares or Send a Copy.
- Apple adds: "Not all features are available in all countries or regions."

## Advanced Data Protection doesn't cover public links
Apple's iCloud data security overview says: "iWork collaboration, the Shared Albums feature in Photos, and sharing content with 'anyone with the link,' do not support Advanced Data Protection." Turning on ADP won't make a public link private.

## Find and tighten your shares (iPhone)

### iCloud Drive files and folders (Files app)
1. Go to the Files app and tap Shared to see shared items.
2. Touch and hold a file or folder, then tap Manage Shared File or Manage Shared Folder.
3. To keep sharing with specific people only, tap Sharing Options and change access to "People you choose". Apple says: "the original link no longer works for anyone, and only people who receive a new invitation from you can open the folder or file." Re-invite anyone who still needs it with Add Participant.
4. To end sharing completely, tap Stop Sharing.
Keep in mind:
- Apple says if you later share the item again with "Anyone with the link", "the original link works" again.
- Apple also says: "If you collaborate on a folder, all items added to that folder by you or other participants are automatically shared."

### Notes
1. Open the shared note (or folder) in Notes.
2. Tap the sharing button at the top, then Manage Shared Note (or Manage Shared Folder).
3. Tap Sharing Options and change who can access to "People you choose", or choose Stop Sharing. Apple says Stop Sharing deletes the shared note or folder "from the devices of the other participants."

### Photos: iCloud Links
Photos shared with an iCloud Link also count. Apple's iCloud guide explains how to stop sharing them: https://support.apple.com/guide/icloud/

## Sharing privately from now on
When you share from Files or Notes, tap "People you choose can edit" and pick "People you choose". Or use Send a Copy, which sends the file itself instead of a link.

## What stopping a link can't do
It can't pull back copies people already downloaded or saved.

## Sources (Apple)
- Anyone with the Link (published Nov 3, 2026): https://support.apple.com/en-us/149168
- iCloud data security overview: https://support.apple.com/en-us/102651
- Share files and folders in iCloud Drive on iPhone: https://support.apple.com/guide/iphone/iph17f9f92a6/ios
- Share notes and collaborate on iPhone: https://support.apple.com/guide/iphone/iphe4d04f674/ios
- iCloud User Guide: https://support.apple.com/guide/icloud/
