# Free built-in call and text screening paths

Official URLs, menu labels, availability, and free vs paid tiers for coaching only. Fortress guides these settings; the phone and carrier do the blocking. Fortress itself does not block calls or texts and cannot remotely change phone or carrier settings.

Personal details stay in the Vault. This file has no PII.

As of 2026-11-10 PT (America/Los_Angeles). If a vendor's live official page or the owner's screen differs, believe those, not an older label here. Subject to change.

Widget on every setup step: **Done · Can't find it · Skip for now.** Pictures only after Can't find it.

US screening checkup: only after a major OS update (or when the owner asks). Do not ping monthly if setup is already done. International I-8 (phone built-ins re-verify) is unchanged.

## Honest opening line

"I can't block calls for you from here. These switches on your phone and carrier can."

Free OS and carrier tools still miss some spam. Paid apps can still win on aggressive pre-ring blocking. Say so if the owner is still flooded after the free setup. Mention paid specialty apps (RoboKiller, Nomorobo, Truecaller Premium, Hiya) once in that case; never imply Fortress replaces them, and never pay through the bot.

## iPhone — calls

Sources (fetched 2026-11-10 PT):

- [Manage unknown callers on iPhone](https://support.apple.com/en-us/111106) (published 2026-09-14)
- [Screen and block calls on iPhone](https://support.apple.com/guide/iphone/screen-and-block-calls-iphe4b3f7823/ios)
- [iOS and iPadOS 27 Feature Availability](https://www.apple.com/ios/feature-availability/) — section **Phone: Call Screening**

Path: **Settings → Apps → Phone**.

Under **Screen Unknown Callers**, choose one:

- **Never** — unsaved numbers ring normally.
- **Ask Reason for Calling** — the caller is asked why they are calling before the iPhone rings. **Recommended default coach.**
- **Silence** — unsaved numbers are silenced and sent to voicemail; they appear in Recents.

Under **Call Filtering**: turn on **Unknown Callers** (missed calls/voicemails from unknown numbers move to the Unknown Callers list — this is *different* from Screen Unknown Callers) and the **spam filter** (carrier spam/fraud list, when offered).

FaceTime: Settings → Apps → FaceTime → **Silence Unknown Callers**, if present.

Apple-documented limits: standard calling and data rates may apply; on software earlier than iOS 17, Live Voicemail must be on to use call screening; **calls are not screened while roaming**; calling emergency services turns screening off for 24 hours. Add important numbers to Contacts so they always ring.

Do **not** coach the obsolete single toggle "Settings → Phone → Silence Unknown Callers" as the only path. Apple Support 111106 (updated 2026-09-14) still uses Settings → Apps → Phone → Screen Unknown Callers. Believe the owner's screen if a label differs.

### Call Screening availability (as of 2026-11-10 PT, subject to change)

From Apple's **Phone: Call Screening** list:

- Cantonese (China mainland, Hong Kong, Macao)
- English (Australia, Canada, India, Ireland, New Zealand, Puerto Rico, Singapore, South Africa, United Kingdom, United States)
- French (Canada, France)
- German (Germany)
- **Italian (Italy)**
- Japanese (Japan)
- Korean (South Korea)
- Mandarin Chinese (China mainland, Macao, Taiwan)
- Portuguese (Brazil)
- Spanish (Mexico, Puerto Rico, Spain, United States)

Countries not listed: coach **Silence** + carrier tools, not Ask Reason for Calling. Re-check Apple's live page if a country is in doubt.

## iPhone — texts (iOS 26 and later)

Sources (125068 fetched 2026-11-10 PT; 124159 cited from the 1.2.2 plan):

- [View conversations from unknown senders](https://support.apple.com/en-us/125068) (published 2026-04-08)
- [View and recover spam messages](https://support.apple.com/en-us/124159) (published 2026-09-14)
- [Screen and filter text messages](https://support.apple.com/guide/iphone/screen-and-filter-texts-iph203ab0be4/ios)

**Screen Unknown Senders** is **off by default** in iOS 26. If Filter Unknown Senders was on in iOS 18, it stays on after upgrade.

Turn it on: Messages → Filters → **Manage Filtering** → Unknown Senders → **Screen Unknown Senders**. Or Settings → Apps → Messages → Unknown Senders.

Unknown texts go to the Unknown Senders filter without (most) alerts. Mark as Known only for people they recognize. Replying does **not** automatically mark a sender as known.

**Filter Spam** is **on by default** in iOS 26 and later. Messages → Filters → Manage Filtering, or Settings → Apps → Messages. Spam sits in a Spam folder with no notification. Recover with **Not Spam**.

**Allow Notifications** (Settings → Apps → Messages → Unknown Senders): Time Sensitive, Personal, Transactions, Promotions. Time Sensitive (codes, alerts, urgent requests) is on by default. Allowed messages appear in the main list for **8 hours**, then return to Unknown Senders. In most countries unknown senders notify by default; **the US, Brazil, and India** can choose which types notify.

Honest catch: "Time Sensitive" is decided by the phone. A scam dressed as urgent can still alert. Keep Time Sensitive on if they get sign-in codes by text.

Fortress cannot remotely block or delete SMS/iMessage. Coach filters, Report Junk, 7726, and on-device block of one number. Never say "I'll auto-block that for you."

## Pixel / Phone by Google — calls

Sources (Call Screen page fetched 2026-11-10 PT):

- [Screen your calls](https://support.google.com/phoneapp/answer/9118387?hl=en)
- [Caller ID & spam protection](https://support.google.com/phoneapp/answer/3459196?hl=en)
- [Scam Detection](https://support.google.com/phoneapp/answer/15654065?hl=en)

**Caller ID and spam** is on by default. Path: Phone → More → Settings → **Caller ID and spam** → **See caller ID & spam**. Optional **Filter spam calls** (no missed-call/voicemail notifications; calls stay in history). Devices with automatic Call Screen have no separate "Filter spam calls" toggle; spam autoblock is a Call Screen protection level (Basic on Pixel 6+).

**Call Screen** path: Phone → More → Settings → **Spam and Call Screen** or **Call Screen** → Call Screen → protection level (Maximum / Medium / Basic). Pixel 7+: **Automatically screen calls**, with categories Spam, Possibly faked numbers, First-time callers. Call Assist asks who is calling and why; spam is hung up; otherwise the phone rings and shows the response.

Automatic Call Screen is available on Pixel phones in **Australia, Canada, Ireland, UK, US**. Manual Call Screen on Pixel is available in those countries plus France, Germany, Italy, Japan, Spain, and (Pixel 10/11 family only) India. Manual Call Screen is also available in the US and Canada on **selected** Android devices (Google does not publish a model list). A SIM from a supported country is required. Automatic screening does not run while roaming, and may not run on Bluetooth/headphones depending on model. It does not work with third-party call-recording apps. Contacts are not screened. If Call Screen is not in Phone settings, use Caller ID & spam + Filter spam calls.

**Scam Detection** (in-call alerts, on-device, off by default, audible beep so the other party knows): Phone → More → Settings → **Scam Detection**. Availability (from Google's help, as recorded in the 1.2.2 plan): Pixel 6+ in the US; Pixel 9+ in AU, CA, FR, DE, IN, IE, IT, JP, MX, SG, ES, UK. Pixel 9a and 10a: US only. Not 100% accurate. Google documents that audio/transcripts for this feature stay on-device and are not sent to Google.

## Google Messages — texts

Source: [Spam and scam protection](https://support.google.com/messages/answer/9327903?hl=en)

Path: Messages → profile → **Messages settings** → **Protection & Safety** → **Spam and scam protection**.

Choose **Enhanced**, **Standard**, or **No protection**. Standard is the default. Enhanced uses Private AI Compute for harder scams. Prefer Standard or Enhanced, not No protection.

## Samsung Galaxy — Smart Call

Source (fetched 2026-11-10 PT): [Block spam calls with Smart Call](https://www.samsung.com/us/support/answer/ANS10003438/)

Path: Phone → More options (⋮) → **Settings** → **Caller ID and spam protection** → turn on → agree to terms → **Block spam and scam calls** → **Block all spam and scam calls** or **Only block high-risk scam calls**.

Also: Settings → **Block numbers**, including **Block calls from unknown numbers**.

**Smart Call may not be available on all carriers or models.** Use on-device labels if they differ.

The same Samsung US page describes **AI Scam detection** as available on Galaxy phones running **Android 16 with One UI 8.5 or higher**, analyzing calls in real time and alerting with a tone or vibration. It does not list a country matrix. Coach: "if you see Scam detection in Phone settings, here is how to turn it on." Do not promise it on a given model, and do not coach a One UI 9-only / JP-CA-IN-only path.

## Verizon Call Filter — free tier

Source (fetched 2026-11-10 PT): [Call Filter FAQs](https://www.verizon.com/support/call-filter-faqs/)

Free on standard monthly or prepaid plans with a compatible device (Android 10+ / iOS 16.6+). Management has moved to the **Verizon Protect** app (or My Verizon if the app isn't compatible).

**Free includes:** Spam Detection, Spam Filter (high-risk spam forwarded to voicemail by default), spam and blocked-call log, Allow numbers, Report spam. Free-tier spam labels are all "Potential Spam."

**Call Filter Plus is paid** ($3.99/month per line, or $10.99/month multi-line, as listed on the FAQs page this day; prices can change): Caller ID, spam lookup, personal block list, block by category (telemarketer, nonprofit, political, survey). Coach the free tier. Mention Plus only if the owner asks or still gets heavy robocalls after free + OS tools.

iPhone: **Silence Junk Callers** (iOS 14+) is documented as auto-enabled; suspected spam/fraud is silenced and may show "Maybe: Junk." Wanted calls can be silenced by mistake; say so.

Neighborhood Filter (from the same FAQs page): Call Filter (free) can block up to 5 area-code/prefix patterns; Call Filter Plus can block up to 10 and can block whole area codes (whole-area-code block is documented as Android app only). May block legitimate calls.

**Unverified:** an exact cap on the free-tier allow list ("up to 5 allowed numbers") was not clearly restated on the FAQs page fetched this day. Do not coach that number as fact.

## T-Mobile Scam Shield — free tier

Sources (official support fetched 2026-11-10 PT):

- [Help with scams & spam](https://www.t-mobile.com/support/plans-features/help-with-scams-spam-and-fraud)
- [Scam Shield benefits](https://www.t-mobile.com/benefits/scam-shield) (marketing FAQ; see conflict below)

**Free, network-level (coach from official support):** Scam ID ("Scam Likely" and other labels such as Telemarketing, Political, Potential Spam), **Scam Block** (blocks Scam Likely before the call rings), neighborhood-spoofing protection, spam-text reporting/blocking guidance, and related network tools. Turn on Scam Block in the T-Life app, My T-Mobile, or by dialing **#662#**.

T-Life app management of Scam Shield is for **postpaid**. Prepaid: free Scam Block and Caller ID still exist via dial codes (**#662#** and **#436#**); T-Life does not support Scam Shield on prepaid.

**Premium (paid), per official support:** category blocking, block calls and texts from specific numbers (network-stored list), reverse number lookup, voicemail-to-text. The report flow's "Add this number to blocked list" is marked Premium users only.

**Conflict — do not paper over:** the marketing FAQ at t-mobile.com/benefits/scam-shield has listed "personal number blocking" among both free and Premium features. Official support treats blocking specific numbers as Premium. **Coach from the support page** until T-Mobile clarifies.

Mint and other T-Mobile-network MVNOs: use whatever spam tools that MVNO actually offers; many have little beyond the network. Do not assume full T-Life Scam Shield.

## AT&T ActiveArmor — free tier

Sources (KM1147710 fetched 2026-11-10 PT):

- [Use the ActiveArmor app](https://www.att.com/support/article/wireless/KM1147710/) (updated 2026-06-15)
- [Get help with ActiveArmor](https://www.att.com/support/article/wireless/KM1185527/) (updated 2026-06-15)
- [What is ActiveArmor](https://www.att.com/wireless/what-is-activearmor-security/)

Free with AT&T wireless plans (compatible smartphone). Download the ActiveArmor app.

**Fraud calls are automatically set to Block.** Keep network call protection on.

**Spam call blocking is not on automatically.** Turn it on in the **Calls** tab. Options: allow, block, or send spam to voicemail; Custom categories include Telemarketers, Political, Account services, Nonprofits, Surveys, and Other. Personal block list and "Always allow contacts" are documented on the Calls tab.

Voicemail must be active if they choose send-to-voicemail; otherwise calls from numbers not in Contacts may not go through.

**ActiveArmor advanced is paid.** The official "what is" marketing page listed **$7/month** on 2026-11-10 PT (earlier notes had a lower figure; prices can change). That page names Public Wi-Fi Protection, Identity Monitoring, Safe browsing, and related identity services as paid. Coach the free app and the Calls-tab spam toggle. Do not upsell advanced.

Coach only what the June 2026 support articles clearly put on the Calls tab or describe as free. Leave older marketing-list extras unverified.

## Other US carriers and MVNOs

Open the carrier app and search spam / scam / call filter. Not verified per-MVNO in this file.

## Unverified (do not coach as fact)

- T-Mobile "personal number blocking" as a free feature (marketing FAQ conflicts with official support).
- Samsung AI Scam detection country list beyond "Android 16 + One UI 8.5 or higher" on the US support page.
- Which non-Pixel Android devices get manual Call Screen (Google says "selected Android devices" in the US and Canada, not a model list).
- Verizon free-tier allow-list cap, unless a later official FAQ restates it.
- AT&T extras that appear only on older marketing lists, not on the June 2026 support articles.
- International carrier rows beyond what `phone-setup-first` already coaches; I-8 re-verifies official pages when that branch runs.
